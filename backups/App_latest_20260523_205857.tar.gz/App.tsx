import React, { useState, useEffect, useRef, useCallback, useMemo } from "react";
import { useAuth } from "./lib/auth-context";
import { Footer } from "./components/Footer";
import {
  synthesize,
  type SynthesizeIntent,
  type Pillar as SynthPillar,
  type Horizon as SynthHorizon,
  type PriorContext as SynthPriorContext,
  type PriorContextItem as SynthPriorContextItem,
} from "./lib/synthesize";
const KEYS = {
  map:    "to_map",
  done:   "to_done",
  step:   "to_step",
  voice:  "to_voice",
  intake: "to_intake",
  phase:  "to_phase",
  mapofme_origin: "to_mapofme_origin",
};
const ALLOWED_SERVER_KEYS = new Set([
  "map", "voice", "mapofme_origin", "intake", "phase", "step", "done",
]);
let serverDataCache: Record<string, any> | null = null;
let isAuthed = false;
function localKeyToServerKey(k: string): string | null {
  if (!k.startsWith("to_")) return null;
  const s = k.slice(3);
  return ALLOWED_SERVER_KEYS.has(s) ? s : null;
}
function saveData(k: string, v: any) {
  try { localStorage.setItem(k, JSON.stringify(v)); } catch {}
  const sk = localKeyToServerKey(k);
  if (sk && serverDataCache) serverDataCache[sk] = v;
  if (sk && isAuthed) {
    fetch(`/api/userdata/${sk}`, {
      method: "PUT",
      credentials: "include",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ value: v }),
    }).catch(() => {});
  }
}
function loadDataSync(k: string): any {
  const sk = localKeyToServerKey(k);
  if (sk && serverDataCache && sk in serverDataCache) return serverDataCache[sk];
  try {
    const r = localStorage.getItem(k);
    if (!r) return null;
    try { return JSON.parse(r); } catch { return r; }
  } catch { return null; }
}
function loadData(k: string): Promise<any> { return Promise.resolve(loadDataSync(k)); }
function _setServerAuthState(authed: boolean, cache: Record<string, any> | null) {
  isAuthed = authed;
  serverDataCache = cache;
}
const VOICES = {
  own:         { id:"own",         label:"Your Voice",             short:"Your Voice",  icon:"◎", color:"#a78bfa", muted:"rgba(167,139,250,0.1)",  border:"rgba(167,139,250,0.3)" },
  coach:       { id:"coach",       label:"Katherine · Coach",      short:"Coach",       icon:"◈", color:"#c9a84c", muted:"rgba(79,203,242,0.1)",   border:"rgba(79,203,242,0.3)"  },
  supportive:  { id:"supportive",  label:"Katherine · Supportive", short:"Supportive",  icon:"◇", color:"#34d399", muted:"rgba(52,211,153,0.1)",   border:"rgba(52,211,153,0.3)"  },
  challenging: { id:"challenging", label:"Katherine · Challenging",short:"Challenging", icon:"◆", color:"#f59e0b", muted:"rgba(245,158,11,0.1)",   border:"rgba(245,158,11,0.3)"  },
  advice:      { id:"advice",      label:"Katherine · Advice",     short:"Advice",      icon:"◉", color:"#c9a84c", muted:"rgba(232,149,109,0.1)",  border:"rgba(232,149,109,0.3)" },
  truth:       { id:"truth",       label:"Uncomfortable Truth",    short:"Hard Truth",  icon:"⬡", color:"#ef4444", muted:"rgba(239,68,68,0.1)",    border:"rgba(239,68,68,0.3)"   },
};
const VOICE_DESC = {
  own:"Reflects your own words back. No advice -- just your truth made visible.",
  coach:"Open questions that create insight. You do the thinking.",
  supportive:"In your corner. Sees your strength. Keeps you moving.",
  challenging:"Names the contradiction. Asks what you've been avoiding.",
  advice:"25 years of experience. Direct recommendation. Here's what I'd do.",
  truth:"What you need to hear. Not what you want to.",
};
const VOICE_REASON = {
  own:"You're ready to hear yourself more clearly.",
  coach:"You're searching for clarity -- the right questions will get you there faster than any answers.",
  supportive:"You need someone genuinely in your corner right now.",
  challenging:"You already know what you need to do. You need someone who won't let you off the hook.",
  advice:"You're ready to move. Direct guidance will serve you better than more questions.",
  truth:"You're asking for honesty. That takes courage.",
};
function detectVoice(q3) {
  const t = (q3||"").toLowerCase();
  if (/don.t know|scared|lost|not sure|overwhelm|finally|help|afraid|anxious|support/.test(t)) return "supportive";
  if (/clarity|direction|figure|understand|confused|what|why|which|clear/.test(t)) return "coach";
  if (/keep|same|always|stop|tired|excuse|again|know what|stuck|frustrated|push/.test(t)) return "challenging";
  if (/ready|now|do it|build|start|move|time|urgent|action/.test(t)) return "advice";
  if (/truth|honest|real|hard|uncomfortable|brutal/.test(t)) return "truth";
  return "coach";
}
function buildFullContext(name, intake, mapData) {
  const lines = [];
  lines.push(`Client name: ${name}`);
  if (intake?.q1) lines.push(`What brought them here: "${intake.q1}"`);
  if (intake?.q2) lines.push(`Who they are becoming: "${intake.q2}"`);
  if (intake?.q3) lines.push(`What they most need: "${intake.q3}"`);
  const layers = (mapData?.purpose_layers || []).filter(l => (l||"").trim());
  if (layers.length > 0) {
    lines.push(`\nPurpose peeling layers (${layers.length} deep):`);
    layers.forEach((l, i) => lines.push(`  Layer ${i + 1}: "${l}"`));
  }
  if (mapData?.purpose_draft) lines.push(`Purpose draft (AI): "${mapData.purpose_draft}"`);
  if (mapData?.purpose_final) lines.push(`Purpose final (their words): "${mapData.purpose_final}"`);
  if (mapData?.bag_year) lines.push(`BAG target year: ${mapData.bag_year}`);
  const areas = (mapData?.life_areas || []);
  if (areas.length > 0) {
    lines.push(`\nLife priorities (ranked):`);
    areas.forEach((a, i) => {
      lines.push(`  ${i+1}. ${a.label}`);
      if (a.see) lines.push(`     See: "${a.see}"`);
      if (a.hear) lines.push(`     Hear: "${a.hear}"`);
      if (a.feel) lines.push(`     Feel: "${a.feel}"`);
    });
  }
  if (mapData?.time_summary) lines.push(`Time summary: "${mapData.time_summary}"`);
  const goals = (mapData?.life_areas || []).filter(a => a.goal);
  if (goals.length > 0) {
    lines.push(`\nLife goals:`);
    goals.forEach((a, i) => lines.push(`  ${i+1}. ${a.label}: "${a.goal}"`));
  }
  if (mapData?.bag_retirement) lines.push(`Wealth - Retirement: "${mapData.bag_retirement}"`);
  if (mapData?.bag_assets) lines.push(`Wealth - Assets: "${mapData.bag_assets}"`);
  if (mapData?.bag_cashflow) lines.push(`Wealth - Cash flow: "${mapData.bag_cashflow}"`);
  if (mapData?.bag_other) lines.push(`Wealth - Other: "${mapData.bag_other}"`);
  if (mapData?.wealth_summary) lines.push(`Wealth summary: "${mapData.wealth_summary}"`);
  if (mapData?.growth_summary) lines.push(`Growth summary: "${mapData.growth_summary}"`);
  if (mapData?.bag_growth) lines.push(`Growth: "${mapData.bag_growth}"`);
  const animals = (mapData?.animals || []).filter(a => a.name);
  if (animals.length > 0) {
    lines.push(`\nIdentity animals:`);
    animals.forEach(a => { const t = [a.adj1, a.adj2, a.name].filter(Boolean).join(" "); lines.push(`  "${t}" -- alignment ${a.alignment}/10`); });
  }
  const chipLabels = (mapData?.identity_chips || []).map(c => c.label);
  const qualitiesStr = chipLabels.length > 0 ? chipLabels.join(", ") : (mapData?.identity_adjectives || "");
  if (qualitiesStr) lines.push(`Qualities: "${qualitiesStr}"`);
  if (mapData?.capabilities_note) lines.push(`Superpowers note: "${mapData.capabilities_note}"`);
  const values = (mapData?.values || []).filter(v => v.name);
  if (values.length > 0) {
    lines.push(`\nValues (top ${values.length}):`);
    values.forEach((v, i) => {
      lines.push(`  ${i + 1}. ${v.name}${v.irk ? ` -- revealed by: "${v.irk}"` : ""}${v.behaviors ? ` -- behaviors: "${v.behaviors}"` : ""}`);
    });
  }
  if (mapData?.values_irks) lines.push(`Values irks dump: "${mapData.values_irks}"`);
  if (mapData?.behaviors_note) lines.push(`Behaviors note: "${mapData.behaviors_note}"`);
  if (mapData?.align_direction !== undefined || mapData?.align_superpowers !== undefined || mapData?.align_behaviors !== undefined) {
    lines.push(`\nAlignment ratings:`);
    if (mapData.align_direction   !== undefined) lines.push(`  Direction: ${mapData.align_direction}/10`);
    if (mapData.align_superpowers !== undefined) lines.push(`  Superpowers: ${mapData.align_superpowers}/10`);
    if (mapData.align_behaviors   !== undefined) lines.push(`  Behaviors: ${mapData.align_behaviors}/10`);
  }
  const sessions = (mapData?.purpose_sessions || []);
  if (sessions.length > 0) {
    lines.push(`\nPurpose peeling sessions (${sessions.length} total):`);
    sessions.forEach((s, i) => lines.push(`  Session ${i + 1} (${s.date || ""}): draft = "${s.draft || ""}", verbs = ${(s.verbs || []).join(", ")}`));
  }
  return lines.join("\n");
}
function buildPrompt(voiceId, name, intake, mapData) {
  const ctx = buildFullContext(name, intake, mapData);
  const voiceInstructions = {
    own:`Mirror ${name}'s OWN words back. Start "You said..." or "What I'm hearing...". Draw directly from what they have written -- quote their specific words back. One question from their own words. No advice. Under 120 words.`,
    coach:`Katherine Breuss coaching ${name}. You have read everything they have written -- reference specific details from their map. ONE open-ended question per response. Acknowledge in one sentence using their actual words, then ask. End on the question. Under 100 words.`,
    supportive:`Katherine Breuss fully in ${name}'s corner. You can see everything they have put in -- reference it specifically. Name something SPECIFIC you see in their work. Celebrate real progress. Make them feel seen, not managed. One forward question. Under 120 words.`,
    challenging:`Katherine Breuss not letting ${name} off the hook -- with warmth. You have read everything. Name a specific gap between what they have written and what they are not saying. One observation using their words, one harder question. Under 100 words.`,
    advice:`Katherine Breuss giving direct advice to ${name}. You have read their full map. "Here's what I'd do..." -- grounded in their specific purpose, animals, values. Clear recommendation, why, hard part, one first step. Under 150 words.`,
    truth:`Katherine Breuss: ${name} asked for uncomfortable truth. You have read everything they wrote. Find the specific avoidance or contradiction in their actual inputs. Name it plainly. Why it matters. What changes if faced. Under 120 words.`,
  };
  return `${voiceInstructions[voiceId]}\n\nEverything ${name} has entered so far:\n${ctx}`;
}
async function callAI(voiceId, name, intake, mapData, message, history=[]) {
  const res = await fetch("/api/claude", {
    method:"POST", headers:{"Content-Type":"application/json"},
    body: JSON.stringify({ model:"claude-sonnet-4-20250514", max_tokens:400,
      system: buildPrompt(voiceId, name, intake, mapData),
      messages: [...history.slice(-6), {role:"user", content:message}] }),
  });
  const d = await res.json();
  return d.content?.map(b=>b.text||"").join("")||"Something went wrong.";
}
async function callStructured(prompt) {
  const res = await fetch("/api/claude", {
    method:"POST", headers:{"Content-Type":"application/json"},
    body: JSON.stringify({ model:"claude-sonnet-4-20250514", max_tokens:800,
      messages:[{role:"user", content:prompt}] }),
  });
  const d = await res.json();
  const text = d.content?.map(b=>b.text||"").join("")||"{}";
  try { return JSON.parse(text.replace(/```json|```/g,"").trim()); } catch { return {}; }
}
const CSS = `
@import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;1,300;1,400&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500&display=swap');
*{box-sizing:border-box;margin:0;padding:0;}
:root{--bg:#0d1b2e;--bg2:#112240;--bg3:#1a2f4a;--bg4:#1e3554;--text:#f4f1eb;--text2:#d4cfc5;--text3:#9a9590;--text4:#5c6b7a;--border:#1e3554;--border2:#254060;--warm:#c9a84c;--accent:#c9a84c;--serif:'Cormorant Garamond',serif;--sans:'DM Sans',sans-serif;}
body{background:var(--bg);color:var(--text);font-family:var(--sans);}
@keyframes fadeUp{from{opacity:0;transform:translateY(18px)}to{opacity:1;transform:translateY(0)}}
@keyframes fadeIn{from{opacity:0}to{opacity:1}}
@keyframes pulse{0%,100%{opacity:.4}50%{opacity:1}}
.fade-up{animation:fadeUp .55s cubic-bezier(.22,1,.36,1) both}
.fade-in{animation:fadeIn .35s ease both}
.to-field{background:var(--bg4);border:1px solid var(--border2);border-radius:10px;color:var(--warm);font-family:var(--sans);font-size:13px;line-height:1.7;padding:13px 15px;width:100%;outline:none;transition:border-color .2s;resize:none;}
.to-field:focus{border-color:var(--warm);box-shadow:0 0 0 3px rgba(201,168,76,0.12);}
.to-field::placeholder{color:var(--text3);opacity:.7;}
input[type=range]{width:100%;cursor:pointer;height:5px;appearance:none;-webkit-appearance:none;border-radius:4px;outline:none;background:var(--bg4);border:1px solid var(--border2);}
input[type=range]::-webkit-slider-thumb{-webkit-appearance:none;width:20px;height:20px;border-radius:50%;background:var(--text);border:3px solid var(--bg2);cursor:pointer;box-shadow:0 1px 4px rgba(0,0,0,.4);}
input[type=range]::-moz-range-track{height:5px;border-radius:4px;background:var(--bg4);border:1px solid var(--border2);}
input[type=range]::-moz-range-thumb{width:20px;height:20px;border-radius:50%;background:var(--text);border:3px solid var(--bg2);cursor:pointer;}
.btn{background:var(--warm);border:none;border-radius:60px;color:#0d1b2e;cursor:pointer;font-family:var(--sans);font-size:13px;font-weight:500;letter-spacing:1.5px;padding:13px 30px;text-transform:uppercase;transition:all .22s;display:inline-flex;align-items:center;gap:8px;}
.btn:hover{filter:brightness(1.08);transform:translateY(-1px);}
.btn:disabled{background:var(--bg4);color:var(--text4);cursor:not-allowed;transform:none;filter:none;}
.btn-g{background:none;border:1px solid var(--border2);border-radius:60px;color:var(--text2);cursor:pointer;font-family:var(--sans);font-size:13px;padding:10px 22px;transition:all .2s;}
.btn-g:hover{border-color:var(--text4);color:var(--text2);}
.lbl{color:var(--accent);font-size:12px;font-weight:700;letter-spacing:2px;text-transform:uppercase;font-family:var(--sans);}
.dot-l span{display:inline-block;width:5px;height:5px;border-radius:50%;background:currentColor;animation:pulse 1.2s ease-in-out infinite;margin:0 2px;}
.dot-l span:nth-child(2){animation-delay:.2s}.dot-l span:nth-child(3){animation-delay:.4s}
.vid-block{background:var(--bg2);border:1px solid var(--border2);border-radius:12px;padding:17px 20px;display:flex;align-items:flex-start;gap:13px;margin-bottom:22px;}
.mirror-grid{display:grid;grid-template-columns:1fr 38px 1fr;gap:0;margin-bottom:26px;}
.mirror-side{background:var(--bg3);border:1px solid var(--border2);border-radius:12px;padding:20px;}
.mirror-div{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:5px;}
.mirror-line{flex:1;width:1px;background:var(--border);opacity:.4;}
.sidebar-btn{display:flex;align-items:center;gap:8px;width:100%;padding:8px 10px;border-radius:8px;cursor:pointer;margin-bottom:2px;text-align:left;font-family:var(--sans);border:1px solid transparent;background:transparent;transition:all .18s;}
.sidebar-btn.active{background:rgba(201,168,76,.1);border-color:rgba(201,168,76,.3);}
.to-field.summary-field::placeholder{font-family:var(--sans);font-style:normal;font-size:13px;color:var(--text3);opacity:.6;}
.to-field.summary-field{font-family:var(--serif);font-style:italic;font-size:15px;line-height:1.7;}
.chip{display:inline-flex;align-items:center;gap:5px;padding:4px 12px;border-radius:20px;font-family:var(--sans);font-size:12px;transition:all .15s;user-select:none;}
.chip-gold{background:rgba(201,168,76,.12);border:1px solid rgba(201,168,76,.35);color:var(--warm);}
.chip-green{background:rgba(52,211,153,.1);border:1px solid rgba(52,211,153,.3);color:#34d399;}
.chip-red{background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.25);color:#ef4444;cursor:pointer;}
.chip-red:hover{background:rgba(239,68,68,.18);}
.chip-drag{cursor:grab;}.chip-drag:active{cursor:grabbing;}
.drop-zone{transition:border-color .2s,background .2s;}.drop-zone.over{background:rgba(201,168,76,.04);}
`;
// ─── DIRECTION: Life Areas ────────────────────────────────────────────────────
const LIFE_AREA_PRESETS = [
  { id:"family",    label:"Family",       icon:"👨‍👩‍👧‍👦", hint:"Where will your kids be? What does your relationship with your partner look like? What do you do together?" },
  { id:"love",      label:"Love",         icon:"💛", hint:"Your romantic life -- partner, intimacy, the relationship you choose to build. What does love look like at your best?" },
  { id:"business",  label:"Business",     icon:"🏔️",  hint:"What are you building? Who are you leading? How much are you working? What is your role?" },
  { id:"health",    label:"Health",       icon:"⚡",  hint:"How do you feel physically? What are you doing regularly? What have you let go of?" },
  { id:"friends",   label:"Friends",      icon:"🤝",  hint:"Who is still in your life? How often do you connect? What do you do together?" },
  { id:"spiritual", label:"Spirituality", icon:"🌿",  hint:"How do you connect to something bigger? What practices ground you?" },
  { id:"community", label:"Community",    icon:"🌍",  hint:"What are you contributing to? Who do you serve beyond your immediate circle?" },
  { id:"adventure", label:"Adventure",    icon:"🧭",  hint:"Where have you been? What have you experienced? What risks have you taken?" },
];
// ----- DIRECTION: Wealth Areas (W.1) -----
const WEALTH_AREA_PRESETS = [
  { id:"retirement",     label:"Retirement",     icon:"🏖️", hint:"When, how, what does life feel like when you stop working by necessity?" },
  { id:"assets",         label:"Assets",         icon:"🏛️", hint:"Property, investments, business equity -- what have you built and what does it generate?" },
  { id:"cashflow",       label:"Cashflow",       icon:"💸", hint:"Annual income or cash flow. What level creates genuine freedom?" },
  { id:"investments",    label:"Investments",    icon:"📈", hint:"Portfolio, markets, compounding. What is your investment picture?" },
  { id:"passive-income", label:"Passive Income", icon:"💰", hint:"Income that doesn't require your direct time. What streams are running?" },
  { id:"real-estate",    label:"Real Estate",    icon:"🏡", hint:"Properties you own, how they work for you, what they enable." },
];
// W.1a-ext: Time presets (9 cards, prototype parity)
const TIME_AREA_PRESETS = [
  { id:"family",       label:"Family",       icon:"👨‍👩‍👧", hint:"How does your time shape your family life? What does a typical week look like?" },
  { id:"love",         label:"Love",         icon:"💛",     hint:"Your intimate relationship -- how do you show up, how do you spend time together?" },
  { id:"business",     label:"Business",     icon:"🏔️",     hint:"Your work, craft, or venture -- what are you building, what's your rhythm?" },
  { id:"health",       label:"Health",       icon:"⚡",     hint:"Movement, recovery, energy -- what are you doing regularly to stay vital?" },
  { id:"friends",      label:"Friends",      icon:"🤝",     hint:"Friendships, community -- who's in your inner circle and how do you stay close?" },
  { id:"spirituality", label:"Spirituality", icon:"🌿",     hint:"Your inner practice -- how do you connect with something beyond yourself?" },
  { id:"community",    label:"Community",    icon:"🌍",     hint:"Where you give back, contribute, or belong to something bigger." },
  { id:"adventure",    label:"Adventure",    icon:"🧭",     hint:"Travel, exploration, the edges of your comfort zone." },
  { id:"wellbeing",    label:"Wellbeing",    icon:"✦",     hint:"Mental space, rest, the quality of your inner life day-to-day." },
];
// W.1c: Tier ranking constants (prototype parity)
const TIERS = [
  { id: "non-neg", label: "Non-negotiable", color: "#ef4444" },
  { id: "imp",     label: "Important",     color: "#f59e0b" },
  { id: "nth",     label: "Nice to have",  color: "#94a3b8" },
];
const NON_NEG_CAP = 3;
const segColor = (seg) =>
  seg === "Time" ? "var(--warm)" :
  seg === "Wealth" ? "#34d399" :
  "#a78bfa"; // Growth
function WealthChipSelector({ selected, onToggle, onAddCustom }) {
  const [customInput, setCustomInput] = useState("");
  const [showCustom, setShowCustom] = useState(false);
  const selectedIds = selected.map(a => a.id);
  const addCustom = () => {
    const label = customInput.trim();
    if (!label) return;
    const id = "custom_w_" + label.toLowerCase().replace(/\s+/g, "_");
    onAddCustom({ id, label, icon:"✨", hint:"Describe your vision for " + label + " in 10-15 years.", text:"", goal:"" });
    setCustomInput("");
    setShowCustom(false);
  };
  return (
    <div style={{ marginBottom:16 }}>
      <div style={{ fontSize:12, color:"var(--text3)", marginBottom:10, lineHeight:1.5 }}>
        Pick the wealth areas that matter in your 10-15 year financial life. No limit -- add as many as you need.
      </div>
      <div style={{ display:"flex", flexWrap:"wrap", gap:7, marginBottom:10 }}>
        {WEALTH_AREA_PRESETS.map(area => {
          const isSelected = selectedIds.includes(area.id);
          return (
            <button key={area.id} onClick={() => onToggle(area)}
              style={{
                display:"flex", alignItems:"center", gap:6,
                padding:"7px 12px", borderRadius:20,
                border: isSelected ? "1px solid #34d399" : "1px solid var(--border2)",
                background: isSelected ? "rgba(52,211,153,0.12)" : "var(--bg2)",
                color: isSelected ? "#34d399" : "var(--text3)",
                fontSize:12, fontWeight:500, fontFamily:"var(--sans)",
                cursor:"pointer", transition:"all 0.15s"
              }}>
              <span style={{ fontSize:13 }}>{area.icon}</span>
              <span>{area.label}</span>
            </button>
          );
        })}
        {selected.filter(a => !WEALTH_AREA_PRESETS.some(p => p.id === a.id)).map(area => (
          <button key={area.id} onClick={() => onToggle(area)}
            style={{
              display:"flex", alignItems:"center", gap:6,
              padding:"7px 12px", borderRadius:20,
              border:"1px solid #34d399", background:"rgba(52,211,153,0.12)",
              color:"#34d399", fontSize:12, fontWeight:500, fontFamily:"var(--sans)",
              cursor:"pointer"
            }}>
            <span style={{ fontSize:13 }}>{area.icon}</span>
            <span>{area.label}</span>
          </button>
        ))}
        {!showCustom && (
          <button onClick={() => setShowCustom(true)}
            style={{
              padding:"7px 12px", borderRadius:20,
              border:"1px dashed var(--border2)", background:"transparent",
              color:"var(--text4)", fontSize:12, fontFamily:"var(--sans)",
              cursor:"pointer"
            }}>
            + Add your own
          </button>
        )}
      </div>
      {showCustom && (
        <div style={{ display:"flex", gap:6, marginBottom:10 }}>
          <input type="text" value={customInput} onChange={e => setCustomInput(e.target.value)}
            onKeyDown={e => e.key === "Enter" && addCustom()}
            placeholder="e.g. Crypto, Collectibles, Trust..."
            style={{
              flex:1, padding:"7px 12px", borderRadius:6,
              border:"1px solid var(--border2)", background:"var(--bg2)",
              color:"var(--text)", fontSize:12, fontFamily:"var(--sans)", outline:"none"
            }} />
          <button onClick={addCustom}
            style={{
              padding:"7px 14px", borderRadius:6,
              background:"#34d399", color:"#0a0a0a", border:"none",
              fontSize:12, fontWeight:600, cursor:"pointer"
            }}>Add</button>
          <button onClick={() => { setShowCustom(false); setCustomInput(""); }}
            style={{
              padding:"7px 10px", borderRadius:6,
              background:"transparent", color:"var(--text4)",
              border:"1px solid var(--border2)", fontSize:12, cursor:"pointer"
            }}>Cancel</button>
        </div>
      )}
    </div>
  );
}
function WealthItemCard({ area, onRemove, onChange }) {
  return (
    <div style={{ marginBottom:13, padding:"12px 14px", background:"var(--bg2)", border:"1px solid var(--border2)", borderRadius:9 }}>
      <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:7 }}>
        <div style={{ display:"flex", alignItems:"center", gap:7 }}>
          <span style={{ fontSize:14 }}>{area.icon}</span>
          <label style={{ fontSize:12, fontWeight:600, color:"#34d399", fontFamily:"var(--sans)" }}>{area.label}</label>
        </div>
        <button onClick={onRemove}
          style={{ background:"transparent", border:"none", color:"var(--text4)", fontSize:11, cursor:"pointer", fontFamily:"var(--sans)" }}>
          remove
        </button>
      </div>
      {area.hint && (
        <div style={{ fontSize:11, color:"var(--text4)", marginBottom:6, fontStyle:"italic" }}>{area.hint}</div>
      )}
      <textarea rows={3}
        value={area.text || ""}
        onChange={e => onChange("text", e.target.value)}
        placeholder={"Describe your vision for " + area.label + " in 10-15 years..."}
        className="to-field"
        style={{ fontSize:13, marginBottom:6 }} />
      <button
        onClick={() => onChange("goal", area.text || "")}
        disabled={!(area.text && area.text.trim())}
        style={{
          padding:"5px 11px", borderRadius:5,
          background: (area.text && area.text.trim()) ? "rgba(52,211,153,0.15)" : "var(--bg3)",
          border:"1px solid rgba(52,211,153,0.3)",
          color:"#34d399", fontSize:11, fontWeight:500, fontFamily:"var(--sans)",
          cursor: (area.text && area.text.trim()) ? "pointer" : "not-allowed",
          opacity: (area.text && area.text.trim()) ? 1 : 0.5
        }}>
        Summarise into a goal →
      </button>
      {area.goal && (
        <div style={{ marginTop:8, padding:"8px 10px", background:"rgba(52,211,153,0.06)", borderLeft:"2px solid #34d399", borderRadius:3 }}>
          <div style={{ fontSize:10, fontWeight:600, color:"#34d399", textTransform:"uppercase", letterSpacing:0.5, marginBottom:3 }}>Goal</div>
          <div style={{ fontSize:12, fontFamily:"var(--serif)", fontStyle:"italic", color:"var(--text)", lineHeight:1.5 }}>{area.goal}</div>
        </div>
      )}
    </div>
  );
}
// ─── W.1a: Prototype components (structural parity with a1_direction_prototype_v2.jsx) ────────
// Using existing CSS vars for now; W.1b will migrate to prototype's exact design tokens.
function CollapsibleSegment_v2({ icon, title, color, confirmed, confirmedSummary, children }) {
  // Auto-rule: open unless confirmed. User can override via click.
  // On confirm transition (false → true), auto-collapse to satisfy v3.1 principle #2.
  const [userState, setUserState] = useState(null); // null | true | false
  const prevConfirmedRef = useRef(confirmed);
  useEffect(() => {
    if (!prevConfirmedRef.current && confirmed) {
      // Just became confirmed -- force closed regardless of prior user override.
      setUserState(false);
    }
    prevConfirmedRef.current = confirmed;
  }, [confirmed]);
  const autoOpen = !confirmed;
  const isOpen = userState === null ? autoOpen : userState;
  const toggle = () => setUserState(!isOpen);
  return (
    <div style={{
      marginTop:20, marginBottom:14,
      background: `${color}10`,
      borderRadius:8, borderLeft: `4px solid ${color}`,
      overflow:"hidden",
      transition:"all .2s ease",
    }}>
      <div onClick={toggle} style={{
        padding:"12px 16px",
        display:"flex", alignItems:"center", justifyContent:"space-between",
        cursor:"pointer", gap:10,
      }}>
        <div style={{ display:"flex", alignItems:"center", gap:10, flex:1, minWidth:0 }}>
          <div style={{
            fontFamily:"var(--serif)", fontSize:20, fontWeight:500,
            color:"var(--text)", flexShrink:0,
          }}>{icon} {title}</div>
          <div style={{
            fontSize:10, letterSpacing:1.2, textTransform:"uppercase",
            fontWeight:600, padding:"2px 8px", borderRadius:10,
            background: confirmed ? "rgba(52,211,153,.15)" : `${color}15`,
            color: confirmed ? "#34d399" : color,
            border: `1px solid ${confirmed ? "#34d399" : color}40`,
            flexShrink:0,
          }}>{confirmed ? "✓ Confirmed" : "In progress"}</div>
        </div>
        <div style={{
          fontSize:14, color:"var(--text3)",
          transform: isOpen ? "rotate(0deg)" : "rotate(-90deg)",
          transition:"transform .2s ease",
          flexShrink:0,
        }}>▾</div>
      </div>
      {!isOpen && confirmedSummary && (
        <div style={{ padding:"0 16px 14px" }}>
          <div style={{
            padding:"10px 14px",
            background:"rgba(0,0,0,.2)",
            borderRadius:6,
            fontFamily:"var(--serif)", fontSize:15, fontStyle:"italic",
            color:"var(--text)", lineHeight:1.5,
          }}>
            "{confirmedSummary}"
          </div>
          <div style={{
            fontSize:11, color:"var(--text4)", fontStyle:"italic",
            marginTop:6, textAlign:"center",
          }}>Click above to expand and edit.</div>
        </div>
      )}
      {isOpen && (
        <div style={{ padding:"0 16px 16px" }}>
          {children}
        </div>
      )}
    </div>
  );
}
function SubLabel_v2({ children }) {
  return (
    <div style={{ fontSize:14, color:"var(--text3)", fontStyle:"italic", marginBottom:10, marginTop:14 }}>
      {children}
    </div>
  );
}
function CardPicker_v2({ cards, picked, onToggle, onAddCustom, color }) {
  const [customText, setCustomText] = useState("");
  const [addingCustom, setAddingCustom] = useState(false);
  const commitCustom = () => {
    const label = customText.trim();
    if (label && onAddCustom) {
      onAddCustom(label);
    }
    setAddingCustom(false);
    setCustomText("");
  };
  return (
    <div style={{ display:"flex", gap:8, flexWrap:"wrap", marginBottom:16 }}>
      {cards.map(c => {
        const isPicked = picked.includes(c.id);
        return (
          <div key={c.id} onClick={() => onToggle(c.id)} style={{
            padding:"8px 14px", borderRadius:18,
            background: isPicked ? `${color}20` : "rgba(255,255,255,.03)",
            color: isPicked ? color : "var(--text2)",
            border: `1px solid ${isPicked ? color : "var(--border2)"}`,
            fontSize:13, fontWeight:500, cursor:"pointer",
            display:"inline-flex", alignItems:"center", gap:6,
            transition:"all .15s",
          }}>
            {c.icon && <span>{c.icon}</span>}
            {c.label}
            {isPicked && (
              <span style={{
                fontSize:10, background:color, color:"var(--bg)",
                borderRadius:8, padding:"1px 6px", fontWeight:700,
                marginLeft:2,
              }}>✓</span>
            )}
          </div>
        );
      })}
      {addingCustom ? (
        <input autoFocus value={customText}
          onChange={e => setCustomText(e.target.value)}
          onBlur={commitCustom}
          onKeyDown={e => {
            if (e.key === "Enter") { e.preventDefault(); commitCustom(); }
            else if (e.key === "Escape") { setAddingCustom(false); setCustomText(""); }
          }}
          placeholder="Type and press Enter..."
          style={{
            padding:"8px 14px", borderRadius:18,
            background:"transparent", color:"var(--text)",
            border:`1px dashed ${color}`, fontSize:13,
            fontFamily:"var(--sans)", outline:"none", minWidth:180,
          }} />
      ) : (
        <div onClick={() => setAddingCustom(true)} style={{
          padding:"8px 14px", borderRadius:18,
          background:"transparent", color:"var(--text3)",
          border:"1px dashed var(--border2)",
          fontSize:13, cursor:"pointer",
        }}>+ Add your own</div>
      )}
    </div>
  );
}
// Stage 4: shared error display + retry button used by all Summarise components.
// Uniform visual treatment across PriorityItemCard_v2, SimpleItemCard_v2, SummaryGenerator_v2
// so users get a consistent failure experience regardless of which button they hit.
function SynthesizeError({ message, onRetry, color = "#ef4444" }) {
  return (
    <div role="alert" style={{
      marginTop:8, padding:"8px 12px",
      background:"rgba(239,68,68,.08)",
      border:"1px solid rgba(239,68,68,.3)",
      borderLeft:`3px solid ${color}`,
      borderRadius:6,
      display:"flex", alignItems:"center", gap:10, flexWrap:"wrap",
    }}>
      <span style={{ fontSize:13 }}>⚠️</span>
      <div style={{ flex:1, minWidth:140, fontSize:11, color:"var(--text2)", lineHeight:1.5, fontFamily:"var(--sans)" }}>
        <div style={{ fontSize:9, fontWeight:700, letterSpacing:1.2, textTransform:"uppercase", color:"#ef4444", marginBottom:2 }}>Synthesis failed</div>
        <div>{message || "Something went wrong reaching the AI."}</div>
      </div>
      <button onClick={onRetry} style={{
        padding:"4px 10px", borderRadius:12,
        background:"transparent", color:"var(--warm)",
        border:"1px solid var(--warm)",
        cursor:"pointer", fontSize:11, fontWeight:600,
        fontFamily:"var(--sans)",
      }}>↻ Try again</button>
    </div>
  );
}
function PriorityItemCard_v2({ icon, label, color, text, goal, promptText, onTextChange, onGoalChange,
                                voiceId, name, pillar, horizon, horizonYearLabel }) {
  const [summarising, setSummarising] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const runSynth = async () => {
    if (!(text || "").trim()) return;
    setSummarising(true);
    setErrorMsg("");
    try {
      // Item-goal intent: minimal priorContext per Q2 clarification (just voice/name/focus).
      const synthesized = await synthesize({
        intent: "item-goal",
        voiceId: voiceId || "coach",
        name: name || "you",
        focus: {
          label,
          sourceText: text || "",
          pillar: (pillar as SynthPillar) || undefined,
          horizon: (horizon as SynthHorizon) || undefined,
          horizonYearLabel,
        },
      });
      onGoalChange(synthesized);
    } catch (e: any) {
      setErrorMsg(e?.message || "Synthesis failed.");
    }
    setSummarising(false);
  };
  return (
    <div style={{
      marginBottom:14, padding:"16px 18px",
      background:"rgba(255,255,255,.03)",
      border:"1px solid var(--border2)", borderLeft:`3px solid ${color}`,
      borderRadius:8,
    }}>
      <div style={{
        display:"flex", alignItems:"center", gap:8, marginBottom:10,
      }}>
        {icon && <span style={{ fontSize:18 }}>{icon}</span>}
        <div style={{
          fontFamily:"var(--serif)", fontSize:19, fontWeight:500, color:"var(--text)",
        }}>{label}</div>
      </div>
      <div style={{
        fontSize:14, color:"var(--text3)", fontStyle:"italic", marginBottom:8, lineHeight:1.5,
      }}>{promptText}</div>
      <textarea value={text || ""} onChange={e => onTextChange(e.target.value)}
        placeholder="Write freely here..." rows={3}
        style={{
          width:"100%", background:"rgba(0,0,0,.2)",
          border:"1px solid var(--border2)", borderRadius:4,
          padding:"10px 12px", color:"var(--text)",
          fontFamily:"var(--serif)", fontSize:16, lineHeight:1.6,
          resize:"vertical", outline:"none",
        }} />
      <div style={{
        display:"flex", gap:10, marginTop:10, flexWrap:"wrap", alignItems:"center",
      }}>
        <button onClick={runSynth} disabled={!(text || "").trim() || summarising} style={{
          padding:"6px 14px", borderRadius:14,
          background:"transparent",
          color: (text || "").trim() ? "var(--warm)" : "var(--text4)",
          border:`1px solid ${(text || "").trim() ? "var(--warm)" : "var(--border2)"}`,
          cursor: (text || "").trim() ? "pointer" : "default",
          fontSize:12, fontWeight:600,
        }}>{summarising ? "✨ Synthesizing..." : (goal ? "↺ Regenerate goal" : "✨ Summarise into a goal")}</button>
        {goal && !errorMsg && (
          <div style={{
            flex:1, minWidth:200,
            padding:"6px 10px", borderRadius:6,
            background:`${color}15`, color:"var(--text)",
            fontSize:14, fontStyle:"italic",
          }}>
            <span style={{
              fontSize:9, letterSpacing:1.2, textTransform:"uppercase",
              color, fontWeight:600, marginRight:8,
            }}>GOAL</span>
            {goal}
          </div>
        )}
      </div>
      {errorMsg && <SynthesizeError message={errorMsg} onRetry={runSynth} color={color} />}
    </div>
  );
}
function SHFField_v2({ label, placeholder, value, onChange }) {
  return (
    <div style={{ marginBottom:10 }}>
      <div style={{ fontSize:11, color:"var(--warm)", fontWeight:600, marginBottom:4 }}>{label}</div>
      <textarea value={value || ""} onChange={e => onChange(e.target.value)}
        placeholder={placeholder} rows={2}
        style={{
          width:"100%", background:"rgba(0,0,0,.2)",
          border:"1px solid var(--border2)", borderRadius:4,
          padding:"8px 10px", color:"var(--text)",
          fontFamily:"var(--serif)", fontSize:14, lineHeight:1.5,
          resize:"vertical", outline:"none",
        }} />
    </div>
  );
}
function SeeHearFeelBlock_v2({ title, subtitle, color, values, onChange }) {
  return (
    <div style={{
      marginTop:20, marginBottom:14,
      padding:"18px 20px",
      background:`linear-gradient(135deg, ${color}10, rgba(255,255,255,.02))`,
      border:`1px solid ${color}40`, borderRadius:10,
    }}>
      <div style={{
        fontSize:11, letterSpacing:2, textTransform:"uppercase",
        color, fontWeight:700, marginBottom:4,
      }}>{title}</div>
      <div style={{
        fontSize:14, color:"var(--text3)", fontStyle:"italic", marginBottom:14,
      }}>{subtitle}</div>
      <SHFField_v2 label="👁 I will see..."
        placeholder="The scenes, people, spaces..."
        value={values.see}
        onChange={v => onChange("see", v)} />
      <SHFField_v2 label="👂 I will hear..."
        placeholder="The words, sounds, conversations..."
        value={values.hear}
        onChange={v => onChange("hear", v)} />
      <SHFField_v2 label="❤ I will feel..."
        placeholder="The emotions, energy, sense of self..."
        value={values.feel}
        onChange={v => onChange("feel", v)} />
    </div>
  );
}
function SummaryGenerator_v2({ color, label, sourceText, onConfirm, existingConfirmed, bottomTitle,
                                intent, voiceId, name, priorContext, pillar, horizon, horizonYearLabel }: any) {
  // State machine: idle | generating | editing | error
  const [state, setState] = useState("idle");
  const [draft, setDraft] = useState("");
  const [errorMsg, setErrorMsg] = useState("");
  const generate = async () => {
    if (!sourceText.trim()) return;
    setState("generating");
    setErrorMsg("");
    try {
      const synthesized = await synthesize({
        intent: (intent as SynthesizeIntent) || "pillar-overall",
        voiceId: voiceId || "coach",
        name: name || "you",
        focus: {
          label,
          sourceText,
          pillar: (pillar as SynthPillar) || undefined,
          horizon: (horizon as SynthHorizon) || undefined,
          horizonYearLabel,
        },
        priorContext: (priorContext as SynthPriorContext) || {},
      });
      setDraft(synthesized);
      setState("editing");
    } catch (e: any) {
      setErrorMsg(e?.message || "Synthesis failed.");
      setState("error");
    }
  };
  const confirm = () => {
    if (!draft.trim()) return;
    onConfirm(draft.trim());
    setState("idle");
  };
  const startOver = () => {
    setState("idle");
    setDraft("");
    setErrorMsg("");
  };
  // Confirmed state with regenerate option
  if (existingConfirmed && state === "idle") {
    return (
      <div style={{
        marginTop:18, marginBottom:24,
        padding:"16px 18px",
        background:"linear-gradient(135deg, rgba(52,211,153,.08), rgba(201,168,76,.04))",
        border:"1px solid #34d399", borderRadius:10,
        position:"relative",
      }}>
        <div style={{
          position:"absolute", top:-10, right:14,
          background:"#34d399", color:"var(--bg)",
          fontSize:10, letterSpacing:1.5, textTransform:"uppercase",
          fontWeight:700, padding:"2px 10px", borderRadius:10,
        }}>✓ Confirmed summary</div>
        <div style={{
          fontSize:10, letterSpacing:2, textTransform:"uppercase",
          color:"#34d399", fontWeight:600, marginBottom:8,
        }}>{bottomTitle || `${label} summary`}</div>
        <div style={{
          fontFamily:"var(--serif)", fontSize:17, lineHeight:1.5,
          color:"var(--text)", fontStyle:"italic", marginBottom:10,
        }}>"{existingConfirmed}"</div>
        <button onClick={generate} style={{
          padding:"5px 12px", borderRadius:12,
          background:"transparent", color:"var(--text3)",
          border:"1px solid var(--border2)", cursor:"pointer",
          fontSize:11,
        }}>↻ Regenerate from my writing</button>
      </div>
    );
  }
  return (
    <div style={{
      marginTop:18, marginBottom:24,
      padding:"14px 16px",
      background:"rgba(0,0,0,.25)",
      border:`1px dashed ${color}`, borderRadius:8,
    }}>
      <div style={{
        fontSize:11, letterSpacing:1.5, textTransform:"uppercase",
        color, fontWeight:600, marginBottom:6,
      }}>{bottomTitle || `Ready to summarise ${label}?`}</div>
      <div style={{
        fontSize:13, color:"var(--text2)", lineHeight:1.5, marginBottom:12, fontStyle:"italic",
      }}>
        You've done the writing. Let me stitch it into one sentence you can edit, then confirm.
      </div>
      {state === "idle" && (
        <button onClick={generate} disabled={!sourceText.trim()} style={{
          padding:"8px 16px", borderRadius:16,
          background: sourceText.trim() ? color : "transparent",
          color: sourceText.trim() ? "var(--bg)" : "var(--text4)",
          border:`1px solid ${sourceText.trim() ? color : "var(--border2)"}`,
          cursor: sourceText.trim() ? "pointer" : "default",
          fontSize:13, fontWeight:600,
        }}>✨ Summarise into one sentence</button>
      )}
      {state === "generating" && (
        <div style={{ padding:"8px 14px", fontSize:14, color:"var(--text3)", fontStyle:"italic" }}>
          ✨ Reading your writing and stitching...
        </div>
      )}
      {state === "editing" && (
        <div>
          <div style={{
            fontSize:11, letterSpacing:1.5, textTransform:"uppercase",
            color:"var(--text3)", fontWeight:600, marginBottom:6,
          }}>Draft — edit freely, then confirm</div>
          <textarea value={draft} onChange={e => setDraft(e.target.value)}
            rows={3}
            style={{
              width:"100%", background:"rgba(0,0,0,.3)",
              border:`1px solid ${color}60`, borderRadius:4,
              padding:"10px 12px", color:"var(--text)",
              fontFamily:"var(--serif)", fontSize:16, lineHeight:1.5,
              resize:"vertical", outline:"none", marginBottom:10,
            }} />
          <div style={{ display:"flex", gap:10, flexWrap:"wrap" }}>
            <button onClick={confirm} disabled={!draft.trim()} style={{
              padding:"8px 18px", borderRadius:16,
              background: draft.trim() ? color : "transparent",
              color: draft.trim() ? "var(--bg)" : "var(--text4)",
              border:`1px solid ${draft.trim() ? color : "var(--border2)"}`,
              cursor: draft.trim() ? "pointer" : "default",
              fontSize:13, fontWeight:700,
            }}>✓ Confirm</button>
            <button onClick={generate} style={{
              padding:"8px 14px", borderRadius:16,
              background:"transparent", color:"var(--text2)",
              border:"1px solid var(--border2)", cursor:"pointer",
              fontSize:12,
            }}>↻ Try again</button>
            <button onClick={startOver} style={{
              padding:"8px 14px", borderRadius:16,
              background:"transparent", color:"var(--text3)",
              border:"none", cursor:"pointer", fontSize:12,
            }}>Cancel</button>
          </div>
        </div>
      )}
      {state === "error" && (
        <SynthesizeError message={errorMsg} onRetry={generate} color={color} />
      )}
    </div>
  );
}
// W.1c: TierRankingSection_v2 — port from prototype (a1_direction_prototype_v2.jsx line 1435)
// Non-negotiable capped at NON_NEG_CAP (3). No ordering within tiers — tier IS the ranking signal.
function TierRankingSection_v2({ items, tiers, setTiers, horizonLabel, confirmed, onConfirmed }) {
  const [openPill, setOpenPill] = useState(null);
  const [capWarning, setCapWarning] = useState(false);
  const [userState, setUserState] = useState(null);
  const byTier = useMemo(() => {
    const g = { "non-neg": [], imp: [], nth: [] };
    items.forEach(i => {
      const t = tiers[i.id] || "nth";
      g[t].push(i);
    });
    return g;
  }, [items, tiers]);
  const nonNegCount = byTier["non-neg"].length;
  const nonNegFull = nonNegCount >= NON_NEG_CAP;
  const hasAnyRanking = nonNegCount > 0 || byTier.imp.length > 0;
  // Auto-rule: open unless confirmed. Auto-collapse on confirm transition (v3.1 principle #2).
  const prevConfirmedRef = useRef(confirmed);
  useEffect(() => {
    if (!prevConfirmedRef.current && confirmed) {
      setUserState(false);
    }
    prevConfirmedRef.current = confirmed;
  }, [confirmed]);
  const autoOpen = !confirmed;
  const isOpen = userState === null ? autoOpen : userState;
  const toggle = () => setUserState(!isOpen);
  const setTier = (itemId, tierId) => {
    const currentTier = tiers[itemId] || "nth";
    if (tierId === "non-neg" && currentTier !== "non-neg" && nonNegFull) {
      setCapWarning(true);
      setTimeout(() => setCapWarning(false), 2500);
      setOpenPill(null);
      return;
    }
    setTiers({ ...tiers, [itemId]: tierId });
    setOpenPill(null);
  };
  return (
    <div style={{
      marginTop: 36, marginBottom: 14,
      background: "rgba(201,168,76,.08)",
      borderRadius: 8, borderLeft: "4px solid var(--warm)",
      overflow: "hidden",
      transition: "all .2s ease",
    }}>
      {/* Collapsible header */}
      <div onClick={toggle} style={{
        padding: "12px 16px",
        display: "flex", alignItems: "center", justifyContent: "space-between",
        cursor: "pointer", gap: 10,
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, flex: 1, minWidth: 0 }}>
          <div style={{
            fontFamily: "var(--serif)", fontSize: 22, fontWeight: 500, color: "var(--text)",
            flexShrink: 0,
          }}>📊 Rank your priorities</div>
          <div style={{
            fontSize: 10, letterSpacing: 1.2, textTransform: "uppercase",
            fontWeight: 600, padding: "2px 8px", borderRadius: 10,
            background: confirmed ? "rgba(52,211,153,.15)" : "rgba(201,168,76,.15)",
            color: confirmed ? "#34d399" : "var(--warm)",
            border: `1px solid ${confirmed ? "#34d399" : "var(--warm)"}40`,
            flexShrink: 0,
          }}>{confirmed ? "✓ Confirmed" : hasAnyRanking ? "In progress" : "Not started"}</div>
        </div>
        <div style={{
          fontSize: 18, color: "var(--text3)",
          transform: isOpen ? "rotate(0deg)" : "rotate(-90deg)",
          transition: "transform .2s ease",
          flexShrink: 0,
        }}>▾</div>
      </div>
      {/* Collapsed: compact ranking summary */}
      {!isOpen && (
        <div style={{ padding: "0 16px 14px" }}>
          <div style={{
            padding: "10px 14px",
            background: "rgba(0,0,0,.2)",
            borderRadius: 6,
          }}>
            <div style={{
              fontSize: 10, letterSpacing: 1.5, textTransform: "uppercase",
              color: "#ef4444", fontWeight: 700, marginBottom: 8,
            }}>Non-negotiable · {nonNegCount}/{NON_NEG_CAP}</div>
            {byTier["non-neg"].length === 0 ? (
              <div style={{ fontSize: 12, color: "var(--text4)", fontStyle: "italic" }}>
                — none yet —
              </div>
            ) : (
              <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                {byTier["non-neg"].map(item => (
                  <div key={item.id} style={{
                    display: "inline-flex", alignItems: "center", gap: 6,
                    padding: "4px 10px", borderRadius: 12,
                    background: "rgba(0,0,0,.3)",
                    borderLeft: `3px solid ${segColor(item.segment)}`,
                    fontSize: 12, color: "var(--text)",
                  }}>
                    {item.icon && <span>{item.icon}</span>}
                    {item.label}
                  </div>
                ))}
              </div>
            )}
            <div style={{
              marginTop: 10, fontSize: 11, color: "var(--text3)",
              display: "flex", gap: 14, flexWrap: "wrap",
            }}>
              <span>{byTier.imp.length} Important</span>
              <span>{byTier.nth.length} Nice to have</span>
            </div>
          </div>
          <div style={{
            fontSize: 11, color: "var(--text3)", fontStyle: "italic",
            marginTop: 6, textAlign: "center",
          }}>Click above to expand and edit.</div>
        </div>
      )}
      {/* Open: full ranking UI */}
      {isOpen && (
        <div style={{ padding: "0 16px 16px" }}>
          {items.length === 0 && (
            <div style={{
              padding: "14px 16px",
              background: "rgba(255,255,255,.03)",
              border: "1px solid var(--border2)", borderRadius: 10,
              fontSize: 13, color: "var(--text3)", fontStyle: "italic", lineHeight: 1.6,
            }}>
              Complete your Time, Wealth, and/or Growth segments above first -- then come back here to rank them.
            </div>
          )}
          {items.length > 0 && (<>
            <div style={{
              padding: "18px 20px",
              background: "rgba(255,255,255,.03)",
              border: "1px solid var(--border2)", borderRadius: 10,
            }}>
              <div style={{ fontSize: 12, color: "var(--text3)", fontStyle: "italic", marginBottom: 4 }}>
                What matters MOST for {horizonLabel}? Tap each to assign a tier.
              </div>
              <div style={{
                marginTop: 10, padding: "8px 12px",
                background: nonNegFull ? "rgba(248,113,113,.08)" : "rgba(201,168,76,.05)",
                borderLeft: `2px solid ${nonNegFull ? "#f59e0b" : "var(--warm)"}`,
                borderRadius: 4,
                fontSize: 12, color: "var(--text2)", lineHeight: 1.5,
              }}>
                <strong style={{ color: "var(--warm)" }}>Rule:</strong> Non-negotiable is capped at {NON_NEG_CAP} items -- only three
                things can truly be non-negotiable for this horizon. Currently: <strong style={{
                  color: nonNegFull ? "#f59e0b" : "#34d399",
                }}>{nonNegCount}/{NON_NEG_CAP}</strong>.
                {nonNegFull && " To pick a different Non-negotiable, move one of your current three to Important first."}
              </div>
              {capWarning && (
                <div style={{
                  marginTop: 10, padding: "10px 14px",
                  background: "rgba(248,113,113,.15)",
                  border: "1px solid #ef4444", borderRadius: 6,
                  fontSize: 13, color: "var(--text)", lineHeight: 1.5,
                }}>
                  You've already got 3 Non-negotiables. Move one to Important first, then try again.
                </div>
              )}
              <div style={{ marginTop: 12 }}>
                {items.map(item => {
                  const currentTier = tiers[item.id] || "nth";
                  const tierObj = TIERS.find(t => t.id === currentTier);
                  const isPillOpen = openPill === item.id;
                  return (
                    <div key={item.id} style={{
                      display: "flex", alignItems: "center", gap: 10,
                      padding: "8px 10px 8px 12px", marginBottom: 4,
                      background: "rgba(0,0,0,.2)",
                      borderLeft: `3px solid ${segColor(item.segment)}`,
                      borderRadius: 4, flexWrap: "nowrap",
                    }}>
                      <div style={{
                        fontSize: 9, letterSpacing: 1.2, textTransform: "uppercase",
                        color: segColor(item.segment), fontWeight: 600,
                        width: 60, flexShrink: 0,
                      }}>{item.segment}</div>
                      <div style={{ flex: 1, fontSize: 13, color: "var(--text)", minWidth: 0 }}>
                        {item.icon && <span style={{ marginRight: 6 }}>{item.icon}</span>}
                        {item.label}
                      </div>
                      <div style={{ position: "relative", flexShrink: 0 }}>
                        <button onClick={() => setOpenPill(isPillOpen ? null : item.id)} style={{
                          padding: "5px 12px", borderRadius: 12,
                          background: `${tierObj.color}20`, color: tierObj.color,
                          border: `1px solid ${tierObj.color}60`,
                          fontSize: 12, fontWeight: 600, cursor: "pointer",
                          fontFamily: "var(--sans)", display: "flex", alignItems: "center", gap: 6,
                          minHeight: 28,
                        }}>{tierObj.label}<span style={{ fontSize: 9 }}>▾</span></button>
                        {isPillOpen && (
                          <div style={{
                            position: "absolute", top: "calc(100% + 4px)", right: 0,
                            background: "var(--bg2)", border: "1px solid var(--border)", borderRadius: 6,
                            minWidth: 160, zIndex: 20, boxShadow: "0 8px 20px rgba(0,0,0,.4)",
                          }}>
                            {TIERS.map(t => {
                              const isDisabled = t.id === "non-neg"
                                && currentTier !== "non-neg"
                                && nonNegFull;
                              return (
                                <div key={t.id}
                                  onClick={() => !isDisabled && setTier(item.id, t.id)}
                                  title={isDisabled ? `${NON_NEG_CAP}/${NON_NEG_CAP} Non-negotiables used` : undefined}
                                  style={{
                                    padding: "8px 12px", fontSize: 12,
                                    color: isDisabled ? "var(--text4)" : t.color,
                                    cursor: isDisabled ? "not-allowed" : "pointer",
                                    borderBottom: "1px solid var(--border2)",
                                    background: currentTier === t.id ? "rgba(255,255,255,.05)" : "transparent",
                                    opacity: isDisabled ? 0.5 : 1,
                                    display: "flex", justifyContent: "space-between", alignItems: "center",
                                  }}>
                                  <span>{t.label}</span>
                                  {t.id === "non-neg" && (
                                    <span style={{
                                      fontSize: 10, color: isDisabled ? "#ef4444" : "var(--text3)",
                                      fontWeight: 600,
                                    }}>{nonNegCount}/{NON_NEG_CAP}</span>
                                  )}
                                </div>
                              );
                            })}
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
            <div style={{ marginTop: 24 }}>
              <div style={{
                fontSize: 10, letterSpacing: 2, textTransform: "uppercase",
                color: "var(--text3)", fontWeight: 600, marginBottom: 10, textAlign: "center",
              }}>Your ranking for {horizonLabel}</div>
              {TIERS.map(tier => {
                const itemsInTier = byTier[tier.id];
                const isNonNeg = tier.id === "non-neg";
                const atCap = isNonNeg && itemsInTier.length === NON_NEG_CAP;
                return (
                  <div key={tier.id} style={{
                    marginBottom: 10, padding: "12px 14px",
                    background: `${tier.color}10`,
                    border: `1px solid ${atCap ? tier.color : `${tier.color}40`}`,
                    borderRadius: 8,
                    boxShadow: atCap ? `0 0 0 1px ${tier.color}40` : "none",
                  }}>
                    <div style={{
                      fontSize: 10, letterSpacing: 2, textTransform: "uppercase",
                      color: tier.color, fontWeight: 700, marginBottom: 8,
                      display: "flex", justifyContent: "space-between", alignItems: "center",
                    }}>
                      <span>
                        {tier.label}
                        {atCap && <span style={{ marginLeft: 8, fontSize: 9, color: "#34d399" }}>✓ FULL</span>}
                      </span>
                      <span style={{ color: "var(--text3)", fontWeight: 500 }}>
                        {isNonNeg ? `${itemsInTier.length}/${NON_NEG_CAP}` : `${itemsInTier.length} items`}
                      </span>
                    </div>
                    {itemsInTier.length === 0 ? (
                      <div style={{ fontSize: 12, color: "var(--text4)", fontStyle: "italic" }}>
                        {isNonNeg ? `— pick your top ${NON_NEG_CAP} only —` : "— nothing here —"}
                      </div>
                    ) : (
                      <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                        {itemsInTier.map(item => (
                          <div key={item.id} style={{
                            display: "inline-flex", alignItems: "center", gap: 6,
                            padding: "4px 10px", borderRadius: 12,
                            background: "rgba(0,0,0,.25)",
                            borderLeft: `3px solid ${segColor(item.segment)}`,
                            fontSize: 12, color: "var(--text)",
                          }}>
                            {item.icon && <span>{item.icon}</span>}
                            {item.label}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
            {/* Confirm ranking button */}
            {!confirmed && hasAnyRanking && onConfirmed && (
              <div style={{ marginTop: 16, textAlign: "center" }}>
                <button onClick={onConfirmed} style={{
                  padding: "10px 22px", borderRadius: 16,
                  background: "#34d399", color: "var(--bg)",
                  border: "none", cursor: "pointer",
                  fontSize: 13, fontWeight: 700,
                }}>✓ Confirm my ranking</button>
                <div style={{
                  fontSize: 11, color: "var(--text3)", fontStyle: "italic", marginTop: 8,
                }}>Once you confirm, this section collapses to a compact view. You can expand and change it anytime.</div>
              </div>
            )}
          </>)}
        </div>
      )}
    </div>
  );
}
// W.2: SimpleItemCard_v2 — used on 3-Year + 1-Year pages (simpler than PriorityItemCard_v2, no prompt sub-label needed)
function SimpleItemCard_v2({ icon, label, color, text, goal, promptText, onTextChange, onGoalChange, hintText, hintLabel,
                              voiceId, name, pillar, horizon, horizonYearLabel }: any) {
  const [summarising, setSummarising] = useState(false);
  const [hintOpen, setHintOpen] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const summarise = async () => {
    if (!(text || "").trim()) return;
    setSummarising(true);
    setErrorMsg("");
    try {
      // Item-goal intent: minimal priorContext per Q2 clarification (just voice/name/focus).
      const synthesized = await synthesize({
        intent: "item-goal",
        voiceId: voiceId || "coach",
        name: name || "you",
        focus: {
          label,
          sourceText: text || "",
          pillar: (pillar as SynthPillar) || undefined,
          horizon: (horizon as SynthHorizon) || undefined,
          horizonYearLabel,
        },
      });
      onGoalChange(synthesized);
    } catch (e: any) {
      setErrorMsg(e?.message || "Synthesis failed.");
    }
    setSummarising(false);
  };
  return (
    <div style={{
      marginBottom:10, padding:"12px 14px",
      background:"rgba(255,255,255,.02)",
      borderLeft:`3px solid ${color}`, borderRadius:6,
    }}>
      <div style={{ display:"flex", alignItems:"center", gap:6, marginBottom:6 }}>
        {icon && <span style={{ fontSize:14 }}>{icon}</span>}
        <div style={{ fontFamily:"var(--serif)", fontSize:16, fontWeight:500, color:"var(--text)" }}>{label}</div>
      </div>
      {hintText && (
        <div style={{ marginBottom:8 }}>
          <button onClick={() => setHintOpen(o => !o)} style={{
            background:"transparent", border:"none", cursor:"pointer",
            padding:0, fontSize:10, fontWeight:600, letterSpacing:1.2, textTransform:"uppercase",
            color:"var(--text3)", display:"inline-flex", alignItems:"center", gap:4,
          }}>
            <span>📎</span>
            <span>{hintOpen ? "▴" : "▾"} {hintLabel || "From BAG"}</span>
          </button>
          {hintOpen && (
            <div style={{
              marginTop:6, padding:"8px 10px",
              background:"rgba(201,168,76,.06)",
              borderLeft:"2px solid var(--warm)", borderRadius:4,
              fontFamily:"var(--serif)", fontSize:14, fontStyle:"italic",
              color:"var(--text2)", lineHeight:1.55,
            }}>
              "{hintText}"
            </div>
          )}
        </div>
      )}
      <textarea value={text || ""} onChange={e => onTextChange(e.target.value)}
        placeholder={promptText} rows={2}
        style={{
          width:"100%", background:"rgba(0,0,0,.2)",
          border:"1px solid var(--border2)", borderRadius:4,
          padding:"8px 10px", color:"var(--text)",
          fontFamily:"var(--serif)", fontSize:14, outline:"none",
          resize:"vertical", lineHeight:1.5,
        }} />
      <div style={{ display:"flex", gap:8, marginTop:8, flexWrap:"wrap", alignItems:"center" }}>
        <button onClick={summarise} disabled={!(text || "").trim() || summarising} style={{
          padding:"5px 12px", borderRadius:12,
          background:"transparent",
          color: (text || "").trim() ? color : "var(--text4)",
          border: `1px solid ${(text || "").trim() ? color : "var(--border2)"}`,
          cursor: (text || "").trim() ? "pointer" : "default",
          fontSize:11, fontWeight:600,
        }}>{summarising ? "✨ Synthesizing..." : (goal ? "↺ Regenerate goal" : "✨ Summarise into a goal")}</button>
        {goal && !errorMsg && (
          <div style={{
            flex:1, minWidth:180,
            padding:"4px 10px", borderRadius:6,
            background:`${color}15`, color:"var(--text)",
            fontSize:14, fontStyle:"italic",
          }}>
            <span style={{
              fontSize:9, letterSpacing:1.2, textTransform:"uppercase",
              color, fontWeight:600, marginRight:6,
            }}>GOAL</span>
            {goal}
          </div>
        )}
      </div>
      {errorMsg && <SynthesizeError message={errorMsg} onRetry={summarise} color={color} />}
    </div>
  );
}
// W.2: PrefillNote_v2 — green-left-bar notice for 3-Year / 1-Year pre-fill explainer
function PrefillNote_v2({ children }) {
  return (
    <div style={{
      marginTop:20, marginBottom:14, padding:"10px 14px",
      background:"rgba(52,211,153,.08)",
      borderLeft:"3px solid #34d399", borderRadius:4,
      fontSize:14, color:"var(--text2)", fontStyle:"italic", lineHeight:1.5,
    }}>{children}</div>
  );
}
// W.2: DirectionTimeline_v2 — port from prototype (line 239 of a1_direction_prototype_v2.jsx)
// Shows 1-YEAR · 3-YEAR · BAG near-to-far. Dots become clickable when that horizon has a confirmed Growth sentence.
// Click a completed dot to expand a preview card showing the sentence.
function DirectionTimeline_v2({ activeHorizon, map }) {
  const year = new Date().getFullYear();
  const points = [
    { key: "oneyr",   label: "1-YEAR", year: String(year + 1),  completed: !!map.oneyr_growth_confirmed },
    { key: "threeyr", label: "3-YEAR", year: String(year + 3),  completed: !!map.threeyr_growth_confirmed },
    { key: "bag",     label: "BAG",    year: String(year + 12), completed: !!map.growth_confirmed },
  ];
  const horizonData = {
    bag: {
      time:   map.time_overall_sentence   || map.time_summary   || map.bag_time_sentence   || map.growth_time_sentence   || "",
      wealth: map.wealth_overall_sentence || map.wealth_summary || map.bag_wealth_sentence || map.growth_wealth_sentence || "",
      growth: map.growth_sentence || map.growth_summary || "",
    },
    threeyr: {
      time:   map.threeyr_time_sentence   || "",
      wealth: map.threeyr_wealth_sentence || "",
      growth: map.threeyr_growth_sentence || "",
    },
    oneyr: {
      time:   map.oneyr_time_sentence   || "",
      wealth: map.oneyr_wealth_sentence || "",
      growth: map.oneyr_growth_sentence || "",
    },
  };
  // Default opened: the activeHorizon if passed, otherwise none
  const [openKey, setOpenKey] = useState(activeHorizon || null);
  const onDotClick = (k) => setOpenKey(openKey === k ? null : k);

  const pillarRow = (label, text, color) => (
    <div style={{
      display:"grid", gridTemplateColumns:"62px 1fr", gap:10,
      alignItems:"start", marginBottom:8,
    }}>
      <span style={{
        fontSize:11, color:"var(--text3)", letterSpacing:1.2,
        textTransform:"uppercase", fontWeight:600, paddingTop:4,
      }}>{label}</span>
      <div style={{ minWidth:0 }}>
        {text && text.trim() ? (
          <div style={{
            fontFamily:"var(--serif)", fontSize:15, lineHeight:1.6,
            fontStyle:"italic", padding:"7px 12px", borderRadius:4,
            background:"rgba(0,0,0,.2)", borderLeft:`2px solid ${color}`,
            color:"var(--text)",
          }}>"{text}"</div>
        ) : (
          <div style={{ fontSize:12, color:"var(--text4)", fontStyle:"italic", padding:"7px 12px" }}>
            Not yet captured in A1.
          </div>
        )}
      </div>
    </div>
  );

  const openPoint = points.find(p => p.key === openKey);
  const data = openKey ? horizonData[openKey] : null;

  return (
    <div style={{
      background:"linear-gradient(180deg, rgba(0,0,0,.25), rgba(0,0,0,.05))",
      border:"1px solid var(--border2)", borderRadius:10,
      padding:"14px 20px 16px", marginBottom:20,
    }}>
      <div style={{
        fontSize:11, letterSpacing:2, textTransform:"uppercase",
        color:"var(--text3)", fontWeight:600, textAlign:"center",
        marginBottom:14,
      }}>Your Direction · Near to Far · <span style={{ color:"var(--warm)" }}>click a dot to see that horizon</span></div>

      {/* Dots strip — clickable */}
      <div style={{ position:"relative", maxWidth:640, margin:"0 auto" }}>
        <div style={{
          position:"absolute", left:"16%", right:"16%", top:7,
          height:2, background:"var(--border2)", borderRadius:1,
        }} />
        <div style={{
          position:"absolute", left:"16%", top:7, height:2,
          background:"var(--warm)", borderRadius:1,
          width: points.filter(p => p.completed).length === 3 ? "68%"
            : points.filter(p => p.completed).length === 2 ? "34%"
            : "0%",
          transition:"width .4s ease",
        }} />
        <div style={{ display:"flex", justifyContent:"space-between", position:"relative" }}>
          {points.map(p => {
            const isOpen = openKey === p.key;
            const isActive = activeHorizon === p.key;
            return (
              <div key={p.key}
                onClick={() => onDotClick(p.key)}
                style={{
                  display:"flex", flexDirection:"column", alignItems:"center",
                  width:"33%", padding:"2px 0", cursor:"pointer", userSelect:"none",
                }}>
                <div style={{
                  width: isOpen ? 20 : isActive ? 18 : 14,
                  height: isOpen ? 20 : isActive ? 18 : 14,
                  borderRadius:10,
                  background: isOpen || isActive || p.completed ? "var(--warm)" : "var(--bg)",
                  border:`2px solid ${isOpen || isActive || p.completed ? "var(--warm)" : "var(--border2)"}`,
                  display:"grid", placeItems:"center",
                  boxShadow: isOpen ? "0 0 0 5px rgba(201,168,76,.3)" : isActive ? "0 0 0 4px rgba(201,168,76,.2)" : "none",
                  color:"var(--bg)", fontSize:9, fontWeight:700, transition:"all .2s ease",
                }}>{p.completed && !isOpen && !isActive && "✓"}</div>
                <div style={{ marginTop:6, textAlign:"center" }}>
                  <div style={{
                    fontSize:11, letterSpacing:1.5, textTransform:"uppercase",
                    color: isOpen || isActive ? "var(--warm)" : p.completed ? "var(--text2)" : "var(--text4)",
                    fontWeight:600,
                  }}>{p.label}</div>
                  <div style={{
                    fontFamily:"var(--serif)", fontSize:13,
                    color: isOpen || isActive ? "var(--warm)" : p.completed ? "var(--text)" : "var(--text4)",
                  }}>{p.year}</div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Opened horizon card — shows Time / Wealth / Growth */}
      {openPoint && data && (
        <div style={{
          marginTop:18, padding:"14px 16px",
          background:"rgba(201,168,76,.06)",
          border:"1px solid rgba(201,168,76,.4)",
          borderRadius:8,
        }}>
          <div style={{ display:"flex", alignItems:"baseline", gap:10, marginBottom:12 }}>
            <span style={{
              fontFamily:"var(--sans)", fontSize:12, letterSpacing:2,
              textTransform:"uppercase", fontWeight:700, color:"var(--warm)",
            }}>{openPoint.label}</span>
            <span style={{ fontSize:12, color:"var(--text4)", fontFamily:"var(--serif)", fontStyle:"italic" }}>
              {openPoint.year}
            </span>
            <span style={{ fontSize:12, color:"var(--text4)", marginLeft:"auto", cursor:"pointer" }}
              onClick={() => setOpenKey(null)}>
              ✕ close
            </span>
          </div>
          {pillarRow("Time",   data.time,   "var(--warm)")}
          {pillarRow("Wealth", data.wealth, "#34d399")}
          {pillarRow("Growth", data.growth, "#a78bfa")}
        </div>
      )}

      {!openPoint && (
        <div style={{
          marginTop:14, fontSize:12, color:"var(--text4)",
          fontStyle:"italic", textAlign:"center",
        }}>
          Tap a dot above to see Time, Wealth, and Growth for that horizon.
        </div>
      )}
    </div>
  );
}
// W.2 (1-Year): Compute Growth suggestions from lowest-scoring Identity capabilities + Values behaviors.
// Returns top-N worst-scored items as seed suggestions with source attribution.
function computeIdentityValuesSeeds(map, topN = 4) {
  const seeds = [];
  // Identity: iterate animals → capabilities → align_cap_{i}_{ci} scores
  const animals = (map.animals || []).filter(a => a && a.name);
  animals.forEach((animal, i) => {
    const caps = (animal.capabilities || []).filter(c => c && c.name);
    caps.forEach((cap, ci) => {
      const key = `align_cap_${i}_${ci}`;
      const raw = map?.[key];
      if (raw === undefined || raw === null) return;
      const score = Number(raw);
      const animalLabel = [animal.adj1, animal.adj2, animal.name].filter(Boolean).join(" ") || animal.name;
      seeds.push({
        id: `iv_cap_${i}_${ci}`,
        label: cap.name,
        source: `Identity · ${animalLabel}`,
        score,
        kind: "identity",
      });
    });
  });
  // Values: iterate val_count + val_{i}_name + beh_{i}_count + beh_{i}_{j}_name → align_val_{i}_beh_{j} scores
  const valCount = parseInt(map?.val_count) || (map?.values || []).filter(v => v && v.name).length || 0;
  for (let i = 0; i < valCount; i++) {
    const vName = map?.[`val_${i}_name`] || (map?.values || [])[i]?.name || "";
    if (!vName) continue;
    const bCount = parseInt(map?.[`beh_${i}_count`]) || 0;
    for (let j = 0; j < bCount; j++) {
      const bName = map?.[`beh_${i}_${j}_name`];
      if (!bName) continue;
      const key = `align_val_${i}_beh_${j}`;
      const raw = map?.[key];
      if (raw === undefined || raw === null) continue;
      const score = Number(raw);
      seeds.push({
        id: `iv_val_${i}_beh_${j}`,
        label: bName,
        source: `Values · ${vName}`,
        score,
        kind: "values",
      });
    }
  }
  // Sort ascending by score (lowest first), Identity before Values on ties
  seeds.sort((a, b) => {
    if (a.score !== b.score) return a.score - b.score;
    if (a.kind !== b.kind) return a.kind === "identity" ? -1 : 1;
    return 0;
  });
  return seeds.slice(0, topN);
}
// W.2 (1-Year): GrowthSuggestions_v2 — renders computed seeds with Accept/Edit/Remove + custom add.
// All state persisted to map via provided setters. Seeds are rendered LIVE from computeIdentityValuesSeeds.
function GrowthSuggestions_v2({ seeds, accepted, setAccepted, editedLabels, setEditedLabels, removed, setRemoved, custom, setCustom }) {
  const [editingId, setEditingId] = useState(null);
  const [draftLabel, setDraftLabel] = useState("");
  const [newCustom, setNewCustom] = useState("");
  const startEdit = (id, currentLabel) => {
    setEditingId(id);
    setDraftLabel(currentLabel);
  };
  const saveEdit = (id) => {
    const trimmed = (draftLabel || "").trim();
    if (trimmed) {
      setEditedLabels({ ...editedLabels, [id]: trimmed });
    }
    setEditingId(null);
    setDraftLabel("");
  };
  const cancelEdit = () => {
    setEditingId(null);
    setDraftLabel("");
  };
  const toggleAccept = (id) => {
    setAccepted({ ...accepted, [id]: !accepted[id] });
  };
  const removeSeed = (id) => {
    setRemoved({ ...removed, [id]: true });
  };
  const addCustomItem = () => {
    const label = newCustom.trim();
    if (!label) return;
    const id = `custom_${Date.now().toString(36)}`;
    setCustom([...(custom || []), { id, label }]);
    setNewCustom("");
  };
  const removeCustom = (id) => {
    setCustom((custom || []).filter(x => x.id !== id));
  };
  const visibleSeeds = seeds.filter(s => !removed[s.id]);
  if (visibleSeeds.length === 0 && (!custom || custom.length === 0)) {
    return (
      <div style={{
        marginTop:14, marginBottom:16, padding:"18px 20px",
        background:"rgba(201,168,76,.06)",
        border:"1px dashed var(--border2)", borderRadius:10,
      }}>
        <div style={{
          fontSize:10, letterSpacing:2, textTransform:"uppercase",
          color:"var(--warm)", fontWeight:600, marginBottom:6,
        }}>Growth suggestions from your inner work</div>
        <div style={{ fontSize:14, color:"var(--text3)", fontStyle:"italic", lineHeight:1.5, marginBottom:10 }}>
          Complete the Identity · Superpowers and Values · Behaviors pages -- your lowest-scoring items will surface here as Growth suggestions for the year ahead.
        </div>
        <div style={{
          padding:"10px 12px", marginTop:8,
          background:"rgba(255,255,255,.02)",
          border:"1px dashed var(--border2)", borderRadius:6,
        }}>
          <div style={{
            fontSize:10, letterSpacing:1.5, textTransform:"uppercase",
            color:"var(--text3)", marginBottom:6, fontWeight:600,
          }}>+ Add your own Growth focus</div>
          <div style={{ display:"flex", gap:8 }}>
            <input value={newCustom} onChange={e => setNewCustom(e.target.value)}
              onKeyDown={e => e.key === "Enter" && addCustomItem()}
              placeholder="Something else that matters..."
              style={{
                flex:1, background:"transparent", border:"none", outline:"none",
                color:"var(--text)", fontSize:14, fontFamily:"var(--sans)",
              }} />
            {newCustom.trim() && (
              <button onClick={addCustomItem} style={{
                padding:"4px 10px", borderRadius:10,
                background:"var(--warm)", color:"var(--bg)",
                border:"none", cursor:"pointer", fontSize:11, fontWeight:700,
              }}>Add</button>
            )}
          </div>
        </div>
      </div>
    );
  }
  return (
    <div style={{
      marginTop:14, marginBottom:16, padding:"18px 20px",
      background:"linear-gradient(135deg, rgba(201,168,76,.12), rgba(245,158,11,.05))",
      border:"1px solid var(--warm)", borderRadius:10,
    }}>
      <div style={{
        fontSize:10, letterSpacing:2, textTransform:"uppercase",
        color:"var(--warm)", fontWeight:600, marginBottom:4,
      }}>Growth suggestions from your inner work</div>
      <div style={{ fontSize:13, color:"var(--text2)", marginBottom:14, lineHeight:1.5 }}>
        Lowest-scoring items from your Identity &amp; Values alignment. Accept, edit the wording, or remove any that don't fit.
        Accepted items flow into your tier ranking below.
      </div>
      {visibleSeeds.map(s => {
        const isEditing = editingId === s.id;
        const isAccepted = !!accepted[s.id];
        const currentLabel = editedLabels[s.id] ?? s.label;
        return (
          <div key={s.id} style={{
            padding:"10px 12px", marginBottom:8,
            background: isAccepted ? "rgba(201,168,76,.12)" : "rgba(255,255,255,.02)",
            border: `1px ${isAccepted ? "solid" : "dashed"} var(--warm)`,
            borderRadius:6,
          }}>
            <div style={{ display:"flex", alignItems:"center", gap:10, flexWrap:"wrap" }}>
              <div onClick={() => toggleAccept(s.id)} style={{
                width:20, height:20, borderRadius:4, flexShrink:0,
                background: isAccepted ? "var(--warm)" : "transparent",
                border:"1px solid var(--warm)",
                display:"grid", placeItems:"center", cursor:"pointer",
                color:"var(--bg)", fontWeight:700, fontSize:12,
              }}>{isAccepted && "✓"}</div>
              <div style={{ flex:1, minWidth:180 }}>
                {isEditing ? (
                  <input autoFocus
                    value={draftLabel}
                    onChange={e => setDraftLabel(e.target.value)}
                    onBlur={() => saveEdit(s.id)}
                    onKeyDown={e => {
                      if (e.key === "Enter") saveEdit(s.id);
                      if (e.key === "Escape") cancelEdit();
                    }}
                    style={{
                      width:"100%", background:"rgba(0,0,0,.3)",
                      border:"1px solid var(--warm)", borderRadius:4,
                      padding:"4px 8px", color:"var(--text)",
                      fontSize:14, fontFamily:"var(--sans)", outline:"none",
                    }} />
                ) : (
                  <>
                    <div style={{ fontSize:14, color:"var(--text)" }}>{currentLabel}</div>
                    <div style={{ fontSize:10, color:"var(--text3)", marginTop:2 }}>
                      {s.source} · scored {s.score}/10
                    </div>
                  </>
                )}
              </div>
              {!isEditing && (
                <div style={{ display:"flex", gap:4 }}>
                  <button onClick={() => startEdit(s.id, currentLabel)} title="Edit wording" style={{
                    padding:"4px 8px", borderRadius:10,
                    background:"transparent", color:"var(--text3)",
                    border:"1px solid var(--border2)", cursor:"pointer",
                    fontSize:11,
                  }}>✎ Edit</button>
                  <button onClick={() => removeSeed(s.id)} title="Remove this suggestion" style={{
                    padding:"4px 8px", borderRadius:10,
                    background:"transparent", color:"#ef4444",
                    border:"1px solid rgba(239,68,68,.25)", cursor:"pointer",
                    fontSize:11,
                  }}>× Remove</button>
                </div>
              )}
            </div>
          </div>
        );
      })}
      {/* Custom items */}
      {(custom || []).map(item => (
        <div key={item.id} style={{
          padding:"10px 12px", marginBottom:8,
          background:"rgba(201,168,76,.12)",
          border:"1px solid var(--warm)", borderRadius:6,
          display:"flex", alignItems:"center", gap:10,
        }}>
          <div style={{
            width:20, height:20, borderRadius:4,
            background:"var(--warm)", display:"grid", placeItems:"center",
            color:"var(--bg)", fontWeight:700, fontSize:12,
          }}>✓</div>
          <div style={{ flex:1, fontSize:14 }}>{item.label}</div>
          <div style={{
            fontSize:9, color:"var(--warm)", padding:"1px 6px", borderRadius:4,
            background:"rgba(201,168,76,.1)", border:"1px solid var(--border)",
          }}>YOUR OWN</div>
          <button onClick={() => removeCustom(item.id)} style={{
            padding:"4px 8px", borderRadius:10,
            background:"transparent", color:"#ef4444",
            border:"1px solid rgba(239,68,68,.25)", cursor:"pointer", fontSize:11,
          }}>× Remove</button>
        </div>
      ))}
      {/* Add your own */}
      <div style={{
        padding:"10px 12px", marginTop:8,
        background:"rgba(255,255,255,.02)",
        border:"1px dashed var(--border2)", borderRadius:6,
      }}>
        <div style={{
          fontSize:10, letterSpacing:1.5, textTransform:"uppercase",
          color:"var(--text3)", marginBottom:6, fontWeight:600,
        }}>+ Add your own Growth focus</div>
        <div style={{ display:"flex", gap:8 }}>
          <input value={newCustom} onChange={e => setNewCustom(e.target.value)}
            onKeyDown={e => e.key === "Enter" && addCustomItem()}
            placeholder="Something else that matters..."
            style={{
              flex:1, background:"transparent", border:"none", outline:"none",
              color:"var(--text)", fontSize:14, fontFamily:"var(--sans)",
            }} />
          {newCustom.trim() && (
            <button onClick={addCustomItem} style={{
              padding:"4px 10px", borderRadius:10,
              background:"var(--warm)", color:"var(--bg)",
              border:"none", cursor:"pointer", fontSize:11, fontWeight:700,
            }}>Add</button>
          )}
        </div>
      </div>
    </div>
  );
}
// W.3: Helper — assemble items + tier assignment for a given horizon (bag / threeyr / oneyr)
// For 1-Year, additionally includes accepted Identity/Values seeds + custom growth items.
function computeHorizonItems(map, horizon, seeds) {
  const items = [];
  const tiers = map[`${horizon}_tiers`] || {};
  const getTier = (id) => tiers[id] || "nth";
  (map.time_picked || []).forEach(id => {
    const preset = TIME_AREA_PRESETS.find(p => p.id === id);
    const stored = (map.time_items || {})[id] || {};
    items.push({
      id: `t_${id}`,
      segment: "Time",
      label: preset?.label || stored.label || id,
      icon:  preset?.icon  || stored.icon  || "",
      tier: getTier(`t_${id}`),
    });
  });
  (map.wealth_picked || []).forEach(id => {
    const preset = WEALTH_AREA_PRESETS.find(p => p.id === id);
    const stored = (map.wealth_items || {})[id] || {};
    items.push({
      id: `w_${id}`,
      segment: "Wealth",
      label: preset?.label || stored.label || id,
      icon:  preset?.icon  || stored.icon  || "",
      tier: getTier(`w_${id}`),
    });
  });
  // Growth vision — if that horizon's growth sentence is confirmed
  const growthConfirmedKey = horizon === "bag" ? "growth_confirmed" : `${horizon}_growth_confirmed`;
  const growthSentenceKey  = horizon === "bag" ? "growth_sentence"  : `${horizon}_growth_sentence`;
  if (map[growthConfirmedKey] && (map[growthSentenceKey] || "").trim()) {
    items.push({ id: "g_main", segment: "Growth", label: "Growth vision", icon: "🌱", tier: getTier("g_main") });
  }
  // 1-Year only: accepted seeds + custom growth items
  if (horizon === "oneyr") {
    const accepted = map.oneyr_growth_accepted || {};
    const editedLabels = map.oneyr_growth_edited_labels || {};
    const removed = map.oneyr_growth_removed || {};
    (seeds || []).forEach(s => {
      if (removed[s.id]) return;
      if (!accepted[s.id]) return;
      const gid = `g_${s.id}`;
      items.push({
        id: gid,
        segment: "Growth",
        label: editedLabels[s.id] ?? s.label,
        icon: s.kind === "identity" ? "⚡" : "🧭",
        tier: getTier(gid),
        suggested: true,
      });
    });
    (map.oneyr_growth_custom || []).forEach(item => {
      const gid = `g_custom_${item.id}`;
      items.push({
        id: gid,
        segment: "Growth",
        label: item.label,
        icon: "✦",
        tier: getTier(gid),
      });
    });
  }
  return items;
}

// ═══════════════════════════════════════════════════════════════════════════
// A2 · Key Misalignment — ranking engine
// Ports from a2_key_misalignment_prototype.jsx (v1)
// final_gap = (10 - score) × type_weight × tier_weight × horizon_weight
//   type_weight:    direction 1.0 · identity 0.8 · values 0.8
//   tier_weight:    non-neg 1.5 · imp 1.0 · nth 0.6 · untiered 1.0
//   horizon_weight: 1-Year 1.3 · 3-Year 1.0 · BAG 0.7 · not-horizoned 1.0
// Tie-breakers: kind (direction > identity > values) → horizon (oneyr > threeyr > bag) → alpha
// ═══════════════════════════════════════════════════════════════════════════
const A2_TIER_META = {
  "non-neg": { id: "non-neg", label: "Non-negotiable", color: "#ef4444", weight: 1.5 },
  "imp":     { id: "imp",     label: "Important",      color: "#f59e0b", weight: 1.0 },
  "nth":     { id: "nth",     label: "Nice to have",   color: "#6b7a99", weight: 0.6 },
};
const A2_HORIZON_META = {
  oneyr:   { label: "1-YEAR", yearOffset: 1,  weight: 1.3 },
  threeyr: { label: "3-YEAR", yearOffset: 3,  weight: 1.0 },
  bag:     { label: "BAG",    yearOffset: 12, weight: 0.7 },
};

function computeMisalignments(map) {
  const items = [];
  const horizons = ["oneyr", "threeyr", "bag"];

  horizons.forEach(horizon => {
    const tiers = map[`${horizon}_tiers`] || {};
    const getTier = (id) => tiers[id] || "nth";
    const hw = A2_HORIZON_META[horizon].weight;
    const hLabel = A2_HORIZON_META[horizon].label;

    // Time
    (map.time_picked || []).forEach(id => {
      const preset = TIME_AREA_PRESETS.find(p => p.id === id);
      const stored = (map.time_items || {})[id] || {};
      const itemId = `t_${id}`;
      const raw = map[`dir_align_${horizon}_${itemId}`];
      if (raw === undefined || raw === null) return;
      const score = Number(raw);
      const tier = getTier(itemId);
      const tw = A2_TIER_META[tier]?.weight ?? 1.0;
      const gap_raw = 10 - score;
      items.push({
        id: `${horizon}_${itemId}`,
        itemId, kind: "direction", segment: "Time",
        horizon, horizonLabel: hLabel,
        tier, tierLabel: A2_TIER_META[tier].label,
        label: preset?.label || stored.label || id,
        icon:  preset?.icon  || stored.icon  || "⏳",
        source: `${hLabel} · ${A2_TIER_META[tier].label}`,
        score, gap_raw,
        type_weight: 1.0, tier_weight: tw, horizon_weight: hw,
        final_gap: gap_raw * 1.0 * tw * hw,
      });
    });

    // Wealth
    (map.wealth_picked || []).forEach(id => {
      const preset = WEALTH_AREA_PRESETS.find(p => p.id === id);
      const stored = (map.wealth_items || {})[id] || {};
      const itemId = `w_${id}`;
      const raw = map[`dir_align_${horizon}_${itemId}`];
      if (raw === undefined || raw === null) return;
      const score = Number(raw);
      const tier = getTier(itemId);
      const tw = A2_TIER_META[tier]?.weight ?? 1.0;
      const gap_raw = 10 - score;
      items.push({
        id: `${horizon}_${itemId}`,
        itemId, kind: "direction", segment: "Wealth",
        horizon, horizonLabel: hLabel,
        tier, tierLabel: A2_TIER_META[tier].label,
        label: preset?.label || stored.label || id,
        icon:  preset?.icon  || stored.icon  || "💰",
        source: `${hLabel} · ${A2_TIER_META[tier].label}`,
        score, gap_raw,
        type_weight: 1.0, tier_weight: tw, horizon_weight: hw,
        final_gap: gap_raw * 1.0 * tw * hw,
      });
    });

    // Growth vision
    const growthConfirmedKey = horizon === "bag" ? "growth_confirmed" : `${horizon}_growth_confirmed`;
    const growthSentenceKey  = horizon === "bag" ? "growth_sentence"  : `${horizon}_growth_sentence`;
    if (map[growthConfirmedKey] && (map[growthSentenceKey] || "").trim()) {
      const itemId = "g_main";
      const raw = map[`dir_align_${horizon}_${itemId}`];
      if (raw !== undefined && raw !== null) {
        const score = Number(raw);
        const tier = getTier(itemId);
        const tw = A2_TIER_META[tier]?.weight ?? 1.0;
        const gap_raw = 10 - score;
        items.push({
          id: `${horizon}_${itemId}`,
          itemId, kind: "direction", segment: "Growth",
          horizon, horizonLabel: hLabel,
          tier, tierLabel: A2_TIER_META[tier].label,
          label: "Growth vision", icon: "🌱",
          source: `${hLabel} · ${A2_TIER_META[tier].label}`,
          score, gap_raw,
          type_weight: 1.0, tier_weight: tw, horizon_weight: hw,
          final_gap: gap_raw * 1.0 * tw * hw,
        });
      }
    }
  });

  // Identity capabilities
  (map.animals || []).filter(a => a && a.name).forEach((animal, i) => {
    (animal.capabilities || []).filter(c => c && c.name).forEach((cap, ci) => {
      const raw = map[`align_cap_${i}_${ci}`];
      if (raw === undefined || raw === null) return;
      const score = Number(raw);
      const gap_raw = 10 - score;
      const tw = 0.8;
      const animalLabel = [animal.adj1, animal.adj2, animal.name].filter(Boolean).join(" ") || animal.name;
      items.push({
        id: `id_cap_${i}_${ci}`,
        itemId: `cap_${i}_${ci}`,
        kind: "identity", horizon: null, tier: null,
        animalName: animal.name,
        label: cap.name, icon: "⚡",
        source: `Identity · ${animalLabel}`,
        score, gap_raw,
        type_weight: tw, tier_weight: 1.0, horizon_weight: 1.0,
        final_gap: gap_raw * tw,
      });
    });
  });

  // Values behaviors
  const valCount = parseInt(map.val_count) || 0;
  for (let i = 0; i < valCount; i++) {
    const vName = map[`val_${i}_name`];
    if (!vName) continue;
    const bCount = parseInt(map[`beh_${i}_count`]) || 0;
    for (let j = 0; j < bCount; j++) {
      const bName = map[`beh_${i}_${j}_name`];
      if (!bName) continue;
      const raw = map[`align_val_${i}_beh_${j}`];
      if (raw === undefined || raw === null) continue;
      const score = Number(raw);
      const gap_raw = 10 - score;
      const tw = 0.8;
      items.push({
        id: `val_${i}_beh_${j}`,
        itemId: `val_${i}_beh_${j}`,
        kind: "values", horizon: null, tier: null,
        valueName: vName,
        label: bName, icon: "⚖️",
        source: `Values · ${vName}`,
        score, gap_raw,
        type_weight: tw, tier_weight: 1.0, horizon_weight: 1.0,
        final_gap: gap_raw * tw,
      });
    }
  }

  // Sort: final_gap DESC → kind → horizon → alpha
  const kindRank = { direction: 0, identity: 1, values: 2 };
  const horizonRank = { oneyr: 0, threeyr: 1, bag: 2 };
  items.sort((a, b) => {
    if (a.final_gap !== b.final_gap) return b.final_gap - a.final_gap;
    if (kindRank[a.kind] !== kindRank[b.kind]) return kindRank[a.kind] - kindRank[b.kind];
    const ah = horizonRank[a.horizon] ?? 3;
    const bh = horizonRank[b.horizon] ?? 3;
    if (ah !== bh) return ah - bh;
    return (a.label || "").localeCompare(b.label || "");
  });
  return items.map((item, rank) => ({ ...item, rank: rank + 1 }));
}

// W.3: CollapsibleTier_v2 — inside Direction Alignment column. Non-negotiable opens by default.
// Per-item interactive slider 1–10. Avg badge in header (red ≤4, amber ≤6, green ≥7).
function CollapsibleTier_v2({ tier, items, horizonKey, map, set }) {
  const defaultOpen = tier.id === "non-neg";
  const [open, setOpen] = useState(defaultOpen);
  const scoreOf = (itemId) => {
    const key = `dir_align_${horizonKey}_${itemId}`;
    const raw = map[key];
    return raw === undefined || raw === null ? 5 : Number(raw);
  };
  const scoreColor = (score) => score <= 4 ? "#ef4444" : score <= 6 ? "#f59e0b" : "#34d399";
  const avg = items.length === 0
    ? 0
    : Number((items.reduce((s, i) => s + scoreOf(i.id), 0) / items.length).toFixed(1));
  const avgColor = scoreColor(avg);
  return (
    <div style={{
      marginBottom:12,
      background: `${tier.color}10`,
      border: `1.5px solid ${tier.color}60`,
      borderRadius:6, overflow:"hidden",
    }}>
      <div onClick={() => setOpen(!open)} style={{
        padding:"10px 12px",
        display:"flex", justifyContent:"space-between", alignItems:"center",
        cursor:"pointer", gap:8,
      }}>
        <div style={{ display:"flex", alignItems:"center", gap:8, flex:1, minWidth:0 }}>
          <span style={{
            fontSize:9, letterSpacing:1.5, textTransform:"uppercase",
            color: tier.color, fontWeight:700,
          }}>{tier.label}</span>
          <span style={{ fontSize:10, color:"var(--text3)", fontWeight:500 }}>
            {items.length} {items.length === 1 ? "item" : "items"}
          </span>
        </div>
        <div style={{ display:"flex", alignItems:"center", gap:8 }}>
          {items.length > 0 && (
            <span style={{
              fontSize:12, fontWeight:700,
              color: avgColor,
              padding:"2px 8px", borderRadius:10,
              background: `${avgColor}15`,
              border: `1px solid ${avgColor}40`,
            }}>avg {avg}</span>
          )}
          <span style={{
            fontSize:14, color:"var(--text3)",
            transform: open ? "rotate(0deg)" : "rotate(-90deg)",
            transition:"transform .2s ease",
          }}>▾</span>
        </div>
      </div>
      {open && (
        <div style={{ padding:"0 12px 10px" }}>
          {items.length === 0 ? (
            <div style={{ fontSize:11, color:"var(--text4)", fontStyle:"italic" }}>—</div>
          ) : items.map(item => {
            const score = scoreOf(item.id);
            const col = scoreColor(score);
            const storeKey = `dir_align_${horizonKey}_${item.id}`;
            return (
              <div key={item.id} style={{ marginBottom:10 }}>
                <div style={{
                  display:"flex", justifyContent:"space-between", fontSize:11, marginBottom:3, gap:8,
                }}>
                  <span style={{ color:"var(--text2)", flex:1, minWidth:0, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>
                    {item.icon && <span style={{ marginRight:4 }}>{item.icon}</span>}
                    {item.label}
                  </span>
                  <span style={{ color: col, fontWeight:600, flexShrink:0 }}>{score}</span>
                </div>
                <input type="range" min={1} max={10} step={1}
                  value={score}
                  onChange={e => set(storeKey, Number(e.target.value))}
                  style={{ width:"100%", accentColor: col }} />
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
// W.3: HorizonAlignmentColumn_v2 — one column (1-Year / 3-Year / BAG) with 3 CollapsibleTiers
function HorizonAlignmentColumn_v2({ horizonKey, horizonLabel, items, map, set }) {
  const byTier = useMemo(() => {
    const g = { "non-neg": [], imp: [], nth: [] };
    items.forEach(i => { g[i.tier || "nth"].push(i); });
    return g;
  }, [items]);
  return (
    <div style={{
      padding:"16px",
      background:"rgba(255,255,255,.03)",
      border:"1px solid var(--border2)", borderRadius:8,
    }}>
      <div style={{
        fontFamily:"var(--serif)", fontSize:16, fontStyle:"italic",
        color:"var(--warm)", marginBottom:14, textAlign:"center",
      }}>{horizonLabel}</div>
      {TIERS.map(t => (
        <CollapsibleTier_v2 key={t.id}
          tier={t}
          items={byTier[t.id]}
          horizonKey={horizonKey}
          map={map} set={set} />
      ))}
    </div>
  );
}
// ─── end W.1a components ──────────────────────────────────────────────────────────────────────
function LifeAreaSelector({ selected, onToggle, onAddCustom }) {
  const [customInput, setCustomInput] = useState("");
  const [showCustom, setShowCustom] = useState(false);
  const selectedIds = selected.map(a => a.id);
  const atMax = selected.length >= 5;
  const addCustom = () => {
    const label = customInput.trim();
    if (!label) return;
    const id = "custom_" + label.toLowerCase().replace(/\s+/g, "_");
    onAddCustom({ id, label, icon:"✦", hint:`Describe your vision for ${label} in 10–15 years.`, see:"", hear:"", feel:"" });
    setCustomInput("");
    setShowCustom(false);
  };
  return (
    <div style={{ marginBottom:16 }}>
      <div style={{ fontSize:12, color:"var(--text3)", marginBottom:10, lineHeight:1.5 }}>
        Pick up to 5 areas that matter most in your 10–15 year life. You will rank them after.
      </div>
      <div style={{ display:"flex", flexWrap:"wrap", gap:7, marginBottom:10 }}>
        {LIFE_AREA_PRESETS.map(area => {
          const isSelected = selectedIds.includes(area.id);
          const rank = selected.findIndex(a => a.id === area.id) + 1;
          return (
            <button key={area.id}
              onClick={() => (!atMax || isSelected) && onToggle(area)}
              style={{
                display:"flex", alignItems:"center", gap:6,
                padding:"7px 13px",
                background: isSelected ? "rgba(201,168,76,.15)" : "var(--bg3)",
                border: isSelected ? "1px solid rgba(201,168,76,.5)" : "1px solid var(--border2)",
                borderRadius:20, cursor: atMax && !isSelected ? "not-allowed" : "pointer",
                fontFamily:"var(--sans)", fontSize:12,
                color: isSelected ? "var(--warm)" : atMax ? "var(--text4)" : "var(--text2)",
                opacity: atMax && !isSelected ? 0.5 : 1, transition:"all .18s"
              }}>
              <span style={{fontSize:13}}>{area.icon}</span>
              {area.label}
              {isSelected && (
                <span style={{fontSize:10,fontWeight:700,background:"var(--warm)",color:"#0d1b2e",borderRadius:"50%",width:16,height:16,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
                  {rank}
                </span>
              )}
            </button>
          );
        })}
        {selected.filter(a => !LIFE_AREA_PRESETS.some(p => p.id === a.id)).map(area => {
          const rank = selected.findIndex(a2 => a2.id === area.id) + 1;
          return (
            <button key={area.id}
              onClick={() => onToggle(area)}
              style={{
                display:"flex", alignItems:"center", gap:6,
                padding:"7px 13px",
                background:"rgba(201,168,76,.15)",
                border:"1px solid rgba(201,168,76,.5)",
                borderRadius:20, cursor:"pointer",
                fontFamily:"var(--sans)", fontSize:12,
                color:"var(--warm)", transition:"all .18s"
              }}>
              <span style={{fontSize:13}}>{area.icon || "✦"}</span>
              {area.label}
              <span style={{fontSize:10,fontWeight:700,background:"var(--warm)",color:"#0d1b2e",borderRadius:"50%",width:16,height:16,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
                {rank}
              </span>
              <span style={{fontSize:13, color:"var(--text4)", marginLeft:2}}>×</span>
            </button>
          );
        })}
        {!showCustom && !atMax && (
          <button onClick={() => setShowCustom(true)}
            style={{ display:"flex", alignItems:"center", gap:6, padding:"7px 13px", background:"transparent", border:"1.5px dashed var(--border2)", borderRadius:20, cursor:"pointer", fontFamily:"var(--sans)", fontSize:12, color:"var(--text4)" }}>
            + Add your own
          </button>
        )}
        {showCustom && (
          <div style={{ display:"flex", alignItems:"center", gap:7 }}>
            <input value={customInput} onChange={e => setCustomInput(e.target.value)}
              onKeyDown={e => e.key === "Enter" && addCustom()}
              placeholder="e.g. Creative work" autoFocus
              style={{ background:"var(--bg4)", border:"1px solid var(--warm)", borderRadius:20, color:"var(--warm)", fontFamily:"var(--sans)", fontSize:12, padding:"7px 13px", outline:"none", width:150 }} />
            <button onClick={addCustom} style={{ background:"var(--warm)", border:"none", borderRadius:20, color:"#0d1b2e", cursor:"pointer", fontSize:12, fontWeight:700, padding:"7px 13px" }}>Add</button>
            <button onClick={() => setShowCustom(false)} style={{ background:"none", border:"none", color:"var(--text4)", cursor:"pointer", fontSize:16 }}>×</button>
          </div>
        )}
      </div>
      {atMax && <div style={{ fontSize:11, color:"var(--text4)", fontStyle:"italic" }}>Maximum 5 areas -- remove one to add another.</div>}
    </div>
  );
}
function LifeAreaCard({ area, rank, total, onMoveUp, onMoveDown, onRemove, onChange, voiceId, name }: any) {
  const [expanded, setExpanded] = useState(true);
  const [summarising, setSummarising] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const summarise = async () => {
    if (!area.see && !area.hear && !area.feel) return;
    setSummarising(true);
    setErrorMsg("");
    try {
      const sourceText = [
        area.see  ? `I will see: ${area.see}`   : "",
        area.hear ? `I will hear: ${area.hear}` : "",
        area.feel ? `I will feel: ${area.feel}` : "",
      ].filter(Boolean).join(". ");
      const synthesized = await synthesize({
        intent: "item-goal",
        voiceId: voiceId || "coach",
        name: name || "you",
        focus: { label: area.label, sourceText, pillar: "time", horizon: "bag" },
      });
      onChange("goal", synthesized);
    } catch (e: any) {
      setErrorMsg(e?.message || "Synthesis failed.");
    }
    setSummarising(false);
  };
  const hasContent = area.see || area.hear || area.feel;
  return (
    <div className="fade-up" style={{ background:"var(--bg3)", border:"1px solid var(--border2)", borderRadius:11, marginBottom:10, overflow:"hidden" }}>
      <div style={{ padding:"11px 14px", display:"flex", alignItems:"center", gap:10 }}>
        <div style={{ width:26, height:26, borderRadius:"50%", background:"var(--warm)", display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0 }}>
          <span style={{ fontSize:11, fontWeight:700, color:"#0d1b2e" }}>{rank}</span>
        </div>
        <span style={{ fontSize:16 }}>{area.icon}</span>
        <div style={{ flex:1 }}>
          <div style={{ fontFamily:"var(--sans)", fontSize:13, fontWeight:700, color:"var(--text)" }}>{area.label}</div>
          {area.goal
            ? <div style={{ fontFamily:"var(--serif)", fontSize:13, fontStyle:"italic", color:"rgba(201,168,76,.7)", lineHeight:1.4, marginTop:2 }}>{area.goal.slice(0, 80)}{area.goal.length > 80 ? "..." : ""}</div>
            : <div style={{ fontSize:11, color:"var(--text4)" }}>Priority {rank} of {total} · add your vision below</div>
          }
        </div>
        <div style={{ display:"flex", gap:4 }}>
          <button onClick={onMoveUp} disabled={rank === 1}
            style={{ background:"none", border:"1px solid var(--border2)", borderRadius:5, color: rank === 1 ? "var(--text4)" : "var(--text3)", cursor: rank === 1 ? "not-allowed" : "pointer", fontSize:11, padding:"3px 7px" }}>▲</button>
          <button onClick={onMoveDown} disabled={rank === total}
            style={{ background:"none", border:"1px solid var(--border2)", borderRadius:5, color: rank === total ? "var(--text4)" : "var(--text3)", cursor: rank === total ? "not-allowed" : "pointer", fontSize:11, padding:"3px 7px" }}>▼</button>
        </div>
        <button onClick={() => setExpanded(e => !e)}
          style={{ background:"none", border:"none", color:"var(--text4)", cursor:"pointer", fontSize:14, padding:"0 4px", transform: expanded ? "rotate(180deg)" : "none", transition:"transform .2s" }}>▾</button>
        <button onClick={onRemove} style={{ background:"none", border:"none", color:"var(--text4)", cursor:"pointer", fontSize:16, padding:0 }}>×</button>
      </div>
      {expanded && (
        <div className="fade-in" style={{ padding:"0 14px 14px", borderTop:"1px solid var(--border)" }}>
          <div style={{ padding:"9px 12px", background:"rgba(201,168,76,.05)", border:"1px solid rgba(201,168,76,.12)", borderRadius:7, marginBottom:12, marginTop:10 }}>
            <div style={{ fontFamily:"var(--serif)", fontSize:14, fontStyle:"italic", color:"var(--text3)", lineHeight:1.6 }}>{area.hint}</div>
          </div>
          {[
            { key:"see",  label:"I will see...",  icon:"👁",  placeholder:"The scenes, moments, people around me..." },
            { key:"hear", label:"I will hear...", icon:"👂",  placeholder:"The words, sounds, conversations I experience..." },
            { key:"feel", label:"I will feel...", icon:"💛",  placeholder:"The emotions, energy, sense of self I carry..." },
          ].map(f => (
            <div key={f.key} style={{ marginBottom:10 }}>
              <div style={{ display:"flex", alignItems:"center", gap:7, marginBottom:5 }}>
                <span style={{ fontSize:13 }}>{f.icon}</span>
                <label style={{ fontFamily:"var(--sans)", fontSize:13, fontWeight:700, color:"var(--warm)", letterSpacing:0.5 }}>{f.label}</label>
              </div>
              <textarea rows={2} value={area[f.key] || ""} onChange={e => onChange(f.key, e.target.value)}
                placeholder={f.placeholder} className="to-field"
                style={{ fontSize:16, fontFamily:"var(--sans)", fontStyle:"normal", color:"var(--warm)", lineHeight:1.7 }} />
            </div>
          ))}
          {/* Goal statement */}
          {area.goal && (
            <div style={{ padding:"11px 14px", background:"rgba(201,168,76,.08)", border:"1px solid rgba(201,168,76,.25)", borderRadius:9, marginBottom:10 }}>
              <div style={{ fontSize:10, fontWeight:700, letterSpacing:1.5, textTransform:"uppercase", color:"var(--warm)", marginBottom:6 }}>Your {area.label} goal</div>
              <div style={{ fontFamily:"var(--serif)", fontSize:18, fontStyle:"italic", color:"var(--text)", lineHeight:1.75, marginBottom:8 }}>{area.goal}</div>
              <textarea rows={2} value={area.goal} onChange={e => onChange("goal", e.target.value)}
                className="to-field" style={{ fontSize:16, fontFamily:"var(--serif)", fontStyle:"italic", color:"var(--warm)", marginBottom:0 }} />
            </div>
          )}
          {/* Summarise button */}
          <button onClick={summarise} disabled={!hasContent || summarising}
            style={{ display:"flex", alignItems:"center", gap:7, background:"none", border:"1px solid rgba(201,168,76,.3)", borderRadius:20, color:"var(--warm)", cursor: !hasContent || summarising ? "not-allowed" : "pointer", fontFamily:"var(--sans)", fontSize:12, fontWeight:500, padding:"7px 16px", opacity: !hasContent ? 0.5 : 1, transition:"all .2s" }}
            onMouseEnter={e => { if(hasContent && !summarising) e.currentTarget.style.background = "rgba(201,168,76,.1)"; }}
            onMouseLeave={e => { e.currentTarget.style.background = "none"; }}>
            {summarising
              ? <><span className="dot-l" style={{ color:"var(--warm)" }}><span /><span /><span /></span> Summarising...</>
              : <>{area.goal ? "↺ Regenerate goal" : "✦ Summarise into a goal"}</>
            }
          </button>
        </div>
      )}
    </div>
  );
}
function DirectionSection({ map, set, voiceId, name, intake }: any) {
  const areas = map.life_areas || [];
  // Stage 4: synthesis context — pillar items + life areas + purpose
  const bagYearLabel = String(new Date().getFullYear() + 12);
  const bagTimeItemsCtx: SynthPriorContextItem[] = (map.time_picked || []).map((id: string) => {
    const stored = (map.time_items || {})[id] || {};
    const preset = TIME_AREA_PRESETS.find((p: any) => p.id === id);
    return { label: preset?.label || stored.label || id, goal: stored.goal || stored.text || "" };
  }).filter((i: any) => i.goal);
  const bagWealthItemsCtx: SynthPriorContextItem[] = (map.wealth_picked || []).map((id: string) => {
    const stored = (map.wealth_items || {})[id] || {};
    const preset = WEALTH_AREA_PRESETS.find((p: any) => p.id === id);
    return { label: preset?.label || stored.label || id, goal: stored.goal || stored.text || "" };
  }).filter((i: any) => i.goal);
  const lifeAreasCtx: SynthPriorContextItem[] = (areas || []).filter((a: any) => a && (a.label || a.id))
    .map((a: any) => ({ label: a.label || a.id, goal: a.goal || "" }));
  const purposeText = (map.purpose_final || map.purpose_draft || "").trim();
  const toggleArea = (area) => {
    const ids = areas.map(a => a.id);
    if (ids.includes(area.id)) {
      set("life_areas", areas.filter(a => a.id !== area.id));
    } else if (areas.length < 5) {
      set("life_areas", [...areas, { ...area, see:"", hear:"", feel:"" }]);
    }
  };
  const addCustom = (area) => {
    if (areas.length >= 5) return;
    if (areas.some(a => a.id === area.id)) return;
    set("life_areas", [...areas, { see:"", hear:"", feel:"", ...area }]);
  };
  const removeArea = (id) => set("life_areas", areas.filter(a => a.id !== id));
  const moveArea = (index, dir) => {
    const next = [...areas];
    const swap = index + dir;
    if (swap < 0 || swap >= next.length) return;
    [next[index], next[swap]] = [next[swap], next[index]];
    set("life_areas", next);
  };
  const updateArea = (id, field, val) => {
    set("life_areas", areas.map(a => a.id === id ? { ...a, [field]: val } : a));
  };
  const [timeOpen, setTimeOpen] = useState(true);
  const [wealthOpen, setWealthOpen] = useState(false);
  const [growthOpen, setGrowthOpen] = useState(false);
  // W.1c: Assemble all items that flow to tier ranking
  const bagItems = useMemo(() => {
    const items = [];
    (map.time_picked || []).forEach(id => {
      const preset = TIME_AREA_PRESETS.find(p => p.id === id);
      const stored = (map.time_items || {})[id] || {};
      items.push({
        id: `t_${id}`,
        segment: "Time",
        label: preset?.label || stored.label || id,
        icon:  preset?.icon  || stored.icon  || "",
      });
    });
    (map.wealth_picked || []).forEach(id => {
      const preset = WEALTH_AREA_PRESETS.find(p => p.id === id);
      const stored = (map.wealth_items || {})[id] || {};
      items.push({
        id: `w_${id}`,
        segment: "Wealth",
        label: preset?.label || stored.label || id,
        icon:  preset?.icon  || stored.icon  || "",
      });
    });
    // Growth appears as a single ranking item only once the user has confirmed their Growth sentence
    if (map.growth_confirmed && (map.growth_sentence || "").trim()) {
      items.push({ id: "g_main", segment: "Growth", label: "Growth vision", icon: "🌱" });
    }
    return items;
  }, [map.time_picked, map.time_items, map.wealth_picked, map.wealth_items, map.growth_confirmed, map.growth_sentence]);
  const SectionHeader = ({ icon, label, color, isOpen, onToggle, summary, summaryColor }) => (
    <button onClick={onToggle}
      style={{ display:"flex", alignItems:"center", gap:10, width:"100%", background:"none", border:"none", cursor:"pointer", padding:"13px 0", textAlign:"left" }}>
      <span style={{ fontSize:16 }}>{icon}</span>
      <div style={{ flex:1 }}>
        <div style={{ fontFamily:"var(--sans)", fontSize:13, fontWeight:700, color }}>{label}</div>
        {!isOpen && summary && (
          <div style={{ fontFamily:"var(--serif)", fontSize:17, fontStyle:"italic", color: summaryColor || "var(--text3)", lineHeight:1.7, marginTop:4 }}>{summary}</div>
        )}
      </div>
      <div style={{
        width:28, height:28, borderRadius:"50%",
        background: isOpen ? "rgba(201,168,76,.15)" : "var(--bg4)",
        border: `1px solid ${isOpen ? "rgba(201,168,76,.4)" : "var(--border2)"}`,
        display:"flex", alignItems:"center", justifyContent:"center",
        flexShrink:0, transition:"all .2s"
      }}>
        <span style={{ fontSize:13, color: isOpen ? "var(--warm)" : "var(--text3)", transform: isOpen ? "rotate(180deg)" : "none", transition:"transform .2s", display:"block", lineHeight:1 }}>▾</span>
      </div>
    </button>
  );
  return (
    <div>
      <DirectionTimeline_v2 activeHorizon="bag" map={map} />
      {/* TIME -- W.1a-ext: prototype structural parity */}
      <CollapsibleSegment_v2
        icon="⏳" title="Time -- Your Life Priorities" color="var(--warm)"
        confirmed={!!map.time_overall_confirmed}
        confirmedSummary={map.time_overall_confirmed ? map.time_overall_sentence : null}>
        <SubLabel_v2>Pick the areas of life that matter most. You'll write a bit about each.</SubLabel_v2>
        <CardPicker_v2
          cards={TIME_AREA_PRESETS}
          picked={map.time_picked || []}
          color="var(--warm)"
          onToggle={id => {
            const picked = map.time_picked || [];
            const items = { ...(map.time_items || {}) };
            if (picked.includes(id)) {
              set("time_picked", picked.filter(p => p !== id));
              delete items[id];
              set("time_items", items);
            } else {
              const preset = TIME_AREA_PRESETS.find(p => p.id === id);
              set("time_picked", [...picked, id]);
              if (!items[id]) {
                items[id] = {
                  text: "", goal: "",
                  label: preset?.label || id,
                  icon: preset?.icon || "✨",
                  hint: preset?.hint || "",
                };
                set("time_items", items);
              }
            }
          }}
          onAddCustom={label => {
            const picked = map.time_picked || [];
            const id = `custom-${label.toLowerCase().replace(/\s+/g, "-")}-${Date.now().toString(36).slice(-4)}`;
            const items = { ...(map.time_items || {}) };
            items[id] = { text: "", goal: "", label, icon: "✨", hint: "" };
            set("time_picked", [...picked, id]);
            set("time_items", items);
          }}
        />
        {(map.time_picked || []).map(id => {
          const preset = TIME_AREA_PRESETS.find(p => p.id === id);
          const stored = (map.time_items || {})[id] || { text: "", goal: "" };
          const meta = preset || { label: stored.label || id, icon: stored.icon || "✨", hint: stored.hint || "" };
          return (
            <PriorityItemCard_v2
              key={id}
              icon={meta.icon}
              label={meta.label}
              color="var(--warm)"
              text={stored.text}
              goal={stored.goal}
              promptText={meta.hint || "How does your time shape this? What are you doing regularly? What have you let go of?"}
              voiceId={voiceId}
              name={name}
              pillar="time"
              horizon="bag"
              horizonYearLabel={bagYearLabel}
              onTextChange={v => {
                const items = { ...(map.time_items || {}) };
                items[id] = { ...(items[id] || {}), text: v };
                set("time_items", items);
                // W.1a-ext: mirror to legacy life_areas for BAG Dashboard/PDF
                const updatedItems = items;
                const legacyAreas = (map.time_picked || []).map(pid => {
                  const p = TIME_AREA_PRESETS.find(x => x.id === pid);
                  const s = updatedItems[pid] || {};
                  return {
                    id: pid,
                    label: p?.label || s.label || pid,
                    icon: p?.icon || s.icon || "✨",
                    see: "", hear: "", feel: "",
                    goal: s.goal || "",
                  };
                });
                set("life_areas", legacyAreas);
              }}
              onGoalChange={v => {
                const items = { ...(map.time_items || {}) };
                items[id] = { ...(items[id] || {}), goal: v };
                set("time_items", items);
                // W.1a-ext: mirror to legacy life_areas
                const updatedItems = items;
                const legacyAreas = (map.time_picked || []).map(pid => {
                  const p = TIME_AREA_PRESETS.find(x => x.id === pid);
                  const s = updatedItems[pid] || {};
                  return {
                    id: pid,
                    label: p?.label || s.label || pid,
                    icon: p?.icon || s.icon || "✨",
                    see: "", hear: "", feel: "",
                    goal: s.goal || "",
                  };
                });
                set("life_areas", legacyAreas);
              }}
            />
          );
        })}
        <SeeHearFeelBlock_v2
          title="Overall Time -- See · Hear · Feel"
          subtitle={`When you picture your whole life in ${String(new Date().getFullYear() + 12)}, what's the sensory texture?`}
          color="var(--warm)"
          values={map.time_see_hear_feel || { see: "", hear: "", feel: "" }}
          onChange={(field, value) => {
            const current = map.time_see_hear_feel || { see: "", hear: "", feel: "" };
            set("time_see_hear_feel", { ...current, [field]: value });
          }}
        />
        <SummaryGenerator_v2
          color="var(--warm)"
          label="Time"
          bottomTitle={`In one sentence, my time in ${String(new Date().getFullYear() + 12)} is...`}
          sourceText={(() => {
            const shf = map.time_see_hear_feel || { see: "", hear: "", feel: "" };
            const items = map.time_items || {};
            const itemBits = Object.values(items).flatMap(i => [i.goal, i.text]).filter(Boolean);
            return [shf.see, shf.hear, shf.feel, ...itemBits].filter(Boolean).join(". ");
          })()}
          existingConfirmed={map.time_overall_confirmed ? map.time_overall_sentence : null}
          intent="pillar-overall"
          voiceId={voiceId}
          name={name}
          pillar="time"
          horizon="bag"
          horizonYearLabel={bagYearLabel}
          priorContext={{ bagTimeItems: bagTimeItemsCtx, purpose: purposeText, lifeAreas: lifeAreasCtx }}
          onConfirm={text => {
            set("time_overall_sentence", text);
            set("time_overall_confirmed", true);
            set("time_summary", text); // W.1a-ext transition: keep legacy field populated
          }}
        />
      </CollapsibleSegment_v2>
      {/* WEALTH -- W.1a: prototype structural parity (CollapsibleSegment_v2 + CardPicker + PriorityItemCards + SeeHearFeelBlock + SummaryGenerator) */}
      <CollapsibleSegment_v2
        icon="💰" title="Wealth -- What you own, what flows" color="#34d399"
        confirmed={!!map.wealth_overall_confirmed}
        confirmedSummary={map.wealth_overall_confirmed ? map.wealth_overall_sentence : null}>
        <SubLabel_v2>Pick the wealth categories that matter for this horizon.</SubLabel_v2>
        <CardPicker_v2
          cards={WEALTH_AREA_PRESETS}
          picked={map.wealth_picked || []}
          color="#34d399"
          onToggle={id => {
            const picked = map.wealth_picked || [];
            const items = { ...(map.wealth_items || {}) };
            if (picked.includes(id)) {
              set("wealth_picked", picked.filter(p => p !== id));
              delete items[id];
              set("wealth_items", items);
            } else {
              const preset = WEALTH_AREA_PRESETS.find(p => p.id === id);
              set("wealth_picked", [...picked, id]);
              if (!items[id]) {
                items[id] = {
                  text: "", goal: "",
                  label: preset?.label || id,
                  icon: preset?.icon || "✨",
                  hint: preset?.hint || "",
                };
                set("wealth_items", items);
              }
            }
          }}
          onAddCustom={label => {
            const picked = map.wealth_picked || [];
            const id = `custom-${label.toLowerCase().replace(/\s+/g, "-")}-${Date.now().toString(36).slice(-4)}`;
            const items = { ...(map.wealth_items || {}) };
            items[id] = { text: "", goal: "", label, icon: "✨", hint: "" };
            set("wealth_picked", [...picked, id]);
            set("wealth_items", items);
          }}
        />
        {(map.wealth_picked || []).map(id => {
          const preset = WEALTH_AREA_PRESETS.find(p => p.id === id);
          const stored = (map.wealth_items || {})[id] || { text: "", goal: "" };
          const meta = preset || { label: stored.label || id, icon: stored.icon || "✨", hint: stored.hint || "" };
          return (
            <PriorityItemCard_v2
              key={id}
              icon={meta.icon}
              label={meta.label}
              color="#34d399"
              text={stored.text}
              goal={stored.goal}
              promptText={meta.hint || `What does this look like in ${String(new Date().getFullYear() + 12)}? Be specific.`}
              voiceId={voiceId}
              name={name}
              pillar="wealth"
              horizon="bag"
              horizonYearLabel={bagYearLabel}
              onTextChange={v => {
                const items = { ...(map.wealth_items || {}) };
                items[id] = { ...(items[id] || {}), text: v };
                set("wealth_items", items);
              }}
              onGoalChange={v => {
                const items = { ...(map.wealth_items || {}) };
                items[id] = { ...(items[id] || {}), goal: v };
                set("wealth_items", items);
              }}
            />
          );
        })}
        <SeeHearFeelBlock_v2
          title="Overall Wealth -- See · Hear · Feel"
          subtitle={`When you picture your financial life in ${String(new Date().getFullYear() + 12)}, what do you see, hear, feel?`}
          color="#34d399"
          values={map.wealth_see_hear_feel || { see: "", hear: "", feel: "" }}
          onChange={(field, value) => {
            const current = map.wealth_see_hear_feel || { see: "", hear: "", feel: "" };
            set("wealth_see_hear_feel", { ...current, [field]: value });
          }}
        />
        <SummaryGenerator_v2
          color="#34d399"
          label="Wealth"
          bottomTitle={`In one sentence, my wealth in ${String(new Date().getFullYear() + 12)} is...`}
          sourceText={(() => {
            const shf = map.wealth_see_hear_feel || { see: "", hear: "", feel: "" };
            const items = map.wealth_items || {};
            const itemBits = Object.values(items).flatMap(i => [i.goal, i.text]).filter(Boolean);
            return [shf.see, shf.hear, shf.feel, ...itemBits].filter(Boolean).join(". ");
          })()}
          existingConfirmed={map.wealth_overall_confirmed ? map.wealth_overall_sentence : null}
          intent="pillar-overall"
          voiceId={voiceId}
          name={name}
          pillar="wealth"
          horizon="bag"
          horizonYearLabel={bagYearLabel}
          priorContext={{ bagWealthItems: bagWealthItemsCtx, purpose: purposeText, lifeAreas: lifeAreasCtx }}
          onConfirm={text => {
            set("wealth_overall_sentence", text);
            set("wealth_overall_confirmed", true);
            set("wealth_summary", text); // W.1a transition: keep legacy field populated so dashboard + PDF still render
          }}
        />
      </CollapsibleSegment_v2>
      {/* GROWTH -- W.1a-ext: prototype structural parity (no card picker — just S/H/F + summary) */}
      <CollapsibleSegment_v2
        icon="🌱" title="Growth -- Who you are becoming" color="#a78bfa"
        confirmed={!!map.growth_confirmed}
        confirmedSummary={map.growth_confirmed ? map.growth_sentence : null}>
        <div style={{
          fontSize:13, color:"var(--text2)", lineHeight:1.6, marginBottom:18, marginTop:8,
          padding:"12px 16px",
          background:"rgba(255,255,255,.03)",
          borderLeft:"2px solid #a78bfa", borderRadius:4,
        }}>
          Growth is who you become. Do the See/Hear/Feel below to paint who you are in {String(new Date().getFullYear() + 12)},
          then summarise it into one sentence at the bottom.
        </div>
        <SeeHearFeelBlock_v2
          title="Growth -- See · Hear · Feel"
          subtitle={`When you picture the person you've become in ${String(new Date().getFullYear() + 12)}, what do you see, hear, feel?`}
          color="#a78bfa"
          values={map.growth_see_hear_feel || { see: "", hear: "", feel: "" }}
          onChange={(field, value) => {
            const current = map.growth_see_hear_feel || { see: "", hear: "", feel: "" };
            set("growth_see_hear_feel", { ...current, [field]: value });
          }}
        />
        <SummaryGenerator_v2
          color="#a78bfa"
          label="Growth"
          bottomTitle={`In one sentence, who I am in ${String(new Date().getFullYear() + 12)}...`}
          sourceText={(() => {
            const shf = map.growth_see_hear_feel || { see: "", hear: "", feel: "" };
            return [shf.see, shf.hear, shf.feel].filter(Boolean).join(". ");
          })()}
          existingConfirmed={map.growth_confirmed ? map.growth_sentence : null}
          intent="horizon-growth"
          voiceId={voiceId}
          name={name}
          pillar="growth"
          horizon="bag"
          horizonYearLabel={bagYearLabel}
          priorContext={{
            purpose: purposeText,
            lifeAreas: lifeAreasCtx,
            bagTime: map.time_overall_sentence || "",
            bagWealth: map.wealth_overall_sentence || "",
          }}
          onConfirm={text => {
            set("growth_sentence", text);
            set("growth_confirmed", true);
            set("growth_summary", text); // W.1a-ext: keep legacy field populated for dashboard/PDF
            set("bag_growth", text);      // W.1a-ext: keep legacy long-form field populated too
          }}
        />
      </CollapsibleSegment_v2>
      {/* W.1c: Tier ranking (prototype parity) */}
      <TierRankingSection_v2
        items={bagItems}
        tiers={map.bag_tiers || {}}
        setTiers={next => set("bag_tiers", next)}
        horizonLabel={String(new Date().getFullYear() + 12)}
        confirmed={!!map.bag_ranking_confirmed}
        onConfirmed={() => set("bag_ranking_confirmed", true)}
      />
    </div>
  );
}
// W.2: ThreeYearPage -- Direction · 3-Year (v3.1 Page 3)
// Pre-fills Time and Wealth from BAG. No S/H/F. Growth is free-writing + Summary Generator.
// Includes tier ranking at bottom. User re-ranks fresh for this horizon.
function ThreeYearPage({ map, set, voiceId, name, intake }: any) {
  const year = new Date().getFullYear() + 3;
  // Stage 4: synthesis context for 3-year horizon
  const yearLabel = String(year);
  const threeyrTimeItemsCtx: SynthPriorContextItem[] = Object.entries(map.threeyr_time_items || {}).map(([id, v]: any) => {
    const preset = TIME_AREA_PRESETS.find((p: any) => p.id === id);
    const bagStored = (map.time_items || {})[id] || {};
    return { label: preset?.label || bagStored.label || id, goal: v?.goal || v?.text || "" };
  }).filter((i: any) => i.goal);
  const threeyrWealthItemsCtx: SynthPriorContextItem[] = Object.entries(map.threeyr_wealth_items || {}).map(([id, v]: any) => {
    const preset = WEALTH_AREA_PRESETS.find((p: any) => p.id === id);
    const bagStored = (map.wealth_items || {})[id] || {};
    return { label: preset?.label || bagStored.label || id, goal: v?.goal || v?.text || "" };
  }).filter((i: any) => i.goal);
  const lifeAreasCtx: SynthPriorContextItem[] = ((map.life_areas || []) as any[])
    .filter((a: any) => a && (a.label || a.id))
    .map((a: any) => ({ label: a.label || a.id, goal: a.goal || "" }));
  const purposeText = (map.purpose_final || map.purpose_draft || "").trim();
  // Pre-fill Time and Wealth items from BAG on first visit
  useEffect(() => {
    const hasTimeItems = Object.keys(map.threeyr_time_items || {}).length > 0;
    const hasWealthItems = Object.keys(map.threeyr_wealth_items || {}).length > 0;
    if (!hasTimeItems && (map.time_picked || []).length > 0) {
      const seeded = {};
      (map.time_picked || []).forEach(id => {
        seeded[id] = { text: "", goal: "" };
      });
      set("threeyr_time_items", seeded);
    }
    if (!hasWealthItems && (map.wealth_picked || []).length > 0) {
      const seeded = {};
      (map.wealth_picked || []).forEach(id => {
        seeded[id] = { text: "", goal: "" };
      });
      set("threeyr_wealth_items", seeded);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  // Assemble items for tier ranking (Time picks + Wealth picks + Growth if confirmed)
  const threeyrItems = useMemo(() => {
    const items = [];
    (map.time_picked || []).forEach(id => {
      const preset = TIME_AREA_PRESETS.find(p => p.id === id);
      const stored = (map.time_items || {})[id] || {};
      items.push({
        id: `t_${id}`,
        segment: "Time",
        label: preset?.label || stored.label || id,
        icon:  preset?.icon  || stored.icon  || "",
      });
    });
    (map.wealth_picked || []).forEach(id => {
      const preset = WEALTH_AREA_PRESETS.find(p => p.id === id);
      const stored = (map.wealth_items || {})[id] || {};
      items.push({
        id: `w_${id}`,
        segment: "Wealth",
        label: preset?.label || stored.label || id,
        icon:  preset?.icon  || stored.icon  || "",
      });
    });
    if (map.threeyr_growth_confirmed && (map.threeyr_growth_sentence || "").trim()) {
      items.push({ id: "g_main", segment: "Growth", label: "Growth vision", icon: "🌱" });
    }
    return items;
  }, [map.time_picked, map.time_items, map.wealth_picked, map.wealth_items, map.threeyr_growth_confirmed, map.threeyr_growth_sentence]);
  const timePicked = (map.time_picked || []) as string[];
  const wealthPicked = (map.wealth_picked || []) as string[];
  const hasBagData = timePicked.length > 0 || wealthPicked.length > 0;
  const updateTimeItem = (id, field, value) => {
    const items = { ...(map.threeyr_time_items || {}) };
    items[id] = { ...(items[id] || { text: "", goal: "" }), [field]: value };
    set("threeyr_time_items", items);
  };
  const updateWealthItem = (id, field, value) => {
    const items = { ...(map.threeyr_wealth_items || {}) };
    items[id] = { ...(items[id] || { text: "", goal: "" }), [field]: value };
    set("threeyr_wealth_items", items);
  };
  return (
    <div>
      {!hasBagData && (
        <div style={{
          padding:"18px 20px", marginBottom:20,
          background:"rgba(201,168,76,.06)", borderLeft:"3px solid var(--warm)",
          borderRadius:8,
          fontSize:13, color:"var(--text2)", lineHeight:1.6,
        }}>
          <div style={{ fontFamily:"var(--serif)", fontSize:17, color:"var(--text)", marginBottom:8 }}>
            Come back here after BAG.
          </div>
          Pick your Time and Wealth priorities in the BAG page first — this 3-Year page refines them rather than starting blank.
        </div>
      )}
      {hasBagData && (<>
        <PrefillNote_v2>
          Your priorities from BAG have been carried forward. Refine what each one looks like at 3 years out.
        </PrefillNote_v2>
        {/* TIME */}
        <CollapsibleSegment_v2
          icon="⏳" title="Time" color="var(--warm)"
          confirmed={!!map.threeyr_time_confirmed}
          confirmedSummary={map.threeyr_time_confirmed ? map.threeyr_time_sentence : null}>
          {timePicked.map(id => {
            const preset = TIME_AREA_PRESETS.find(p => p.id === id);
            const stored = (map.threeyr_time_items || {})[id] || { text: "", goal: "" };
            const bagStored = (map.time_items || {})[id] || {};
            const meta = preset || { label: bagStored.label || id, icon: bagStored.icon || "✨" };
            const bagHint = (bagStored.goal || bagStored.text || "").trim();
            return (
              <SimpleItemCard_v2
                key={id}
                icon={meta.icon}
                label={meta.label}
                color="var(--warm)"
                text={stored.text}
                goal={stored.goal}
                promptText={`What does this look like in ${year}?`}
                hintText={bagHint || null}
                hintLabel={`From BAG · ${new Date().getFullYear() + 12}`}
                voiceId={voiceId}
                name={name}
                pillar="time"
                horizon="threeyr"
                horizonYearLabel={yearLabel}
                onTextChange={v => updateTimeItem(id, "text", v)}
                onGoalChange={v => updateTimeItem(id, "goal", v)}
              />
            );
          })}
          <SummaryGenerator_v2
            color="var(--warm)"
            label="Time"
            bottomTitle={`In one sentence, my time in ${year} is...`}
            sourceText={Object.values(map.threeyr_time_items || {}).map((i: any) => i.goal || i.text).filter(Boolean).join(". ")}
            existingConfirmed={map.threeyr_time_confirmed ? map.threeyr_time_sentence : null}
            intent="pillar-overall"
            voiceId={voiceId}
            name={name}
            pillar="time"
            horizon="threeyr"
            horizonYearLabel={yearLabel}
            priorContext={{ threeyrTimeItems: threeyrTimeItemsCtx, purpose: purposeText, lifeAreas: lifeAreasCtx }}
            onConfirm={text => {
              set("threeyr_time_sentence", text);
              set("threeyr_time_confirmed", true);
            }}
          />
        </CollapsibleSegment_v2>
        {/* WEALTH */}
        <CollapsibleSegment_v2
          icon="💰" title="Wealth" color="#34d399"
          confirmed={!!map.threeyr_wealth_confirmed}
          confirmedSummary={map.threeyr_wealth_confirmed ? map.threeyr_wealth_sentence : null}>
          {wealthPicked.map(id => {
            const preset = WEALTH_AREA_PRESETS.find(p => p.id === id);
            const stored = (map.threeyr_wealth_items || {})[id] || { text: "", goal: "" };
            const bagStored = (map.wealth_items || {})[id] || {};
            const meta = preset || { label: bagStored.label || id, icon: bagStored.icon || "✨" };
            const bagHint = (bagStored.goal || bagStored.text || "").trim();
            return (
              <SimpleItemCard_v2
                key={id}
                icon={meta.icon}
                label={meta.label}
                color="#34d399"
                text={stored.text}
                goal={stored.goal}
                promptText={`What does this look like in ${year}?`}
                hintText={bagHint || null}
                hintLabel={`From BAG · ${new Date().getFullYear() + 12}`}
                voiceId={voiceId}
                name={name}
                pillar="wealth"
                horizon="threeyr"
                horizonYearLabel={yearLabel}
                onTextChange={v => updateWealthItem(id, "text", v)}
                onGoalChange={v => updateWealthItem(id, "goal", v)}
              />
            );
          })}
          <SummaryGenerator_v2
            color="#34d399"
            label="Wealth"
            bottomTitle={`In one sentence, my wealth in ${year} is...`}
            sourceText={Object.values(map.threeyr_wealth_items || {}).map((i: any) => i.goal || i.text).filter(Boolean).join(". ")}
            existingConfirmed={map.threeyr_wealth_confirmed ? map.threeyr_wealth_sentence : null}
            intent="pillar-overall"
            voiceId={voiceId}
            name={name}
            pillar="wealth"
            horizon="threeyr"
            horizonYearLabel={yearLabel}
            priorContext={{ threeyrWealthItems: threeyrWealthItemsCtx, purpose: purposeText, lifeAreas: lifeAreasCtx }}
            onConfirm={text => {
              set("threeyr_wealth_sentence", text);
              set("threeyr_wealth_confirmed", true);
            }}
          />
        </CollapsibleSegment_v2>
        {/* GROWTH -- free writing + Summary Generator (no cards, no S/H/F per v3.1) */}
        <CollapsibleSegment_v2
          icon="🌱" title="Growth" color="#a78bfa"
          confirmed={!!map.threeyr_growth_confirmed}
          confirmedSummary={map.threeyr_growth_confirmed ? map.threeyr_growth_sentence : null}>
          <div style={{
            fontSize:13, color:"var(--text2)", lineHeight:1.6, marginBottom:14, marginTop:8,
            padding:"10px 14px",
            background:"rgba(255,255,255,.03)",
            borderLeft:"2px solid #a78bfa", borderRadius:4,
          }}>
            Who are you in {year}? Write freely about who you're becoming -- then summarise into one sentence at the bottom.
          </div>
          <div style={{
            marginBottom:12, padding:"12px 14px",
            background:"rgba(255,255,255,.03)",
            border:"1px solid var(--border2)",
            borderLeft:"3px solid #a78bfa",
            borderRadius:6,
          }}>
            <div style={{
              fontSize:11, letterSpacing:1.5, textTransform:"uppercase",
              color:"#a78bfa", fontWeight:600, marginBottom:6,
            }}>Who you are in {year} -- write freely</div>
            <textarea
              value={map.threeyr_growth_text || ""}
              onChange={e => set("threeyr_growth_text", e.target.value)}
              placeholder="Who have you become? What have you built? What's different about you?"
              rows={4}
              style={{
                width:"100%", background:"rgba(0,0,0,.2)",
                border:"1px solid var(--border2)", borderRadius:4,
                padding:"8px 10px", color:"var(--text)",
                fontFamily:"var(--serif)", fontSize:15, outline:"none",
                resize:"vertical", lineHeight:1.55,
              }} />
          </div>
          <SummaryGenerator_v2
            color="#a78bfa"
            label="Growth"
            bottomTitle={`In one sentence, who I am in ${year}...`}
            sourceText={map.threeyr_growth_text || ""}
            existingConfirmed={map.threeyr_growth_confirmed ? map.threeyr_growth_sentence : null}
            intent="horizon-growth"
            voiceId={voiceId}
            name={name}
            pillar="growth"
            horizon="threeyr"
            horizonYearLabel={yearLabel}
            priorContext={{
              purpose: purposeText,
              lifeAreas: lifeAreasCtx,
              threeyrTime: map.threeyr_time_sentence || "",
              threeyrWealth: map.threeyr_wealth_sentence || "",
            }}
            onConfirm={text => {
              set("threeyr_growth_sentence", text);
              set("threeyr_growth_confirmed", true);
            }}
          />
        </CollapsibleSegment_v2>
        {/* TIER RANKING -- fresh ranking for this horizon */}
        <TierRankingSection_v2
          items={threeyrItems}
          tiers={map.threeyr_tiers || {}}
          setTiers={next => set("threeyr_tiers", next)}
          horizonLabel={String(year)}
          confirmed={!!map.threeyr_ranking_confirmed}
          onConfirmed={() => set("threeyr_ranking_confirmed", true)}
        />
      </>)}
    </div>
  );
}
// W.2: OneYearPage -- Direction · 1-Year (v3.1 Page 7)
// Pre-fills Time and Wealth categories from BAG. Growth pulls from Identity/Values lowest scores.
// Tier ranking includes Time + Wealth + accepted Identity/Values seeds + custom growth items.
function OneYearPage({ map, set, voiceId, name, intake }: any) {
  const year = new Date().getFullYear() + 1;
  // Stage 4: synthesis context for 1-year horizon (incl. final-1yr-growth bundle)
  const yearLabel = String(year);
  const oneyrTimeItemsCtx: SynthPriorContextItem[] = Object.entries(map.oneyr_time_items || {}).map(([id, v]: any) => {
    const preset = TIME_AREA_PRESETS.find((p: any) => p.id === id);
    const bagStored = (map.time_items || {})[id] || {};
    return { label: preset?.label || bagStored.label || id, goal: v?.goal || v?.text || "" };
  }).filter((i: any) => i.goal);
  const oneyrWealthItemsCtx: SynthPriorContextItem[] = Object.entries(map.oneyr_wealth_items || {}).map(([id, v]: any) => {
    const preset = WEALTH_AREA_PRESETS.find((p: any) => p.id === id);
    const bagStored = (map.wealth_items || {})[id] || {};
    return { label: preset?.label || bagStored.label || id, goal: v?.goal || v?.text || "" };
  }).filter((i: any) => i.goal);
  const lifeAreasCtx: SynthPriorContextItem[] = ((map.life_areas || []) as any[])
    .filter((a: any) => a && (a.label || a.id))
    .map((a: any) => ({ label: a.label || a.id, goal: a.goal || "" }));
  const purposeText = (map.purpose_final || map.purpose_draft || "").trim();
  // Pre-fill on first visit (same pattern as 3-Year)
  useEffect(() => {
    const hasTimeItems = Object.keys(map.oneyr_time_items || {}).length > 0;
    const hasWealthItems = Object.keys(map.oneyr_wealth_items || {}).length > 0;
    if (!hasTimeItems && (map.time_picked || []).length > 0) {
      const seeded = {};
      (map.time_picked || []).forEach(id => { seeded[id] = { text: "", goal: "" }; });
      set("oneyr_time_items", seeded);
    }
    if (!hasWealthItems && (map.wealth_picked || []).length > 0) {
      const seeded = {};
      (map.wealth_picked || []).forEach(id => { seeded[id] = { text: "", goal: "" }; });
      set("oneyr_wealth_items", seeded);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  // Compute live Identity/Values growth seeds (lowest-scoring items)
  const seeds = useMemo(() => computeIdentityValuesSeeds(map, 4), [
    map.animals, map.values, map.val_count,
    // Depend on all the underlying scores — shallow diff is fine since map is rewritten on each set()
    JSON.stringify(Object.keys(map).filter(k => k.startsWith("align_cap_") || k.startsWith("align_val_")).reduce((o, k) => ((o[k] = map[k]), o), {})),
  ]);
  // Tier ranking items: Time + Wealth picks + Growth vision (if confirmed) + accepted seeds + custom items
  const oneyrItems = useMemo(() => {
    const items = [];
    (map.time_picked || []).forEach(id => {
      const preset = TIME_AREA_PRESETS.find(p => p.id === id);
      const stored = (map.time_items || {})[id] || {};
      items.push({
        id: `t_${id}`,
        segment: "Time",
        label: preset?.label || stored.label || id,
        icon:  preset?.icon  || stored.icon  || "",
      });
    });
    (map.wealth_picked || []).forEach(id => {
      const preset = WEALTH_AREA_PRESETS.find(p => p.id === id);
      const stored = (map.wealth_items || {})[id] || {};
      items.push({
        id: `w_${id}`,
        segment: "Wealth",
        label: preset?.label || stored.label || id,
        icon:  preset?.icon  || stored.icon  || "",
      });
    });
    if (map.oneyr_growth_confirmed && (map.oneyr_growth_sentence || "").trim()) {
      items.push({ id: "g_main", segment: "Growth", label: "Growth vision", icon: "🌱" });
    }
    // Accepted Identity/Values seeds
    const accepted = map.oneyr_growth_accepted || {};
    const editedLabels = map.oneyr_growth_edited_labels || {};
    const removed = map.oneyr_growth_removed || {};
    seeds.forEach(s => {
      if (removed[s.id]) return;
      if (!accepted[s.id]) return;
      items.push({
        id: `g_${s.id}`,
        segment: "Growth",
        label: editedLabels[s.id] ?? s.label,
        icon: s.kind === "identity" ? "⚡" : "🧭",
        suggested: true,
      });
    });
    // Custom growth items (always accepted)
    (map.oneyr_growth_custom || []).forEach(item => {
      items.push({
        id: `g_custom_${item.id}`,
        segment: "Growth",
        label: item.label,
        icon: "✦",
      });
    });
    return items;
  }, [map.time_picked, map.time_items, map.wealth_picked, map.wealth_items,
      map.oneyr_growth_confirmed, map.oneyr_growth_sentence,
      map.oneyr_growth_accepted, map.oneyr_growth_edited_labels,
      map.oneyr_growth_removed, map.oneyr_growth_custom,
      seeds]);
  const timePicked = (map.time_picked || []) as string[];
  const wealthPicked = (map.wealth_picked || []) as string[];
  const hasBagData = timePicked.length > 0 || wealthPicked.length > 0;
  const updateTimeItem = (id, field, value) => {
    const items = { ...(map.oneyr_time_items || {}) };
    items[id] = { ...(items[id] || { text: "", goal: "" }), [field]: value };
    set("oneyr_time_items", items);
  };
  const updateWealthItem = (id, field, value) => {
    const items = { ...(map.oneyr_wealth_items || {}) };
    items[id] = { ...(items[id] || { text: "", goal: "" }), [field]: value };
    set("oneyr_wealth_items", items);
  };
  return (
    <div>
      {!hasBagData && (
        <div style={{
          padding:"18px 20px", marginBottom:20,
          background:"rgba(201,168,76,.06)", borderLeft:"3px solid var(--warm)",
          borderRadius:8,
          fontSize:13, color:"var(--text2)", lineHeight:1.6,
        }}>
          <div style={{ fontFamily:"var(--serif)", fontSize:17, color:"var(--text)", marginBottom:8 }}>
            Come back here after BAG.
          </div>
          Pick your Time and Wealth priorities in the BAG page first -- this 1-Year page refines them rather than starting blank.
        </div>
      )}
      {hasBagData && (<>
        <PrefillNote_v2>
          Pre-filled from your 3-Year. Refine what each looks like for {year}.
        </PrefillNote_v2>
        {/* TIME */}
        <CollapsibleSegment_v2
          icon="⏳" title="Time" color="var(--warm)"
          confirmed={!!map.oneyr_time_confirmed}
          confirmedSummary={map.oneyr_time_confirmed ? map.oneyr_time_sentence : null}>
          {timePicked.map(id => {
            const preset = TIME_AREA_PRESETS.find(p => p.id === id);
            const stored = (map.oneyr_time_items || {})[id] || { text: "", goal: "" };
            const threeyrStored = (map.threeyr_time_items || {})[id] || {};
            const bagStored = (map.time_items || {})[id] || {};
            const meta = preset || { label: bagStored.label || id, icon: bagStored.icon || "✨" };
            // Hint: prefer 3-Year text (closer horizon), fall back to BAG
            const hintFromThreeYr = (threeyrStored.goal || threeyrStored.text || "").trim();
            const hintFromBag = (bagStored.goal || bagStored.text || "").trim();
            const hintText = hintFromThreeYr || hintFromBag || null;
            const hintLabel = hintFromThreeYr
              ? `From 3-YEAR · ${new Date().getFullYear() + 3}`
              : `From BAG · ${new Date().getFullYear() + 12}`;
            return (
              <SimpleItemCard_v2
                key={id}
                icon={meta.icon}
                label={meta.label}
                color="var(--warm)"
                text={stored.text}
                goal={stored.goal}
                promptText={`What does this look like in ${year}?`}
                hintText={hintText}
                hintLabel={hintLabel}
                voiceId={voiceId}
                name={name}
                pillar="time"
                horizon="oneyr"
                horizonYearLabel={yearLabel}
                onTextChange={v => updateTimeItem(id, "text", v)}
                onGoalChange={v => updateTimeItem(id, "goal", v)}
              />
            );
          })}
          <SummaryGenerator_v2
            color="var(--warm)"
            label="Time"
            bottomTitle={`In one sentence, my time in ${year} is...`}
            sourceText={Object.values(map.oneyr_time_items || {}).map((i: any) => i.goal || i.text).filter(Boolean).join(". ")}
            existingConfirmed={map.oneyr_time_confirmed ? map.oneyr_time_sentence : null}
            intent="pillar-overall"
            voiceId={voiceId}
            name={name}
            pillar="time"
            horizon="oneyr"
            horizonYearLabel={yearLabel}
            priorContext={{ oneyrTimeItems: oneyrTimeItemsCtx, purpose: purposeText, lifeAreas: lifeAreasCtx }}
            onConfirm={text => {
              set("oneyr_time_sentence", text);
              set("oneyr_time_confirmed", true);
            }}
          />
        </CollapsibleSegment_v2>
        {/* WEALTH */}
        <CollapsibleSegment_v2
          icon="💰" title="Wealth" color="#34d399"
          confirmed={!!map.oneyr_wealth_confirmed}
          confirmedSummary={map.oneyr_wealth_confirmed ? map.oneyr_wealth_sentence : null}>
          {wealthPicked.map(id => {
            const preset = WEALTH_AREA_PRESETS.find(p => p.id === id);
            const stored = (map.oneyr_wealth_items || {})[id] || { text: "", goal: "" };
            const threeyrStored = (map.threeyr_wealth_items || {})[id] || {};
            const bagStored = (map.wealth_items || {})[id] || {};
            const meta = preset || { label: bagStored.label || id, icon: bagStored.icon || "✨" };
            const hintFromThreeYr = (threeyrStored.goal || threeyrStored.text || "").trim();
            const hintFromBag = (bagStored.goal || bagStored.text || "").trim();
            const hintText = hintFromThreeYr || hintFromBag || null;
            const hintLabel = hintFromThreeYr
              ? `From 3-YEAR · ${new Date().getFullYear() + 3}`
              : `From BAG · ${new Date().getFullYear() + 12}`;
            return (
              <SimpleItemCard_v2
                key={id}
                icon={meta.icon}
                label={meta.label}
                color="#34d399"
                text={stored.text}
                goal={stored.goal}
                promptText={`What does this look like in ${year}?`}
                hintText={hintText}
                hintLabel={hintLabel}
                voiceId={voiceId}
                name={name}
                pillar="wealth"
                horizon="oneyr"
                horizonYearLabel={yearLabel}
                onTextChange={v => updateWealthItem(id, "text", v)}
                onGoalChange={v => updateWealthItem(id, "goal", v)}
              />
            );
          })}
          <SummaryGenerator_v2
            color="#34d399"
            label="Wealth"
            bottomTitle={`In one sentence, my wealth in ${year} is...`}
            sourceText={Object.values(map.oneyr_wealth_items || {}).map((i: any) => i.goal || i.text).filter(Boolean).join(". ")}
            existingConfirmed={map.oneyr_wealth_confirmed ? map.oneyr_wealth_sentence : null}
            intent="pillar-overall"
            voiceId={voiceId}
            name={name}
            pillar="wealth"
            horizon="oneyr"
            horizonYearLabel={yearLabel}
            priorContext={{ oneyrWealthItems: oneyrWealthItemsCtx, purpose: purposeText, lifeAreas: lifeAreasCtx }}
            onConfirm={text => {
              set("oneyr_wealth_sentence", text);
              set("oneyr_wealth_confirmed", true);
            }}
          />
        </CollapsibleSegment_v2>
        {/* GROWTH -- 1-Year special: suggestions from Identity/Values + free-writing + summary */}
        <CollapsibleSegment_v2
          icon="🌱" title="Growth" color="#a78bfa"
          confirmed={!!map.oneyr_growth_confirmed}
          confirmedSummary={map.oneyr_growth_confirmed ? map.oneyr_growth_sentence : null}>
          <div style={{
            fontSize:13, color:"var(--text2)", lineHeight:1.6, marginBottom:14, marginTop:8,
            padding:"10px 14px",
            background:"rgba(255,255,255,.03)",
            borderLeft:"2px solid #a78bfa", borderRadius:4,
          }}>
            Your 1-year Growth pulls from your Identity &amp; Values alignment below.
            Accept the suggestions, edit them, or remove them and add your own.
          </div>
          <GrowthSuggestions_v2
            seeds={seeds}
            accepted={map.oneyr_growth_accepted || {}}
            setAccepted={v => set("oneyr_growth_accepted", v)}
            editedLabels={map.oneyr_growth_edited_labels || {}}
            setEditedLabels={v => set("oneyr_growth_edited_labels", v)}
            removed={map.oneyr_growth_removed || {}}
            setRemoved={v => set("oneyr_growth_removed", v)}
            custom={map.oneyr_growth_custom || []}
            setCustom={v => set("oneyr_growth_custom", v)}
          />
          <div style={{
            marginBottom:12, padding:"12px 14px",
            background:"rgba(255,255,255,.03)",
            border:"1px solid var(--border2)",
            borderLeft:"3px solid #a78bfa",
            borderRadius:6,
          }}>
            <div style={{
              fontSize:11, letterSpacing:1.5, textTransform:"uppercase",
              color:"#a78bfa", fontWeight:600, marginBottom:6,
            }}>Who you are in {year} -- write freely</div>
            <textarea
              value={map.oneyr_growth_text || ""}
              onChange={e => set("oneyr_growth_text", e.target.value)}
              placeholder="What are you becoming this year? What are you doing differently?"
              rows={4}
              style={{
                width:"100%", background:"rgba(0,0,0,.2)",
                border:"1px solid var(--border2)", borderRadius:4,
                padding:"8px 10px", color:"var(--text)",
                fontFamily:"var(--serif)", fontSize:15, outline:"none",
                resize:"vertical", lineHeight:1.55,
              }} />
          </div>
          <SummaryGenerator_v2
            color="#a78bfa"
            label="Growth"
            bottomTitle={`In one sentence, who I am in ${year}...`}
            sourceText={map.oneyr_growth_text || ""}
            existingConfirmed={map.oneyr_growth_confirmed ? map.oneyr_growth_sentence : null}
            intent="final-1yr-growth"
            voiceId={voiceId}
            name={name}
            pillar="growth"
            horizon="oneyr"
            horizonYearLabel={yearLabel}
            priorContext={{
              purpose: purposeText,
              lifeAreas: lifeAreasCtx,
              bagGrowth: map.growth_sentence || "",
              threeyrGrowth: map.threeyr_growth_sentence || "",
            }}
            onConfirm={text => {
              set("oneyr_growth_sentence", text);
              set("oneyr_growth_confirmed", true);
            }}
          />
        </CollapsibleSegment_v2>
        {/* TIER RANKING -- fresh ranking for this horizon */}
        <TierRankingSection_v2
          items={oneyrItems}
          tiers={map.oneyr_tiers || {}}
          setTiers={next => set("oneyr_tiers", next)}
          horizonLabel={String(year)}
          confirmed={!!map.oneyr_ranking_confirmed}
          onConfirmed={() => set("oneyr_ranking_confirmed", true)}
        />
      </>)}
    </div>
  );
}
// W.3: DirectionAlignmentPage -- Direction Alignment (v3.1 Page 8)
// 3 horizons × 3 tiers × N items. Per-item sliders score TODAY's reality against each priority.
// Feeds A2's Misalignment engine. This is the final page of A1.
function DirectionAlignmentPage({ map, set }) {
  const year = new Date().getFullYear();
  // Compute 1-Year seeds the same way OneYearPage does — needed for 1-Year items
  const seeds = useMemo(() => computeIdentityValuesSeeds(map, 4), [
    map.animals, map.values, map.val_count,
    JSON.stringify(Object.keys(map).filter(k => k.startsWith("align_cap_") || k.startsWith("align_val_")).reduce((o, k) => ((o[k] = map[k]), o), {})),
  ]);
  const oneyrItems  = useMemo(() => computeHorizonItems(map, "oneyr", seeds), [map, seeds]);
  const threeyrItems = useMemo(() => computeHorizonItems(map, "threeyr"), [map]);
  const bagItems    = useMemo(() => computeHorizonItems(map, "bag"), [map]);
  const totalItems = oneyrItems.length + threeyrItems.length + bagItems.length;
  return (
    <div>
      {totalItems === 0 && (
        <div style={{
          padding:"18px 20px", marginBottom:20,
          background:"rgba(201,168,76,.06)", borderLeft:"3px solid var(--warm)",
          borderRadius:8,
          fontSize:13, color:"var(--text2)", lineHeight:1.6,
        }}>
          <div style={{ fontFamily:"var(--serif)", fontSize:17, color:"var(--text)", marginBottom:8 }}>
            Complete your horizons first.
          </div>
          Build out your BAG, 3-YEAR, and 1-YEAR priorities before scoring. Once you've picked priorities and ranked them, you'll score TODAY's reality against each one here.
        </div>
      )}
      {totalItems > 0 && (<>
        <div style={{
          marginTop:18, marginBottom:18, padding:"12px 16px",
          background:"rgba(201,168,76,.08)",
          borderLeft:"3px solid var(--warm)", borderRadius:6,
          fontSize:13, color:"var(--text2)", lineHeight:1.6,
        }}>
          <strong style={{ color:"var(--warm)" }}>How to read this:</strong> Your 1-Year Non-negotiable average
          should be higher than your BAG Non-negotiable average -- because 1-year is closer to today.
          If a far-horizon Non-negotiable scores higher than a near-horizon Non-negotiable, that IS the misalignment.
        </div>
        <div style={{
          display:"grid",
          gridTemplateColumns:"repeat(auto-fit, minmax(260px, 1fr))",
          gap:14, marginTop:14, marginBottom:18,
        }}>
          <HorizonAlignmentColumn_v2
            horizonKey="oneyr"
            horizonLabel={`1-YEAR · ${year + 1}`}
            items={oneyrItems} map={map} set={set} />
          <HorizonAlignmentColumn_v2
            horizonKey="threeyr"
            horizonLabel={`3-YEAR · ${year + 3}`}
            items={threeyrItems} map={map} set={set} />
          <HorizonAlignmentColumn_v2
            horizonKey="bag"
            horizonLabel={`BAG · ${year + 12}`}
            items={bagItems} map={map} set={set} />
        </div>
      </>)}
    </div>
  );
}
// ─────────────────────────────────────────────────────────────────────────────
// OWN_IT_QUESTIONS removed -- replaced by slider-based OwnItCheck
function OwnItCheck({ context, onComplete, storageKey, purposeFinal, onFinalChange }) {
  const [open, setOpen] = useState(true);
  const [scores, setScores] = useState({ body:5, lights:5, meant:5 });
  const [missing, setMissing] = useState("");
  const [confirmed, setConfirmed] = useState(null); // null | true | false
  const [saved, setSaved] = useState(false);
  const avg = Math.round((scores.body + scores.lights + scores.meant) / 3 * 10) / 10;
  const allHigh = scores.body >= 7 && scores.lights >= 7 && scores.meant >= 7;
  const confirm = async (yes) => {
    setConfirmed(yes);
    if (yes && purposeFinal) {
      if (storageKey) await saveData(storageKey, { scores, missing, confirmed: true });
      if (onComplete) onComplete({ scores, missing, confirmed: true });
      setSaved(true);
    } else {
      if (onComplete) onComplete({ scores, missing, confirmed: false });
    }
  };
  const ScoreSlider = ({ id, label, emoji }) => {
    const val = scores[id];
    const col = val >= 8 ? "#34d399" : val >= 5 ? "#f59e0b" : "#ef4444";
    return (
      <div style={{ marginBottom:16 }}>
        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:6 }}>
          <div style={{ display:"flex", alignItems:"center", gap:7 }}>
            <span style={{ fontSize:15 }}>{emoji}</span>
            <span style={{ fontFamily:"var(--sans)", fontSize:13, color:"var(--text)" }}>{label}</span>
          </div>
          <div style={{ fontFamily:"var(--serif)", fontSize:18, fontWeight:300, color:col }}>{val}<span style={{ fontSize:11 }}>/10</span></div>
        </div>
        <input type="range" min={1} max={10} step={1} value={val}
          onChange={e => setScores(s => ({ ...s, [id]: Number(e.target.value) }))}
          style={{ accentColor:col, width:"100%" }} />
        <div style={{ display:"flex", justifyContent:"space-between", fontSize:10, color:"var(--text4)", marginTop:4 }}>
          <span style={{ color:"#ef4444" }}>1 · In the dark</span>
          {[2,3,4,5,6,7,8,9].map(n => <span key={n} style={{ opacity:0.3 }}>|</span>)}
          <span style={{ color:"#34d399" }}>10 · That's it</span>
        </div>
      </div>
    );
  };
  if (!open) return (
    <button onClick={() => setOpen(true)}
      style={{ display:"flex", alignItems:"center", gap:8, background:"none", border:"1px solid rgba(201,168,76,.22)", borderRadius:20, padding:"6px 14px", cursor:"pointer", fontFamily:"var(--sans)", fontSize:12, color:"var(--warm)", marginTop:12 }}>
      <span style={{ fontSize:10 }}>◎</span> {saved ? "✓ Purpose confirmed" : "Own It™ Check"}
    </button>
  );
  return (
    <div className="fade-in" style={{ marginTop:16, background:"rgba(232,149,109,.04)", border:"1px solid rgba(201,168,76,.2)", borderRadius:13, overflow:"hidden" }}>
      <div style={{ padding:"12px 18px", borderBottom:"1px solid rgba(201,168,76,.12)", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
        <div style={{ display:"flex", alignItems:"center", gap:10 }}>
          <div style={{ width:6, height:6, borderRadius:"50%", background:"var(--warm)", animation:"pulse 2s infinite" }} />
          <div style={{ fontFamily:"var(--sans)", fontSize:11, fontWeight:500, letterSpacing:2, textTransform:"uppercase", color:"var(--warm)" }}>Own It™ Check</div>
          {avg > 0 && (
            <div style={{ fontSize:10, color: avg >= 7 ? "#34d399" : avg >= 5 ? "#f59e0b" : "#ef4444", fontWeight:600 }}>avg {avg}/10</div>
          )}
        </div>
        <button onClick={() => setOpen(false)} style={{ background:"none", border:"none", color:"var(--text4)", cursor:"pointer", fontSize:16, padding:0, lineHeight:1 }}>×</button>
      </div>
      <div style={{ padding:"16px 18px" }}>
        {/* Instruction */}
        <div style={{ fontFamily:"var(--serif)", fontSize:14, fontStyle:"italic", color:"var(--text3)", lineHeight:1.7, marginBottom:18 }}>
          Read your purpose statement back. When I read my purpose statement...
        </div>
        {/* 3 sliders */}
        <ScoreSlider id="body"   label="Feels right in my body"             emoji="🫀" />
        <ScoreSlider id="lights" label="Lights me up"                        emoji="✨" />
        <ScoreSlider id="meant"  label="Sounds like what I'm meant to do"    emoji="🧭" />
        {/* What's missing */}
        <div style={{ marginBottom:16 }}>
          <div style={{ fontFamily:"var(--sans)", fontSize:13, fontWeight:500, color:"var(--text)", marginBottom:3 }}>What's missing or not quite right?</div>
          <div style={{ fontSize:11, color:"var(--text4)", marginBottom:7 }}>Use the Voice below for guidance -- then iterate on your statement above.</div>
          <textarea rows={3} value={missing} onChange={e => setMissing(e.target.value)}
            placeholder="What I'd change or add is..."
            className="to-field" style={{ fontSize:13 }} />
        </div>
        {/* Yes / No confirmation */}
        {confirmed === null && (
          <div style={{ padding:"13px 16px", background:"var(--bg3)", border:"1px solid var(--border2)", borderRadius:9 }}>
            <div style={{ fontFamily:"var(--sans)", fontSize:13, fontWeight:500, color:"var(--text)", marginBottom:10 }}>
              Now -- does this check all the boxes above?
            </div>
            <div style={{ display:"flex", gap:9 }}>
              <button onClick={() => confirm(true)}
                style={{ flex:1, padding:"10px", background:"rgba(52,211,153,.1)", border:"1px solid #34d399", borderRadius:8, color:"#34d399", cursor:"pointer", fontFamily:"var(--sans)", fontSize:13, fontWeight:700, transition:"all .2s" }}
                onMouseEnter={e => e.currentTarget.style.background = "rgba(52,211,153,.2)"}
                onMouseLeave={e => e.currentTarget.style.background = "rgba(52,211,153,.1)"}>
                ✓ Yes -- this is it
              </button>
              <button onClick={() => confirm(false)}
                style={{ flex:1, padding:"10px", background:"rgba(245,158,11,.08)", border:"1px solid rgba(245,158,11,.4)", borderRadius:8, color:"#f59e0b", cursor:"pointer", fontFamily:"var(--sans)", fontSize:13, fontWeight:500, transition:"all .2s" }}
                onMouseEnter={e => e.currentTarget.style.background = "rgba(245,158,11,.18)"}
                onMouseLeave={e => e.currentTarget.style.background = "rgba(245,158,11,.08)"}>
                Not yet -- still working on it
              </button>
            </div>
          </div>
        )}
        {/* Confirmed YES */}
        {confirmed === true && saved && (
          <div className="fade-in" style={{ display:"flex", alignItems:"center", justifyContent:"space-between", gap:10, padding:"9px 14px", background:"rgba(52,211,153,.06)", border:"1px solid rgba(52,211,153,.22)", borderRadius:8 }}>
            <div style={{ display:"flex", alignItems:"center", gap:8 }}>
              <span style={{ fontSize:13, color:"#34d399" }}>✓</span>
              <div style={{ fontFamily:"var(--sans)", fontSize:11, fontWeight:600, letterSpacing:0.5, color:"#34d399" }}>Confirmed -- see next step below</div>
            </div>
            <button onClick={() => { setConfirmed(null); setSaved(false); if (onComplete) onComplete({ scores, missing, confirmed: false }); }}
              style={{ background:"none", border:"1px solid var(--border2)", borderRadius:20, color:"var(--text4)", cursor:"pointer", fontFamily:"var(--sans)", fontSize:11, padding:"3px 11px", flexShrink:0 }}>
              ↺ Re-check
            </button>
          </div>
        )}
        {/* Confirmed NO */}
        {confirmed === false && (
          <div className="fade-in" style={{ padding:"13px 16px", background:"rgba(245,158,11,.06)", border:"1px solid rgba(245,158,11,.2)", borderRadius:9 }}>
            <div style={{ fontFamily:"var(--sans)", fontSize:12, color:"var(--text2)", lineHeight:1.6, marginBottom:8 }}>
              Good -- keep going. Use the notes above and ask the Voice for help refining it. Come back when it feels right.
            </div>
            <button onClick={() => setConfirmed(null)}
              style={{ background:"none", border:"1px solid var(--border2)", borderRadius:20, color:"var(--text4)", cursor:"pointer", fontFamily:"var(--sans)", fontSize:11, padding:"4px 12px" }}>
              ↺ Try again
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
// OwnItField removed -- no longer used
const TextArea = ({ value, onChange, rows, placeholder, className, style: s }) => {
  const ref = useRef(null);
  const lastVal = useRef(value);
  useEffect(() => { if (ref.current && document.activeElement !== ref.current && value !== lastVal.current) { ref.current.value = value || ""; lastVal.current = value; } }, [value]);
  const handleChange = (e) => { lastVal.current = e.target.value; onChange(e.target.value); };
  return <textarea ref={ref} rows={rows || 4} placeholder={placeholder} defaultValue={value || ""} onChange={handleChange} className={`to-field${className ? " " + className : ""}`} style={s} />;
};
const TextInput = ({ value, onChange, placeholder, style: s }) => {
  const ref = useRef(null);
  const lastVal = useRef(value);
  useEffect(() => { if (ref.current && document.activeElement !== ref.current && value !== lastVal.current) { ref.current.value = value || ""; lastVal.current = value; } }, [value]);
  const handleChange = (e) => { lastVal.current = e.target.value; onChange(e.target.value); };
  return <input type="text" ref={ref} placeholder={placeholder} defaultValue={value || ""} onChange={handleChange} className="to-field" style={{ ...(s || {}), resize:"none" }} />;
};
function VoiceDropdown({ voiceId, onSelect }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  const v = VOICES[voiceId];
  useEffect(() => { const handler = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); }; document.addEventListener("mousedown", handler); return () => document.removeEventListener("mousedown", handler); }, []);
  return (
    <div ref={ref} style={{ position:"relative" }}>
      <button onClick={() => setOpen(!open)} style={{ display:"flex", alignItems:"center", gap:7, background:v.muted, border:`1px solid ${v.border}`, borderRadius:20, padding:"5px 13px", cursor:"pointer" }}>
        <span style={{ color:v.color, fontSize:13 }}>{v.icon}</span>
        <span style={{ fontFamily:"var(--sans)", fontSize:12, color:v.color, fontWeight:700 }}>{v.short}</span>
        <span style={{ color:"var(--text4)", fontSize:9 }}>▾</span>
      </button>
      {open && (
        <div className="fade-in" style={{ position:"absolute", top:"calc(100% + 7px)", right:0, background:"var(--bg2)", border:"1px solid var(--border2)", borderRadius:12, padding:7, zIndex:300, minWidth:230, boxShadow:"0 20px 60px rgba(0,0,0,.65)" }}>
          {Object.values(VOICES).map(vv => (
            <button key={vv.id} onClick={() => { onSelect(vv.id); setOpen(false); }} style={{ display:"flex", alignItems:"center", gap:10, width:"100%", padding:"9px 11px", background:vv.id === voiceId ? vv.muted : "transparent", border:"none", borderRadius:7, cursor:"pointer", textAlign:"left" }}>
              <span style={{ color:vv.color, fontSize:14, minWidth:17 }}>{vv.icon}</span>
              <div>
                <div style={{ fontFamily:"var(--sans)", fontSize:13, color:vv.id === voiceId ? vv.color : "var(--text)", fontWeight:vv.id === voiceId ? 500 : 400 }}>{vv.label}</div>
                <div style={{ fontFamily:"var(--sans)", fontSize:11, color:"var(--text4)", marginTop:1 }}>{VOICE_DESC[vv.id].slice(0, 42)}…</div>
              </div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
function VoiceGrid({ selected, onSelect }) {
  return (
    <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:8 }}>
      {Object.values(VOICES).map(vv => (
        <button key={vv.id} onClick={() => onSelect(vv.id)} style={{ padding:"13px 14px", background:vv.id === selected ? vv.muted : "var(--bg3)", border:`1px solid ${vv.id === selected ? vv.border : "var(--border)"}`, borderRadius:10, cursor:"pointer", textAlign:"left", transition:"all .18s", fontFamily:"var(--sans)" }}>
          <div style={{ display:"flex", alignItems:"center", gap:7, marginBottom:5 }}>
            <span style={{ color:vv.color, fontSize:15 }}>{vv.icon}</span>
            <span style={{ fontSize:12, color:vv.id === selected ? vv.color : "var(--text)", fontWeight:500 }}>{vv.label}</span>
          </div>
          <div style={{ fontSize:11, color:"var(--text4)", lineHeight:1.45 }}>{VOICE_DESC[vv.id]}</div>
          {vv.id === selected && <div style={{ marginTop:7, fontSize:10, color:vv.color, fontWeight:500, letterSpacing:1, textTransform:"uppercase" }}>✓ Selected</div>}
        </button>
      ))}
    </div>
  );
}
function AIChat({ voiceId, onVoiceChange, name, intake, mapData, sectionLabel, placeholder }) {
  const [msgs, setMsgs] = useState([]);
  const [loading, setLoading] = useState(false);
  const inputRef = useRef(null);
  const bottomRef = useRef(null);
  const v = VOICES[voiceId];
  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior:"smooth" }); }, [msgs]);
  const send = async () => {
    const text = inputRef.current?.value?.trim();
    if (!text || loading) return;
    inputRef.current.value = "";
    const newMsgs = [...msgs, { role:"user", content:text }];
    setMsgs(newMsgs);
    setLoading(true);
    try {
      const history = newMsgs.slice(-8).map(m => ({ role:m.role, content:m.content }));
      const reply = await callAI(voiceId, name, intake, mapData, text, history.slice(0, -1));
      setMsgs(prev => [...prev, { role:"assistant", content:reply, vid:voiceId }]);
    } catch {
      setMsgs(prev => [...prev, { role:"assistant", content:"Something went wrong.", vid:voiceId }]);
    }
    setLoading(false);
  };
  const contextItems = [];
  if ((mapData?.purpose_layers || []).filter(l => (l||"").trim()).length > 0) contextItems.push("purpose peeling");
  if (mapData?.purpose_final || mapData?.purpose_draft) contextItems.push("purpose statement");
  if ((mapData?.life_areas || []).length > 0) contextItems.push("life priorities");
  if (mapData?.bag_growth) contextItems.push("growth vision");
  if ((mapData?.animals || []).filter(a => a.name).length > 0) contextItems.push("animals");
  if ((mapData?.values || []).filter(v => v.name).length > 0) contextItems.push("values");
  if (mapData?.align_direction !== undefined) contextItems.push("alignment scores");
  return (
    <div style={{ background:"var(--bg3)", border:"1px solid var(--border)", borderRadius:13, overflow:"hidden" }}>
      <div style={{ padding:"9px 13px", borderBottom:"1px solid var(--border)", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
        <div style={{ display:"flex", alignItems:"center", gap:7 }}>
          <div style={{ width:6, height:6, borderRadius:"50%", background:v.color, animation:"pulse 2s infinite" }} />
          <span style={{ fontFamily:"var(--sans)", fontSize:12, color:v.color, fontWeight:700 }}>{v.label}</span>
        </div>
        <VoiceDropdown voiceId={voiceId} onSelect={onVoiceChange} />
      </div>
      {contextItems.length > 0 && (
        <div style={{ padding:"7px 13px", borderBottom:"1px solid var(--border)", background:"rgba(201,168,76,.04)", display:"flex", alignItems:"center", gap:6, flexWrap:"wrap" }}>
          <span style={{ fontFamily:"var(--sans)", fontSize:10, color:"var(--text4)", letterSpacing:1, textTransform:"uppercase", flexShrink:0 }}>Katherine can see:</span>
          {contextItems.map(item => <span key={item} style={{ fontFamily:"var(--sans)", fontSize:10, color:"var(--warm)", background:"rgba(201,168,76,.1)", border:"1px solid rgba(201,168,76,.2)", borderRadius:10, padding:"2px 8px" }}>{item}</span>)}
        </div>
      )}
      {msgs.length > 0 && (
        <div style={{ maxHeight:270, overflowY:"auto", padding:"13px" }}>
          {msgs.map((m, i) => {
            const mv = m.vid ? VOICES[m.vid] : v;
            return (
              <div key={i} style={{ marginBottom:13, display:"flex", flexDirection:"column", alignItems:m.role === "user" ? "flex-end" : "flex-start" }}>
                {m.role === "user"
                  ? <div style={{ background:"var(--bg4)", border:"1px solid var(--border2)", borderRadius:"11px 11px 3px 11px", padding:"9px 13px", maxWidth:"80%", fontSize:13, color:"var(--text2)", lineHeight:1.6 }}>{m.content}</div>
                  : <div style={{ maxWidth:"90%" }}>
                      <div style={{ display:"flex", alignItems:"center", gap:5, marginBottom:5 }}>
                        <span style={{ color:mv.color, fontSize:12 }}>{mv.icon}</span>
                        <span style={{ fontSize:11, color:"var(--text4)", fontWeight:500 }}>{mv.short}</span>
                      </div>
                      <div style={{ fontFamily:"var(--serif)", fontSize:17, lineHeight:1.85, color:"var(--text)", fontWeight:300, borderLeft:`2px solid ${mv.border}`, paddingLeft:11 }}>{m.content}</div>
                    </div>
                }
              </div>
            );
          })}
          {loading && <div style={{ display:"flex", alignItems:"center", gap:7, marginBottom:13 }}><span style={{ color:v.color, fontSize:12 }}>{v.icon}</span><div className="dot-l" style={{ color:v.color }}><span /><span /><span /></div></div>}
          <div ref={bottomRef} />
        </div>
      )}
      <div style={{ padding:"9px 11px", borderTop:msgs.length > 0 ? "1px solid var(--border)" : "none", display:"flex", gap:8, alignItems:"flex-end" }}>
        <textarea ref={inputRef} rows={2}
          placeholder={placeholder || `Ask Katherine about your ${sectionLabel || "progress"}...`}
          className="to-field"
          onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }}
          style={{ flex:1, minHeight:52, fontSize:13, padding:"9px 11px", borderRadius:8 }} />
        <button onClick={send} disabled={loading} style={{ background:loading ? "var(--bg4)" : v.color, border:"none", borderRadius:8, color:loading ? "var(--text4)" : "#000", cursor:loading ? "not-allowed" : "pointer", fontSize:18, padding:"11px 15px", transition:"all .2s", lineHeight:1 }}>→</button>
      </div>
      <div style={{ fontSize:11, color:"var(--text3)", textAlign:"right", padding:"0 11px 7px" }}>Enter to send · Shift+Enter for new line</div>
    </div>
  );
}
function VideoBlock({ title, duration, points }) {
  return (
    <div className="vid-block">
      <div style={{ width:38, height:38, borderRadius:"50%", background:"rgba(201,168,76,.1)", border:"1px solid rgba(201,168,76,.22)", display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0, color:"var(--warm)", fontSize:13 }}>▶</div>
      <div style={{ flex:1 }}>
        <div style={{ display:"flex", justifyContent:"space-between", marginBottom:5 }}>
          <div style={{ fontFamily:"var(--sans)", fontSize:14, fontWeight:400, color:"#e8e4dc", lineHeight:1.3 }}>{title}</div>
          <div style={{ fontSize:11, color:"var(--text4)", flexShrink:0, marginLeft:10 }}>{duration}</div>
        </div>
        <div style={{ fontSize:11, color:"#7a9bb0", textTransform:"uppercase", letterSpacing:1.4, marginBottom:5, fontWeight:500 }}>Katherine covers:</div>
        {points.map((p, i) => (
          <div key={i} style={{ fontSize:12, color:"#9eb3c2", lineHeight:1.6, paddingLeft:9, position:"relative", marginBottom:2 }}>
            <span style={{ position:"absolute", left:0, color:"var(--warm)" }}>·</span>{p}
          </div>
        ))}
        <div style={{ marginTop:9, display:"inline-flex", alignItems:"center", gap:5, fontSize:11, color:"var(--warm)", background:"rgba(201,168,76,.07)", border:"1px solid rgba(232,149,109,.16)", borderRadius:18, padding:"3px 11px" }}>
          ▶ Video placeholder -- record to this brief
        </div>
      </div>
    </div>
  );
}
const A2_STEPS = [
  { id: "intro",        label: "Introduction" },
  { id: "dir_align",    label: "Direction Alignment" },
  { id: "iv_align",     label: "Identity & Values Alignment" },
  { id: "snapshot",     label: "Alignment Snapshot" },
  { id: "key_mis",      label: "Key Misalignment" },
  { id: "time_audit",   label: "Time Audit" },
  { id: "letter",       label: "Future Self Letter" },
  { id: "mirror",       label: "A2 Mirror" },
  { id: "map",          label: "My Map of Me™" },
];
const A2_MAP_STEP = { id: "map", label: "My Map of Me™" };
function A2({ intake, onDone, phase, setPhase }) {
  const [a2Step, setA2Step] = useState("intro");
  const [a2Done, setA2Done] = useState([]);
  const a2Goto = (s) => { setA2Step(s); window.scrollTo({ top: 0, behavior: "smooth" }); };
  useEffect(() => {
    if (a2Step === "map") {
      setA2Step("intro");
      saveData("to_mapofme_origin", "a2");
      setPhase("_mapofme");
    }
  }, [a2Step]);
  const currentLabel = [...A2_STEPS, A2_MAP_STEP].find(s => s.id === a2Step)?.label || "Align With It";

  // ─── 4a: A2 data plumbing ──────────────────────────────────────────────
  // Shares KEYS.map / KEYS.done / KEYS.voice with A1 so state flows between them.
  // a2Step is NOT restored from localStorage — it's A2's own in-memory routing.
  const [voice, setVoice] = useState(intake?.defaultVoice || "coach");
  const [done, setDone] = useState([]);
  const [map, setMap] = useState(EMPTY_MAP);
  const [ai, setAi] = useState({});
  const [busy, setBusy] = useState({});
  const [savedAt, setSavedAt] = useState(null);
  const saveTimer = useRef(null);
  const { name } = intake || {};

  useEffect(() => {
    Promise.all([loadData(KEYS.map), loadData(KEYS.done), loadData(KEYS.voice)]).then(([m, d, v]) => {
      if (m) {
        // Honor a pending target step (set by A1 "Back to A2" buttons), then clear it
        if (m.a2_pending_step) {
          const pending = m.a2_pending_step;
          const cleared = { ...m };
          delete cleared.a2_pending_step;
          setMap({ ...EMPTY_MAP, ...cleared });
          setA2Step(pending);
          saveData(KEYS.map, cleared);
        } else {
          setMap({ ...EMPTY_MAP, ...m });
        }
      }
      if (d) setDone(d);
      if (v) setVoice(v);
    });
  }, []);

  const saveMap = useCallback((next) => {
    clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(async () => { await saveData(KEYS.map, next); setSavedAt(new Date()); }, 800);
  }, []);

  const set = useCallback((key, val) => {
    setMap(prev => { const next = { ...prev, [key]: val }; saveMap(next); return next; });
  }, [saveMap]);

  const setVoicePersist = (v) => { setVoice(v); saveData(KEYS.voice, v); };
  const markDone = (s) => setDone(prev => { const n = [...new Set([...prev, s])]; saveData(KEYS.done, n); return n; });
  const runAI = async (key, prompt) => {
    setBusy(b => ({ ...b, [key]: true }));
    const r = await callStructured(prompt);
    setAi(a => ({ ...a, [key]: r }));
    setBusy(b => ({ ...b, [key]: false }));
  };
  // ─── end 4a ────────────────────────────────────────────────────────────
  const phaseTabs = (
    <div style={{ display:"flex", gap:5 }}>
      {["A1","A2","A3","A4","A5"].map((a) => {
        const key = a.toLowerCase();
        const isActive = phase === key;
        const isAvailable = key === "a1" || key === "a2" || key === "a3" || phase === "done";
        return (
          <div key={a}
            onClick={() => { if (isAvailable) setPhase(key); }}
            title={isAvailable ? (isActive ? `You are in ${a}` : `Jump to ${a}`) : `${a} coming soon`}
            style={{ width:25, height:25, borderRadius:"50%", background: isActive ? "rgba(201,168,76,.18)" : "transparent", border:`1px solid ${isActive ? "rgba(232,149,109,.55)" : "var(--border)"}`, display:"flex", alignItems:"center", justifyContent:"center", cursor: isAvailable ? "pointer" : "not-allowed", opacity: isAvailable ? 1 : 0.4 }}>
            <span style={{ fontFamily:"var(--sans)", fontSize:10, color: isActive ? "var(--warm)" : "var(--text4)", fontWeight: isActive ? 700 : 500 }}>{a}</span>
          </div>
        );
      })}
    </div>
  );
  const hdr = (
    <div style={{ borderBottom:"1px solid #1a1a16", padding:"11px 28px", display:"flex", justifyContent:"space-between", alignItems:"center", position:"sticky", top:0, background:"rgba(13,27,46,.96)", backdropFilter:"blur(12px)", zIndex:50 }}>
      <div style={{ display:"flex", alignItems:"center", gap:11 }}>
        <div style={{ width:6, height:6, borderRadius:"50%", background:"var(--warm)", animation:"pulse 3s ease-in-out infinite" }} />
        <div style={{ fontFamily:"var(--sans)", fontSize:13, fontWeight:700 }}>True Ownership™</div>
        <div style={{ fontFamily:"var(--sans)", fontSize:12, color:"var(--text4)" }}>· {intake?.name || ""}</div>
      </div>
      <div style={{ display:"flex", alignItems:"center", gap:14 }}>
        {phaseTabs}
        <AdminBar phase={phase} onAdminClick={() => setPhase("_admin")} mode="inline" />
        <AccountMenu mode="inline" />
      </div>
    </div>
  );
  const sidebar = (
    <div style={{ width:206, flexShrink:0, paddingRight:22, borderRight:"1px solid var(--border)" }}>
      <div style={{ fontSize:11, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color:"var(--text2)", marginBottom:15, fontFamily:"var(--sans)" }}>Align With It · A2</div>
      {A2_STEPS.map(s => {
        const active = a2Step === s.id;
        const isDone = a2Done.includes(s.id);
        return (
          <button key={s.id} className={`sidebar-btn${active ? " active" : ""}`} onClick={() => {
            if (s.id === "map") { saveData("to_mapofme_origin", "a2"); setPhase("_mapofme"); return; }
            a2Goto(s.id);
          }}>
            <div style={{ width:7, height:7, borderRadius:"50%", background:isDone ? "#34d399" : active ? "var(--warm)" : "var(--border2)", flexShrink:0, transition:"background .3s" }} />
            <span style={{ fontSize:12, color:active ? "var(--warm)" : isDone ? "var(--text)" : "var(--text2)", fontWeight:active ? 500 : 400, lineHeight:1.3 }}>{s.label}</span>
          </button>
        );
      })}
      <div style={{ marginTop:18, paddingTop:14, borderTop:"1px solid var(--border)" }}>
        <div style={{ fontSize:10, fontWeight:500, letterSpacing:2, textTransform:"uppercase", color:"var(--text4)", marginBottom:7, fontFamily:"var(--sans)" }}>Voice</div>
        <VoiceDropdown voiceId={voice} onSelect={setVoicePersist} />
      </div>
    </div>
  );

  const wrapA2 = (children) => (
    <>
      {hdr}
      <div style={{ display:"flex", gap:32, padding:"32px 28px 80px", maxWidth:980, margin:"0 auto" }}>
        {sidebar}
        <div style={{ flex:1, minWidth:0 }} className="fade-up">{children}</div>
      </div>
    </>
  );
  // Stub page renderer (used for all 10 pages until real content is built)
  const renderStub = (title, description) => (
    <div>
      <div style={{ fontSize:11, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color:"var(--warm)", marginBottom:11 }}>A2 · {title}</div>
      <h2 style={{ fontFamily:"var(--serif)", fontSize:38, fontWeight:300, lineHeight:1.2, marginBottom:13, letterSpacing:"-0.5px" }}>{title}</h2>
      <p style={{ fontFamily:"var(--sans)", fontSize:16, color:"var(--text2)", lineHeight:1.8, marginBottom:26, maxWidth:620 }}>{description}</p>
      <div style={{ padding:"20px 24px", background:"rgba(201,168,76,.06)", border:"1px dashed rgba(201,168,76,.3)", borderRadius:10, marginBottom:26 }}>
        <div style={{ fontSize:11, color:"var(--warm)", fontWeight:700, letterSpacing:1.5, textTransform:"uppercase", marginBottom:6 }}>Coming next</div>
        <div style={{ fontSize:13, color:"var(--text3)", lineHeight:1.6, fontStyle:"italic" }}>This page is a scaffolding stub. The real content is being built next.</div>
      </div>
      <div style={{ display:"flex", gap:8 }}>
        {a2Step !== "intro" && <button className="btn-g" onClick={() => {
          const idx = A2_STEPS.findIndex(s => s.id === a2Step);
          if (idx > 0) a2Goto(A2_STEPS[idx - 1].id);
        }}>← Back</button>}
        {a2Step !== "map" && <button className="btn" onClick={() => {
          const idx = A2_STEPS.findIndex(s => s.id === a2Step);
          if (idx >= 0 && idx < A2_STEPS.length - 1) a2Goto(A2_STEPS[idx + 1].id);
          else a2Goto("map");
        }}>Next →</button>}
        <button className="btn-g" onClick={onDone}>← Back to Map of Me™</button>
      </div>
    </div>
  );
  if (a2Step === "intro") {
    const introIdx = A2_STEPS.findIndex(s => s.id === "intro");
    const nextStep = A2_STEPS[introIdx + 1];
    return wrapA2(
      <div>
        <div style={{ fontSize:11, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color:"var(--warm)", marginBottom:11 }}>A2 · Introduction</div>
        <h2 style={{ fontFamily:"var(--serif)", fontSize:42, fontWeight:400, lineHeight:1.15, marginBottom:16, letterSpacing:"-0.5px" }}>
          <em>A1 named the pull. A2 sees the drift.</em>
        </h2>

        <p style={{ fontFamily:"var(--sans)", fontSize:15, color:"var(--text2)", lineHeight:1.85, marginBottom:14, maxWidth:620 }}>
          A1 showed you what you're moving toward. A2 shows you where your life today is pulling the other way — and where your time is going instead.
        </p>
        <p style={{ fontSize:15, color:"var(--text2)", lineHeight:1.85, marginBottom:14, maxWidth:620 }}>
          {name}, in A1 you built the Map of Me. Purpose, direction, identity, values, behaviors. That map is the life you say you're moving toward.
        </p>
        <p style={{ fontSize:15, color:"var(--text2)", lineHeight:1.85, marginBottom:24, maxWidth:620 }}>
          A2 is where we hold that map up against your life as it is today — and look honestly at the gap. Not to judge. To see. Alignment isn't about perfection; it's about <em>knowing where you actually are</em> so you can move on purpose.
        </p>

        {/* Core principle card */}
        <div style={{ padding:"18px 22px", background:"rgba(201,168,76,.07)", border:"1px solid rgba(201,168,76,.18)", borderRadius:11, marginBottom:26 }}>
          <div style={{ fontSize:10, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color:"var(--warm)", marginBottom:10, fontFamily:"var(--sans)" }}>Before we start — one principle</div>
          <div style={{ fontFamily:"var(--serif)", fontSize:17, fontStyle:"italic", color:"var(--text)", lineHeight:1.85, marginBottom:10 }}>
            "Your time is telling the truth about what you've chosen. A2 is where you let it."
          </div>
          <div style={{ fontSize:13, color:"var(--text3)", lineHeight:1.7 }}>
            You don't need to fix anything here. You just need to look. Most of the work of A2 is the looking itself — everything you build in A3, A4, and A5 stands on what you see in these ten pages.
          </div>
        </div>

        {/* What you'll do in A2 — the 10 pages, collapsible */}
        {(() => {
          const open = !!map.a2_intro_pages_open;
          return (
            <div style={{ background:"var(--bg2)", border:"1px solid var(--border)", borderRadius:11, marginBottom:26, overflow:"hidden" }}>
              <div onClick={() => set("a2_intro_pages_open", !open)}
                style={{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:"14px 22px", cursor:"pointer", userSelect:"none" }}>
                <div style={{ fontSize:10, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color:"var(--warm)", fontFamily:"var(--sans)" }}>The ten pages ahead</div>
                <span style={{ fontSize:14, color:"var(--warm)", flexShrink:0, transform: open ? "rotate(180deg)" : "none", transition:"transform .2s" }}>▾</span>
              </div>
              {open && (
                <div style={{ padding:"4px 22px 18px", borderTop:"1px solid var(--border)" }}>
                  {[
                    { icon:"🧭", label:"Direction Alignment", desc:"Score the Time priorities from your BAG, 3-year, and 1-year against today. Where is the pull strong? Where has it weakened?" },
                    { icon:"✨", label:"Identity & Values Alignment", desc:"Score each of your animals and values 1–10 on how much you're living them right now." },
                    { icon:"📊", label:"Alignment Snapshot", desc:"All your scores in one view — the shape of where your life is in line with who you said you are." },
                    { icon:"🎯", label:"Key Misalignment", desc:"The single item pulling furthest — chosen by weight across direction, identity, and values. Your A2 focus." },
                    { icon:"⏳", label:"Time Audit", desc:"Where your week actually goes. Sort it. See what's missing. Map the trades you'd need to make." },
                    { icon:"✍️", label:"Future Self Letter", desc:"A letter from ten years ahead — not generated, written by you. Four short sections. Leave a reflection at the end." },
                    { icon:"🪞", label:"A2 Mirror", desc:"Everything you've seen, gathered in one place. Confirm the direction. Decide if it's still the pull." },
                    { icon:"🗺️", label:"My Map of Me™", desc:"Your living document. One Thing at the top — one sentence, your words — and the trades you committed to carry forward." },
                  ].map((item, i, arr) => (
                    <div key={i} style={{ display:"flex", alignItems:"flex-start", gap:11, marginTop:14, marginBottom: i < arr.length - 1 ? 0 : 0 }}>
                      <span style={{ fontSize:16, flexShrink:0, marginTop:1 }}>{item.icon}</span>
                      <div>
                        <span style={{ fontFamily:"var(--sans)", fontSize:13, fontWeight:600, color:"var(--text)" }}>{item.label}</span>
                        <div style={{ fontSize:13, color:"var(--text3)", lineHeight:1.6, marginTop:2 }}>{item.desc}</div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          );
        })()}

        {/* What you walk away with */}
        <div style={{ padding:"18px 22px", background:"rgba(96,165,250,.05)", border:"1px solid rgba(96,165,250,.22)", borderLeft:"3px solid #60a5fa", borderRadius:11, marginBottom:26 }}>
          <div style={{ fontSize:10, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color:"#60a5fa", marginBottom:10, fontFamily:"var(--sans)" }}>What you walk away with</div>
          <div style={{ fontFamily:"var(--serif)", fontSize:16, fontStyle:"italic", color:"var(--text)", lineHeight:1.85, marginBottom:10 }}>
            Three things, in this order: <strong style={{ fontStyle:"normal", fontWeight:500, color:"var(--warm)" }}>the truth of where you are.</strong> The honesty about <strong style={{ fontStyle:"normal", fontWeight:500, color:"var(--warm)" }}>where the gap is biggest.</strong> And the sentence — your <strong style={{ fontStyle:"normal", fontWeight:500, color:"var(--warm)" }}>One Thing</strong> — that names who you're becoming next.
          </div>
          <div style={{ fontSize:13, color:"var(--text3)", lineHeight:1.7 }}>
            Plus a short list of trades to carry into A4, and a Future Self Letter you can re-read in 90 days.
          </div>
        </div>

        {/* Katherine's ask — tone-setter */}
        <div style={{ fontFamily:"var(--serif)", fontSize:16, fontStyle:"italic", color:"var(--text2)", lineHeight:1.85, padding:"14px 18px", borderLeft:"2px solid var(--warm)", marginBottom:28 }}>
          "Come in open. Leave the story about what you should be doing at the door. The only useful question in A2 is: <span style={{ color:"var(--warm)" }}>what's actually true about my life right now?</span>"
          <div style={{ fontFamily:"var(--sans)", fontStyle:"normal", fontSize:11, color:"var(--text4)", marginTop:8, letterSpacing:1.5, textTransform:"uppercase", fontWeight:600 }}>— Katherine</div>
        </div>

        <div style={{ marginBottom:22 }}>
          <AIChat voiceId={voice} onVoiceChange={setVoicePersist} name={name} intake={intake} mapData={map}
            sectionLabel="a2 introduction"
            placeholder="Ask Katherine what A2 is asking of you before you start..." />
        </div>

        <div style={{ marginTop:26, paddingTop:18, borderTop:"1px solid var(--border)", display:"flex", justifyContent:"flex-end", gap:8 }}>
          <button className="btn" onClick={() => { setA2Done(d => [...new Set([...d, "intro"])]); a2Goto(nextStep.id); }}>{nextStep.label} →</button>
        </div>
      </div>
    );
  }
  if (a2Step === "dir_align") {
    const dirAlignIdx = A2_STEPS.findIndex(s => s.id === "dir_align");
    const prevStep = A2_STEPS[dirAlignIdx - 1];
    const nextStep = A2_STEPS[dirAlignIdx + 1];
    const year = new Date().getFullYear();
    const seedsDA = computeIdentityValuesSeeds(map, 4);
    const oneyrItemsDA  = computeHorizonItems(map, "oneyr", seedsDA);
    const threeyrItemsDA = computeHorizonItems(map, "threeyr");
    const bagItemsDA    = computeHorizonItems(map, "bag");
    const totalItems = oneyrItemsDA.length + threeyrItemsDA.length + bagItemsDA.length;
    const tierLabel = (t) => t === "non-neg" ? "Non-neg" : t === "imp" ? "Important" : "Nice";
    const tierColor = (t) => t === "non-neg" ? "var(--warm)" : t === "imp" ? "#a78bfa" : "var(--text4)";
    const ctxBagOpen = !!map.a2_dir_ctx_bag_open;
    const ctxThreeyrOpen = !!map.a2_dir_ctx_threeyr_open;

    const ContextPane = ({ label, items, openKey, open }) => (
      <div style={{ marginBottom:10, border:"1px solid var(--border2)", borderRadius:10, overflow:"hidden", background:"rgba(255,255,255,.02)" }}>
        <div onClick={() => set(openKey, !open)}
          style={{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:"11px 16px", cursor:"pointer", userSelect:"none" }}>
          <div style={{ display:"flex", alignItems:"center", gap:8 }}>
            <span style={{ fontSize:10, letterSpacing:1.5, textTransform:"uppercase", fontWeight:700, color:"var(--text3)" }}>{label}</span>
            <span style={{ fontSize:10, color:"var(--text4)" }}>· {items.length} priorit{items.length === 1 ? "y" : "ies"}</span>
          </div>
          <span style={{ fontSize:12, color:"var(--text4)", transform: open ? "rotate(180deg)" : "none", transition:"transform .2s" }}>▾</span>
        </div>
        {open && items.length > 0 && (
          <div style={{ padding:"10px 16px 14px", borderTop:"1px solid var(--border)" }}>
            {items.map(it => (
              <div key={it.id} style={{ display:"flex", alignItems:"center", gap:8, marginBottom:5, fontSize:12, color:"var(--text2)" }}>
                <span style={{ fontSize:13, flexShrink:0 }}>{it.icon}</span>
                <span style={{ flex:1, minWidth:0, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{it.label}</span>
                <span style={{ fontSize:9, padding:"2px 7px", borderRadius:10, color: tierColor(it.tier), border:`1px solid ${tierColor(it.tier)}`, fontWeight:700, letterSpacing:0.5, textTransform:"uppercase", flexShrink:0 }}>
                  {tierLabel(it.tier)}
                </span>
              </div>
            ))}
          </div>
        )}
        {open && items.length === 0 && (
          <div style={{ padding:"10px 16px 14px", borderTop:"1px solid var(--border)", fontSize:11, color:"var(--text4)", fontStyle:"italic" }}>
            Nothing captured for this horizon in A1.
          </div>
        )}
      </div>
    );

    return wrapA2(
      <div>
        <DirectionTimeline_v2 map={map} />
        <div style={{ fontSize:11, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color:"var(--warm)", marginBottom:11 }}>A2 · Direction Alignment</div>
        <h2 style={{ fontFamily:"var(--serif)", fontSize:34, fontWeight:400, lineHeight:1.2, marginBottom:7, letterSpacing:"-0.3px" }}>1-YEAR Alignment · {year + 1}</h2>
        <p style={{ fontSize:16, color:"var(--text2)", lineHeight:1.75, marginBottom:10, maxWidth:600 }}>
          Your daily actions reveal 1-year alignment most honestly. Today's hours either ladder up to this year — or they don't.
        </p>
        <p style={{ fontSize:13, color:"var(--text3)", lineHeight:1.7, marginBottom:22, maxWidth:600, fontStyle:"italic" }}>
          BAG and 3-year are aspirational distance markers — they don't have a clean "am I living this today?" test, so we don't score them here. They sit above as context.
        </p>

        {totalItems === 0 ? (
          <div style={{
            padding:"18px 20px", marginBottom:20,
            background:"rgba(201,168,76,.06)", borderLeft:"3px solid var(--warm)", borderRadius:8,
            fontSize:13, color:"var(--text2)", lineHeight:1.6,
          }}>
            <div style={{ fontFamily:"var(--serif)", fontSize:17, color:"var(--text)", marginBottom:8 }}>
              Complete your horizons first.
            </div>
            Build out your BAG, 3-YEAR, and 1-YEAR priorities in A1 before scoring.
          </div>
        ) : (
          <>
            {/* Context: BAG + 3-Year (read-only) */}
            <div style={{ marginBottom:26 }}>
              <div style={{ fontSize:10, letterSpacing:2, textTransform:"uppercase", color:"var(--text3)", fontWeight:700, marginBottom:10 }}>
                Your distance markers · from A1
              </div>
              <ContextPane label={`BAG · ${year + 12}`}    items={bagItemsDA}    openKey="a2_dir_ctx_bag_open"    open={ctxBagOpen} />
              <ContextPane label={`3-YEAR · ${year + 3}`}  items={threeyrItemsDA} openKey="a2_dir_ctx_threeyr_open" open={ctxThreeyrOpen} />
            </div>

            {/* Active: 1-Year scoring */}
            <div style={{ marginBottom:22 }}>
              <div style={{ fontSize:10, letterSpacing:2, textTransform:"uppercase", color:"var(--warm)", fontWeight:700, marginBottom:10 }}>
                This is where we score · 1-Year
              </div>
              {oneyrItemsDA.length > 0 ? (
                <HorizonAlignmentColumn_v2
                  horizonKey="oneyr"
                  horizonLabel={`1-YEAR · ${year + 1}`}
                  items={oneyrItemsDA}
                  map={map} set={set} />
              ) : (
                <div style={{ padding:"14px 18px", background:"rgba(255,255,255,.02)", border:"1px dashed var(--border2)", borderRadius:8, fontSize:14, color:"var(--text3)", fontStyle:"italic" }}>
                  Build your 1-Year priorities in A1 before scoring.
                </div>
              )}
            </div>
          </>
        )}

        <div style={{ marginBottom:22, marginTop:18 }}>
          <AIChat voiceId={voice} onVoiceChange={setVoicePersist} name={name} intake={intake} mapData={map}
            sectionLabel="direction alignment"
            placeholder="Ask Katherine about the gaps between today and your 1-year..." />
        </div>
        <div style={{ marginTop:26, paddingTop:18, borderTop:"1px solid var(--border)", display:"flex", justifyContent:"space-between", gap:8 }}>
          <button className="btn-g" onClick={() => a2Goto(prevStep.id)}>← {prevStep.label}</button>
          <button className="btn" onClick={() => { setA2Done(d => [...new Set([...d, "dir_align"])]); a2Goto(nextStep.id); }}>{nextStep.label} →</button>
        </div>
      </div>
    );
  }
  if (a2Step === "iv_align") {
    const ivIdx = A2_STEPS.findIndex(s => s.id === "iv_align");
    const prevStep = A2_STEPS[ivIdx - 1];
    const nextStep = A2_STEPS[ivIdx + 1];
    const animals = (map.animals || []).filter(a => a && a.name);
    const valCount = parseInt(map?.val_count) || (map?.values || []).filter(v => v && v.name).length || 0;
    const scoreColor = (s) => s >= 7 ? "#34d399" : s >= 4 ? "#f59e0b" : "#ef4444";
    const totalAnimals = animals.length;
    const totalValues = (() => {
      let count = 0;
      for (let i = 0; i < valCount; i++) {
        const name = map?.[`val_${i}_name`] || (map?.values || [])[i]?.name;
        if (name) count++;
      }
      return count;
    })();

    return wrapA2(
      <div>
        <div style={{ fontSize:11, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color:"var(--warm)", marginBottom:11 }}>A2 · Identity & Values Alignment</div>
        <h2 style={{ fontFamily:"var(--serif)", fontSize:34, fontWeight:400, lineHeight:1.2, marginBottom:7, letterSpacing:"-0.3px" }}>Identity &amp; Values Alignment</h2>
        <p style={{ fontSize:16, color:"var(--text2)", lineHeight:1.75, marginBottom:20, maxWidth:560 }}>
          You named who you are and what you stand for in A1. Now score how fully you're living each one today. The gaps are the data — not the judgment.
        </p>

        {totalAnimals === 0 && totalValues === 0 && (
          <div style={{ padding:"18px 20px", marginBottom:20, background:"rgba(201,168,76,.06)", borderLeft:"3px solid var(--warm)", borderRadius:8, fontSize:13, color:"var(--text2)", lineHeight:1.6 }}>
            <div style={{ fontFamily:"var(--serif)", fontSize:17, color:"var(--text)", marginBottom:8 }}>Go back to A1 first.</div>
            Complete your animals + capabilities (Identity · Superpowers) and your values + behaviors (Values · Behaviors) before scoring alignment here.
          </div>
        )}

        {/* IDENTITY section */}
        {totalAnimals > 0 && (
          <div style={{ marginBottom:28 }}>
            <div style={{ display:"flex", alignItems:"baseline", gap:10, marginBottom:14, paddingBottom:8, borderBottom:"1px solid var(--border)" }}>
              <span style={{ fontSize:18 }}>🦁</span>
              <div style={{ fontFamily:"var(--sans)", fontSize:15, fontWeight:700, color:"var(--text)", letterSpacing:0.3 }}>Identity</div>
              <div style={{ fontSize:11, color:"var(--text4)", fontStyle:"italic" }}>Your animals and their superpowers</div>
              <button onClick={async () => {
                set("return_to_a2", "iv_align");
                await saveData(KEYS.step, "mirror2");
                await saveData(KEYS.phase, "a1");
                set("mirror2_sub", "pressure");
                setPhase("a1");
              }}
                style={{ marginLeft:"auto", padding:"5px 11px", borderRadius:12, background:"transparent", color:"var(--warm)", border:"1px solid var(--warm)", cursor:"pointer", fontSize:11, flexShrink:0 }}>
                See what you wrote →
              </button>
            </div>
            {animals.map((animal, i) => {
              const animalLabel = [animal.adj1, animal.adj2, animal.name].filter(Boolean).join(" ");
              const caps = (animal.capabilities || []).filter(c => c && c.name);
              const openKey = `a2_iv_animal_${i}_open`;
              const isOpen = map?.[openKey] !== false;
              const scores = caps.map((_, ci) => (map?.[`align_cap_${i}_${ci}`] ?? 5));
              const avg = caps.length > 0 ? (scores.reduce((a,b) => a+b, 0) / caps.length).toFixed(1) : null;
              const avgCol = avg !== null ? scoreColor(parseFloat(avg)) : "var(--warm)";
              return (
                <div key={i} style={{ marginBottom:14, border:"1px solid var(--border2)", borderRadius:10, overflow:"hidden" }}>
                  <div onClick={() => set(openKey, !isOpen)}
                    style={{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:"14px 18px", background:"var(--bg3)", cursor:"pointer", userSelect:"none" }}>
                    <div style={{ fontFamily:"var(--serif)", fontSize:16, fontStyle:"italic", color:"var(--warm)" }}>{animalLabel}</div>
                    <div style={{ display:"flex", alignItems:"center", gap:10 }}>
                      {avg && <span style={{ fontSize:13, fontWeight:700, color:avgCol }}>Avg {avg}/10</span>}
                      <span style={{ fontSize:14, color:"var(--text3)", transform: isOpen ? "rotate(180deg)" : "none", transition:"transform .2s" }}>▾</span>
                    </div>
                  </div>
                  {isOpen && (
                    <div style={{ padding:"16px 18px", borderTop:"1px solid var(--border)" }}>
                      <div style={{ fontSize:10, fontWeight:700, letterSpacing:1.5, textTransform:"uppercase", color:"#a78bfa", marginBottom:10 }}>Superpowers</div>
                      {caps.length === 0 ? (
                        <div style={{ fontSize:12, color:"var(--text4)", fontStyle:"italic", lineHeight:1.5 }}>
                          Go to A1 · Identity · Superpowers to add superpowers for this animal.
                        </div>
                      ) : caps.map((cap, ci) => {
                        const storeKey = `align_cap_${i}_${ci}`;
                        const score = map?.[storeKey] ?? 5;
                        const col = scoreColor(score);
                        return (
                          <div key={ci} style={{ marginBottom:14 }}>
                            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:4 }}>
                              <span style={{ fontSize:12, fontWeight:600, color:"var(--text)" }}>{cap.name}</span>
                              <span style={{ fontSize:13, fontWeight:700, color:col }}>{score}/10</span>
                            </div>
                            <input type="range" min={1} max={10} step={1} value={score}
                              onChange={e => set(storeKey, Number(e.target.value))}
                              style={{ width:"100%", accentColor:col }} />
                            <div style={{ display:"flex", justifyContent:"space-between", fontSize:10, marginTop:2 }}>
                              <span style={{ color:"#ef4444" }}>1 = living far from this</span>
                              <span style={{ color:"#34d399" }}>10 = fully embodying this</span>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {/* VALUES section */}
        {totalValues > 0 && (
          <div style={{ marginBottom:28 }}>
            <div style={{ display:"flex", alignItems:"baseline", gap:10, marginBottom:14, paddingBottom:8, borderBottom:"1px solid var(--border)" }}>
              <span style={{ fontSize:18 }}>⚖️</span>
              <div style={{ fontFamily:"var(--sans)", fontSize:15, fontWeight:700, color:"var(--text)", letterSpacing:0.3 }}>Values</div>
              <div style={{ fontSize:11, color:"var(--text4)", fontStyle:"italic" }}>What you stand for and the behaviors that prove it</div>
              <button onClick={async () => {
                set("return_to_a2", "iv_align");
                await saveData(KEYS.step, "mirror3");
                await saveData(KEYS.phase, "a1");
                set("mirror3_sub", "behaviors");
                setPhase("a1");
              }}
                style={{ marginLeft:"auto", padding:"5px 11px", borderRadius:12, background:"transparent", color:"var(--warm)", border:"1px solid var(--warm)", cursor:"pointer", fontSize:11, flexShrink:0 }}>
                See what you wrote →
              </button>
            </div>
            {Array.from({ length: valCount }).map((_, i) => {
              const vName = map?.[`val_${i}_name`] || (map?.values || [])[i]?.name || "";
              if (!vName) return null;
              const vSummary = map?.[`val_${i}_summary`] || "";
              const bCount = parseInt(map?.[`beh_${i}_count`]) || 0;
              const behs = [];
              for (let j = 0; j < bCount; j++) {
                const bn = map?.[`beh_${i}_${j}_name`];
                if (bn) behs.push({ j, name: bn });
              }
              const openKey = `a2_iv_val_${i}_open`;
              const isOpen = map?.[openKey] !== false;
              const scores = behs.map(({ j }) => (map?.[`align_val_${i}_beh_${j}`] ?? 5));
              const avg = behs.length > 0 ? (scores.reduce((a,b) => a+b, 0) / behs.length).toFixed(1) : null;
              const avgCol = avg !== null ? scoreColor(parseFloat(avg)) : "#34d399";
              return (
                <div key={i} style={{ marginBottom:14, border:"1px solid var(--border2)", borderRadius:10, overflow:"hidden" }}>
                  <div onClick={() => set(openKey, !isOpen)}
                    style={{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:"14px 18px", background:"var(--bg3)", cursor:"pointer", userSelect:"none" }}>
                    <div style={{ fontFamily:"var(--serif)", fontSize:16, fontStyle:"italic", color:"#34d399" }}>"{vName}"</div>
                    <div style={{ display:"flex", alignItems:"center", gap:10 }}>
                      {avg && <span style={{ fontSize:13, fontWeight:700, color:avgCol }}>Avg {avg}/10</span>}
                      <span style={{ fontSize:14, color:"var(--text3)", transform: isOpen ? "rotate(180deg)" : "none", transition:"transform .2s" }}>▾</span>
                    </div>
                  </div>
                  {isOpen && (
                    <div style={{ padding:"16px 18px", borderTop:"1px solid var(--border)" }}>
                      <div style={{ fontSize:10, fontWeight:700, letterSpacing:1.5, textTransform:"uppercase", color:"#a78bfa", marginBottom:10 }}>Behaviors</div>
                      {vSummary && <div style={{ fontSize:12, fontStyle:"italic", color:"var(--text3)", lineHeight:1.5, marginBottom:12 }}>{vSummary}</div>}
                      {behs.length === 0 ? (
                        <div style={{ fontSize:12, color:"var(--text4)", fontStyle:"italic", lineHeight:1.5 }}>
                          Go to A1 · Values · Behaviors to add behaviors for this value.
                        </div>
                      ) : behs.map(({ j, name }) => {
                        const storeKey = `align_val_${i}_beh_${j}`;
                        const score = map?.[storeKey] ?? 5;
                        const col = scoreColor(score);
                        return (
                          <div key={j} style={{ marginBottom:14 }}>
                            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:4 }}>
                              <span style={{ fontSize:12, fontWeight:600, color:"var(--text)" }}>{name}</span>
                              <span style={{ fontSize:13, fontWeight:700, color:col }}>{score}/10</span>
                            </div>
                            <input type="range" min={1} max={10} step={1} value={score}
                              onChange={e => set(storeKey, Number(e.target.value))}
                              style={{ width:"100%", accentColor:col }} />
                            <div style={{ display:"flex", justifyContent:"space-between", fontSize:10, marginTop:2 }}>
                              <span style={{ color:"#ef4444" }}>1 = living far from this</span>
                              <span style={{ color:"#34d399" }}>10 = fully embodying this</span>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        <div style={{ marginBottom:22, marginTop:8 }}>
          <AIChat voiceId={voice} onVoiceChange={setVoicePersist} name={name} intake={intake} mapData={map}
            sectionLabel="identity and values alignment"
            placeholder="Ask Katherine about the gap between who you are and how you're living..." />
        </div>

        <div style={{ marginTop:26, paddingTop:18, borderTop:"1px solid var(--border)", display:"flex", justifyContent:"space-between", gap:8 }}>
          <button className="btn-g" onClick={() => a2Goto(prevStep.id)}>← {prevStep.label}</button>
          <button className="btn" onClick={() => { setA2Done(d => [...new Set([...d, "iv_align"])]); a2Goto(nextStep.id); }}>{nextStep.label} →</button>
        </div>
      </div>
    );
  }
  if (a2Step === "snapshot") {
    const snapIdx = A2_STEPS.findIndex(s => s.id === "snapshot");
    const prevStep = A2_STEPS[snapIdx - 1];
    const nextStep = A2_STEPS[snapIdx + 1];

    // Helpers matching A1's Alignment Check
    const AlignSlider = ({ storeKey, label, desc, color="#c9a84c", indent=false }) => {
      const val = map[storeKey] !== undefined ? map[storeKey] : 5;
      const col = val >= 7 ? "#34d399" : val >= 4 ? "#f59e0b" : "#ef4444";
      return (
        <div style={{ marginBottom:10, paddingLeft: indent ? 14 : 0, borderLeft: indent ? "2px solid var(--border2)" : "none" }}>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:4 }}>
            <div>
              <div style={{ fontSize: indent ? 12 : 13, fontWeight: indent ? 400 : 600, color: indent ? "var(--text2)" : "var(--text)" }}>{label}</div>
              {desc && <div style={{ fontSize:11, color:"var(--text4)", marginTop:1 }}>{desc}</div>}
            </div>
            <div style={{ fontFamily:"var(--serif)", fontSize: indent ? 16 : 19, fontWeight:300, color:col, flexShrink:0, marginLeft:12 }}>{val}<span style={{ fontSize:10 }}>/10</span></div>
          </div>
          <input type="range" min={0} max={10} step={1} value={val}
            onChange={e => set(storeKey, Number(e.target.value))}
            style={{ accentColor:col, width:"100%" }} />
          <div style={{ fontSize:10, color:"var(--text4)", marginTop:2 }}>
            {val >= 8 ? "Strong alignment" : val >= 5 ? "Partial -- something in the way" : "Low -- needs attention"}
          </div>
        </div>
      );
    };
    const ScoreRow = ({ storeKey, label, desc, indent=false, defaultVal=5 }) => {
      const val = map[storeKey] !== undefined ? map[storeKey] : defaultVal;
      const col = val >= 7 ? "#34d399" : val >= 4 ? "#f59e0b" : "#ef4444";
      const isScored = map[storeKey] !== undefined;
      return (
        <div style={{ marginBottom:8, paddingLeft: indent ? 14 : 0, borderLeft: indent ? "2px solid var(--border2)" : "none" }}>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", gap:12 }}>
            <div style={{ minWidth:0, flex:1 }}>
              <div style={{ fontSize: indent ? 12 : 13, fontWeight: indent ? 400 : 600, color: indent ? "var(--text2)" : "var(--text)" }}>{label}</div>
              {desc && <div style={{ fontSize:11, color:"var(--text4)", marginTop:1 }}>{desc}</div>}
            </div>
            {isScored ? (
              <div style={{ fontFamily:"var(--serif)", fontSize:18, fontWeight:300, color:col, flexShrink:0 }}>{val}<span style={{ fontSize:10 }}>/10</span></div>
            ) : (
              <div style={{ fontSize:10, color:"var(--text4)", fontStyle:"italic", flexShrink:0 }}>not scored</div>
            )}
          </div>
        </div>
      );
    };
    const AvgBadge = ({ scores }) => {
      const valid = scores.filter(s => s !== undefined && s !== null);
      if (valid.length === 0) return null;
      const avg = Math.round(valid.reduce((a,b) => a+b, 0) / valid.length * 10) / 10;
      const col = avg >= 7 ? "#34d399" : avg >= 4 ? "#f59e0b" : "#ef4444";
      return (
        <div style={{ display:"inline-flex", alignItems:"center", gap:5, padding:"3px 10px", background:`rgba(${avg >= 7 ? "52,211,153" : avg >= 4 ? "245,158,11" : "239,68,68"},.1)`, border:`1px solid ${col}`, borderRadius:20, marginLeft:10 }}>
          <span style={{ fontSize:11, fontWeight:700, color:col }}>avg {avg}/10</span>
        </div>
      );
    };

    // --- DIRECTION data (1-Year only — uses A2 Direction Alignment scores) ---
    const seedsSnap = computeIdentityValuesSeeds(map, 4);
    const oneyrItemsSnap = computeHorizonItems(map, "oneyr", seedsSnap);
    const oneyrTimeItems   = oneyrItemsSnap.filter(i => i.segment === "Time");
    const oneyrWealthItems = oneyrItemsSnap.filter(i => i.segment === "Wealth");
    const oneyrGrowthItems = oneyrItemsSnap.filter(i => i.segment === "Growth");
    const dirScores = oneyrItemsSnap
      .map(i => map[`dir_align_oneyr_${i.id}`])
      .filter(s => s !== undefined);

    // --- IDENTITY data ---
    const animals = (map.animals || []).filter(a => a && a.name);
    const spScores = animals.flatMap((a, i) => {
      const caps = (a.capabilities || []).filter(c => c.name);
      return caps.map((_, ci) => map[`align_cap_${i}_${ci}`]).filter(s => s !== undefined);
    });

    // --- VALUES data ---
    const valCount = parseInt(map?.val_count) || (map?.values || []).filter(v => v && v.name).length || 0;
    const valueRows = Array.from({ length: valCount }).map((_, i) => {
      const vName = map?.[`val_${i}_name`] || (map?.values || [])[i]?.name || "";
      const bCount = parseInt(map?.[`beh_${i}_count`]) || 0;
      const behs = [];
      for (let j = 0; j < bCount; j++) {
        const bn = map?.[`beh_${i}_${j}_name`];
        if (bn) behs.push({ j, name: bn });
      }
      return { i, name: vName, behs, summary: map?.[`val_${i}_summary`] || "" };
    }).filter(r => r.name);
    const bhvScores = valueRows.flatMap(r =>
      r.behs.map(({ j }) => map[`align_val_${r.i}_beh_${j}`]).filter(s => s !== undefined)
    );

    return wrapA2(
      <div>
        <div style={{ fontSize:11, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color:"var(--warm)", marginBottom:11 }}>A2 · Alignment Snapshot</div>
        <h2 style={{ fontFamily:"var(--serif)", fontSize:34, fontWeight:400, lineHeight:1.2, marginBottom:7, letterSpacing:"-0.3px" }}>Your <em>Alignment Snapshot</em></h2>
        <p style={{ fontSize:16, color:"var(--text2)", lineHeight:1.8, marginBottom:26, maxWidth:520 }}>This isn't about doing everything — it's about finding the one shift that will most change who you are, how you show up, and the direction of your life.</p>

        {/* ── PURPOSE · DIRECTION ── */}
        {(() => { const isOpen = map?.a2_snap_dir_open !== false; return (
        <div style={{ background:"var(--bg2)", border:"1px solid var(--border)", borderRadius:11, marginBottom:14, overflow:"hidden" }}>
          <div onClick={() => set("a2_snap_dir_open", !isOpen)}
            style={{ padding:"13px 18px", borderBottom: isOpen ? "1px solid var(--border)" : "none", display:"flex", alignItems:"center", gap:9, cursor:"pointer", userSelect:"none" }}>
            <span style={{ fontSize:17 }}>⛰️</span>
            <span style={{ fontFamily:"var(--sans)", fontSize:14, fontWeight:700, color:"var(--text)" }}>Purpose · Direction</span>
            <AvgBadge scores={dirScores} />
            <span style={{ marginLeft:"auto", fontSize:14, color:"var(--text3)", transform: isOpen ? "rotate(180deg)" : "none", transition:"transform .2s" }}>▾</span>
          </div>
          {isOpen && (<div style={{ padding:"14px 18px" }}>
            <div style={{ fontSize:11, color:"var(--text4)", fontStyle:"italic", marginBottom:14, padding:"6px 10px", background:"rgba(0,0,0,.2)", borderRadius:6 }}>
              Read-only view of your 1-Year scores. To adjust, return to Direction Alignment.
            </div>
            {/* Time priorities */}
            <div style={{ marginBottom:16 }}>
              <div style={{ display:"flex", alignItems:"center", gap:9, marginBottom:10, padding:"8px 12px", background:"var(--bg3)", borderRadius:8 }}>
                <div style={{ fontFamily:"var(--serif)", fontSize:15, fontStyle:"italic", color:"var(--warm)" }}>⏳ Time Priorities</div>
                {oneyrTimeItems.length > 0 && <AvgBadge scores={oneyrTimeItems.map(it => map[`dir_align_oneyr_${it.id}`]).filter(s => s !== undefined)} />}
              </div>
              {oneyrTimeItems.length === 0 && (
                <div style={{ fontSize:12, color:"var(--text4)", fontStyle:"italic", padding:"8px 0" }}>No 1-YEAR time priorities — go to A1 Direction · 1-YEAR to add them.</div>
              )}
              {oneyrTimeItems.map((it) => (
                <ScoreRow key={it.id}
                  storeKey={`dir_align_oneyr_${it.id}`}
                  label={`${it.icon} ${it.label}`.trim()}
                  indent={true} />
              ))}
            </div>
            {/* Wealth */}
            <div style={{ marginBottom:16 }}>
              <div style={{ display:"flex", alignItems:"center", gap:9, marginBottom:10, padding:"8px 12px", background:"var(--bg3)", borderRadius:8 }}>
                <div style={{ fontFamily:"var(--serif)", fontSize:15, fontStyle:"italic", color:"var(--warm)" }}>💰 Wealth</div>
                {oneyrWealthItems.length > 0 && <AvgBadge scores={oneyrWealthItems.map(it => map[`dir_align_oneyr_${it.id}`]).filter(s => s !== undefined)} />}
              </div>
              {oneyrWealthItems.length === 0 && (
                <div style={{ fontSize:12, color:"var(--text4)", fontStyle:"italic", padding:"8px 0" }}>No 1-YEAR wealth items.</div>
              )}
              {oneyrWealthItems.map(it => (
                <ScoreRow key={it.id}
                  storeKey={`dir_align_oneyr_${it.id}`}
                  label={`${it.icon} ${it.label}`.trim()}
                  indent={true} />
              ))}
            </div>
            {/* Growth */}
            <div>
              <div style={{ display:"flex", alignItems:"center", gap:9, marginBottom:10, padding:"8px 12px", background:"var(--bg3)", borderRadius:8 }}>
                <div style={{ fontFamily:"var(--serif)", fontSize:15, fontStyle:"italic", color:"var(--warm)" }}>🌱 Growth</div>
                {oneyrGrowthItems.length > 0 && <AvgBadge scores={oneyrGrowthItems.map(it => map[`dir_align_oneyr_${it.id}`]).filter(s => s !== undefined)} />}
              </div>
              {oneyrGrowthItems.length === 0 ? (
                <div style={{ fontSize:12, color:"var(--text4)", fontStyle:"italic", padding:"8px 0" }}>No 1-YEAR growth items.</div>
              ) : (
                oneyrGrowthItems.map(it => (
                  <ScoreRow key={it.id}
                    storeKey={`dir_align_oneyr_${it.id}`}
                    label={`${it.icon} ${it.label}`.trim()}
                    indent={true} />
                ))
              )}
            </div>
          </div>)}
        </div>
        ); })()}

        {/* ── IDENTITY · SUPERPOWERS ── */}
        {(() => { const isOpen = map?.a2_snap_sup_open !== false; return (
        <div style={{ background:"var(--bg2)", border:"1px solid var(--border)", borderRadius:11, marginBottom:14, overflow:"hidden" }}>
          <div onClick={() => set("a2_snap_sup_open", !isOpen)}
            style={{ padding:"13px 18px", borderBottom: isOpen ? "1px solid var(--border)" : "none", display:"flex", alignItems:"center", gap:9, cursor:"pointer", userSelect:"none" }}>
            <span style={{ fontSize:17 }}>⚡</span>
            <span style={{ fontFamily:"var(--sans)", fontSize:14, fontWeight:700, color:"var(--text)" }}>Identity · Superpowers</span>
            <AvgBadge scores={spScores} />
            <span style={{ marginLeft:"auto", fontSize:14, color:"var(--text3)", transform: isOpen ? "rotate(180deg)" : "none", transition:"transform .2s" }}>▾</span>
          </div>
          {isOpen && (<div style={{ padding:"14px 18px" }}>
            {animals.length === 0 && (
              <div style={{ fontSize:12, color:"var(--text4)", fontStyle:"italic" }}>No animals set yet -- go back to A1 Identity to add them.</div>
            )}
            {animals.map((a, i) => {
              const capList = (a.capabilities || []).filter(c => c.name);
              const animalScores = capList.map((_, ci) => map[`align_cap_${i}_${ci}`]).filter(s => s !== undefined);
              const pressureText = a.under_pressure || "";
              return (
                <div key={i} style={{ marginBottom:18 }}>
                  <div style={{ display:"flex", alignItems:"center", gap:9, marginBottom:10, padding:"8px 12px", background:"var(--bg3)", borderRadius:8 }}>
                    <div style={{ fontFamily:"var(--serif)", fontSize:15, fontStyle:"italic", color:"var(--warm)" }}>"{[a.adj1, a.adj2, a.name].filter(Boolean).join(" ")}"</div>
                    <AvgBadge scores={animalScores} />
                  </div>
                  {capList.length === 0 ? (
                    <div style={{ fontSize:12, color:"var(--text4)", fontStyle:"italic", paddingLeft:14, borderLeft:"2px solid var(--border2)" }}>
                      Go to A1 · Identity · Superpowers and add superpowers for this animal.
                    </div>
                  ) : (
                    <div>
                      {capList.map((cap, ci) => (
                        <ScoreRow key={ci}
                          storeKey={`align_cap_${i}_${ci}`}
                          label={cap.name}
                          desc={cap.description || ""}
                          indent={true} />
                      ))}
                      {pressureText && (
                        <div style={{ padding:"8px 12px", background:"rgba(239,68,68,.05)", border:"1px solid rgba(239,68,68,.15)", borderRadius:7, marginTop:6, marginLeft:14 }}>
                          <div style={{ fontSize:10, fontWeight:700, letterSpacing:1, textTransform:"uppercase", color:"#ef4444", marginBottom:3 }}>Under Pressure</div>
                          <div style={{ fontSize:11, color:"var(--text3)", lineHeight:1.5 }}>{pressureText}</div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>)}
        </div>
        ); })()}

        {/* ── VALUES · BEHAVIORS ── */}
        {(() => { const isOpen = map?.a2_snap_beh_open !== false; return (
        <div style={{ background:"var(--bg2)", border:"1px solid var(--border)", borderRadius:11, marginBottom:22, overflow:"hidden" }}>
          <div onClick={() => set("a2_snap_beh_open", !isOpen)}
            style={{ padding:"13px 18px", borderBottom: isOpen ? "1px solid var(--border)" : "none", display:"flex", alignItems:"center", gap:9, cursor:"pointer", userSelect:"none" }}>
            <span style={{ fontSize:17 }}>🎯</span>
            <span style={{ fontFamily:"var(--sans)", fontSize:14, fontWeight:700, color:"var(--text)" }}>Values · Behaviors</span>
            <AvgBadge scores={bhvScores} />
            <span style={{ marginLeft:"auto", fontSize:14, color:"var(--text3)", transform: isOpen ? "rotate(180deg)" : "none", transition:"transform .2s" }}>▾</span>
          </div>
          {isOpen && (<div style={{ padding:"14px 18px" }}>
            {valueRows.length === 0 && (
              <div style={{ fontSize:12, color:"var(--text4)", fontStyle:"italic" }}>No values set yet -- go back to A1 Values · Behaviors to add them.</div>
            )}
            {valueRows.map(row => {
              const valScores = row.behs.map(({ j }) => map[`align_val_${row.i}_beh_${j}`]).filter(s => s !== undefined);
              return (
                <div key={row.i} style={{ marginBottom:18 }}>
                  <div style={{ display:"flex", alignItems:"center", gap:9, marginBottom:10, padding:"8px 12px", background:"var(--bg3)", borderRadius:8 }}>
                    <div style={{ fontFamily:"var(--serif)", fontSize:15, fontStyle:"italic", color:"var(--warm)" }}>"{row.name}"</div>
                    <AvgBadge scores={valScores} />
                  </div>
                  {row.summary && (
                    <div style={{ fontSize:14, color:"var(--text3)", fontStyle:"italic", paddingLeft:14, marginBottom:8, borderLeft:"2px solid rgba(52,211,153,.3)" }}>{row.summary}</div>
                  )}
                  {row.behs.length === 0 ? (
                    <div style={{ fontSize:12, color:"var(--text4)", fontStyle:"italic", paddingLeft:14, borderLeft:"2px solid var(--border2)" }}>
                      No behaviors defined yet -- go to A1 Values · Behaviors · Step 2 to add them.
                    </div>
                  ) : (
                    <div>
                      {row.behs.map(({ j, name }) => (
                        <ScoreRow key={j}
                          storeKey={`align_val_${row.i}_beh_${j}`}
                          label={name}
                          indent={true} />
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>)}
        </div>
        ); })()}

        <div style={{ marginBottom:22 }}>
          <AIChat voiceId={voice} onVoiceChange={setVoicePersist} name={name} intake={intake} mapData={map}
            sectionLabel="alignment snapshot"
            placeholder="Ask Katherine about what this snapshot is showing you..." />
        </div>

        <div style={{ marginTop:26, paddingTop:18, borderTop:"1px solid var(--border)", display:"flex", justifyContent:"space-between", gap:8 }}>
          <button className="btn-g" onClick={() => a2Goto(prevStep.id)}>← {prevStep.label}</button>
          <button className="btn" onClick={() => { setA2Done(d => [...new Set([...d, "snapshot"])]); a2Goto(nextStep.id); }}>{nextStep.label} →</button>
        </div>
      </div>
    );
  }
  if (a2Step === "key_mis") {
    const kmIdx = A2_STEPS.findIndex(s => s.id === "key_mis");
    const prevStep = A2_STEPS[kmIdx - 1];
    const nextStep = A2_STEPS[kmIdx + 1];

    const scoreColor = (s) => s <= 4 ? "#ef4444" : s <= 6 ? "#f59e0b" : "#34d399";
    const misalignments = computeMisalignments(map);
    const hasDirScores = Object.keys(map).some(k => k.startsWith("dir_align_"));

    const noItems = misalignments.length === 0;
    const noDirScores = !hasDirScores && misalignments.length > 0;
    const top = misalignments[0];
    const allAligned = top && top.score >= 8;

    const pinnedId = map.a2_km_pinned_id || null;
    const primaryId = map.a2_km_primary_id || (misalignments[0]?.id || null);
    const primary = misalignments.find(m => m.id === primaryId) || misalignments[0];
    const secondaries = primary ? misalignments.filter(m => m.id !== primary.id).slice(0, 3) : [];
    const pinned = primary && pinnedId === primary.id;

    const h1 = allAligned ? "You're closer than you think" : "Where the pull is strongest";
    const lead = allAligned
      ? "No major gaps surfaced from your map. The work now is protection, not correction. Here's what to keep guarding."
      : "A1 showed you what you're moving toward. This is where your life today is pulling the other way. The gap isn't something to fix in one go — it's a signal about where your time is most worth protecting.";
    const secondariesLabel = allAligned ? "What to protect" : "Also worth looking at";

    const primaryCopy = (item) => {
      if (!item) return "";
      if (item.kind === "direction") {
        const t = (item.tierLabel || "priority").toLowerCase();
        return `You said this is a ${t}. Your life today doesn't reflect that yet. That's the pull we follow in the rest of A2.`;
      }
      if (item.kind === "identity") {
        return `You said this capability defines you. Today you scored it ${item.score}/10. Something is getting in the way of the version of you that knows this.`;
      }
      if (item.kind === "values") {
        return `You said this is how you live out ${item.valueName}. Today you scored it ${item.score}/10. Time to look at why.`;
      }
      return "";
    };

    return wrapA2(
      <div>
        <div style={{ fontSize:11, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color:"var(--warm)", marginBottom:11 }}>A2 · Key Misalignment</div>
        <h2 style={{ fontFamily:"var(--serif)", fontSize:40, fontWeight:400, lineHeight:1.15, marginBottom:16, letterSpacing:"-0.5px" }}>{h1}</h2>
        <p style={{ fontSize:15, color:"var(--text2)", lineHeight:1.7, marginBottom:32, maxWidth:640 }}>{lead}</p>

        {/* Empty state: nothing surfaces at all */}
        {noItems && (
          <div style={{ padding:"40px 32px", background:"rgba(201,168,76,.06)", border:"1px solid rgba(201,168,76,.3)", borderRadius:12, textAlign:"center" }}>
            <div style={{ fontSize:28, marginBottom:14 }}>⏳</div>
            <div style={{ fontFamily:"var(--serif)", fontSize:22, color:"var(--text)", marginBottom:10 }}>Direction Alignment isn't complete yet.</div>
            <div style={{ fontSize:15, color:"var(--text2)", lineHeight:1.6, maxWidth:460, margin:"0 auto 20px" }}>
              Head back to A2 · Direction Alignment and score TODAY's reality against each of your horizons. Once you've done that, your Key Misalignment will surface here.
            </div>
            <button className="btn" onClick={() => a2Goto("dir_align")}>← Back to Direction Alignment</button>
          </div>
        )}

        {/* Partial view: no direction scores but identity/values do exist */}
        {!noItems && noDirScores && (
          <div style={{ padding:"14px 18px", marginBottom:24, background:"rgba(201,168,76,.06)", border:"1px solid rgba(201,168,76,.3)", borderRadius:8, fontSize:13, color:"var(--text2)", lineHeight:1.6 }}>
            <strong style={{ color:"var(--warm)" }}>Partial view.</strong>{" "}
            Direction Alignment isn't scored yet — these surfaces come only from your Identity &amp; Values work.{" "}
            <button onClick={() => a2Goto("dir_align")} style={{ background:"none", border:"none", color:"var(--warm)", cursor:"pointer", textDecoration:"underline", padding:0, fontFamily:"inherit", fontSize:"inherit" }}>Finish Direction Alignment</button> to see the full picture.
          </div>
        )}

        {/* Primary card */}
        {primary && (() => {
          const col = scoreColor(primary.score);
          return (
            <div style={{
              padding:"28px 30px",
              background: pinned
                ? "linear-gradient(135deg, rgba(201,168,76,.12), rgba(255,255,255,.02))"
                : "linear-gradient(135deg, rgba(239,68,68,.08), rgba(255,255,255,.02))",
              border:`1px solid ${pinned ? "var(--warm)" : "rgba(239,68,68,.4)"}`,
              borderRadius:12, marginBottom:32, position:"relative",
            }}>
              {pinned && (
                <div style={{ position:"absolute", top:-10, right:16, background:"var(--warm)", color:"var(--bg)", fontSize:10, letterSpacing:1.5, textTransform:"uppercase", fontWeight:700, padding:"2px 10px", borderRadius:10 }}>
                  ✓ Your A2 focus
                </div>
              )}
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:14 }}>
                <div style={{ fontSize:10, letterSpacing:2, textTransform:"uppercase", color: pinned ? "var(--warm)" : "#ef4444", fontWeight:700 }}>{primary.source}</div>
                <div style={{ fontSize:10, color:"var(--text3)", fontWeight:500, padding:"2px 8px", border:"1px solid var(--border2)", borderRadius:8 }}>gap {primary.final_gap.toFixed(1)}</div>
              </div>
              <div style={{ display:"flex", alignItems:"center", gap:14, marginBottom:14 }}>
                <div style={{ fontSize:32, lineHeight:1 }}>{primary.icon}</div>
                <div style={{ fontFamily:"var(--serif)", fontSize:26, fontWeight:400, color:"var(--text)", lineHeight:1.2 }}>{primary.label}</div>
              </div>
              <div style={{ fontSize:13, color:"var(--text2)", marginBottom:16, fontFamily:"var(--serif)", fontStyle:"italic" }}>
                You scored this <span style={{ color:col, fontWeight:600, fontStyle:"normal" }}>{primary.score}/10</span> today.
              </div>
              <div style={{ fontSize:15, color:"var(--text)", lineHeight:1.7, marginBottom:22 }}>
                {primaryCopy(primary)}
              </div>
              {!pinned ? (
                <div style={{ display:"flex", gap:10, flexWrap:"wrap" }}>
                  <button onClick={() => set("a2_km_pinned_id", primary.id)}
                    style={{ padding:"10px 20px", borderRadius:16, background:"var(--warm)", color:"var(--bg)", border:"none", cursor:"pointer", fontSize:13, fontWeight:700 }}>
                    ✓ Pin this as my focus
                  </button>
                  <button onClick={() => set("a2_km_picker_open", !map.a2_km_picker_open)}
                    style={{ padding:"10px 16px", borderRadius:16, background:"transparent", color:"var(--text2)", border:"1px solid var(--border2)", cursor:"pointer", fontSize:12, fontWeight:500 }}>
                    {map.a2_km_picker_open ? "Close picker" : "Choose a different focus"}
                  </button>
                </div>
              ) : (
                <div style={{ padding:"14px 18px", background:"rgba(201,168,76,.08)", border:"1px solid rgba(201,168,76,.25)", borderRadius:8 }}>
                  <div style={{ fontSize:14, color:"var(--text)", fontFamily:"var(--serif)", fontStyle:"italic", marginBottom:12, lineHeight:1.6 }}>
                    Pinned. Now let's look at how it plays out day-to-day.
                  </div>
                  <div style={{ display:"flex", gap:8, flexWrap:"wrap" }}>
                    <button onClick={() => a2Goto("time_audit")}
                      style={{ padding:"10px 20px", borderRadius:16, background:"var(--warm)", color:"var(--bg)", border:"none", cursor:"pointer", fontSize:13, fontWeight:700 }}>
                      Continue → Time Audit
                    </button>
                    <button onClick={() => { set("a2_km_pinned_id", null); set("a2_km_picker_open", true); }}
                      style={{ padding:"10px 14px", borderRadius:16, background:"transparent", color:"var(--text3)", border:"1px solid var(--border2)", cursor:"pointer", fontSize:12 }}>
                      Change focus
                    </button>
                  </div>
                </div>
              )}
            </div>
          );
        })()}

        {/* Full picker — opens when user wants to choose a different focus */}
        {map.a2_km_picker_open && misalignments.length > 0 && (
          <div style={{ marginBottom:32, padding:"20px 22px", background:"rgba(255,255,255,.02)", border:"1px solid var(--border2)", borderRadius:10 }}>
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:14 }}>
              <div>
                <div style={{ fontSize:11, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color:"var(--warm)", marginBottom:4 }}>Choose your focus</div>
                <div style={{ fontSize:14, color:"var(--text3)", fontStyle:"italic" }}>
                  Katherine's ranking is a suggestion — you choose what matters most. {misalignments.length} scored item{misalignments.length === 1 ? "" : "s"}.
                </div>
              </div>
              <button onClick={() => set("a2_km_picker_open", false)}
                style={{ background:"none", border:"none", color:"var(--text4)", cursor:"pointer", fontSize:18, padding:0, lineHeight:1 }}>×</button>
            </div>
            <div style={{ maxHeight:360, overflowY:"auto", paddingRight:4 }}>
              {misalignments.map(item => {
                const col = scoreColor(item.score);
                const isPrimary = item.id === primary?.id;
                return (
                  <div key={item.id}
                    onClick={() => {
                      set("a2_km_primary_id", item.id);
                      set("a2_km_picker_open", false);
                    }}
                    style={{
                      display:"flex", alignItems:"center", gap:12,
                      padding:"10px 12px", marginBottom:6,
                      background: isPrimary ? "rgba(201,168,76,.1)" : "transparent",
                      border:`1px solid ${isPrimary ? "rgba(201,168,76,.35)" : "transparent"}`,
                      borderRadius:8, cursor:"pointer", transition:"all .12s"
                    }}
                    onMouseEnter={e => { if (!isPrimary) e.currentTarget.style.background = "rgba(255,255,255,.04)"; }}
                    onMouseLeave={e => { if (!isPrimary) e.currentTarget.style.background = "transparent"; }}>
                    <span style={{ fontSize:10, color:"var(--text4)", fontWeight:600, minWidth:24, textAlign:"right" }}>#{item.rank}</span>
                    <span style={{ fontSize:16 }}>{item.icon}</span>
                    <div style={{ flex:1, minWidth:0 }}>
                      <div style={{ fontSize:13, color:"var(--text)", fontWeight:500, lineHeight:1.3, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{item.label}</div>
                      <div style={{ fontSize:10, color:"var(--text4)", marginTop:2 }}>{item.source}</div>
                    </div>
                    <div style={{ display:"flex", flexDirection:"column", alignItems:"flex-end", gap:2, flexShrink:0 }}>
                      <span style={{ fontSize:12, fontWeight:700, color:col }}>{item.score}/10</span>
                      <span style={{ fontSize:9, color:"var(--text4)" }}>gap {item.final_gap.toFixed(1)}</span>
                    </div>
                    {isPrimary && <span style={{ fontSize:11, color:"var(--warm)", fontWeight:700, flexShrink:0, marginLeft:4 }}>✓</span>}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Secondaries */}
        {secondaries.length > 0 && (
          <>
            <div style={{ fontSize:10, letterSpacing:2, textTransform:"uppercase", color:"var(--text3)", fontWeight:600, marginBottom:12 }}>
              {secondariesLabel}
            </div>
            <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit, minmax(220px, 1fr))", gap:12, marginBottom:16 }}>
              {secondaries.map(item => {
                const col = scoreColor(item.score);
                const borderCol = allAligned ? "#34d399" : (item.score <= 4 ? "#ef4444" : "#f59e0b");
                return (
                  <div key={item.id}
                    onClick={() => { if (!pinned) set("a2_km_primary_id", item.id); }}
                    style={{ padding:"14px 16px", background:"rgba(255,255,255,.03)", border:`1px solid ${borderCol}30`, borderRadius:10, cursor: pinned ? "default" : "pointer", transition:"all .15s ease", opacity: pinned ? 0.7 : 1 }}
                    onMouseEnter={e => { if (!pinned) { e.currentTarget.style.background = "rgba(255,255,255,.06)"; e.currentTarget.style.borderColor = `${borderCol}80`; }}}
                    onMouseLeave={e => { e.currentTarget.style.background = "rgba(255,255,255,.03)"; e.currentTarget.style.borderColor = `${borderCol}30`; }}>
                    <div style={{ fontSize:9, letterSpacing:1.5, textTransform:"uppercase", color:borderCol, fontWeight:700, marginBottom:8 }}>{item.source}</div>
                    <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:10 }}>
                      <div style={{ fontSize:20, lineHeight:1 }}>{item.icon}</div>
                      <div style={{ fontSize:14, color:"var(--text)", fontWeight:500, lineHeight:1.3, flex:1, minWidth:0 }}>{item.label}</div>
                    </div>
                    <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", fontSize:11, color:"var(--text3)" }}>
                      <span>score <span style={{ color:col, fontWeight:600 }}>{item.score}/10</span></span>
                      <span>gap {item.final_gap.toFixed(1)}</span>
                    </div>
                  </div>
                );
              })}
            </div>
            {!pinned && (
              <div style={{ fontSize:11, color:"var(--text3)", fontStyle:"italic", textAlign:"center", marginBottom:12 }}>
                Click any card above to make it the primary.
              </div>
            )}
          </>
        )}

        {!noItems && (
          <div style={{ marginBottom:22, marginTop:18 }}>
            <AIChat voiceId={voice} onVoiceChange={setVoicePersist} name={name} intake={intake} mapData={map}
              sectionLabel="key misalignment"
              placeholder="Ask Katherine why this surfaced — or whether you agree..." />
          </div>
        )}

        <div style={{ marginTop:26, paddingTop:18, borderTop:"1px solid var(--border)", display:"flex", justifyContent:"space-between", gap:8 }}>
          <button className="btn-g" onClick={() => a2Goto(prevStep.id)}>← {prevStep.label}</button>
          <button className="btn" onClick={() => { setA2Done(d => [...new Set([...d, "key_mis"])]); a2Goto(nextStep.id); }}>{nextStep.label} →</button>
        </div>
      </div>
    );
  }
  if (a2Step === "time_audit") {
    const taIdx = A2_STEPS.findIndex(s => s.id === "time_audit");
    const prevStep = A2_STEPS[taIdx - 1];
    const nextStep = A2_STEPS[taIdx + 1];

    const acts = map.a2_ta_acts || [];
    const p1Done = !!map.a2_ta_p1_done;
    const p2Done = !!map.a2_ta_p2_done;
    const totalHours = acts.reduce((t, a) => t + (Number(a.hours) || 0), 0);
    const readyP1 = acts.length >= 5;
    const sortedCount = acts.filter(a => a.feeling && a.pri).length;
    const readyP2 = sortedCount === acts.length && acts.length > 0;

    const HOURS_OPTS = [1, 3, 5, 8, 10, 12, 15, 20];

    // Feelings
    const FEELING_META = {
      love:    { label: "Love",    emoji: "💛", color: "#34d399" },
      like:    { label: "Like",    emoji: "👍", color: "#34d399" },
      dislike: { label: "Dislike", emoji: "👎", color: "#f59e0b" },
      despise: { label: "Despise", emoji: "😤", color: "#ef4444" },
    };

    // Priority list — user's A1 time picks + Wealth + Personal Growth + None
    const priorityList = (() => {
      const list = [];
      (map.time_picked || []).forEach(id => {
        const preset = TIME_AREA_PRESETS.find(p => p.id === id);
        const stored = (map.time_items || {})[id] || {};
        list.push({
          id: `t_${id}`,
          label: preset?.label || stored.label || id,
          icon:  preset?.icon  || stored.icon  || "⏳",
          kind: "time",
          subtitle: null,
        });
      });
      // Fallback: if user hasn't picked time in new shape, use legacy life_areas
      if (list.length === 0 && (map.life_areas || []).length > 0) {
        (map.life_areas || []).forEach(a => {
          list.push({
            id: `t_${a.id || a.label}`,
            label: a.label || a.id || "",
            icon: a.icon || "⏳",
            kind: "time",
            subtitle: null,
          });
        });
      }
      // Wealth summary
      const wealthLabels = (map.wealth_picked || []).map(id => {
        const preset = WEALTH_AREA_PRESETS.find(p => p.id === id);
        return preset?.label || id;
      });
      list.push({
        id: "wealth",
        label: "Wealth",
        icon: "💰",
        kind: "wealth",
        subtitle: wealthLabels.length > 0 ? wealthLabels.join(" · ") : null,
      });
      // Personal Growth
      const growthSentence = map.oneyr_growth_sentence || map.growth_sentence || map.growth_summary || "";
      list.push({
        id: "growth",
        label: "Personal Growth",
        icon: "🌱",
        kind: "growth",
        subtitle: growthSentence || null,
      });
      // None
      list.push({
        id: "none",
        label: "None of my priorities",
        icon: "·",
        kind: "none",
        subtitle: null,
      });
      return list;
    })();
    const priById = (id) => priorityList.find(p => p.id === id) || null;

    const addAct = () => {
      const labelEl = document.getElementById("a2_ta_newLbl");
      const hrsEl = document.getElementById("a2_ta_newHrs");
      const label = (labelEl?.value || "").trim();
      if (!label) return;
      const hours = Number(hrsEl?.value || 5);
      const next = [...acts, { id: `a${Date.now()}`, label, hours, feeling: null, pri: null }];
      set("a2_ta_acts", next);
      if (labelEl) { labelEl.value = ""; labelEl.focus(); }
    };
    const removeAct = (id) => set("a2_ta_acts", acts.filter(a => a.id !== id));
    const editHours = (id, hrs) => set("a2_ta_acts", acts.map(a => a.id === id ? { ...a, hours: Number(hrs) } : a));
    const setPri = (id, pri) => set("a2_ta_acts", acts.map(a => a.id === id ? { ...a, pri: pri || null } : a));
    const setFeel = (id, feeling) => set("a2_ta_acts", acts.map(a => a.id === id ? { ...a, feeling: a.feeling === feeling ? null : feeling } : a));

    return wrapA2(
      <div>
        <div style={{ fontSize:11, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color:"var(--warm)", marginBottom:11 }}>A2 · Time Audit</div>
        <h2 style={{ fontFamily:"var(--serif)", fontSize:38, fontWeight:400, lineHeight:1.2, marginBottom:10, letterSpacing:"-0.3px" }}>Where your time is really going</h2>
        <p style={{ fontSize:16, color:"var(--text2)", lineHeight:1.75, marginBottom:28, maxWidth:620 }}>
          You told A1 where you're going. You just saw the biggest gap between that direction and today. Now — the hours you said you didn't have. They're here, somewhere. Let's look honestly.
        </p>

        {/* ─── PHASE 1 ─── */}
        {p1Done ? (
          <div style={{ marginBottom:16, padding:"12px 16px", background:"rgba(52,211,153,.06)", border:"1px solid rgba(52,211,153,.35)", borderRadius:8, display:"flex", justifyContent:"space-between", alignItems:"center" }}>
            <div>
              <div style={{ fontSize:10, letterSpacing:2, textTransform:"uppercase", fontWeight:700, color:"#34d399", marginBottom:4 }}>✓ Phase 1 · Name your week</div>
              <div style={{ fontSize:13, color:"var(--text2)" }}>{acts.length} activities · {totalHours} hrs/week</div>
            </div>
            <button onClick={() => set("a2_ta_p1_done", false)}
              style={{ padding:"5px 12px", background:"transparent", color:"var(--text3)", border:"1px solid var(--border2)", borderRadius:12, cursor:"pointer", fontSize:11 }}>
              Edit
            </button>
          </div>
        ) : (
          <div style={{ marginBottom:16, padding:"24px 28px", background:"var(--bg2)", border:"1px solid var(--border2)", borderRadius:10 }}>
            <div style={{ fontSize:10, letterSpacing:2, textTransform:"uppercase", fontWeight:700, color:"var(--warm)", marginBottom:4 }}>Phase 1 · Name your week</div>
            <h3 style={{ fontFamily:"var(--serif)", fontSize:24, fontWeight:400, margin:"0 0 7px", color:"var(--text)", letterSpacing:"-0.3px" }}>List the things that actually take up your typical week.</h3>
            <p style={{ fontSize:13, color:"var(--text2)", lineHeight:1.7, margin:"0 0 18px" }}>
              Work, home, fun, obligations — everything. Don't filter. 15 minutes of scrolling counts. The 3am anxiety loop counts. Get it all down.
            </p>

            {/* Add row */}
            <div style={{ display:"flex", gap:8, alignItems:"center", padding:"10px 12px", background:"rgba(0,0,0,.2)", border:"1px dashed rgba(201,168,76,.4)", borderRadius:8, marginBottom:14 }}>
              <span style={{ color:"var(--warm)", fontSize:18 }}>+</span>
              <input id="a2_ta_newLbl" placeholder="Add an activity... (e.g. Morning meetings)"
                onKeyDown={e => { if (e.key === "Enter") { e.preventDefault(); addAct(); } }}
                style={{ flex:1, background:"transparent", border:"none", outline:"none", color:"var(--text)", fontSize:14, fontFamily:"var(--sans)" }} />
              <select id="a2_ta_newHrs" defaultValue={5}
                style={{ fontFamily:"var(--sans)", fontSize:12, background:"var(--bg3)", color:"var(--text2)", border:"1px solid var(--border2)", borderRadius:6, padding:"4px 8px", cursor:"pointer" }}>
                {HOURS_OPTS.map(h => <option key={h} value={h}>{h} hrs</option>)}
                <option value={25}>20+ hrs</option>
              </select>
              <button onClick={addAct}
                style={{ padding:"6px 14px", background:"var(--warm)", color:"var(--bg)", border:"none", borderRadius:6, fontFamily:"var(--sans)", fontSize:12, fontWeight:700, cursor:"pointer" }}>
                Add
              </button>
            </div>

            {/* List */}
            {acts.length === 0 ? (
              <div style={{ padding:"24px 14px", textAlign:"center", fontSize:13, color:"var(--text4)", fontStyle:"italic" }}>
                Nothing yet. Start with one — anything that takes a chunk of your week.
              </div>
            ) : (
              <>
                {acts.map(a => (
                  <div key={a.id} style={{ display:"flex", alignItems:"center", gap:10, padding:"10px 12px", marginBottom:6, background:"rgba(0,0,0,.2)", borderRadius:6 }}>
                    <span style={{ flex:1, fontSize:14, color:"var(--text)" }}>{a.label}</span>
                    <select value={a.hours} onChange={e => editHours(a.id, e.target.value)}
                      style={{ fontFamily:"var(--sans)", fontSize:12, background:"var(--bg3)", color:"var(--text2)", border:"1px solid var(--border2)", borderRadius:6, padding:"4px 8px", cursor:"pointer" }}>
                      {HOURS_OPTS.map(h => <option key={h} value={h}>{h} hrs</option>)}
                      <option value={25}>20+ hrs</option>
                    </select>
                    <button onClick={() => removeAct(a.id)}
                      style={{ background:"transparent", color:"var(--text4)", border:"none", cursor:"pointer", fontSize:18, padding:"0 6px", lineHeight:1 }}>
                      ×
                    </button>
                  </div>
                ))}
                <div style={{ marginTop:12, padding:"4px 12px", fontSize:11, color:"var(--text3)", textAlign:"right" }}>
                  {acts.length} activities · {totalHours} hrs/week total
                </div>
              </>
            )}

            {/* Ready */}
            <div style={{ marginTop:18, textAlign:"center", paddingTop:16, borderTop:"1px solid var(--border)" }}>
              <button disabled={!readyP1} onClick={() => set("a2_ta_p1_done", true)}
                style={{ padding:"10px 24px", borderRadius:16, background: readyP1 ? "var(--warm)" : "transparent", color: readyP1 ? "var(--bg)" : "var(--text4)", border: readyP1 ? "none" : "1px solid var(--border2)", cursor: readyP1 ? "pointer" : "not-allowed", fontFamily:"var(--sans)", fontSize:13, fontWeight:700 }}>
                Next · Sort it →
              </button>
              {!readyP1 && (
                <div style={{ marginTop:8, fontSize:11, color:"var(--text4)", fontStyle:"italic" }}>
                  Add at least 5 activities to continue.
                </div>
              )}
            </div>
          </div>
        )}

        {/* ─── PHASE 2 ─── */}
        {!p1Done ? (
          <div style={{ marginBottom:16, padding:"12px 16px", background:"rgba(255,255,255,.02)", border:"1px dashed var(--border2)", borderRadius:8, opacity:0.55 }}>
            <div style={{ fontSize:10, letterSpacing:2, textTransform:"uppercase", fontWeight:700, color:"var(--text4)", marginBottom:4 }}>Phase 2 · Sort it (locked)</div>
            <div style={{ fontSize:12, color:"var(--text4)" }}>
              Name your week first, then we'll sort each activity — priority + how it feels.
            </div>
          </div>
        ) : p2Done ? (
          <div style={{ marginBottom:16, padding:"12px 16px", background:"rgba(52,211,153,.06)", border:"1px solid rgba(52,211,153,.35)", borderRadius:8, display:"flex", justifyContent:"space-between", alignItems:"center" }}>
            <div>
              <div style={{ fontSize:10, letterSpacing:2, textTransform:"uppercase", fontWeight:700, color:"#34d399", marginBottom:4 }}>✓ Phase 2 · Sort it</div>
              <div style={{ fontSize:13, color:"var(--text2)" }}>{acts.length} activities sorted</div>
            </div>
            <button onClick={() => set("a2_ta_p2_done", false)}
              style={{ padding:"5px 12px", background:"transparent", color:"var(--text3)", border:"1px solid var(--border2)", borderRadius:12, cursor:"pointer", fontSize:11 }}>
              Edit
            </button>
          </div>
        ) : (
          <div style={{ marginBottom:16, padding:"24px 28px", background:"var(--bg2)", border:"1px solid var(--border2)", borderRadius:10 }}>
            <div style={{ fontSize:10, letterSpacing:2, textTransform:"uppercase", fontWeight:700, color:"var(--warm)", marginBottom:4 }}>Phase 2 · Sort it</div>
            <h3 style={{ fontFamily:"var(--serif)", fontSize:24, fontWeight:400, margin:"0 0 7px", color:"var(--text)", letterSpacing:"-0.3px" }}>For each one — which priority does it serve, and how does it feel?</h3>
            <p style={{ fontSize:13, color:"var(--text2)", lineHeight:1.7, margin:"0 0 18px" }}>
              Priority comes from your A1 picks. Feeling is gut. If something doesn't serve any priority you named, tag it "None of my priorities" — that's useful data too.
            </p>

            {acts.map(a => {
              const both = a.pri && a.feeling;
              const noneBorder = a.feeling === "despise" ? "#ef4444"
                : a.feeling === "dislike" ? "#f59e0b"
                : (a.feeling === "love" || a.feeling === "like") ? "#34d399"
                : "var(--border2)";
              const noneBg = a.feeling === "despise" ? "rgba(239,68,68,.04)"
                : a.feeling === "dislike" ? "rgba(245,158,11,.04)"
                : (a.feeling === "love" || a.feeling === "like") ? "rgba(52,211,153,.04)"
                : "rgba(0,0,0,.2)";
              const prObj = a.pri ? priById(a.pri) : null;
              const priBorder = a.pri === "none" ? "rgba(239,68,68,.3)"
                : a.pri ? "var(--warm)"
                : "var(--border2)";
              const priColor = a.pri === "none" ? "#ef4444"
                : a.pri ? "var(--text)"
                : "var(--text2)";
              return (
                <div key={a.id} style={{
                  padding:"14px 16px", marginBottom:8,
                  background: both ? noneBg : "rgba(0,0,0,.2)",
                  border: `1px solid ${both ? noneBorder : "var(--border2)"}`,
                  borderRadius:8,
                }}>
                  <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:12 }}>
                    <span style={{ fontSize:14, color:"var(--text)", fontWeight:500 }}>{a.label}</span>
                    <span style={{ fontSize:11, color:"var(--text3)" }}>{a.hours} hrs/wk</span>
                  </div>
                  <div style={{ display:"grid", gridTemplateColumns:"230px 1fr", gap:14, alignItems:"start" }}>
                    {/* Priority select */}
                    <div>
                      <div style={{ fontSize:9, letterSpacing:1.2, textTransform:"uppercase", color:"var(--text3)", fontWeight:600, marginBottom:5 }}>Priority</div>
                      <select value={a.pri || ""} onChange={e => setPri(a.id, e.target.value)}
                        style={{ width:"100%", fontFamily:"var(--sans)", fontSize:12, background:"var(--bg3)", color: priColor, border:`1px solid ${priBorder}`, borderRadius:6, padding:"6px 8px", cursor:"pointer" }}>
                        <option value="">— Which priority does this serve? —</option>
                        {priorityList.map(p => (
                          <option key={p.id} value={p.id}>{p.icon} {p.label}</option>
                        ))}
                      </select>
                      {prObj?.subtitle && (
                        <div style={{ fontSize:10, color:"var(--text4)", fontStyle:"italic", marginTop:4, lineHeight:1.4 }}>{prObj.subtitle}</div>
                      )}
                    </div>
                    {/* Feeling buttons */}
                    <div>
                      <div style={{ fontSize:9, letterSpacing:1.2, textTransform:"uppercase", color:"var(--text3)", fontWeight:600, marginBottom:5 }}>Feeling</div>
                      <div style={{ display:"flex", gap:6, flexWrap:"wrap" }}>
                        {Object.entries(FEELING_META).map(([k, f]) => {
                          const sel = a.feeling === k;
                          return (
                            <button key={k} onClick={() => setFeel(a.id, k)}
                              style={{
                                padding:"5px 10px", borderRadius:14,
                                border: sel ? `1px solid ${f.color}` : "1px solid var(--border2)",
                                background: sel ? `${f.color}22` : "transparent",
                                color: sel ? f.color : "var(--text2)",
                                cursor:"pointer", fontFamily:"var(--sans)", fontSize:11,
                                fontWeight: sel ? 700 : 500,
                                display:"inline-flex", alignItems:"center", gap:4,
                              }}>
                              {f.emoji} {f.label}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}

            <div style={{ marginTop:12, padding:"4px 12px", fontSize:11, color:"var(--text3)", textAlign:"right" }}>
              {sortedCount} of {acts.length} sorted
            </div>

            <div style={{ marginTop:18, textAlign:"center", paddingTop:16, borderTop:"1px solid var(--border)" }}>
              <button disabled={!readyP2} onClick={() => set("a2_ta_p2_done", true)}
                style={{ padding:"10px 24px", borderRadius:16, background: readyP2 ? "var(--warm)" : "transparent", color: readyP2 ? "var(--bg)" : "var(--text4)", border: readyP2 ? "none" : "1px solid var(--border2)", cursor: readyP2 ? "pointer" : "not-allowed", fontFamily:"var(--sans)", fontSize:13, fontWeight:700 }}>
                Next · What's missing →
              </button>
              {!readyP2 && (
                <div style={{ marginTop:8, fontSize:11, color:"var(--text4)", fontStyle:"italic" }}>
                  Sort every activity to continue.
                </div>
              )}
            </div>
          </div>
        )}

        {/* ─── PHASE 3 ─── */}
        {!p2Done ? (
          <div style={{ marginBottom:16, padding:"12px 16px", background:"rgba(255,255,255,.02)", border:"1px dashed var(--border2)", borderRadius:8, opacity:0.55 }}>
            <div style={{ fontSize:10, letterSpacing:2, textTransform:"uppercase", fontWeight:700, color:"var(--text4)", marginBottom:4 }}>Phase 3 · What's missing (locked)</div>
            <div style={{ fontSize:12, color:"var(--text4)" }}>
              Sort your week first, then we'll look at what's NOT on the list.
            </div>
          </div>
        ) : (() => {
          const wishes = map.a2_ta_wishes || [];
          const p3Done = !!map.a2_ta_p3_done;
          const wishHours = wishes.reduce((t, w) => t + (Number(w.hours) || 0), 0);
          const readyP3 = wishes.length >= 1 && wishes.every(w => w.pri && w.feeling);

          // Bucket helper — mirrors prototype bucketFor
          const bucketFor = (a) => {
            if (!a.feeling || !a.pri) return null;
            const isNone = a.pri === "none";
            const f = a.feeling;
            if (f === "despise") return "leaks";
            if (f === "dislike" && isNone) return "leaks";
            if (isNone) return "leaks";
            if (f === "love") return "supports";
            if (f === "like") return "supports";
            return "reshape";
          };
          const enrichedActs = acts.map(a => ({ ...a, bucket: bucketFor(a) })).filter(a => a.bucket);
          const leaksActs = enrichedActs.filter(a => a.bucket === "leaks").sort((x,y) => y.hours - x.hours);
          const reshapeActs = enrichedActs.filter(a => a.bucket === "reshape").sort((x,y) => y.hours - x.hours);
          const supportsActs = enrichedActs.filter(a => a.bucket === "supports").sort((x,y) => y.hours - x.hours);
          const showSupports = !!map.a2_ta_show_supports;
          const reclaimPool = [...leaksActs, ...reshapeActs, ...(showSupports ? supportsActs : [])];

          const swaps = map.a2_ta_swaps || {};
          const setSwap = (wid, patch) => {
            const next = { ...swaps, [wid]: { ...(swaps[wid] || {}), ...patch } };
            set("a2_ta_swaps", next);
          };
          const swapPatch = (wid) => swaps[wid] || {};

          const TIMELINES = [
            { id: "3mo",  label: "< 3 months" },
            { id: "6mo",  label: "< 6 months" },
            { id: "12mo", label: "> 12 months" },
          ];
          const BLOCK_OPTIONS = [
            { id: "fear",       label: "Fear / doubt" },
            { id: "permission", label: "Permission from someone else" },
            { id: "identity",   label: "Identity — 'I'm not someone who does this'" },
            { id: "skill",      label: "Skill — I don't know how to start" },
            { id: "money",      label: "Money" },
            { id: "energy",     label: "Energy — I'm exhausted" },
            { id: "social",     label: "Social — no one around me does this" },
            { id: "other",      label: "Something else" },
          ];
          const SHIFT_HOURS = [1, 2, 3, 5, 8, 10];

          const hasNonTimeBlock = Object.values(swaps).some(sw => sw && (sw.block === "not_time" || sw.block === "both"));

          const addWish = () => {
            const labelEl = document.getElementById("a2_ta_newWishLbl");
            const hrsEl = document.getElementById("a2_ta_newWishHrs");
            const label = (labelEl?.value || "").trim();
            if (!label) return;
            const hours = Number(hrsEl?.value || 3);
            const next = [...wishes, { id: `w${Date.now()}`, label, hours, feeling: null, pri: null }];
            set("a2_ta_wishes", next);
            if (labelEl) { labelEl.value = ""; labelEl.focus(); }
          };
          const removeWish = (id) => set("a2_ta_wishes", wishes.filter(w => w.id !== id));
          const editWishHours = (id, hrs) => set("a2_ta_wishes", wishes.map(w => w.id === id ? { ...w, hours: Number(hrs) } : w));
          const setWishPri = (id, pri) => set("a2_ta_wishes", wishes.map(w => w.id === id ? { ...w, pri: pri || null } : w));
          const setWishFeel = (id, feeling) => set("a2_ta_wishes", wishes.map(w => w.id === id ? { ...w, feeling: w.feeling === feeling ? null : feeling } : w));

          if (p3Done) {
            return (
              <div style={{ marginBottom:16, padding:"12px 16px", background:"rgba(52,211,153,.06)", border:"1px solid rgba(52,211,153,.35)", borderRadius:8, display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                <div>
                  <div style={{ fontSize:10, letterSpacing:2, textTransform:"uppercase", fontWeight:700, color:"#34d399", marginBottom:4 }}>✓ Phase 3 · What's missing</div>
                  <div style={{ fontSize:13, color:"var(--text2)" }}>{wishes.length} wishlist item{wishes.length === 1 ? "" : "s"} · {wishHours} hrs/week needed</div>
                </div>
                <button onClick={() => set("a2_ta_p3_done", false)}
                  style={{ padding:"5px 12px", background:"transparent", color:"var(--text3)", border:"1px solid var(--border2)", borderRadius:12, cursor:"pointer", fontSize:11 }}>
                  Edit
                </button>
              </div>
            );
          }

          return (
            <div style={{ marginBottom:16, padding:"24px 28px", background:"var(--bg2)", border:"1px solid var(--border2)", borderRadius:10 }}>
              <div style={{ fontSize:10, letterSpacing:2, textTransform:"uppercase", fontWeight:700, color:"var(--warm)", marginBottom:4 }}>Phase 3 · What's missing</div>
              <h3 style={{ fontFamily:"var(--serif)", fontSize:24, fontWeight:400, margin:"0 0 7px", color:"var(--text)", letterSpacing:"-0.3px" }}>What keeps getting pushed off the list?</h3>
              <p style={{ fontSize:13, color:"var(--text2)", lineHeight:1.7, margin:"0 0 18px" }}>
                The things you keep saying "I'd do it if I had time." List them. How many hours/week would you need? Tag the priority it serves and how you'd feel doing it (because "should exercise but will hate it" is real data too).
              </p>

              {/* Add row */}
              <div style={{ display:"flex", gap:8, alignItems:"center", padding:"10px 12px", background:"rgba(0,0,0,.2)", border:"1px dashed rgba(201,168,76,.4)", borderRadius:8, marginBottom:14 }}>
                <span style={{ color:"var(--warm)", fontSize:18 }}>+</span>
                <input id="a2_ta_newWishLbl" placeholder="Add something you've been postponing... (e.g. Book writing)"
                  onKeyDown={e => { if (e.key === "Enter") { e.preventDefault(); addWish(); } }}
                  style={{ flex:1, background:"transparent", border:"none", outline:"none", color:"var(--text)", fontSize:14, fontFamily:"var(--sans)" }} />
                <select id="a2_ta_newWishHrs" defaultValue={3}
                  style={{ fontFamily:"var(--sans)", fontSize:12, background:"var(--bg3)", color:"var(--text2)", border:"1px solid var(--border2)", borderRadius:6, padding:"4px 8px", cursor:"pointer" }}>
                  {HOURS_OPTS.map(h => <option key={h} value={h}>{h} hrs</option>)}
                </select>
                <button onClick={addWish}
                  style={{ padding:"6px 14px", background:"var(--warm)", color:"var(--bg)", border:"none", borderRadius:6, fontFamily:"var(--sans)", fontSize:12, fontWeight:700, cursor:"pointer" }}>
                  Add
                </button>
              </div>

              {/* Wishlist rows */}
              {wishes.length === 0 ? (
                <div style={{ padding:"24px 14px", textAlign:"center", fontSize:13, color:"var(--text4)", fontStyle:"italic" }}>
                  Nothing yet. What's something you've been meaning to make time for?
                </div>
              ) : (
                <>
                  {wishes.map(w => {
                    const both = w.pri && w.feeling;
                    const noneBorder = w.feeling === "despise" ? "#ef4444"
                      : w.feeling === "dislike" ? "#f59e0b"
                      : (w.feeling === "love" || w.feeling === "like") ? "#34d399"
                      : "var(--border2)";
                    const noneBg = w.feeling === "despise" ? "rgba(239,68,68,.04)"
                      : w.feeling === "dislike" ? "rgba(245,158,11,.04)"
                      : (w.feeling === "love" || w.feeling === "like") ? "rgba(52,211,153,.04)"
                      : "rgba(0,0,0,.2)";
                    const prObj = w.pri ? priById(w.pri) : null;
                    const priBorder = w.pri ? "var(--warm)" : "var(--border2)";
                    const priColor = w.pri ? "var(--text)" : "var(--text2)";
                    return (
                      <div key={w.id} style={{
                        padding:"14px 16px", marginBottom:8,
                        background: both ? noneBg : "rgba(0,0,0,.2)",
                        border: `1px solid ${both ? noneBorder : "var(--border2)"}`,
                        borderRadius:8,
                      }}>
                        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:12, gap:10 }}>
                          <span style={{ fontSize:14, color:"var(--text)", fontWeight:500 }}>{w.label}</span>
                          <div style={{ display:"flex", alignItems:"center", gap:6 }}>
                            <select value={w.hours} onChange={e => editWishHours(w.id, e.target.value)}
                              style={{ fontFamily:"var(--sans)", fontSize:11, background:"var(--bg3)", color:"var(--text2)", border:"1px solid var(--border2)", borderRadius:6, padding:"3px 6px", cursor:"pointer" }}>
                              {HOURS_OPTS.map(h => <option key={h} value={h}>{h} hrs/wk</option>)}
                            </select>
                            <button onClick={() => removeWish(w.id)}
                              style={{ background:"transparent", color:"var(--text4)", border:"none", cursor:"pointer", fontSize:18, padding:"0 4px", lineHeight:1 }}>
                              ×
                            </button>
                          </div>
                        </div>
                        <div style={{ display:"grid", gridTemplateColumns:"230px 1fr", gap:14, alignItems:"start" }}>
                          <div>
                            <div style={{ fontSize:9, letterSpacing:1.2, textTransform:"uppercase", color:"var(--text3)", fontWeight:600, marginBottom:5 }}>Priority</div>
                            <select value={w.pri || ""} onChange={e => setWishPri(w.id, e.target.value)}
                              style={{ width:"100%", fontFamily:"var(--sans)", fontSize:12, background:"var(--bg3)", color: priColor, border:`1px solid ${priBorder}`, borderRadius:6, padding:"6px 8px", cursor:"pointer" }}>
                              <option value="">— Which priority would this serve? —</option>
                              {priorityList.filter(p => p.id !== "none").map(p => (
                                <option key={p.id} value={p.id}>{p.icon} {p.label}</option>
                              ))}
                            </select>
                            {prObj?.subtitle && (
                              <div style={{ fontSize:10, color:"var(--text4)", fontStyle:"italic", marginTop:4, lineHeight:1.4 }}>{prObj.subtitle}</div>
                            )}
                          </div>
                          <div>
                            <div style={{ fontSize:9, letterSpacing:1.2, textTransform:"uppercase", color:"var(--text3)", fontWeight:600, marginBottom:5 }}>Feeling (if you did it)</div>
                            <div style={{ display:"flex", gap:6, flexWrap:"wrap" }}>
                              {Object.entries(FEELING_META).map(([k, f]) => {
                                const sel = w.feeling === k;
                                return (
                                  <button key={k} onClick={() => setWishFeel(w.id, k)}
                                    style={{
                                      padding:"5px 10px", borderRadius:14,
                                      border: sel ? `1px solid ${f.color}` : "1px solid var(--border2)",
                                      background: sel ? `${f.color}22` : "transparent",
                                      color: sel ? f.color : "var(--text2)",
                                      cursor:"pointer", fontFamily:"var(--sans)", fontSize:11,
                                      fontWeight: sel ? 700 : 500,
                                      display:"inline-flex", alignItems:"center", gap:4,
                                    }}>
                                    {f.emoji} {f.label}
                                  </button>
                                );
                              })}
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                  <div style={{ marginTop:12, padding:"4px 12px", fontSize:11, color:"var(--text3)", textAlign:"right" }}>
                    {wishes.length} item{wishes.length === 1 ? "" : "s"} · {wishHours} hrs/week needed
                  </div>
                </>
              )}

              {/* ─── SWAP FLOW — "Imagine the trade" ─── */}
              {readyP3 && (
                <div style={{ marginTop:26, paddingTop:24, borderTop:"1px solid var(--border)" }}>
                  <div style={{ fontSize:10, letterSpacing:2, textTransform:"uppercase", fontWeight:700, color:"var(--warm)", marginBottom:6 }}>Imagine the trade</div>
                  <p style={{ fontSize:16, color:"var(--text)", lineHeight:1.75, margin:"0 0 12px", fontFamily:"var(--serif)", fontStyle:"italic" }}>
                    Nothing has to change today. But — imagine the trade. What would you hand off, reshape, or stop, to make room for what's missing?
                  </p>
                  <div style={{ padding:"10px 14px", marginBottom:18, background:"rgba(0,0,0,.25)", borderRadius:6, fontSize:12, color:"var(--text2)", lineHeight:1.6 }}>
                    <strong style={{ color:"var(--warm)" }}>Just the thought experiment for now.</strong>{" "}
                    Whatever trades you nominate here carry forward to <strong>A4 — Act On It</strong>, where you'll turn each one into the first concrete step. Here, you're mapping intent, not committing to a plan.
                  </div>

                  {/* Supports toggle */}
                  <div onClick={() => set("a2_ta_show_supports", !showSupports)}
                    style={{
                      display:"inline-flex", alignItems:"center", gap:8, marginBottom:14,
                      padding:"7px 12px", background:"rgba(0,0,0,.2)",
                      border: `1px solid ${showSupports ? "var(--warm)" : "var(--border2)"}`,
                      borderRadius:14, cursor:"pointer", fontSize:11,
                      color: showSupports ? "var(--warm)" : "var(--text2)",
                    }}>
                    <span style={{
                      width:8, height:8, borderRadius:"50%",
                      background: showSupports ? "var(--warm)" : "transparent",
                      border: `1px solid ${showSupports ? "var(--warm)" : "var(--text3)"}`,
                    }} />
                    <span>Also show activities I love (some great time might still be misallocated)</span>
                  </div>

                  {/* Per-wish swap rows */}
                  {wishes.map(w => {
                    const sw = swapPatch(w.id);
                    const haveTime = sw.fromId === "__have_time__";
                    const fromAct = !haveTime && sw.fromId
                      ? [...leaksActs, ...reshapeActs, ...supportsActs].find(a => a.id === sw.fromId)
                      : null;
                    const maxShift = fromAct ? Math.min(fromAct.hours, w.hours) : w.hours;
                    const shiftOptions = SHIFT_HOURS.filter(h => h <= (maxShift || 20));
                    const hoursDisabled = haveTime || !sw.fromId;
                    const coreFilled = sw.fromId && sw.when && (haveTime || sw.hours);
                    const needsDetail = sw.block === "not_time" || sw.block === "both";
                    const showNameIt = needsDetail && sw.blockDetail === "other";
                    const fEmoji = FEELING_META[w.feeling]?.emoji || "";
                    const pl = priById(w.pri)?.label || "";

                    return (
                      <div key={w.id} style={{ padding:"14px 16px", marginBottom:10, background:"rgba(0,0,0,.2)", border:"1px solid var(--border2)", borderRadius:8 }}>
                        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:12 }}>
                          <span style={{ fontSize:14, fontWeight:500, color:"var(--text)" }}>
                            <span style={{ marginRight:6 }}>{fEmoji}</span>{w.label}
                          </span>
                          <span style={{ fontSize:11, color:"var(--text3)" }}>{pl} · needs {w.hours} hrs/wk</span>
                        </div>

                        <div style={{ display:"grid", gridTemplateColumns:"1fr auto", gap:"10px 14px", alignItems:"start" }}>
                          {/* Trade from */}
                          <div style={{ display:"flex", flexDirection:"column", gap:4 }}>
                            <span style={{ fontSize:9, color:"var(--text3)", letterSpacing:1.2, textTransform:"uppercase", fontWeight:600 }}>Trade from</span>
                            <select value={sw.fromId || ""} onChange={e => setSwap(w.id, { fromId: e.target.value || null, hours: null })}
                              style={{
                                width:"100%", fontFamily:"var(--sans)", fontSize:12,
                                background:"var(--bg3)",
                                color: haveTime ? "#60a5fa" : sw.fromId ? "var(--text)" : "var(--text2)",
                                border: haveTime ? "1px solid #60a5fa" : sw.fromId ? "1px solid var(--warm)" : "1px solid var(--border2)",
                                borderRadius:6, padding:"6px 8px", cursor:"pointer",
                              }}>
                              <option value="">— Reclaim hours from... —</option>
                              <option value="__have_time__">— I have the time, no trade needed —</option>
                              {reclaimPool.map(a => {
                                const pl2 = priById(a.pri)?.label || "";
                                const bucketTag = a.bucket === "supports" ? " (you love this)" : "";
                                const tail = pl2 && a.pri !== "none" ? ` · ${pl2}` : "";
                                return (
                                  <option key={a.id} value={a.id}>{a.label} · {a.hours} hrs/wk{tail}{bucketTag}</option>
                                );
                              })}
                            </select>
                          </div>

                          {/* Hours to shift */}
                          <div style={{ display:"flex", flexDirection:"column", gap:4 }}>
                            <span style={{ fontSize:9, color:"var(--text3)", letterSpacing:1.2, textTransform:"uppercase", fontWeight:600 }}>Hours to shift</span>
                            <select value={sw.hours || ""} onChange={e => setSwap(w.id, { hours: e.target.value ? Number(e.target.value) : null })}
                              disabled={hoursDisabled}
                              style={{
                                width:84, fontFamily:"var(--sans)", fontSize:12,
                                background:"var(--bg3)",
                                color: sw.hours && !haveTime ? "var(--text)" : "var(--text2)",
                                border: sw.hours && !haveTime ? "1px solid var(--warm)" : "1px solid var(--border2)",
                                borderRadius:6, padding:"6px 8px",
                                cursor: hoursDisabled ? "not-allowed" : "pointer",
                                opacity: hoursDisabled ? 0.4 : 1,
                              }}>
                              <option value="">— hrs —</option>
                              {shiftOptions.map(h => <option key={h} value={h}>{h} hrs</option>)}
                            </select>
                          </div>

                          {/* Timeline */}
                          <div style={{ gridColumn:"1 / -1", display:"flex", gap:6, flexWrap:"wrap", alignItems:"center" }}>
                            <span style={{ fontSize:9, color:"var(--text3)", letterSpacing:1.2, textTransform:"uppercase", fontWeight:600, alignSelf:"center" }}>Timeline to act:</span>
                            {TIMELINES.map(t => {
                              const sel = sw.when === t.id;
                              return (
                                <button key={t.id} onClick={() => setSwap(w.id, { when: t.id })}
                                  style={{
                                    padding:"5px 12px", borderRadius:14,
                                    border: sel ? "1px solid var(--warm)" : "1px solid var(--border2)",
                                    background: sel ? "rgba(201,168,76,.18)" : "transparent",
                                    color: sel ? "var(--warm)" : "var(--text2)",
                                    cursor:"pointer", fontFamily:"var(--sans)", fontSize:11,
                                    fontWeight: sel ? 700 : 500,
                                  }}>
                                  {t.label}
                                </button>
                              );
                            })}
                          </div>

                          {/* Block question — appears once core is filled */}
                          {coreFilled && (
                            <div style={{ gridColumn:"1 / -1", marginTop:12, padding:"12px 14px", background:"rgba(0,0,0,.2)", border:"1px dashed var(--border2)", borderRadius:6 }}>
                              <div style={{ fontSize:12, color:"var(--text)", marginBottom:8, fontWeight:500 }}>What's truly stopping you from starting this right now?</div>
                              <div style={{ display:"flex", gap:6, flexWrap:"wrap", marginBottom: needsDetail ? 8 : 0 }}>
                                {[
                                  { v: "not_time", label: "Not time" },
                                  { v: "time",     label: "Time" },
                                  { v: "both",     label: "Time and something else" },
                                ].map(b => {
                                  const sel = sw.block === b.v;
                                  return (
                                    <button key={b.v} onClick={() => setSwap(w.id, { block: b.v, blockDetail: b.v === "time" ? null : sw.blockDetail, blockFreehand: b.v === "time" ? null : sw.blockFreehand })}
                                      style={{
                                        padding:"5px 12px", borderRadius:14,
                                        border: sel ? "1px solid #60a5fa" : "1px solid var(--border2)",
                                        background: sel ? "rgba(96,165,250,.2)" : "transparent",
                                        color: sel ? "#60a5fa" : "var(--text2)",
                                        cursor:"pointer", fontFamily:"var(--sans)", fontSize:11,
                                        fontWeight: sel ? 700 : 500,
                                      }}>
                                      {b.label}
                                    </button>
                                  );
                                })}
                              </div>

                              {/* Detail dropdown — only if not_time or both */}
                              {needsDetail && (
                                <div style={{ marginTop:8 }}>
                                  <div style={{ fontSize:9, color:"var(--text3)", letterSpacing:1.2, textTransform:"uppercase", fontWeight:600, marginBottom:4 }}>What is it?</div>
                                  <select value={sw.blockDetail || ""} onChange={e => setSwap(w.id, { blockDetail: e.target.value || null })}
                                    style={{
                                      width:"100%", fontFamily:"var(--sans)", fontSize:12,
                                      background:"var(--bg3)",
                                      color: sw.blockDetail ? "var(--text)" : "var(--text2)",
                                      border: sw.blockDetail ? "1px solid #60a5fa" : "1px solid var(--border2)",
                                      borderRadius:6, padding:"6px 8px", cursor:"pointer",
                                    }}>
                                    <option value="">— Pick the obstacle —</option>
                                    {BLOCK_OPTIONS.map(o => <option key={o.id} value={o.id}>{o.label}</option>)}
                                  </select>
                                  {sw.blockDetail && (
                                    <div style={{ marginTop:10 }}>
                                      <div style={{ fontSize:9, color:"var(--text3)", letterSpacing:1.2, textTransform:"uppercase", fontWeight:600, marginBottom:4 }}>Name it — in your words</div>
                                      <input type="text" value={sw.blockFreehand || ""}
                                        onChange={e => setSwap(w.id, { blockFreehand: e.target.value })}
                                        placeholder={
                                          sw.blockDetail === "fear" ? "What are you actually afraid of?"
                                          : sw.blockDetail === "permission" ? "Whose permission? What would they say?"
                                          : sw.blockDetail === "identity" ? "Who do you think this is for, if not you?"
                                          : sw.blockDetail === "skill" ? "What would you need to learn first?"
                                          : sw.blockDetail === "money" ? "What's the money story?"
                                          : sw.blockDetail === "energy" ? "What's draining you most?"
                                          : sw.blockDetail === "social" ? "Who do you wish was doing this too?"
                                          : "What's actually in the way?"
                                        }
                                        style={{
                                          width:"100%", fontFamily:"var(--sans)", fontSize:13,
                                          background:"var(--bg3)",
                                          color:"var(--text)",
                                          border: sw.blockFreehand ? "1px solid #60a5fa" : "1px solid var(--border2)",
                                          borderRadius:6, padding:"7px 10px", outline:"none",
                                        }} />
                                    </div>
                                  )}
                                </div>
                              )}
                            </div>
                          )}
                        </div>

                        {/* Hypothetical swap card */}
                        {coreFilled && (haveTime ? (
                          <div style={{ marginTop:10, padding:"12px 14px", background:"rgba(201,168,76,.08)", border:"1px solid rgba(201,168,76,.35)", borderRadius:6, fontSize:13, lineHeight:1.6 }}>
                            <div style={{ color:"var(--text3)", fontStyle:"italic", fontSize:11, marginBottom:4, fontFamily:"var(--serif)" }}>If you could...</div>
                            <div><span style={{ color:"#34d399" }}>Start {w.label}</span> — no trade needed.</div>
                            <span style={{ display:"block", marginTop:4, color:"var(--text2)", fontSize:12 }}>
                              You'd aim to start this within {TIMELINES.find(t => t.id === sw.when)?.label.replace("<", "under ").replace(">", "over ")}.
                            </span>
                          </div>
                        ) : (
                          <div style={{ marginTop:10, padding:"12px 14px", background:"rgba(201,168,76,.08)", border:"1px solid rgba(201,168,76,.35)", borderRadius:6, fontSize:13, lineHeight:1.6 }}>
                            <div style={{ color:"var(--text3)", fontStyle:"italic", fontSize:11, marginBottom:4, fontFamily:"var(--serif)" }}>If you could...</div>
                            <div>
                              <span style={{ color: fromAct?.bucket === "supports" ? "#34d399" : fromAct?.bucket === "reshape" ? "#f59e0b" : "#ef4444" }}>
                                trade {sw.hours} hrs from {fromAct?.label}
                              </span>
                              <span style={{ color:"var(--warm)", margin:"0 6px", fontWeight:700 }}>→</span>
                              <span style={{ color:"#34d399" }}>{sw.hours} hrs for {w.label}</span>
                            </div>
                            <span style={{ display:"block", marginTop:4, color:"var(--text2)", fontSize:12 }}>
                              You'd aim to start this within {TIMELINES.find(t => t.id === sw.when)?.label.replace("<", "under ").replace(">", "over ")}.
                            </span>
                          </div>
                        ))}
                      </div>
                    );
                  })}

                  {/* A3 tee-up — appears when at least one non-time block is set */}
                  {hasNonTimeBlock && (
                    <div style={{ marginTop:16, padding:"14px 18px", background:"rgba(96,165,250,.06)", border:"1px solid rgba(96,165,250,.3)", borderRadius:8 }}>
                      <div style={{ fontSize:10, letterSpacing:2, textTransform:"uppercase", fontWeight:700, color:"#60a5fa", marginBottom:6 }}>Tee-up for A3</div>
                      <div style={{ fontSize:13, color:"var(--text)", lineHeight:1.7 }}>
                        Notice — some of these aren't time problems. A3 is where we look at what's really holding you back: the people, habits, places, and thoughts that keep pulling you back. Time can be moved. The rest needs a different kind of look.
                      </div>
                    </div>
                  )}
                </div>
              )}

              <div style={{ marginTop:18, textAlign:"center", paddingTop:16, borderTop:"1px solid var(--border)" }}>
                <button disabled={!readyP3} onClick={() => set("a2_ta_p3_done", true)}
                  style={{ padding:"10px 24px", borderRadius:16, background: readyP3 ? "var(--warm)" : "transparent", color: readyP3 ? "var(--bg)" : "var(--text4)", border: readyP3 ? "none" : "1px solid var(--border2)", cursor: readyP3 ? "pointer" : "not-allowed", fontFamily:"var(--sans)", fontSize:13, fontWeight:700 }}>
                  Next · See it →
                </button>
                {!readyP3 && wishes.length === 0 && (
                  <div style={{ marginTop:8, fontSize:11, color:"var(--text4)", fontStyle:"italic" }}>
                    Add at least one thing you want to be doing.
                  </div>
                )}
                {!readyP3 && wishes.length > 0 && (
                  <div style={{ marginTop:8, fontSize:11, color:"var(--text4)", fontStyle:"italic" }}>
                    Tag priority + feeling on each one.
                  </div>
                )}
              </div>
            </div>
          );
        })()}

        {/* ─── PHASE 4 ─── */}
        {!(map.a2_ta_p2_done && map.a2_ta_p3_done) ? (
          <div style={{ marginBottom:16, padding:"12px 16px", background:"rgba(255,255,255,.02)", border:"1px dashed var(--border2)", borderRadius:8, opacity:0.55 }}>
            <div style={{ fontSize:10, letterSpacing:2, textTransform:"uppercase", fontWeight:700, color:"var(--text4)", marginBottom:4 }}>Phase 4 · See it (locked)</div>
            <div style={{ fontSize:12, color:"var(--text4)" }}>
              Name what's missing, then we'll show you what your time is saying.
            </div>
          </div>
        ) : (() => {
          // Rebuild the buckets and focus detail in Phase 4's scope
          const bucketFor4 = (a) => {
            if (!a.feeling || !a.pri) return null;
            const isNone = a.pri === "none";
            const f = a.feeling;
            if (f === "despise") return "leaks";
            if (f === "dislike" && isNone) return "leaks";
            if (isNone) return "leaks";
            if (f === "love") return "supports";
            if (f === "like") return "supports";
            return "reshape";
          };
          const enriched = acts.map(a => ({ ...a, bucket: bucketFor4(a) })).filter(a => a.bucket);
          const sum = (arr) => arr.reduce((t, a) => t + (Number(a.hours) || 0), 0);
          const supports = enriched.filter(a => a.bucket === "supports").sort((x,y) => y.hours - x.hours);
          const reshape = enriched.filter(a => a.bucket === "reshape").sort((x,y) => y.hours - x.hours);
          const leaks = enriched.filter(a => a.bucket === "leaks").sort((x,y) => y.hours - x.hours);
          const totalCount = enriched.length;
          const totalHrs = sum(enriched);

          // Pinned key misalignment (from Key Misalignment page)
          const misalignments = computeMisalignments(map);
          const pinnedId = map.a2_km_pinned_id;
          const primary = pinnedId ? misalignments.find(m => m.id === pinnedId) : null;
          const focusItemId = primary?.itemId || null;
          const focusActs = focusItemId ? enriched.filter(a => a.pri === focusItemId) : [];
          const fQuality = focusActs.filter(a => a.feeling === "love" || a.feeling === "like");
          const fReshape = focusActs.filter(a => a.feeling === "dislike" || a.feeling === "despise");
          const fQualityHrs = sum(fQuality);
          const fReshapeHrs = sum(fReshape);
          const fTotalHrs = sum(focusActs);

          const BucketBlock = ({ bucketKey, title, subtitle, items, color, bgColor }) => {
            if (items.length === 0) return null;
            const hrs = sum(items);
            return (
              <div style={{ marginBottom:22 }}>
                <div style={{ display:"flex", alignItems:"baseline", gap:10, marginBottom:10 }}>
                  <span style={{ fontSize:11, letterSpacing:2, textTransform:"uppercase", fontWeight:700, color }}>{title}</span>
                  <span style={{ fontSize:11, color:"var(--text3)" }}>
                    {items.length} {items.length === 1 ? "activity" : "activities"} · {hrs} hrs/wk
                  </span>
                </div>
                <div style={{ borderLeft:`2px solid ${bgColor}` }}>
                  {items.map(a => {
                    const feel = FEELING_META[a.feeling];
                    const prObj = priById(a.pri);
                    const pLabel = prObj?.label || "";
                    const isNone = a.pri === "none";
                    return (
                      <div key={a.id} style={{ display:"flex", alignItems:"center", gap:12, padding:"10px 14px", marginBottom:5, marginLeft:8, background:"rgba(0,0,0,.2)", borderRadius:6 }}>
                        <span style={{ fontSize:18 }}>{feel?.emoji}</span>
                        <div style={{ flex:1, minWidth:0 }}>
                          <div style={{ fontSize:13, color:"var(--text)", fontWeight:500 }}>{a.label}</div>
                          {pLabel && (
                            <div style={{ fontSize:10, color: isNone ? "#ef4444" : "var(--text3)", marginTop:2 }}>
                              → {pLabel}
                            </div>
                          )}
                        </div>
                        <span style={{ fontSize:11, color:"var(--text3)", flexShrink:0 }}>{a.hours} hrs</span>
                      </div>
                    );
                  })}
                </div>
                <div style={{ marginTop:8, marginLeft:12, fontSize:14, color:"var(--text2)", fontStyle:"italic", lineHeight:1.6, fontFamily:"var(--serif)" }}>
                  {subtitle}
                </div>
              </div>
            );
          };

          return (
            <div style={{ marginBottom:16 }}>
              {/* FOCUS DETAIL CARD — only shows if Key Misalignment is pinned */}
              {primary && (
                <div style={{
                  padding:"24px 28px", marginBottom:22,
                  background:"linear-gradient(135deg, rgba(201,168,76,.12), rgba(255,255,255,.02))",
                  border:"1px solid var(--warm)", borderRadius:10,
                }}>
                  <div style={{ fontSize:10, color:"var(--warm)", fontWeight:700, letterSpacing:2, textTransform:"uppercase", marginBottom:10 }}>Your A2 focus, up close</div>
                  <div style={{ display:"flex", alignItems:"center", gap:12, marginBottom:14 }}>
                    <span style={{ fontSize:28 }}>{primary.icon}</span>
                    <div>
                      <div style={{ fontFamily:"var(--serif)", fontSize:24, color:"var(--text)", lineHeight:1.2 }}>{primary.label}</div>
                      <div style={{ fontSize:11, color:"var(--text3)", marginTop:3 }}>{primary.source} · scored {primary.score}/10 today</div>
                    </div>
                  </div>

                  {focusActs.length === 0 ? (
                    <div style={{ padding:"12px 16px", background:"rgba(0,0,0,.25)", borderRadius:6, fontSize:13, color:"var(--text2)", lineHeight:1.7 }}>
                      None of your weekly activities are tagged to <strong>{primary.label}</strong>. That's the gap — your time isn't going here at all. The swap flow above is where the first trades get nominated.
                    </div>
                  ) : (
                    <>
                      <div style={{ fontSize:16, color:"var(--text)", lineHeight:1.75, marginBottom:16 }}>
                        You have <strong>{fTotalHrs} hours/week</strong> tagged to {primary.label}. Here's what that time actually is:
                      </div>
                      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12, marginBottom:14 }}>
                        <div style={{ padding:"14px 16px", borderRadius:8, background:"rgba(52,211,153,.08)", border:"1px solid rgba(52,211,153,.3)" }}>
                          <div style={{ fontSize:10, fontWeight:700, letterSpacing:1.5, textTransform:"uppercase", color:"#34d399", marginBottom:6 }}>Quality time here</div>
                          <div style={{ fontFamily:"var(--serif)", fontSize:20, color:"var(--text)", marginBottom:8 }}>
                            {fQualityHrs} <span style={{ fontSize:11, color:"var(--text3)", fontFamily:"var(--sans)" }}>hrs/wk</span>
                          </div>
                          {fQuality.length > 0 ? fQuality.map(a => (
                            <div key={a.id} style={{ padding:"6px 10px", background:"rgba(0,0,0,.2)", borderRadius:5, marginBottom:4, fontSize:12, display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                              <span style={{ marginRight:5 }}>{FEELING_META[a.feeling]?.emoji}</span>
                              <span style={{ flex:1, color:"var(--text)" }}>{a.label}</span>
                              <span style={{ color:"var(--text3)", fontSize:11 }}>{a.hours} hrs</span>
                            </div>
                          )) : (
                            <div style={{ fontSize:12, color:"var(--text4)", fontStyle:"italic", padding:"4px 0" }}>No quality time here yet.</div>
                          )}
                        </div>
                        <div style={{ padding:"14px 16px", borderRadius:8, background:"rgba(245,158,11,.08)", border:"1px solid rgba(245,158,11,.3)" }}>
                          <div style={{ fontSize:10, fontWeight:700, letterSpacing:1.5, textTransform:"uppercase", color:"#f59e0b", marginBottom:6 }}>Could be reshaped</div>
                          <div style={{ fontFamily:"var(--serif)", fontSize:20, color:"var(--text)", marginBottom:8 }}>
                            {fReshapeHrs} <span style={{ fontSize:11, color:"var(--text3)", fontFamily:"var(--sans)" }}>hrs/wk</span>
                          </div>
                          {fReshape.length > 0 ? fReshape.map(a => (
                            <div key={a.id} style={{ padding:"6px 10px", background:"rgba(0,0,0,.2)", borderRadius:5, marginBottom:4, fontSize:12, display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                              <span style={{ marginRight:5 }}>{FEELING_META[a.feeling]?.emoji}</span>
                              <span style={{ flex:1, color:"var(--text)" }}>{a.label}</span>
                              <span style={{ color:"var(--text3)", fontSize:11 }}>{a.hours} hrs</span>
                            </div>
                          )) : (
                            <div style={{ fontSize:12, color:"var(--text4)", fontStyle:"italic", padding:"4px 0" }}>Nothing to reshape here.</div>
                          )}
                        </div>
                      </div>
                      <div style={{ padding:"12px 16px", background:"rgba(0,0,0,.25)", borderLeft:"3px solid var(--warm)", borderRadius:4, fontFamily:"var(--serif)", fontStyle:"italic", fontSize:16, color:"var(--text)", lineHeight:1.75 }}>
                        {fReshape.length > 0
                          ? <>Of your {fTotalHrs} hours tagged to {primary.label}, <strong>{fReshapeHrs} feel draining</strong>. Those hours aren't lost — they're <strong>redirect candidates</strong>. Could this become shared? Outsourced? Reshaped? The time stays with {primary.label}, but how you spend it shifts.</>
                          : <>Everything you've tagged to {primary.label} feels good. The gap isn't in <em>how</em> you spend the time — it's that you need <strong>more of it</strong>. The swap flow above is where those hours come from.</>
                        }
                      </div>
                    </>
                  )}
                </div>
              )}

              {/* THREE BUCKETS — collapsible */}
              {(() => {
                const fullWeekOpen = map.a2_ta_full_week_open !== false;
                return (
                  <div style={{ background:"var(--bg2)", border:"1px solid var(--border2)", borderRadius:10, overflow:"hidden" }}>
                    <div onClick={() => set("a2_ta_full_week_open", !fullWeekOpen)}
                      style={{ padding:"16px 24px", cursor:"pointer", userSelect:"none", display:"flex", justifyContent:"space-between", alignItems:"center", gap:12 }}>
                      <div style={{ minWidth:0 }}>
                        <div style={{ fontSize:10, letterSpacing:2, textTransform:"uppercase", fontWeight:700, color:"var(--warm)", marginBottom:4 }}>Phase 4 · See it</div>
                        <h3 style={{ fontFamily:"var(--serif)", fontSize:22, fontWeight:400, margin:0, color:"var(--text)", letterSpacing:"-0.3px" }}>Your full week</h3>
                        {!fullWeekOpen && (
                          <div style={{ fontSize:11, color:"var(--text3)", marginTop:4, fontStyle:"italic" }}>
                            {totalCount} activities · {totalHrs} hrs/wk — {supports.length} support, {reshape.length} reshape, {leaks.length} leak.
                          </div>
                        )}
                      </div>
                      <span style={{ fontSize:16, color:"var(--warm)", flexShrink:0, transform: fullWeekOpen ? "rotate(180deg)" : "none", transition:"transform .2s" }}>▾</span>
                    </div>
                    {fullWeekOpen && (
                      <div style={{ padding:"0 28px 24px", borderTop:"1px solid var(--border)" }}>
                        <p style={{ fontSize:13, color:"var(--text2)", lineHeight:1.7, margin:"18px 0 20px" }}>
                          Every activity, sorted by what they do to your energy and direction. {totalCount} activities · {totalHrs} hrs/wk — {supports.length} support, {reshape.length} reshape, {leaks.length} leak.
                        </p>

                        <BucketBlock
                          bucketKey="supports" title="Supports"
                          subtitle="These are your fuel. Protect the time."
                          items={supports}
                          color="#34d399" bgColor="rgba(52,211,153,.4)"
                        />
                        <BucketBlock
                          bucketKey="reshape" title="Reshape these"
                          subtitle="Not draining, not driving — move them, reshape them, or let them be."
                          items={reshape}
                          color="#f59e0b" bgColor="rgba(245,158,11,.4)"
                        />
                        <BucketBlock
                          bucketKey="leaks" title="Leaks"
                          subtitle="These are the hours you said you didn't have. They're here."
                          items={leaks}
                          color="#ef4444" bgColor="rgba(239,68,68,.4)"
                        />
                      </div>
                    )}
                  </div>
                );
              })()}

              {/* Closing copy — always visible */}
              <div style={{ marginTop:18, padding:"16px 20px", background:"rgba(201,168,76,.06)", borderLeft:"3px solid var(--warm)", borderRadius:6 }}>
                <div style={{ fontFamily:"var(--serif)", fontSize:15, fontStyle:"italic", color:"var(--text)", lineHeight:1.7 }}>
                  You're not broken. Your time is telling you the truth. The work now isn't to do more — it's to <strong>protect the supports, reshape what you can, and let the leaks be seen</strong>. A4 turns the trades you named above into real moves.
                </div>
              </div>
            </div>
          );
        })()}

        <div style={{ marginBottom:22, marginTop:18 }}>
          <AIChat voiceId={voice} onVoiceChange={setVoicePersist} name={name} intake={intake} mapData={map}
            sectionLabel="time audit"
            placeholder="Ask Katherine about what you're seeing..." />
        </div>

        <div style={{ marginTop:26, paddingTop:18, borderTop:"1px solid var(--border)", display:"flex", justifyContent:"space-between", gap:8 }}>
          <button className="btn-g" onClick={() => a2Goto(prevStep.id)}>← {prevStep.label}</button>
          <button className="btn" onClick={() => { setA2Done(d => [...new Set([...d, "time_audit"])]); a2Goto(nextStep.id); }}>{nextStep.label} →</button>
        </div>
      </div>
    );
  }
  if (a2Step === "letter") {
    const letterIdx = A2_STEPS.findIndex(s => s.id === "letter");
    const prevStep = A2_STEPS[letterIdx - 1];
    const nextStep = A2_STEPS[letterIdx + 1];

    const ctxOpen = !!map.a2_fsl_context_open;
    const s1 = map.a2_fsl_s1 || "";
    const s2 = map.a2_fsl_s2 || "";
    const s3 = map.a2_fsl_s3 || "";
    const s4 = map.a2_fsl_reflection || "";
    const s4text = map.a2_fsl_s4 || "";

    // Pull real data from map
    const purpose = map.purpose_final || map.purpose_draft || "";
    const bagGrowth = map.growth_sentence || map.growth_summary || "";
    const threeyrGrowth = map.threeyr_growth_sentence || "";
    const oneyrGrowth = map.oneyr_growth_sentence || "";
    const bagYear = map.bag_year || "";
    const animals = (map.animals || []).filter(a => a && a.name);
    const animalNames = animals.map(a => a.name);
    // Values — pull top values from val_*_name
    const valCount2 = parseInt(map?.val_count) || 0;
    const topValues = [];
    for (let i = 0; i < valCount2; i++) {
      const vn = map?.[`val_${i}_name`];
      if (vn) topValues.push(vn);
    }
    // Time picks
    const timePickLabels = (map.time_picked || []).map(id => {
      const preset = TIME_AREA_PRESETS.find(p => p.id === id);
      return preset?.label || id;
    });

    // A2 data
    const bucketFor5 = (a) => {
      if (!a.feeling || !a.pri) return null;
      const isNone = a.pri === "none";
      const f = a.feeling;
      if (f === "despise") return "leaks";
      if (f === "dislike" && isNone) return "leaks";
      if (isNone) return "leaks";
      if (f === "love") return "supports";
      if (f === "like") return "supports";
      return "reshape";
    };
    const actsL = (map.a2_ta_acts || []).map(a => ({ ...a, bucket: bucketFor5(a) })).filter(a => a.bucket);
    const sumL = (arr) => arr.reduce((t, a) => t + (Number(a.hours) || 0), 0);
    const leaksHrs = sumL(actsL.filter(a => a.bucket === "leaks"));
    const leakList = actsL.filter(a => a.bucket === "leaks").sort((x,y) => y.hours - x.hours).slice(0, 4).map(a => a.label);

    // Focus from pinned key misalignment
    const misalignL = computeMisalignments(map);
    const pinnedIdL = map.a2_km_pinned_id;
    const primaryL = pinnedIdL ? misalignL.find(m => m.id === pinnedIdL) : null;
    const focusLabel = primaryL?.label || "your top priority";
    const focusActsL = primaryL?.itemId ? actsL.filter(a => a.pri === primaryL.itemId) : [];
    const focusQualityHrs = sumL(focusActsL.filter(a => a.feeling === "love" || a.feeling === "like"));

    // Wishlist
    const wishesL = map.a2_ta_wishes || [];
    const wishLabels = wishesL.map(w => w.label);

    const setText = (key, val) => set(key, val);
    const totalWords = [s1, s2, s3, s4text, s4].join(" ").split(/\s+/).filter(w => w.length > 0).length;
    const allWritten = s1.trim() && s2.trim() && s3.trim() && s4text.trim();

    const countWords = (txt) => (txt || "").split(/\s+/).filter(w => w.length > 0).length;

    return wrapA2(
      <div>
        <div style={{ fontSize:11, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color:"var(--warm)", marginBottom:11 }}>A2 · Future Self Letter</div>
        <h2 style={{ fontFamily:"var(--serif)", fontSize:38, fontWeight:400, lineHeight:1.2, marginBottom:10, letterSpacing:"-0.3px" }}>A letter from your future self</h2>
        <p style={{ fontSize:16, color:"var(--text2)", lineHeight:1.75, marginBottom:20, maxWidth:620 }}>
          Four sections. Each one pulls from what you've already built. You write in your own words — as if the version of you who's already lived this is speaking back to you now.
        </p>

        {/* Context toggle */}
        <div onClick={() => set("a2_fsl_context_open", !ctxOpen)}
          style={{
            display:"inline-flex", alignItems:"center", gap:10, padding:"10px 16px",
            background:"rgba(0,0,0,.25)", border:`1px solid ${ctxOpen ? "var(--warm)" : "var(--border2)"}`,
            borderRadius:10, cursor:"pointer", fontSize:12,
            color: ctxOpen ? "var(--text)" : "var(--text2)", marginBottom:24,
            transition:"all .15s",
          }}>
          <span style={{ color:"var(--warm)", transform: ctxOpen ? "rotate(90deg)" : "none", transition:"transform .15s" }}>▸</span>
          <span style={{ fontWeight:500 }}>{ctxOpen ? "Hide" : "Show"} what you said in A1 — your BAG, Identity, Values</span>
        </div>

        {/* Context panel */}
        {ctxOpen && (
          <div style={{
            padding:"20px 24px", marginBottom:24,
            background:"linear-gradient(180deg, rgba(201,168,76,.06), rgba(0,0,0,.1))",
            border:"1px solid var(--border2)", borderLeft:"3px solid var(--warm)",
            borderRadius:8,
          }}>
            <div style={{ fontSize:10, letterSpacing:2, textTransform:"uppercase", color:"var(--warm)", fontWeight:700, marginBottom:10 }}>From your A1 Map of Me™</div>

            {purpose && (
              <div style={{ marginBottom:16 }}>
                <div style={{ fontSize:10, color:"var(--text3)", letterSpacing:1.5, textTransform:"uppercase", fontWeight:600, marginBottom:6 }}>Purpose — your north star</div>
                <div style={{ fontFamily:"var(--serif)", fontSize:16, lineHeight:1.6, color:"var(--text)", fontStyle:"italic" }}>"{purpose}"</div>
              </div>
            )}

            {bagGrowth && (
              <div style={{ marginBottom:16 }}>
                <div style={{ fontSize:10, color:"var(--text3)", letterSpacing:1.5, textTransform:"uppercase", fontWeight:600, marginBottom:6 }}>BAG — your 10–15 year vision</div>
                <div style={{ fontFamily:"var(--serif)", fontSize:16, lineHeight:1.6, color:"var(--text)", fontStyle:"italic" }}>"{bagGrowth}"</div>
              </div>
            )}

            {threeyrGrowth && (
              <div style={{ marginBottom:16 }}>
                <div style={{ fontSize:10, color:"var(--text3)", letterSpacing:1.5, textTransform:"uppercase", fontWeight:600, marginBottom:6 }}>3-Year growth</div>
                <div style={{ fontFamily:"var(--serif)", fontSize:16, lineHeight:1.6, color:"var(--text)", fontStyle:"italic" }}>"{threeyrGrowth}"</div>
              </div>
            )}

            {oneyrGrowth && (
              <div style={{ marginBottom:16 }}>
                <div style={{ fontSize:10, color:"var(--text3)", letterSpacing:1.5, textTransform:"uppercase", fontWeight:600, marginBottom:6 }}>1-Year growth</div>
                <div style={{ fontFamily:"var(--serif)", fontSize:16, lineHeight:1.6, color:"var(--text)", fontStyle:"italic" }}>"{oneyrGrowth}"</div>
              </div>
            )}

            {animalNames.length > 0 && (
              <div style={{ marginBottom:16 }}>
                <div style={{ fontSize:10, color:"var(--text3)", letterSpacing:1.5, textTransform:"uppercase", fontWeight:600, marginBottom:6 }}>Identity — the animals you chose</div>
                <div style={{ display:"flex", gap:6, flexWrap:"wrap" }}>
                  {animalNames.map((a, i) => (
                    <span key={i} style={{ padding:"4px 10px", background:"rgba(201,168,76,.12)", color:"var(--text)", border:"1px solid rgba(201,168,76,.3)", borderRadius:12, fontSize:12 }}>{a}</span>
                  ))}
                </div>
              </div>
            )}

            {topValues.length > 0 && (
              <div style={{ marginBottom:16 }}>
                <div style={{ fontSize:10, color:"var(--text3)", letterSpacing:1.5, textTransform:"uppercase", fontWeight:600, marginBottom:6 }}>Top values</div>
                <div style={{ display:"flex", gap:6, flexWrap:"wrap" }}>
                  {topValues.map((v, i) => (
                    <span key={i} style={{ padding:"4px 10px", background:"rgba(201,168,76,.12)", color:"var(--text)", border:"1px solid rgba(201,168,76,.3)", borderRadius:12, fontSize:12 }}>{v}</span>
                  ))}
                </div>
              </div>
            )}

            {timePickLabels.length > 0 && (
              <div style={{ marginBottom:0 }}>
                <div style={{ fontSize:10, color:"var(--text3)", letterSpacing:1.5, textTransform:"uppercase", fontWeight:600, marginBottom:6 }}>Time priorities</div>
                <div style={{ display:"flex", gap:6, flexWrap:"wrap" }}>
                  {timePickLabels.map((v, i) => (
                    <span key={i} style={{ padding:"4px 10px", background:"rgba(201,168,76,.12)", color:"var(--text)", border:"1px solid rgba(201,168,76,.3)", borderRadius:12, fontSize:12 }}>{v}</span>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Opening */}
        <div style={{ padding:"24px 28px", background:"var(--bg2)", border:"1px solid var(--warm)", borderRadius:10, marginBottom:28 }}>
          <div style={{ fontSize:10, letterSpacing:2, textTransform:"uppercase", color:"var(--warm)", fontWeight:700, marginBottom:12 }}>From your future self</div>
          <div style={{ fontFamily:"var(--serif)", fontSize:17, lineHeight:1.8, color:"var(--text)", fontStyle:"italic" }}>
            I'm writing from the life you're still building toward. You've just looked at your week honestly. Now I want to speak to what I see. Not to tell you what to do. To show you what I already know about the time you're spending. The four sections below are yours to fill. I'll prompt you with what you've already said you want. You answer me — in your own words. Don't skip this.
          </div>
        </div>

        {/* Section 1 — On the time that matters */}
        <div style={{ marginBottom:32 }}>
          <h3 style={{ fontFamily:"var(--serif)", fontSize:24, fontWeight:400, color:"var(--text)", margin:"0 0 14px", letterSpacing:"-0.2px" }}>On the time that matters</h3>
          <div style={{ padding:"14px 16px 14px 18px", background:"rgba(201,168,76,.05)", borderLeft:"2px solid var(--warm)", borderRadius:4, marginBottom:12, fontFamily:"var(--serif)", fontStyle:"italic", fontSize:15, lineHeight:1.7, color:"var(--text2)" }}>
            {animalNames.length > 0 && <>You chose <strong style={{ color:"var(--text)", fontStyle:"normal", fontWeight:500 }}>{animalNames.join(" and ")}</strong> as your Identity. </>}
            {focusQualityHrs > 0 && focusLabel !== "your top priority" && <>You tagged <strong style={{ color:"var(--text)", fontStyle:"normal", fontWeight:500 }}>{focusQualityHrs} hours/week with {focusLabel} as Love or Like</strong>. </>}
            {purpose && <>And your purpose, in your own words, was: <strong style={{ color:"var(--text)", fontStyle:"normal", fontWeight:500 }}>"{purpose}"</strong> </>}
            What would I — the version of you who's already built that life — say about these hours? Why do they matter? What happens to who you become if you protect them?
          </div>
          <textarea value={s1} onChange={e => setText("a2_fsl_s1", e.target.value)}
            placeholder="Write what I would say to you about these hours..."
            style={{ width:"100%", minHeight:140, padding:"16px 18px", background:"rgba(0,0,0,.22)", border:`1px solid ${s1.trim() ? "var(--warm)" : "var(--border2)"}`, borderRadius:8, color:"var(--text)", fontFamily:"var(--serif)", fontSize:16, lineHeight:1.7, resize:"vertical", outline:"none" }} />
          <div style={{ marginTop:6, fontSize:10, color: s1.trim() ? "#34d399" : "var(--text4)", textAlign:"right" }}>{countWords(s1)} words</div>
        </div>

        {/* Section 2 — On the time to let go */}
        <div style={{ marginBottom:32 }}>
          <h3 style={{ fontFamily:"var(--serif)", fontSize:24, fontWeight:400, color:"var(--text)", margin:"0 0 14px", letterSpacing:"-0.2px" }}>On the time to let go</h3>
          <div style={{ padding:"14px 16px 14px 18px", background:"rgba(201,168,76,.05)", borderLeft:"2px solid var(--warm)", borderRadius:4, marginBottom:12, fontFamily:"var(--serif)", fontStyle:"italic", fontSize:15, lineHeight:1.7, color:"var(--text2)" }}>
            {leaksHrs > 0 ? (
              <>You marked <strong style={{ color:"var(--text)", fontStyle:"normal", fontWeight:500 }}>{leaksHrs} hours a week</strong> as Leaks{leakList.length > 0 && <> — {leakList.join(", ")}</>}. You said none of it serves a priority you named. But you do it anyway. </>
            ) : (
              <>You just looked at where your hours go. Some of it serves what you said matters. Some of it doesn't. </>
            )}
            {topValues.length > 0 && <>And you said one of your top values is <strong style={{ color:"var(--text)", fontStyle:"normal", fontWeight:500 }}>{topValues[0]}</strong>. </>}
            What would I say to you about this gap — between what you say matters and where your hours actually go?
          </div>
          <textarea value={s2} onChange={e => setText("a2_fsl_s2", e.target.value)}
            placeholder="Write what I would say to you about what has to stop..."
            style={{ width:"100%", minHeight:140, padding:"16px 18px", background:"rgba(0,0,0,.22)", border:`1px solid ${s2.trim() ? "var(--warm)" : "var(--border2)"}`, borderRadius:8, color:"var(--text)", fontFamily:"var(--serif)", fontSize:16, lineHeight:1.7, resize:"vertical", outline:"none" }} />
          <div style={{ marginTop:6, fontSize:10, color: s2.trim() ? "#34d399" : "var(--text4)", textAlign:"right" }}>{countWords(s2)} words</div>
        </div>

        {/* URGENCY */}
        <div style={{ margin:"36px 0", padding:"28px 32px", background:"linear-gradient(135deg, rgba(0,0,0,.4), rgba(201,168,76,.1))", border:"1px solid var(--warm)", borderRadius:10, textAlign:"center" }}>
          <div style={{ fontSize:10, letterSpacing:2.5, textTransform:"uppercase", color:"var(--warm)", fontWeight:700, marginBottom:14 }}>A pause, from me</div>
          <div style={{ fontFamily:"var(--serif)", fontSize:22, lineHeight:1.5, color:"var(--text)", fontStyle:"italic", fontWeight:400 }}>
            The clock is running. Mine has more behind it than yours does ahead. Don't waste it.
          </div>
        </div>

        {/* Section 3 — On what you haven't started */}
        <div style={{ marginBottom:32 }}>
          <h3 style={{ fontFamily:"var(--serif)", fontSize:24, fontWeight:400, color:"var(--text)", margin:"0 0 14px", letterSpacing:"-0.2px" }}>On what you haven't started</h3>
          <div style={{ padding:"14px 16px 14px 18px", background:"rgba(201,168,76,.05)", borderLeft:"2px solid var(--warm)", borderRadius:4, marginBottom:12, fontFamily:"var(--serif)", fontStyle:"italic", fontSize:15, lineHeight:1.7, color:"var(--text2)" }}>
            {wishLabels.length > 0 ? (
              <>You wrote a wishlist. <strong style={{ color:"var(--text)", fontStyle:"normal", fontWeight:500 }}>{wishLabels.slice(0, 4).join(". ")}.</strong> </>
            ) : (
              <>You named what's been getting pushed off the list. </>
            )}
            {oneyrGrowth && <>And your 1-Year growth vision, in your own words, was: <strong style={{ color:"var(--text)", fontStyle:"normal", fontWeight:500 }}>"{oneyrGrowth}"</strong> </>}
            What would I say to you about starting these — not later, but now?
          </div>
          <textarea value={s3} onChange={e => setText("a2_fsl_s3", e.target.value)}
            placeholder="Write what I would say to you about what you haven't started..."
            style={{ width:"100%", minHeight:140, padding:"16px 18px", background:"rgba(0,0,0,.22)", border:`1px solid ${s3.trim() ? "var(--warm)" : "var(--border2)"}`, borderRadius:8, color:"var(--text)", fontFamily:"var(--serif)", fontSize:16, lineHeight:1.7, resize:"vertical", outline:"none" }} />
          <div style={{ marginTop:6, fontSize:10, color: s3.trim() ? "#34d399" : "var(--text4)", textAlign:"right" }}>{countWords(s3)} words</div>
        </div>

        {/* Section 4 — On why this is urgent */}
        <div style={{ marginBottom:32 }}>
          <h3 style={{ fontFamily:"var(--serif)", fontSize:24, fontWeight:400, color:"var(--text)", margin:"0 0 14px", letterSpacing:"-0.2px" }}>On why this is urgent</h3>
          <div style={{ padding:"14px 16px 14px 18px", background:"rgba(201,168,76,.05)", borderLeft:"2px solid var(--warm)", borderRadius:4, marginBottom:12, fontFamily:"var(--serif)", fontStyle:"italic", fontSize:15, lineHeight:1.7, color:"var(--text2)" }}>
            {bagGrowth ? (
              <>Your BAG — your {bagYear ? `${bagYear} ` : "10-to-15-year "}vision, in your own words — was: <strong style={{ color:"var(--text)", fontStyle:"normal", fontWeight:500 }}>"{bagGrowth}"</strong> </>
            ) : (
              <>You named the life you're building toward. </>
            )}
            What would I say to you about how important this work is — not just for what you do, but for who you become?
          </div>
          <textarea value={s4text} onChange={e => setText("a2_fsl_s4", e.target.value)}
            placeholder="Write what I would say to you about why this can't wait..."
            style={{ width:"100%", minHeight:140, padding:"16px 18px", background:"rgba(0,0,0,.22)", border:`1px solid ${s4text.trim() ? "var(--warm)" : "var(--border2)"}`, borderRadius:8, color:"var(--text)", fontFamily:"var(--serif)", fontSize:16, lineHeight:1.7, resize:"vertical", outline:"none" }} />
          <div style={{ marginTop:6, fontSize:10, color: s4text.trim() ? "#34d399" : "var(--text4)", textAlign:"right" }}>{countWords(s4text)} words</div>
        </div>

        {/* Closing */}
        <div style={{ marginTop:32, padding:"24px 28px", background:"var(--bg2)", border:"1px solid var(--border2)", borderRadius:10 }}>
          <div style={{ fontFamily:"var(--serif)", fontSize:17, lineHeight:1.8, color:"var(--text)", fontStyle:"italic" }}>
            You already know what I'm going to ask. Go back to those words. The ones you just wrote. Read them tomorrow morning. Read them in six months. Read them when you're tempted to not start, or to quit. Your hand wrote them. Your body will remember.
          </div>
          <div style={{ marginTop:14, fontFamily:"var(--serif)", fontSize:14, color:"var(--warm)", fontStyle:"italic" }}>
            — You, from your future
          </div>
        </div>

        {/* Reflection */}
        <div style={{ marginTop:32, padding:"24px 28px", background:"rgba(96,165,250,.06)", border:"1px solid rgba(96,165,250,.3)", borderLeft:"3px solid #60a5fa", borderRadius:8 }}>
          <div style={{ fontSize:10, letterSpacing:2, textTransform:"uppercase", color:"#60a5fa", fontWeight:700, marginBottom:10 }}>Before you close this</div>
          <div style={{ fontFamily:"var(--serif)", fontSize:19, lineHeight:1.5, color:"var(--text)", marginBottom:14 }}>
            What's one thing from what you just wrote that's sitting with you?
          </div>
          <textarea value={s4} onChange={e => setText("a2_fsl_reflection", e.target.value)}
            placeholder="Write the one line..."
            style={{ width:"100%", minHeight:72, padding:"12px 14px", background:"rgba(0,0,0,.22)", border:`1px solid ${s4.trim() ? "#60a5fa" : "var(--border2)"}`, borderRadius:6, color:"var(--text)", fontFamily:"var(--sans)", fontSize:14, lineHeight:1.6, resize:"vertical", outline:"none" }} />
        </div>

        <div style={{ marginBottom:22, marginTop:24 }}>
          <AIChat voiceId={voice} onVoiceChange={setVoicePersist} name={name} intake={intake} mapData={map}
            sectionLabel="future self letter"
            placeholder="Ask Katherine about what came up as you wrote..." />
        </div>

        <div style={{ marginTop:26, paddingTop:18, borderTop:"1px solid var(--border)", display:"flex", justifyContent:"space-between", gap:8 }}>
          <button className="btn-g" onClick={() => a2Goto(prevStep.id)}>← {prevStep.label}</button>
          <button className="btn" onClick={() => { setA2Done(d => [...new Set([...d, "letter"])]); a2Goto(nextStep.id); }}>{nextStep.label} →</button>
        </div>
      </div>
    );
  }
  if (a2Step === "mirror") {
    const mirIdx = A2_STEPS.findIndex(s => s.id === "mirror");
    const prevStep = A2_STEPS[mirIdx - 1];
    const nextStep = A2_STEPS[mirIdx + 1];

    // A1 anchors
    const purposeMir = map.purpose_final || map.purpose_draft || "";
    const bagTimeMir = map.growth_time_sentence || map.bag_time_sentence || "";
    const bagWealthMir = map.growth_wealth_sentence || map.bag_wealth_sentence || "";
    const bagGrowthMir = map.growth_sentence || map.growth_summary || "";
    const threeyrTimeMir = map.threeyr_time_sentence || "";
    const threeyrWealthMir = map.threeyr_wealth_sentence || "";
    const threeyrGrowthMir = map.threeyr_growth_sentence || "";
    const oneyrTimeMir = map.oneyr_time_sentence || "";
    const oneyrWealthMir = map.oneyr_wealth_sentence || "";
    const oneyrGrowthMir = map.oneyr_growth_sentence || "";
    const thisYearMir = new Date().getFullYear();
    const hasAnyHorizonData = [bagTimeMir, bagWealthMir, bagGrowthMir, threeyrTimeMir, threeyrWealthMir, threeyrGrowthMir, oneyrTimeMir, oneyrWealthMir, oneyrGrowthMir].some(s => s && s.trim());

    // A2 — Key Misalignment
    const misalignMir = computeMisalignments(map);
    const pinnedIdMir = map.a2_km_pinned_id;
    const primaryMir = pinnedIdMir ? misalignMir.find(m => m.id === pinnedIdMir) : null;

    // A2 — Time Audit buckets
    const bucketForMir = (a) => {
      if (!a.feeling || !a.pri) return null;
      const isNone = a.pri === "none";
      const f = a.feeling;
      if (f === "despise") return "leaks";
      if (f === "dislike" && isNone) return "leaks";
      if (isNone) return "leaks";
      if (f === "love") return "supports";
      if (f === "like") return "supports";
      return "reshape";
    };
    const actsMir = (map.a2_ta_acts || []).map(a => ({ ...a, bucket: bucketForMir(a) })).filter(a => a.bucket);
    const sumMir = (arr) => arr.reduce((t, a) => t + (Number(a.hours) || 0), 0);
    const supportsHrsMir = sumMir(actsMir.filter(a => a.bucket === "supports"));
    const reshapeHrsMir = sumMir(actsMir.filter(a => a.bucket === "reshape"));
    const leaksHrsMir = sumMir(actsMir.filter(a => a.bucket === "leaks"));
    const hasTimeData = supportsHrsMir + reshapeHrsMir + leaksHrsMir > 0;

    // A2 — Swaps
    const swapsMir = map.a2_ta_swaps || {};
    const wishesMir = map.a2_ta_wishes || [];
    const actsByIdMir = (map.a2_ta_acts || []).reduce((o, a) => ({ ...o, [a.id]: a }), {});
    const swapList = Object.entries(swapsMir)
      .filter(([wid, sw]) => sw && sw.fromId && sw.when && (sw.fromId === "__have_time__" || sw.hours))
      .map(([wid, sw]) => {
        const wish = wishesMir.find(w => w.id === wid);
        if (!wish) return null;
        const fromAct = sw.fromId !== "__have_time__" ? actsByIdMir[sw.fromId] : null;
        const whenLabel = sw.when === "3mo" ? "< 3 months" : sw.when === "6mo" ? "< 6 months" : "> 12 months";
        return {
          id: wid,
          haveTime: sw.fromId === "__have_time__",
          from: fromAct?.label || "",
          to: wish.label,
          hours: sw.hours || wish.hours,
          when: whenLabel,
          hasNonTimeBlock: sw.block === "not_time" || sw.block === "both",
        };
      })
      .filter(Boolean);

    // Letter
    const letterReflectionMir = map.a2_fsl_reflection || "";
    const fslSectionsMir = [map.a2_fsl_s1, map.a2_fsl_s2, map.a2_fsl_s3, map.a2_fsl_s4].filter(s => s && s.trim()).length;

    // One Thing + direction check
    const oneThingValM = map.a2_one_thing || "";
    const a1OneThingMir = map.one_thing || map.a1_one_thing || "";
    const dirAnswer = map.a2_mir_dir_answer || null;
    const dirShift = map.a2_mir_dir_shift || "";
    const showShift = dirAnswer === "no" || dirAnswer === "shifted";

    // Horizon block
    const HorizonBlock = ({ name, year, primary, time, wealth, growth }) => {
      const row = (label, text, color) => (
        <div style={{ display:"grid", gridTemplateColumns:"70px 1fr", gap:10, alignItems:"start", marginBottom:10 }}>
          <span style={{ fontSize:9, color:"var(--text3)", letterSpacing:1.2, textTransform:"uppercase", fontWeight:600, paddingTop:4 }}>{label}</span>
          <div style={{ minWidth:0 }}>
            {text && text.trim() ? (
              <div style={{ fontFamily:"var(--serif)", fontSize: primary ? 15 : 14, lineHeight:1.65, fontStyle:"italic", padding:"8px 12px", borderRadius:5, background:"rgba(0,0,0,.2)", borderLeft:`2px solid ${color}`, color:"var(--text)" }}>
                "{text}"
              </div>
            ) : (
              <div style={{ fontSize:11, color:"var(--text4)", fontStyle:"italic", padding:"8px 12px" }}>No summary captured in A1.</div>
            )}
          </div>
        </div>
      );
      return (
        <div style={{ padding: primary ? "20px 22px" : "16px 18px", marginBottom:10, background: primary ? "rgba(201,168,76,.06)" : "rgba(0,0,0,.18)", border:`1px solid ${primary ? "rgba(201,168,76,.4)" : "var(--border2)"}`, borderRadius:8 }}>
          <div style={{ display:"flex", alignItems:"baseline", gap:10, marginBottom:12 }}>
            <span style={{ fontFamily:"var(--sans)", fontSize:11, letterSpacing:2, textTransform:"uppercase", fontWeight:700, color: primary ? "var(--warm)" : "var(--text2)" }}>{name}</span>
            <span style={{ fontSize:10, color:"var(--text4)", fontFamily:"var(--serif)", fontStyle:"italic" }}>{year}</span>
          </div>
          {row("Time", time, "var(--warm)")}
          {row("Wealth", wealth, "#34d399")}
          {row("Growth", growth, "#a78bfa")}
        </div>
      );
    };

    return wrapA2(
      <div>
        <div style={{ fontSize:11, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color:"var(--warm)", marginBottom:11 }}>A2 · A2 Mirror</div>
        <h1 style={{ fontFamily:"var(--serif)", fontSize:38, fontWeight:400, lineHeight:1.2, margin:"0 0 10px", color:"var(--text)", letterSpacing:"-0.3px" }}>Look honestly at what you've seen. Then name what you're carrying.</h1>
        <p style={{ fontSize:16, color:"var(--text2)", lineHeight:1.75, margin:"0 0 28px", maxWidth:640 }}>
          You just did real work. You saw your time honestly. You wrote a letter from the life you're building toward. Everything you did in A2 is here — pulled back together. Read it. Sit with it. Then, in your own words, name the one thing you're carrying forward.
        </p>

        {/* ── 01 · What you've seen ── */}
        <div style={{ fontFamily:"var(--sans)", fontSize:10, letterSpacing:2.5, textTransform:"uppercase", color:"var(--text3)", fontWeight:700, margin:"36px 0 16px", paddingBottom:8, borderBottom:"1px solid var(--border)" }}>
          · 01 · What you've seen
        </div>

        {/* Purpose */}
        {purposeMir && (
          <div style={{ padding:"18px 22px", background:"var(--bg2)", border:"1px solid var(--border2)", borderRadius:10, marginBottom:14 }}>
            <div style={{ fontSize:10, color:"var(--text3)", letterSpacing:1.5, textTransform:"uppercase", fontWeight:600, marginBottom:6 }}>Purpose — your north star</div>
            <div style={{ fontFamily:"var(--serif)", fontSize:18, lineHeight:1.5, color:"var(--text)", fontStyle:"italic" }}>"{purposeMir}"</div>
          </div>
        )}

        {/* Horizons — collapsible */}
        {hasAnyHorizonData && (() => {
          const open = map.a2_mir_horiz_open !== false;
          return (
            <div style={{ marginTop:14, marginBottom:14, background:"rgba(201,168,76,.04)", border:"1px solid rgba(201,168,76,.35)", borderRadius:12, overflow:"hidden" }}>
              <div onClick={() => set("a2_mir_horiz_open", !open)}
                style={{ display:"flex", justifyContent:"space-between", alignItems:"center", gap:12, padding:"16px 20px", cursor:"pointer", userSelect:"none", background: open ? "rgba(201,168,76,.06)" : "transparent" }}>
                <div style={{ display:"flex", alignItems:"center", gap:12, minWidth:0 }}>
                  <span style={{ fontSize:20, flexShrink:0 }}>🧭</span>
                  <span style={{ fontSize:12, letterSpacing:2, textTransform:"uppercase", color:"var(--warm)", fontWeight:700 }}>Your direction · from A1</span>
                </div>
                <span style={{ fontSize:14, color:"var(--warm)", flexShrink:0, transform: open ? "rotate(180deg)" : "none", transition:"transform .2s" }}>▾</span>
              </div>
              {open && (
                <div style={{ padding:"16px 24px 20px", borderTop:"1px solid var(--border)" }}>
                  <div style={{ fontSize:10, color:"var(--text3)", letterSpacing:1.5, textTransform:"uppercase", fontWeight:700, marginBottom:14 }}>
                    Pulled from A1 exactly as you wrote it
                  </div>
                  <DirectionTimeline_v2 activeHorizon="oneyr" map={map} />
                </div>
              )}
            </div>
          );
        })()}

        {/* Key Misalignment card — collapsible */}
        {primaryMir && (() => {
          const open = map.a2_mir_km_open !== false;
          return (
            <div style={{ marginBottom:14, background:"rgba(239,68,68,.04)", border:"1px solid rgba(239,68,68,.35)", borderRadius:12, overflow:"hidden" }}>
              <div onClick={() => set("a2_mir_km_open", !open)}
                style={{ display:"flex", justifyContent:"space-between", alignItems:"center", gap:12, padding:"16px 20px", cursor:"pointer", userSelect:"none", background: open ? "rgba(239,68,68,.06)" : "transparent" }}>
                <div style={{ display:"flex", alignItems:"center", gap:12, minWidth:0 }}>
                  <span style={{ fontSize:20, flexShrink:0 }}>{primaryMir.icon}</span>
                  <span style={{ fontSize:12, letterSpacing:2, textTransform:"uppercase", color:"#ef4444", fontWeight:700 }}>Key misalignment · your A2 focus</span>
                </div>
                <span style={{ fontSize:14, color:"#ef4444", flexShrink:0, transform: open ? "rotate(180deg)" : "none", transition:"transform .2s" }}>▾</span>
              </div>
              {open && (
                <div style={{ padding:"0 24px 20px", borderTop:"1px solid var(--border)" }}>
                  <div style={{ fontFamily:"var(--serif)", fontSize:22, lineHeight:1.4, color:"var(--text)", marginTop:16, marginBottom:10 }}>
                    {primaryMir.label} — {primaryMir.source}, scored {primaryMir.score}/10.
                  </div>
                  {primaryMir.note && (
                    <div style={{ fontSize:13, color:"var(--text2)", lineHeight:1.6 }}>{primaryMir.note}</div>
                  )}
                </div>
              )}
            </div>
          );
        })()}

        {/* Time piece — collapsible */}
        {hasTimeData && (() => {
          const open = map.a2_mir_time_open !== false;
          return (
            <div style={{ marginBottom:14, background:"rgba(201,168,76,.04)", border:"1px solid rgba(201,168,76,.35)", borderRadius:12, overflow:"hidden" }}>
              <div onClick={() => set("a2_mir_time_open", !open)}
                style={{ display:"flex", justifyContent:"space-between", alignItems:"center", gap:12, padding:"16px 20px", cursor:"pointer", userSelect:"none", background: open ? "rgba(201,168,76,.06)" : "transparent" }}>
                <div style={{ display:"flex", alignItems:"center", gap:12, minWidth:0 }}>
                  <span style={{ fontSize:20, flexShrink:0 }}>⏳</span>
                  <span style={{ fontSize:12, letterSpacing:2, textTransform:"uppercase", color:"var(--warm)", fontWeight:700 }}>Where your time is telling the truth</span>
                </div>
                <span style={{ fontSize:14, color:"var(--warm)", flexShrink:0, transform: open ? "rotate(180deg)" : "none", transition:"transform .2s" }}>▾</span>
              </div>
              {open && (
                <div style={{ padding:"16px 24px 20px", borderTop:"1px solid var(--border)" }}>
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:10, marginBottom:14 }}>
              <div style={{ padding:"12px 14px", background:"rgba(52,211,153,.08)", border:"1px solid rgba(52,211,153,.3)", borderRadius:8, textAlign:"center" }}>
                <div style={{ fontFamily:"var(--serif)", fontSize:24, color:"#34d399", lineHeight:1 }}>{supportsHrsMir}<span style={{ fontSize:11, color:"var(--text3)", fontFamily:"var(--sans)", marginLeft:3 }}>hrs</span></div>
                <div style={{ fontSize:10, color:"#34d399", letterSpacing:1.2, textTransform:"uppercase", fontWeight:700, marginTop:4 }}>Supports</div>
              </div>
              <div style={{ padding:"12px 14px", background:"rgba(245,158,11,.08)", border:"1px solid rgba(245,158,11,.3)", borderRadius:8, textAlign:"center" }}>
                <div style={{ fontFamily:"var(--serif)", fontSize:24, color:"#f59e0b", lineHeight:1 }}>{reshapeHrsMir}<span style={{ fontSize:11, color:"var(--text3)", fontFamily:"var(--sans)", marginLeft:3 }}>hrs</span></div>
                <div style={{ fontSize:10, color:"#f59e0b", letterSpacing:1.2, textTransform:"uppercase", fontWeight:700, marginTop:4 }}>Reshape</div>
              </div>
              <div style={{ padding:"12px 14px", background:"rgba(239,68,68,.08)", border:"1px solid rgba(239,68,68,.3)", borderRadius:8, textAlign:"center" }}>
                <div style={{ fontFamily:"var(--serif)", fontSize:24, color:"#ef4444", lineHeight:1 }}>{leaksHrsMir}<span style={{ fontSize:11, color:"var(--text3)", fontFamily:"var(--sans)", marginLeft:3 }}>hrs</span></div>
                <div style={{ fontSize:10, color:"#ef4444", letterSpacing:1.2, textTransform:"uppercase", fontWeight:700, marginTop:4 }}>Leaks</div>
              </div>
            </div>
            <div style={{ fontSize:13, color:"var(--text2)", lineHeight:1.7, fontFamily:"var(--serif)", fontStyle:"italic" }}>
              {leaksHrsMir > supportsHrsMir
                ? "More of your week is leaking than feeding you. That's not a failure — that's data."
                : leaksHrsMir === 0
                  ? "No leaks. Your hours are serving your priorities. The work now is protection, not correction."
                  : "Your supports outweigh your leaks. Now protect them."}
            </div>
                </div>
              )}
            </div>
          );
        })()}

        {/* Trades you mapped — collapsible */}
        {swapList.length > 0 && (() => {
          const open = map.a2_mir_trades_open !== false;
          return (
            <div style={{ marginBottom:14, background:"rgba(201,168,76,.04)", border:"1px solid rgba(201,168,76,.35)", borderRadius:12, overflow:"hidden" }}>
              <div onClick={() => set("a2_mir_trades_open", !open)}
                style={{ display:"flex", justifyContent:"space-between", alignItems:"center", gap:12, padding:"16px 20px", cursor:"pointer", userSelect:"none", background: open ? "rgba(201,168,76,.06)" : "transparent" }}>
                <div style={{ display:"flex", alignItems:"center", gap:12, minWidth:0 }}>
                  <span style={{ fontSize:20, flexShrink:0 }}>⇄</span>
                  <span style={{ fontSize:12, letterSpacing:2, textTransform:"uppercase", color:"var(--warm)", fontWeight:700 }}>Trades you mapped · {swapList.length}</span>
                </div>
                <span style={{ fontSize:14, color:"var(--warm)", flexShrink:0, transform: open ? "rotate(180deg)" : "none", transition:"transform .2s" }}>▾</span>
              </div>
              {open && (
                <div style={{ padding:"16px 24px 20px", borderTop:"1px solid var(--border)" }}>
            {swapList.map(sw => (
              <div key={sw.id} style={{ padding:"12px 16px", marginBottom:6, background:"rgba(0,0,0,.25)", borderRadius:8, display:"flex", alignItems:"center", gap:12, flexWrap:"wrap" }}>
                {!sw.haveTime ? (
                  <>
                    <span style={{ color:"#ef4444", fontSize:14, fontWeight:500 }}>{sw.hours}h from {sw.from}</span>
                    <span style={{ color:"var(--warm)", fontWeight:700, fontSize:14 }}>→</span>
                    <span style={{ color:"#34d399", fontSize:14, fontWeight:500 }}>{sw.to}</span>
                  </>
                ) : (
                  <span style={{ color:"#34d399", fontSize:14, fontWeight:500 }}>{sw.hours}h for {sw.to}</span>
                )}
                <span style={{ color:"var(--text3)", fontSize:12, flexShrink:0, marginLeft:"auto" }}>
                  {sw.when}
                  {sw.hasNonTimeBlock && <> · <span style={{ color:"#60a5fa" }}>non-time block</span></>}
                </span>
              </div>
            ))}
            <div style={{ marginTop:10, fontSize:13, color:"var(--text2)", lineHeight:1.6 }}>
              These carry forward to A4. Non-time blocks route to A3.
            </div>
                </div>
              )}
            </div>
          );
        })()}



        {/* Direction check — AFTER all time pieces */}
        <div style={{ padding:"20px 24px", background:"var(--bg2)", border:"1px solid var(--border2)", borderRadius:10, marginTop:22, marginBottom:14 }}>
          <div style={{ fontFamily:"var(--serif)", fontSize:20, color:"var(--text)", lineHeight:1.4, marginBottom:14, fontStyle:"italic" }}>
            After seeing your time honestly — is this still the pull?
          </div>
          <div style={{ display:"flex", gap:8, flexWrap:"wrap" }}>
            {[
              { v:"yes", label:"Yes — this is still it", color:"#34d399", bg:"rgba(52,211,153,.18)" },
              { v:"shifted", label:"Something shifted", color:"#f59e0b", bg:"rgba(245,158,11,.18)" },
              { v:"no", label:"No — it's different now", color:"#ef4444", bg:"rgba(239,68,68,.18)" },
            ].map(b => {
              const sel = dirAnswer === b.v;
              return (
                <button key={b.v} onClick={() => set("a2_mir_dir_answer", sel ? null : b.v)}
                  style={{ padding:"8px 16px", borderRadius:18, border: sel ? `1px solid ${b.color}` : "1px solid var(--border2)", background: sel ? b.bg : "transparent", color: sel ? b.color : "var(--text2)", cursor:"pointer", fontFamily:"var(--sans)", fontSize:13, fontWeight: sel ? 700 : 500 }}>
                  {b.label}
                </button>
              );
            })}
          </div>
          {showShift && (
            <div style={{ marginTop:14, padding:"14px 16px", background:"rgba(245,158,11,.06)", border:"1px solid rgba(245,158,11,.25)", borderLeft:"3px solid #f59e0b", borderRadius:6 }}>
              <div style={{ fontSize:11, color:"#f59e0b", fontWeight:700, letterSpacing:1.5, textTransform:"uppercase", marginBottom:8 }}>
                {dirAnswer === "no" ? "What's changed?" : "What shifted?"}
              </div>
              <textarea value={dirShift} onChange={e => set("a2_mir_dir_shift", e.target.value)}
                placeholder="A sentence or two. You'll work this in A4."
                style={{ width:"100%", minHeight:72, padding:"10px 12px", background:"rgba(0,0,0,.22)", border:"1px solid var(--border2)", borderRadius:6, color:"var(--text)", fontFamily:"var(--sans)", fontSize:13, lineHeight:1.6, resize:"vertical", outline:"none" }} />
            </div>
          )}
        </div>

        {/* Letter echo — collapsible */}
        {letterReflectionMir ? (() => {
          const open = map.a2_mir_letter_open !== false;
          return (
            <div style={{ marginBottom:14, background:"rgba(96,165,250,.04)", border:"1px solid rgba(96,165,250,.35)", borderRadius:12, overflow:"hidden" }}>
              <div onClick={() => set("a2_mir_letter_open", !open)}
                style={{ display:"flex", justifyContent:"space-between", alignItems:"center", gap:12, padding:"16px 20px", cursor:"pointer", userSelect:"none", background: open ? "rgba(96,165,250,.06)" : "transparent" }}>
                <div style={{ display:"flex", alignItems:"center", gap:12, minWidth:0 }}>
                  <span style={{ fontSize:20, flexShrink:0 }}>✍</span>
                  <span style={{ fontSize:12, letterSpacing:2, textTransform:"uppercase", color:"#60a5fa", fontWeight:700 }}>From your Future Self Letter · what's sitting with you</span>
                </div>
                <span style={{ fontSize:14, color:"#60a5fa", flexShrink:0, transform: open ? "rotate(180deg)" : "none", transition:"transform .2s" }}>▾</span>
              </div>
              {open && (
                <div style={{ padding:"16px 24px 20px", borderTop:"1px solid var(--border)" }}>
                  <div style={{ fontFamily:"var(--serif)", fontStyle:"italic", fontSize:15, lineHeight:1.7, color:"var(--text)", padding:"10px 14px", background:"rgba(96,165,250,.05)", borderLeft:"2px solid #60a5fa", borderRadius:4 }}>
                    "{letterReflectionMir}"
                  </div>
                  <div style={{ marginTop:10, fontSize:12, color:"var(--text3)", lineHeight:1.6 }}>
                    Your own words, from the end of the Letter. This is the thread you're pulling on.
                  </div>
                </div>
              )}
            </div>
          );
        })() : fslSectionsMir > 0 && (
          <div style={{ padding:"16px 20px", marginBottom:14, background:"rgba(255,255,255,.02)", border:"1px dashed var(--border2)", borderRadius:10 }}>
            <div style={{ fontSize:11, letterSpacing:2, textTransform:"uppercase", color:"var(--text3)", fontWeight:700, marginBottom:8 }}>From your Future Self Letter</div>
            <div style={{ fontSize:14, color:"var(--text3)", fontStyle:"italic", lineHeight:1.6 }}>
              You wrote {fslSectionsMir} of 4 letter sections. Go back to <button onClick={() => a2Goto("letter")} style={{ background:"none", border:"none", color:"var(--warm)", cursor:"pointer", textDecoration:"underline", padding:0, font:"inherit" }}>Future Self Letter</button> and leave a reflection line at the bottom.
            </div>
          </div>
        )}

        {/* ── 02 · What you're carrying ── */}
        <div style={{ fontFamily:"var(--sans)", fontSize:10, letterSpacing:2.5, textTransform:"uppercase", color:"var(--warm)", fontWeight:700, margin:"36px 0 16px", paddingBottom:8, borderBottom:"1px solid rgba(201,168,76,.3)" }}>
          · 02 · What you're carrying
        </div>

        <div style={{ padding:"28px 32px", background:"linear-gradient(135deg, rgba(201,168,76,.08), rgba(0,0,0,.2))", border:"1px solid var(--warm)", borderRadius:12, marginTop:14 }}>
          <div style={{ fontFamily:"var(--serif)", fontSize:17, lineHeight:1.75, color:"var(--text)", fontStyle:"italic", margin:"0 0 20px" }}>
            Everything you just did feeds into one thing. <strong style={{ fontStyle:"normal", fontWeight:500, color:"var(--warm)" }}>One sentence, in your own words.</strong> What you carry forward into this year and beyond — the direction you named, the time you saw, the letter you wrote, all of it — distilled.
          </div>

          {a1OneThingMir && !oneThingValM && (
            <div style={{ padding:"12px 16px", marginBottom:16, background:"rgba(0,0,0,.25)", borderLeft:"2px solid var(--text3)", borderRadius:4 }}>
              <div style={{ fontSize:10, letterSpacing:1.5, textTransform:"uppercase", color:"var(--text3)", fontWeight:600, marginBottom:6 }}>In A1 you said:</div>
              <div style={{ fontFamily:"var(--serif)", fontSize:15, fontStyle:"italic", color:"var(--text2)", lineHeight:1.6 }}>"{a1OneThingMir}"</div>
            </div>
          )}

          <div style={{ fontFamily:"var(--serif)", fontSize:22, fontWeight:400, color:"var(--text)", marginBottom:14, lineHeight:1.4 }}>
            So — who are you, now?
          </div>
          <textarea value={oneThingValM} onChange={e => set("a2_one_thing", e.target.value)}
            placeholder="I am the one who..."
            style={{ width:"100%", minHeight:100, padding:"18px 20px", background:"rgba(0,0,0,.3)", border:`1px solid ${oneThingValM.trim() ? "var(--warm)" : "var(--border2)"}`, borderRadius:8, color:"var(--text)", fontFamily:"var(--serif)", fontSize:20, fontStyle:"italic", lineHeight:1.6, resize:"vertical", outline:"none" }} />
          <div style={{ marginTop:12, fontSize:12, color:"var(--text3)", lineHeight:1.6, fontStyle:"italic" }}>
            A model that often works: <em>"I am the one who [verb] [what]."</em> But if that doesn't fit, throw it out. The shape of the sentence matters less than the truth of it. You'll come back to this quarterly — read it, feel it, adjust it.
          </div>
        </div>

        {/* A3 tease */}
        <div style={{ marginTop:32, padding:"24px 28px", background:"linear-gradient(180deg, rgba(96,165,250,.08), rgba(96,165,250,.02))", border:"1px solid #60a5fa", borderLeft:"3px solid #60a5fa", borderRadius:10 }}>
          <div style={{ fontSize:10, color:"#60a5fa", letterSpacing:2.5, textTransform:"uppercase", fontWeight:700, marginBottom:10 }}>Next · A3 Advocate</div>
          <div style={{ fontFamily:"var(--serif)", fontSize:17, lineHeight:1.7, color:"var(--text)", fontStyle:"italic", margin:0 }}>
            We are all leaders of our own life. The question is — <strong style={{ color:"#60a5fa", fontWeight:500, fontStyle:"normal" }}>how well are we leading?</strong> You have clarity now. Let's look at how you surround yourself — the people, habits, places, and thoughts that either hold the new way in place, or keep pulling you back to the old one.
          </div>
        </div>

        <div style={{ marginBottom:22, marginTop:24 }}>
          <AIChat voiceId={voice} onVoiceChange={setVoicePersist} name={name} intake={intake} mapData={map}
            sectionLabel="a2 mirror"
            placeholder="Ask Katherine about what your One Thing is asking of you..." />
        </div>

        <div style={{ marginTop:26, paddingTop:18, borderTop:"1px solid var(--border)", display:"flex", justifyContent:"space-between", gap:8 }}>
          <button className="btn-g" onClick={() => a2Goto(prevStep.id)}>← {prevStep.label}</button>
          <button className="btn" onClick={() => { setA2Done(d => [...new Set([...d, "mirror"])]); setPhase("a3"); }}>Continue to A3 →</button>
        </div>
      </div>
    );
  }
  return wrapA2(<div>Unknown step: {a2Step}</div>);
}

// ─── A3 · Advocate For It ─────────────────────────────────────────────
const A3_STEPS = [
  { id:"intro",       label:"Introduction" },
  { id:"people",      label:"Energy Audit · People" },
  { id:"environment", label:"Energy Audit · Environment" },
  { id:"thoughts",    label:"Energy Audit · Thoughts" },
  { id:"energymap",   label:"Energy Map" },
  { id:"board",       label:"The Board" },
  { id:"map",         label:"My Map of Me™" },
];

const A3_BOARD_STRENGTHS = [
  "Listener", "Challenger", "Strategist", "Honest Mirror",
  "Cheerleader", "Healer", "Visionary", "Connector",
  "Wise Elder", "Peer Equal", "Teacher", "Guide",
];

function A3StubShell({ title, tagline, next, setA3Step, children }: any) {
  return (
    <div>
      <div style={{ fontSize:11, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color:"var(--warm)", marginBottom:11 }}>A3 · {title}</div>
      <h2 style={{ fontFamily:"var(--serif)", fontSize:38, fontWeight:300, lineHeight:1.2, marginBottom:13, letterSpacing:"-0.5px" }}>{tagline}</h2>
      <div style={{ padding:"20px 24px", background:"rgba(201,168,76,.06)", border:"1px dashed rgba(201,168,76,.3)", borderRadius:10, marginBottom:26 }}>
        <div style={{ fontSize:11, color:"var(--warm)", fontWeight:700, letterSpacing:1.5, textTransform:"uppercase", marginBottom:6 }}>Coming next</div>
        <div style={{ fontSize:13, color:"var(--text3)", lineHeight:1.6, fontStyle:"italic" }}>{children}</div>
      </div>
      <div style={{ display:"flex", gap:8 }}>
        {next
          ? <button className="btn" onClick={() => setA3Step(next)}>Continue →</button>
          : <span style={{ fontSize:12, color:"var(--text4)", fontStyle:"italic", alignSelf:"center" }}>End of A3 scaffold</span>}
      </div>
    </div>
  );
}

function A3IntroStub({ setA3Step }: any) {
  return (
    <div>
      <div style={{ fontSize:11, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color:"#5DCAA5", marginBottom:11 }}>A3 · Advocate For It</div>
      <h2 style={{ fontFamily:"var(--serif)", fontSize:42, fontWeight:400, lineHeight:1.15, marginBottom:16, letterSpacing:"-0.5px" }}>
        Your environment is either advocating for you — or anchoring you.
      </h2>

      <p style={{ fontFamily:"var(--sans)", fontSize:15, color:"var(--text2)", lineHeight:1.85, marginBottom:14, maxWidth:620 }}>
        A1 named who you are. A2 showed you where your life today is pulling the other way. A3 asks the next honest question: who and what around you is actually helping you get there — and who and what is keeping you stuck?
      </p>
      <p style={{ fontSize:15, color:"var(--text2)", lineHeight:1.85, marginBottom:14, maxWidth:620 }}>
        Over the next few pages you'll audit three things: the people around you, your environment (habits and places), and your own thoughts. For each one, you'll sort it into Advocate, Neutral, or Anchor. No judgment — just clarity.
      </p>
      <p style={{ fontSize:15, color:"var(--text2)", lineHeight:1.85, marginBottom:24, maxWidth:620 }}>
        It starts with you. Not with blaming anyone, not with uprooting your life. With seeing clearly what you've been carrying, what's been keeping you close to who you are, and what's quietly been pulling the other way.
      </p>

      {/* What we'll cover — three cards */}
      <div style={{ background:"var(--bg2)", border:"1px solid var(--border)", borderRadius:11, marginBottom:26, overflow:"hidden" }}>
        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:"14px 22px" }}>
          <div style={{ fontSize:10, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color:"var(--warm)", fontFamily:"var(--sans)" }}>What we'll cover</div>
        </div>
        <div style={{ padding:"4px 22px 18px", borderTop:"1px solid var(--border)" }}>
          {[
            { icon:"👥", label:"People — Who surrounds you?",                   desc:"Brain-dump everyone who shapes a week of your life. Rate each one Advocate, Neutral, or Anchor." },
            { icon:"🏠", label:"Environment — Your habits and your places.",    desc:"The routines you keep. The rooms you sit in. The apps on your home screen. What's lifting you — and what's draining you." },
            { icon:"🧠", label:"Thoughts — Your inner landscape.",              desc:"The voice in your head. Is it a coach or a critic? Is it still yours, or borrowed from someone else?" },
          ].map((item, i) => (
            <div key={i} style={{ display:"flex", alignItems:"flex-start", gap:11, marginTop:14 }}>
              <span style={{ fontSize:16, flexShrink:0, marginTop:1 }}>{item.icon}</span>
              <div>
                <span style={{ fontFamily:"var(--sans)", fontSize:13, fontWeight:600, color:"var(--text)" }}>{item.label}</span>
                <div style={{ fontSize:13, color:"var(--text3)", lineHeight:1.6, marginTop:2 }}>{item.desc}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Closing line */}
      <div style={{ fontFamily:"var(--serif)", fontSize:16, fontStyle:"italic", color:"var(--text2)", lineHeight:1.85, padding:"14px 18px", borderLeft:"2px solid var(--warm)", marginBottom:28 }}>
        By the end of A3, you'll have a Board of twelve — the humans you want in your corner. But first, see clearly what's already there.
      </div>

      <div style={{ marginTop:26, paddingTop:18, borderTop:"1px solid var(--border)", display:"flex", justifyContent:"flex-end", gap:8 }}>
        <button className="btn" onClick={() => setA3Step("people")}>Continue to People →</button>
      </div>
    </div>
  );
}
const A3_ROLES = ['Partner','Family','Friend','Mentor','Work colleague','Client','Other…'];
const A3_NEUTRAL_ACTIONS = ['Accept','Observe','Deepen','Distance','Other…'];
const A3_ANCHOR_ACTIONS = ['Accept','Observe','Set boundaries','Repair','Release','Other…'];
const A3_ACTION_HINTS: Record<string,string> = {
  Accept: "right where you want it, no change",
  Observe: "watch, don't act yet",
  Deepen: "invest more, go closer",
  Distance: "less contact, less weight",
  "Set boundaries": "keep the relationship, change the terms",
  Repair: "work on it, give it a chance",
  Release: "let it fade or end",
  "Other…": "your own words",
};
const A3_HOW_PLACEHOLDERS: Record<string,string> = {
  Accept: "e.g. I've made peace with this one, no change planned…",
  Observe: "e.g. notice how you feel after spending time with them…",
  Deepen: "e.g. schedule a monthly call, be more vulnerable…",
  Distance: "e.g. drop the weekly lunches, less check-ins…",
  "Set boundaries": "e.g. no talk about work at family dinners…",
  Repair: "e.g. have the conversation I've been avoiding…",
  Release: "e.g. stop initiating, let the friendship fade…",
  "Other…": "what does this look like in practice?",
};
const A3_TEAL = "#5DCAA5";
const A3_GREY = "#9A9590";
const A3_RED = "#ef4444";
const A3_AMBER = "#c9a84c";

function A3PeopleStub({ setA3Step, map, set }: any) {
  const people = map.a3_people || [];
  const [a3PeoplePhase, setA3PeoplePhase] = useState<1|2>(people.length > 0 ? 2 : 1);
  const [brainDumpText, setBrainDumpText] = useState<string>(() =>
    people.map((p: any) => p.role && p.role !== "Other…" ? `${p.name} (${p.role})` : p.name).join("\n")
  );
  const [newPersonInput, setNewPersonInput] = useState("");

  const uuid = () => (typeof crypto !== "undefined" && (crypto as any).randomUUID) ? (crypto as any).randomUUID() : String(Date.now()) + Math.random();

  const updatePerson = (id: string, patch: any) => set("a3_people", people.map((p: any) => p.id === id ? { ...p, ...patch } : p));
  const removePerson = (id: string) => set("a3_people", people.filter((p: any) => p.id !== id));
  const addPerson = (rawName: string) => {
    const name = rawName.trim();
    if (!name) return;
    set("a3_people", [...people, { id: uuid(), name }]);
  };

  const lineCount = brainDumpText.split("\n").map(s => s.trim()).filter(Boolean).length;

  const commitBrainDump = () => {
    const lines = brainDumpText.split("\n").map(s => s.trim()).filter(Boolean);
    const byName = new Map<string, any>(people.map((p: any) => [p.name.toLowerCase(), p]));
    const next = lines.map(line => {
      const m = line.match(/^(.+?)\s*\((.+)\)\s*$/);
      const baseName = m ? m[1].trim() : line;
      const inferredRole = m ? m[2].trim() : undefined;
      const existing = byName.get(baseName.toLowerCase());
      if (existing) return inferredRole && !existing.role ? { ...existing, role: inferredRole } : existing;
      return inferredRole ? { id: uuid(), name: baseName, role: inferredRole } : { id: uuid(), name: baseName };
    });
    set("a3_people", next);
    setA3PeoplePhase(2);
  };

  const rated = people.filter((p: any) => p.rating);
  const counts = {
    advocate: rated.filter((p: any) => p.rating === "advocate").length,
    neutral:  rated.filter((p: any) => p.rating === "neutral").length,
    anchor:   rated.filter((p: any) => p.rating === "anchor").length,
  };
  const advPct = rated.length ? counts.advocate / rated.length : 0;
  const ancPct = rated.length ? counts.anchor / rated.length : 0;
  const boardCount = people.filter((p: any) => p.rating === "advocate" && p.onBoard === "yes").length;
  const advocateCellHighlight = (advPct >= 0.6 && ancPct <= 0.2);
  const anchorCellHighlight = (ancPct >= 0.4);
  const reflectionTone = rated.length < 3 ? "balanced" : (advPct >= 0.6 && ancPct <= 0.2) ? "advocate" : ancPct >= 0.4 ? "anchor" : "balanced";

  return (
    <div>
      {/* BREADCRUMB + H1 + LEAD */}
      <div style={{ fontSize:11, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color: A3_TEAL, marginBottom:11 }}>A3 · Energy Audit · People</div>
      <h2 style={{ fontFamily:"var(--serif)", fontSize:42, fontWeight:400, lineHeight:1.15, marginBottom:14, letterSpacing:"-0.5px" }}>
        Who's in your inner circle?
      </h2>
      <p style={{ fontFamily:"var(--sans)", fontSize:15, color:"var(--text2)", lineHeight:1.85, marginBottom:24, maxWidth:620 }}>
        The people who shape your energy — on purpose or by default. Name them first. Rate them second. Don't censor.
      </p>

      {/* PHASE TRACKER */}
      <div style={{ display:"flex", alignItems:"center", gap:14, marginBottom:30 }}>
        {[1,2].map((step, idx) => {
          const isCurrent = a3PeoplePhase === step;
          const isDone = a3PeoplePhase > step;
          const label = step === 1 ? "Name them" : "Rate them";
          const circleStyle: any = {
            width:26, height:26, borderRadius:"50%", display:"flex", alignItems:"center", justifyContent:"center",
            fontSize:12, fontWeight:700, fontFamily:"var(--sans)",
            ...(isDone
              ? { background: A3_TEAL, color:"#0d1b2e", border:`1px solid ${A3_TEAL}` }
              : isCurrent
                ? { background:"transparent", color: A3_TEAL, border:`1.5px solid ${A3_TEAL}` }
                : { background:"transparent", color:"var(--text4)", border:"1px solid var(--border)" }),
          };
          const textColor = isCurrent || isDone ? A3_TEAL : "var(--text4)";
          return (
            <React.Fragment key={step}>
              <div style={{ display:"flex", alignItems:"center", gap:9 }}>
                <div style={circleStyle}>{isDone ? "✓" : step}</div>
                <span style={{ fontSize:12, fontFamily:"var(--sans)", fontWeight:600, color: textColor, letterSpacing:0.4 }}>{label}</span>
              </div>
              {idx === 0 && <div style={{ flex:"0 0 40px", height:1, background:"var(--border)" }} />}
            </React.Fragment>
          );
        })}
      </div>

      {/* PHASE 1 */}
      {a3PeoplePhase === 1 && (
        <>
          <div style={{ background:"var(--bg2)", border:"1px solid var(--border)", borderRadius:11, padding:"22px 24px", marginBottom:18 }}>
            <div style={{ fontSize:10, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color: A3_TEAL, marginBottom:10, fontFamily:"var(--sans)" }}>Phase 1 · Brain-dump</div>
            <div style={{ fontFamily:"var(--serif)", fontSize:22, fontWeight:400, color:"var(--text)", marginBottom:8 }}>Who are the people in your life right now?</div>
            <div style={{ fontSize:13, color:"var(--text3)", lineHeight:1.6, marginBottom:16 }}>
              List everyone who takes up real space in your head or your calendar. One per line. Don't rank, don't judge, don't filter. We'll sort it all next.
            </div>
            <textarea value={brainDumpText} onChange={e => setBrainDumpText(e.target.value)}
              placeholder={"Type one name per line…\ne.g.\nMom\nSarah (best friend)\nMike\nJess on my team"}
              style={{ width:"100%", minHeight:200, padding:"14px 16px", fontSize:14, fontFamily:"var(--sans)",
                background:"var(--bg)", border:"1px solid var(--border)", borderRadius:9, color:"var(--text)",
                outline:"none", resize:"vertical", lineHeight:1.6 }} />
            <div style={{ marginTop:10, fontSize:12, color:"var(--text4)", fontFamily:"var(--sans)" }}>
              {lineCount} {lineCount === 1 ? "name" : "names"} · most lists land between 10 and 25
            </div>
          </div>

          {/* Prompts callout */}
          <div style={{ padding:"16px 20px", background:"rgba(201,168,76,.07)", borderLeft:`3px solid ${A3_AMBER}`, borderRadius:8, marginBottom:30 }}>
            <div style={{ fontSize:10, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color: A3_AMBER, marginBottom:10, fontFamily:"var(--sans)" }}>If you're stuck, ask yourself</div>
            <div style={{ display:"flex", flexWrap:"wrap", gap:10 }}>
              {[
                "Who did I talk to this week?",
                "Who's in my group chats?",
                "Who do I text when something big happens?",
                "Who do I avoid calling back?",
                "Whose opinion runs in my head?",
              ].map((q, i) => (
                <span key={i} style={{ fontFamily:"var(--serif)", fontSize:14, fontStyle:"italic", color:"var(--text2)", padding:"6px 12px", background:"rgba(201,168,76,.05)", border:"1px solid rgba(201,168,76,.18)", borderRadius:999 }}>{q}</span>
              ))}
            </div>
          </div>

          {/* Step footer */}
          <div style={{ marginTop:8, paddingTop:18, borderTop:"1px solid var(--border)", display:"flex", alignItems:"center", justifyContent:"space-between", gap:14 }}>
            <button onClick={() => setA3Step("intro")}
              style={{ padding:"8px 16px", fontSize:12, fontWeight:600, letterSpacing:0.5, fontFamily:"var(--sans)", background:"transparent", color:"var(--text2)", border:"1px solid var(--border)", borderRadius:999, cursor:"pointer" }}>
              ← Back to Introduction
            </button>
            <div style={{ display:"flex", alignItems:"center", gap:14 }}>
              <span style={{ fontSize:12, color:"var(--text4)", fontFamily:"var(--sans)" }}>
                {lineCount === 0 ? "Add at least one name to continue." : "Ready when you are."}
              </span>
              <button onClick={commitBrainDump} disabled={lineCount === 0}
                style={{ padding:"9px 18px", fontSize:12, fontWeight:700, letterSpacing:0.5, fontFamily:"var(--sans)",
                  background: lineCount === 0 ? "var(--border)" : A3_TEAL, color:"#0d1b2e", border:"none", borderRadius:999,
                  cursor: lineCount === 0 ? "not-allowed" : "pointer", opacity: lineCount === 0 ? 0.55 : 1 }}>
                Next · Rate them →
              </button>
            </div>
          </div>
        </>
      )}

      {/* PHASE 2 */}
      {a3PeoplePhase === 2 && (
        <>
          {people.length === 0 && (
            <div style={{ padding:"40px 30px", textAlign:"center", background:"var(--bg2)", border:"1px solid var(--border)", borderRadius:11, marginBottom:30 }}>
              <div style={{ fontFamily:"var(--serif)", fontSize:22, color:"var(--text2)", marginBottom:10 }}>No names yet.</div>
              <div style={{ fontSize:14, color:"var(--text3)", lineHeight:1.6, marginBottom:20, maxWidth:380, marginLeft:"auto", marginRight:"auto" }}>
                Head back to Phase 1 and brain-dump the people who shape your week.
              </div>
              <button onClick={() => setA3PeoplePhase(1)}
                style={{ padding:"8px 16px", fontSize:12, fontWeight:600, letterSpacing:0.5, fontFamily:"var(--sans)", background:"transparent", color: A3_TEAL, border:`1px solid ${A3_TEAL}`, borderRadius:999, cursor:"pointer" }}>
                ← Back to naming
              </button>
            </div>
          )}

          {people.length > 0 && (
            <>
              <p style={{ fontFamily:"var(--sans)", fontSize:15, color:"var(--text2)", lineHeight:1.85, marginBottom:24, maxWidth:680 }}>
                One at a time. Pick a role, then ask yourself: are they an advocate, neutral, or an anchor? The row will expand for the next step — decide if they belong on your Board (advocates) or how you'll interact going forward (neutrals and anchors).
              </p>

              {/* PERSON CARDS */}
              <div style={{ display:"flex", flexDirection:"column", gap:12, marginBottom:24 }}>
                {people.map((p: any) => {
                  const r = p.rating;
                  const borderColor = r === "advocate" ? A3_TEAL : r === "neutral" ? A3_GREY : r === "anchor" ? A3_RED : "var(--border)";
                  const ratingPill = (val: string, label: string, color: string, tintBg: string) => {
                    const selected = r === val;
                    return (
                      <button onClick={() => updatePerson(p.id, { rating: val })}
                        style={{ padding:"5px 11px", fontSize:11, fontWeight:700, letterSpacing:0.6, fontFamily:"var(--sans)",
                          background: selected ? tintBg : "transparent",
                          color: selected ? color : "var(--text4)",
                          border: `1px solid ${selected ? color : "var(--border)"}`,
                          borderRadius:6, cursor:"pointer", transition:"all .15s" }}>
                        {label}
                      </button>
                    );
                  };
                  return (
                    <div key={p.id} style={{ background:"var(--bg2)", border:"1px solid var(--border)", borderLeft:`3px solid ${borderColor}`, borderRadius:9, padding:"14px 16px" }}>
                      {/* HEAD ROW */}
                      <div style={{ display:"grid", gridTemplateColumns:"1fr 160px auto 24px", gap:12, alignItems:"center" }}>
                        <div style={{ fontFamily:"var(--serif)", fontSize:17, color:"var(--text)", fontWeight:400, minWidth:0, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{p.name}</div>
                        <select value={p.role || ""} onChange={e => updatePerson(p.id, { role: e.target.value })}
                          style={{ padding:"6px 8px", fontSize:12, fontFamily:"var(--sans)",
                            background:"var(--bg)", border:"1px solid var(--border)", borderRadius:6,
                            color: p.role ? "var(--text2)" : "var(--text4)",
                            fontStyle: p.role ? "normal" : "italic", cursor:"pointer", outline:"none" }}>
                          <option value="" disabled>Choose a role…</option>
                          {A3_ROLES.map(r2 => <option key={r2} value={r2}>{r2}</option>)}
                        </select>
                        <div style={{ display:"flex", gap:5 }}>
                          {ratingPill("advocate", "ADVOCATE", A3_TEAL, "rgba(93,202,165,.2)")}
                          {ratingPill("neutral",  "NEUTRAL",  A3_GREY, "rgba(156,163,175,.2)")}
                          {ratingPill("anchor",   "ANCHOR",   A3_RED,  "rgba(239,68,68,.18)")}
                        </div>
                        <button onClick={() => removePerson(p.id)} title="Remove"
                          onMouseEnter={(e: any) => e.currentTarget.style.color = A3_RED}
                          onMouseLeave={(e: any) => e.currentTarget.style.color = "var(--text4)"}
                          style={{ width:24, height:24, borderRadius:"50%", background:"transparent", border:"none", color:"var(--text4)", cursor:"pointer", fontSize:16, lineHeight:1, padding:0, transition:"color .15s" }}>×</button>
                      </div>

                      {/* EXPAND ROW */}
                      {r === "advocate" && (
                        <div style={{ marginTop:14, paddingTop:14, borderTop:"1px solid var(--border)", display:"flex", alignItems:"center", gap:14, flexWrap:"wrap" }}>
                          <span style={{ fontSize:10, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color: A3_TEAL, fontFamily:"var(--sans)" }}>Board?</span>
                          <div style={{ display:"flex", gap:5 }}>
                            {["yes","no"].map(v => {
                              const sel = p.onBoard === v;
                              return (
                                <button key={v} onClick={() => updatePerson(p.id, { onBoard: v })}
                                  style={{ padding:"4px 12px", fontSize:11, fontWeight:700, letterSpacing:0.5, fontFamily:"var(--sans)",
                                    background: sel ? "rgba(93,202,165,.2)" : "transparent",
                                    color: sel ? A3_TEAL : "var(--text4)",
                                    border:`1px solid ${sel ? A3_TEAL : "var(--border)"}`,
                                    borderRadius:6, cursor:"pointer", textTransform:"uppercase" }}>{v}</button>
                              );
                            })}
                          </div>
                          <span style={{ fontFamily:"var(--serif)", fontSize:13, fontStyle:"italic", color:"var(--text3)" }}>
                            {p.onBoard === "yes" ? "saving them for The Board" : p.onBoard === "no" ? "great advocate, not a board seat" : "want them on your Board of 12?"}
                          </span>
                        </div>
                      )}

                      {(r === "neutral" || r === "anchor") && (
                        <div style={{ marginTop:14, paddingTop:14, borderTop:"1px solid var(--border)" }}>
                          <div style={{ display:"flex", alignItems:"center", gap:12, flexWrap:"wrap" }}>
                            <span style={{ fontSize:10, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color: r === "anchor" ? A3_RED : A3_GREY, fontFamily:"var(--sans)" }}>Action</span>
                            <select value={p.action || ""} onChange={e => updatePerson(p.id, { action: e.target.value })}
                              style={{ padding:"6px 8px", fontSize:12, fontFamily:"var(--sans)",
                                background:"var(--bg)", border:"1px solid var(--border)", borderRadius:6,
                                color: p.action ? "var(--text2)" : "var(--text4)",
                                fontStyle: p.action ? "normal" : "italic", cursor:"pointer", outline:"none", minWidth:160 }}>
                              <option value="" disabled>Choose an action…</option>
                              {(r === "anchor" ? A3_ANCHOR_ACTIONS : A3_NEUTRAL_ACTIONS).map(a => <option key={a} value={a}>{a}</option>)}
                            </select>
                            {p.action && (
                              <span style={{ fontFamily:"var(--serif)", fontSize:13, fontStyle:"italic", color:"var(--text3)" }}>
                                {A3_ACTION_HINTS[p.action]}
                              </span>
                            )}
                          </div>
                          {p.action && (
                            <div style={{ marginTop:12 }}>
                              <div style={{ fontSize:11, color:"var(--text4)", fontFamily:"var(--sans)", marginBottom:5 }}>
                                How · what does this look like? <span style={{ fontStyle:"italic" }}>optional</span>
                              </div>
                              <textarea value={p.how || ""} onChange={e => updatePerson(p.id, { how: e.target.value })}
                                placeholder={A3_HOW_PLACEHOLDERS[p.action]} rows={2}
                                style={{ width:"100%", padding:"8px 10px", fontSize:13, fontFamily:"var(--sans)",
                                  background:"var(--bg)", border:"1px solid var(--border)", borderRadius:6,
                                  color:"var(--text)", outline:"none", resize:"vertical", lineHeight:1.5 }} />
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>

              {/* ADD SOMEONE ELSE */}
              <div style={{ display:"flex", gap:10, padding:"12px 14px", background:"transparent", border:"1px dashed var(--border)", borderRadius:9, marginBottom:30, alignItems:"center" }}>
                <input value={newPersonInput} onChange={e => setNewPersonInput(e.target.value)}
                  onKeyDown={e => { if (e.key === "Enter") { addPerson(newPersonInput); setNewPersonInput(""); } }}
                  placeholder="Thought of someone else? Add them here…"
                  style={{ flex:1, padding:"7px 10px", fontSize:13, fontFamily:"var(--sans)",
                    background:"transparent", border:"none", color:"var(--text)", outline:"none" }} />
                <button onClick={() => { addPerson(newPersonInput); setNewPersonInput(""); }}
                  style={{ padding:"6px 14px", fontSize:11, fontWeight:700, letterSpacing:0.6, fontFamily:"var(--sans)",
                    background:"transparent", color: A3_TEAL, border:`1px solid ${A3_TEAL}`, borderRadius:999, cursor:"pointer" }}>
                  + ADD
                </button>
              </div>

              {/* SUMMARY */}
              <div style={{ marginBottom:24 }}>
                <div style={{ fontSize:10, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color:"var(--text3)", marginBottom:12, fontFamily:"var(--sans)" }}>Your inner circle so far</div>
                <div style={{ display:"grid", gridTemplateColumns:"repeat(3, 1fr)", gap:12 }}>
                  {[
                    { key:"advocate", label:"Advocates", count: counts.advocate, color: A3_TEAL, glow: advocateCellHighlight },
                    { key:"neutral",  label:"Neutral",   count: counts.neutral,  color: A3_GREY, glow: false },
                    { key:"anchor",   label:"Anchors",   count: counts.anchor,   color: A3_RED,  glow: anchorCellHighlight },
                  ].map(cell => (
                    <div key={cell.key} style={{ padding:"16px 18px", background:"var(--bg2)",
                      border:`1px solid ${cell.color}`, borderRadius:9,
                      boxShadow: cell.glow ? `0 0 14px ${cell.color}66` : "none" }}>
                      <div style={{ fontFamily:"var(--serif)", fontSize:36, fontWeight:300, color: cell.color, lineHeight:1, marginBottom:6 }}>{cell.count}</div>
                      <div style={{ fontSize:11, color:"var(--text3)", letterSpacing:1, textTransform:"uppercase", fontFamily:"var(--sans)", fontWeight:600 }}>{cell.label}</div>
                    </div>
                  ))}
                </div>
                {boardCount >= 1 && (
                  <div style={{ marginTop:12, padding:"10px 14px", background:"rgba(93,202,165,.1)", border:`1px solid ${A3_TEAL}`, borderRadius:8, fontSize:13, fontFamily:"var(--sans)", color: A3_TEAL, fontWeight:600 }}>
                    {boardCount} {boardCount === 1 ? "person" : "people"} heading to your Board
                  </div>
                )}
              </div>

              {/* REFLECTION */}
              {(() => {
                const cfg = reflectionTone === "advocate"
                  ? { color: A3_TEAL, label: "Celebrate this", text: "Celebrate this. The people around you are supporting who you are and who you're evolving into — that's rare, and it didn't happen by accident. Sit with it for a moment. What does it mean to have this much support already in place?" }
                  : reflectionTone === "anchor"
                    ? { color: A3_RED, label: "Be curious, not critical", text: "If your list has more anchors than you'd like, that's okay. It doesn't mean you've done something wrong — it means you're seeing clearly, probably for the first time in a while. We'll get strategic later. For now, just be curious. Which names were a surprise? Which did you already know?" }
                    : { color: A3_AMBER, label: "One thing to notice", text: "What do you notice? Be curious, not critical. Every name on this list is telling you something about the life you've built and the one you're growing into. No judgment — just see." };
                return (
                  <div style={{ padding:"18px 22px", background:`${cfg.color}11`, borderLeft:`3px solid ${cfg.color}`, borderRadius:8, marginBottom:24 }}>
                    <div style={{ fontSize:10, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color: cfg.color, marginBottom:10, fontFamily:"var(--sans)" }}>{cfg.label}</div>
                    <div style={{ fontFamily:"var(--serif)", fontSize:18, fontStyle:"italic", color:"var(--text2)", lineHeight:1.75 }}>{cfg.text}</div>
                  </div>
                );
              })()}

              {/* CLOSING */}
              <div style={{ marginBottom:30 }}>
                <div style={{ fontFamily:"var(--serif)", fontSize:22, fontWeight:400, color:"var(--text)", marginBottom:12 }}>You saw it.</div>
                <p style={{ fontFamily:"var(--sans)", fontSize:16, color:"var(--text2)", lineHeight:1.8, marginBottom:10, maxWidth:640 }}>
                  That's what this page was for. Don't try to fix anything. Don't rewrite relationships in your head. Don't decide who to call or who to cut.
                </p>
                <p style={{ fontFamily:"var(--sans)", fontSize:16, color:"var(--text2)", lineHeight:1.8, maxWidth:640 }}>
                  The people you marked as advocates — and chose for your Board — move to <strong style={{ color: A3_TEAL, fontWeight:700 }}>The Board</strong> next, where you'll give each one their seat at the table. For now, just notice. Reflect without judging. Stay curious.
                </p>
              </div>
            </>
          )}

          {/* STEP FOOTER */}
          <div style={{ marginTop:8, paddingTop:18, borderTop:"1px solid var(--border)", display:"flex", alignItems:"center", justifyContent:"space-between", gap:14 }}>
            <button onClick={() => setA3PeoplePhase(1)}
              style={{ padding:"8px 16px", fontSize:12, fontWeight:600, letterSpacing:0.5, fontFamily:"var(--sans)", background:"transparent", color:"var(--text2)", border:"1px solid var(--border)", borderRadius:999, cursor:"pointer" }}>
              ← Back to naming
            </button>
            <div style={{ display:"flex", alignItems:"center", gap:14 }}>
              <span style={{ fontSize:12, color:"var(--text4)", fontFamily:"var(--sans)" }}>Next up · Environment</span>
              <button onClick={() => setA3Step("environment")}
                style={{ padding:"9px 18px", fontSize:12, fontWeight:700, letterSpacing:0.5, fontFamily:"var(--sans)", background: A3_TEAL, color:"#0d1b2e", border:"none", borderRadius:999, cursor:"pointer" }}>
                Continue →
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
function A3EnvironmentStub({ setA3Step, map, set }: any) {
  const items = map.a3_env_items || [];
  const takeaway = map.a3_env_takeaway || "";
  const [a3EnvPhase, setA3EnvPhase] = useState<1|2>(items.length > 0 ? 2 : 1);
  const [brainDumpText, setBrainDumpText] = useState<string>(() => items.map((i: any) => i.name).join("\n"));
  const [newItemInput, setNewItemInput] = useState("");
  const [promptsOpen, setPromptsOpen] = useState(false);

  const uuid = () => (typeof crypto !== "undefined" && (crypto as any).randomUUID) ? (crypto as any).randomUUID() : String(Date.now()) + Math.random();

  const updateItem = (id: string, patch: any) => set("a3_env_items", items.map((i: any) => i.id === id ? { ...i, ...patch } : i));
  const removeItem = (id: string) => set("a3_env_items", items.filter((i: any) => i.id !== id));
  const addItem = (rawName: string) => {
    const name = rawName.trim();
    if (!name) return;
    set("a3_env_items", [...items, { id: uuid(), name }]);
  };

  const lineCount = brainDumpText.split("\n").map(s => s.trim()).filter(Boolean).length;

  const commitBrainDump = () => {
    const lines = brainDumpText.split("\n").map(s => s.trim()).filter(Boolean);
    const byName = new Map<string, any>(items.map((i: any) => [i.name.toLowerCase(), i]));
    const next = lines.map(line => {
      const existing = byName.get(line.toLowerCase());
      return existing ? existing : { id: uuid(), name: line };
    });
    set("a3_env_items", next);
    setA3EnvPhase(2);
  };

  const rated = items.filter((i: any) => i.rating);
  const counts = {
    advocate: rated.filter((i: any) => i.rating === "advocate").length,
    neutral:  rated.filter((i: any) => i.rating === "neutral").length,
    anchor:   rated.filter((i: any) => i.rating === "anchor").length,
  };
  const advPct = rated.length ? counts.advocate / rated.length : 0;
  const ancPct = rated.length ? counts.anchor / rated.length : 0;
  const advocateCellHighlight = (advPct >= 0.6 && ancPct <= 0.2);
  const anchorCellHighlight = (ancPct >= 0.4);
  const reflectionTone = rated.length < 3 ? "balanced" : (advPct >= 0.6 && ancPct <= 0.2) ? "advocate" : ancPct >= 0.4 ? "anchor" : "balanced";
  const habitCount = items.filter((i: any) => i.kind === "habit").length;
  const placeCount = items.filter((i: any) => i.kind === "place").length;
  const anyKind = (habitCount + placeCount) > 0;

  return (
    <div>
      {/* BREADCRUMB + H1 + LEAD */}
      <div style={{ fontSize:11, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color: A3_TEAL, marginBottom:11 }}>A3 · Energy Audit · Environment</div>
      <h2 style={{ fontFamily:"var(--serif)", fontSize:40, fontWeight:300, lineHeight:1.15, marginBottom:14, letterSpacing:"-0.5px" }}>
        Your habits and your places.
      </h2>
      <p style={{ fontFamily:"var(--sans)", fontSize:15, color:"var(--text2)", lineHeight:1.85, marginBottom:20, maxWidth:640 }}>
        What you do on repeat, and where you spend your time. Your environment speaks before you do — some of it supports who you're evolving into, some of it quietly pulls you back.
      </p>

      {/* FRAMING CARD */}
      <div style={{ background:"var(--bg2)", border:"1px solid var(--border)", borderRadius:11, padding:"18px 22px", marginBottom:26 }}>
        <div style={{ fontSize:10, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color: A3_TEAL, marginBottom:10, fontFamily:"var(--sans)" }}>What belongs here</div>
        <div style={{ fontFamily:"var(--sans)", fontSize:16, color:"var(--text2)", lineHeight:1.75 }}>
          <strong style={{ color: A3_TEAL, fontWeight:700 }}>Habits</strong> are behaviors you repeat — morning routines, how you wind down, what you reach for when stressed. <strong style={{ color: A3_TEAL, fontWeight:700 }}>Places</strong> are the physical environments that shape you — where you work, where you rest, where you come undone. The goal is to name the <strong style={{ color: A3_TEAL, fontWeight:700 }}>good, the bad, and the ugly</strong> — the main ones, not all of them. When something is both a habit and a place (morning coffee at the kitchen counter), pick whichever feels more true.
        </div>
      </div>

      {/* PHASE TRACKER */}
      <div style={{ display:"flex", alignItems:"center", gap:14, marginBottom:30 }}>
        {[1,2].map((step, idx) => {
          const isCurrent = a3EnvPhase === step;
          const isDone = a3EnvPhase > step;
          const label = step === 1 ? "Name them" : "Rate them";
          const circleStyle: any = {
            width:26, height:26, borderRadius:"50%", display:"flex", alignItems:"center", justifyContent:"center",
            fontSize:12, fontWeight:700, fontFamily:"var(--sans)",
            ...(isDone
              ? { background: A3_TEAL, color:"#0d1b2e", border:`1px solid ${A3_TEAL}` }
              : isCurrent
                ? { background:"transparent", color: A3_TEAL, border:`1.5px solid ${A3_TEAL}` }
                : { background:"transparent", color:"var(--text4)", border:"1px solid var(--border)" }),
          };
          const textColor = isCurrent || isDone ? A3_TEAL : "var(--text4)";
          return (
            <React.Fragment key={step}>
              <div style={{ display:"flex", alignItems:"center", gap:9 }}>
                <div style={circleStyle}>{isDone ? "✓" : step}</div>
                <span style={{ fontSize:12, fontFamily:"var(--sans)", fontWeight:600, color: textColor, letterSpacing:0.4 }}>{label}</span>
              </div>
              {idx === 0 && <div style={{ flex:"0 0 40px", height:1, background:"var(--border)" }} />}
            </React.Fragment>
          );
        })}
      </div>

      {/* PHASE 1 */}
      {a3EnvPhase === 1 && (
        <>
          <div style={{ background:"var(--bg2)", border:"1px solid var(--border)", borderRadius:11, padding:"22px 24px", marginBottom:18 }}>
            <div style={{ fontSize:10, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color: A3_TEAL, marginBottom:10, fontFamily:"var(--sans)" }}>Phase 1 · Brain-dump</div>
            <div style={{ fontFamily:"var(--serif)", fontSize:22, fontWeight:400, color:"var(--text)", marginBottom:8 }}>What are your main habits and places right now — the good, the bad, and the ugly?</div>
            <div style={{ fontSize:13, color:"var(--text3)", lineHeight:1.6, marginBottom:16 }}>
              Focus on the ones where you actually spend most of your time. One per line. Don't list everything — list what's real. Short phrases are enough.
            </div>
            <textarea value={brainDumpText} onChange={e => setBrainDumpText(e.target.value)}
              placeholder={"Type one habit or place per line…\ne.g.\nMorning coffee at the kitchen counter\nDoom-scrolling before bed\nMy office\nSunday hike\nThe car"}
              style={{ width:"100%", minHeight:200, padding:"14px 16px", fontSize:14, fontFamily:"var(--sans)",
                background:"var(--bg)", border:"1px solid var(--border)", borderRadius:9, color:"var(--text)",
                outline:"none", resize:"vertical", lineHeight:1.6 }} />
            <div style={{ marginTop:10, fontSize:12, color:"var(--text4)", fontFamily:"var(--sans)" }}>
              {lineCount} {lineCount === 1 ? "item" : "items"} · aim for honest, not complete
            </div>
          </div>

          {/* Collapsible prompts */}
          <div style={{ padding:"14px 20px", background:"rgba(201,168,76,.07)", borderLeft:`3px solid ${A3_AMBER}`, borderRadius:8, marginBottom:30 }}>
            <button onClick={() => setPromptsOpen(!promptsOpen)}
              style={{ display:"flex", alignItems:"center", justifyContent:"space-between", width:"100%", background:"transparent", border:"none", padding:0, cursor:"pointer" }}>
              <span style={{ fontSize:10, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color: A3_AMBER, fontFamily:"var(--sans)" }}>If you're stuck · Memory prompts</span>
              <span style={{ fontSize:14, color: A3_AMBER, transform: promptsOpen ? "rotate(180deg)" : "rotate(0deg)", transition:"transform .2s" }}>▾</span>
            </button>
            {promptsOpen && (
              <div style={{ marginTop:14 }}>
                {[
                  { label: "For habits", chips: ["How I start the day", "What I do when I'm stressed", "How I unwind", "What I reach for on autopilot", "Weekend rhythms"] },
                  { label: "For places", chips: ["Where I work", "Where I sleep", "Where I eat", "Where I think best", "Where I avoid being"] },
                ].map(group => (
                  <div key={group.label} style={{ marginBottom:14 }}>
                    <div style={{ fontSize:10, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color:"var(--text4)", marginBottom:8, fontFamily:"var(--sans)" }}>{group.label}</div>
                    <div style={{ display:"flex", flexWrap:"wrap", gap:8 }}>
                      {group.chips.map((q, i) => (
                        <span key={i} style={{ fontFamily:"var(--serif)", fontSize:14, fontStyle:"italic", color:"var(--text2)", padding:"6px 12px", background:"rgba(201,168,76,.05)", border:"1px solid rgba(201,168,76,.18)", borderRadius:999 }}>{q}</span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Step footer */}
          <div style={{ marginTop:8, paddingTop:18, borderTop:"1px solid var(--border)", display:"flex", alignItems:"center", justifyContent:"space-between", gap:14 }}>
            <button onClick={() => setA3Step("people")}
              style={{ padding:"8px 16px", fontSize:12, fontWeight:600, letterSpacing:0.5, fontFamily:"var(--sans)", background:"transparent", color:"var(--text2)", border:"1px solid var(--border)", borderRadius:999, cursor:"pointer" }}>
              ← Back to People
            </button>
            <div style={{ display:"flex", alignItems:"center", gap:14 }}>
              <span style={{ fontSize:12, color:"var(--text4)", fontFamily:"var(--sans)" }}>
                {lineCount === 0 ? "Add at least one item to continue." : "Ready when you are."}
              </span>
              <button onClick={commitBrainDump} disabled={lineCount === 0}
                style={{ padding:"9px 18px", fontSize:12, fontWeight:700, letterSpacing:0.5, fontFamily:"var(--sans)",
                  background: lineCount === 0 ? "var(--border)" : A3_TEAL, color:"#0d1b2e", border:"none", borderRadius:999,
                  cursor: lineCount === 0 ? "not-allowed" : "pointer", opacity: lineCount === 0 ? 0.55 : 1 }}>
                Next · Rate them →
              </button>
            </div>
          </div>
        </>
      )}

      {/* PHASE 2 */}
      {a3EnvPhase === 2 && (
        <>
          {items.length === 0 && (
            <div style={{ padding:"40px 30px", textAlign:"center", background:"var(--bg2)", border:"1px solid var(--border)", borderRadius:11, marginBottom:30 }}>
              <div style={{ fontFamily:"var(--serif)", fontSize:22, color:"var(--text2)", marginBottom:10 }}>Nothing to rate yet.</div>
              <div style={{ fontSize:14, color:"var(--text3)", lineHeight:1.6, marginBottom:20, maxWidth:380, marginLeft:"auto", marginRight:"auto" }}>
                Head back to Phase 1 and list a few habits or places.
              </div>
              <button onClick={() => setA3EnvPhase(1)}
                style={{ padding:"8px 16px", fontSize:12, fontWeight:600, letterSpacing:0.5, fontFamily:"var(--sans)", background:"transparent", color: A3_TEAL, border:`1px solid ${A3_TEAL}`, borderRadius:999, cursor:"pointer" }}>
                ← Back to naming
              </button>
            </div>
          )}

          {items.length > 0 && (
            <>
              <p style={{ fontFamily:"var(--sans)", fontSize:15, color:"var(--text2)", lineHeight:1.85, marginBottom:24, maxWidth:680 }}>
                For each one, tag it as a habit or a place, then ask yourself: is it an advocate, neutral, or an anchor? Use your gut. No overthinking.
              </p>

              {/* ITEM ROWS */}
              <div style={{ display:"flex", flexDirection:"column", gap:12, marginBottom:24 }}>
                {items.map((it: any) => {
                  const r = it.rating;
                  const borderColor = r === "advocate" ? A3_TEAL : r === "neutral" ? A3_GREY : r === "anchor" ? A3_RED : "var(--border)";
                  const kindBtn = (val: string, label: string, color: string, tintBg: string) => {
                    const sel = it.kind === val;
                    return (
                      <button onClick={() => updateItem(it.id, { kind: val })}
                        style={{ padding:"5px 11px", fontSize:11, fontWeight:700, letterSpacing:0.6, fontFamily:"var(--sans)",
                          background: sel ? tintBg : "transparent",
                          color: sel ? color : "var(--text4)",
                          border: `1px solid ${sel ? color : "var(--border)"}`,
                          borderRadius:6, cursor:"pointer", transition:"all .15s" }}>
                        {label}
                      </button>
                    );
                  };
                  const ratingPill = (val: string, label: string, color: string, tintBg: string) => {
                    const selected = r === val;
                    return (
                      <button onClick={() => updateItem(it.id, { rating: val })}
                        style={{ padding:"5px 11px", fontSize:11, fontWeight:700, letterSpacing:0.6, fontFamily:"var(--sans)",
                          background: selected ? tintBg : "transparent",
                          color: selected ? color : "var(--text4)",
                          border: `1px solid ${selected ? color : "var(--border)"}`,
                          borderRadius:6, cursor:"pointer", transition:"all .15s" }}>
                        {label}
                      </button>
                    );
                  };
                  return (
                    <div key={it.id} style={{ background:"var(--bg2)", border:"1px solid var(--border)", borderLeft:`3px solid ${borderColor}`, borderRadius:9, padding:"14px 16px" }}>
                      <div style={{ display:"grid", gridTemplateColumns:"1fr auto auto 24px", gap:12, alignItems:"center" }}>
                        <div style={{ fontFamily:"var(--serif)", fontSize:17, color:"var(--text)", fontWeight:400, minWidth:0, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{it.name}</div>
                        <div style={{ display:"flex", gap:5 }}>
                          {kindBtn("habit", "HABIT", A3_TEAL,  "rgba(93,202,165,.18)")}
                          {kindBtn("place", "PLACE", A3_AMBER, "rgba(201,168,76,.18)")}
                        </div>
                        <div style={{ display:"flex", gap:5 }}>
                          {ratingPill("advocate", "ADVOCATE", A3_TEAL, "rgba(93,202,165,.2)")}
                          {ratingPill("neutral",  "NEUTRAL",  A3_GREY, "rgba(156,163,175,.2)")}
                          {ratingPill("anchor",   "ANCHOR",   A3_RED,  "rgba(239,68,68,.18)")}
                        </div>
                        <button onClick={() => removeItem(it.id)} title="Remove"
                          onMouseEnter={(e: any) => e.currentTarget.style.color = A3_RED}
                          onMouseLeave={(e: any) => e.currentTarget.style.color = "var(--text4)"}
                          style={{ width:24, height:24, borderRadius:"50%", background:"transparent", border:"none", color:"var(--text4)", cursor:"pointer", fontSize:16, lineHeight:1, padding:0, transition:"color .15s" }}>×</button>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* ADD ITEM */}
              <div style={{ display:"flex", gap:10, padding:"12px 14px", background:"transparent", border:"1px dashed var(--border)", borderRadius:9, marginBottom:30, alignItems:"center" }}>
                <input value={newItemInput} onChange={e => setNewItemInput(e.target.value)}
                  onKeyDown={e => { if (e.key === "Enter") { addItem(newItemInput); setNewItemInput(""); } }}
                  placeholder="Thought of something else? Add it here…"
                  style={{ flex:1, padding:"7px 10px", fontSize:13, fontFamily:"var(--sans)",
                    background:"transparent", border:"none", color:"var(--text)", outline:"none" }} />
                <button onClick={() => { addItem(newItemInput); setNewItemInput(""); }}
                  style={{ padding:"6px 14px", fontSize:11, fontWeight:700, letterSpacing:0.6, fontFamily:"var(--sans)",
                    background:"transparent", color: A3_TEAL, border:`1px solid ${A3_TEAL}`, borderRadius:999, cursor:"pointer" }}>
                  + ADD
                </button>
              </div>

              {/* SUMMARY */}
              <div style={{ marginBottom:24 }}>
                <div style={{ fontSize:10, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color:"var(--text3)", marginBottom:12, fontFamily:"var(--sans)" }}>Your environment so far</div>
                <div style={{ display:"grid", gridTemplateColumns:"repeat(3, 1fr)", gap:12 }}>
                  {[
                    { key:"advocate", label:"Advocate", count: counts.advocate, color: A3_TEAL, glow: advocateCellHighlight },
                    { key:"neutral",  label:"Neutral",  count: counts.neutral,  color: A3_GREY, glow: false },
                    { key:"anchor",   label:"Anchor",   count: counts.anchor,   color: A3_RED,  glow: anchorCellHighlight },
                  ].map(cell => (
                    <div key={cell.key} style={{ padding:"16px 18px", background:"var(--bg2)",
                      border:`1px solid ${cell.color}`, borderRadius:9,
                      boxShadow: cell.glow ? `0 0 14px ${cell.color}66` : "none" }}>
                      <div style={{ fontFamily:"var(--serif)", fontSize:36, fontWeight:300, color: cell.color, lineHeight:1, marginBottom:6 }}>{cell.count}</div>
                      <div style={{ fontSize:11, color:"var(--text3)", letterSpacing:1, textTransform:"uppercase", fontFamily:"var(--sans)", fontWeight:600 }}>{cell.label}</div>
                    </div>
                  ))}
                </div>
                {anyKind && (
                  <div style={{ marginTop:10, fontSize:12, color:"var(--text4)", fontFamily:"var(--sans)" }}>
                    {habitCount} {habitCount === 1 ? "habit" : "habits"} · {placeCount} {placeCount === 1 ? "place" : "places"}
                  </div>
                )}
              </div>

              {/* TAKEAWAY CARD */}
              <div style={{ padding:"18px 22px", background:"rgba(201,168,76,.07)", borderLeft:`3px solid ${A3_AMBER}`, borderRadius:8, marginBottom:24 }}>
                <div style={{ fontSize:10, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color: A3_TEAL, marginBottom:10, fontFamily:"var(--sans)" }}>Your takeaway</div>
                <div style={{ fontFamily:"var(--serif)", fontSize:18, fontWeight:400, color:"var(--text)", marginBottom:12, lineHeight:1.5 }}>
                  Of everything you named — what's the one habit or place you most want to change, and what's one you most want to protect?
                </div>
                <textarea value={takeaway} onChange={e => set("a3_env_takeaway", e.target.value)}
                  placeholder="e.g. Change: the late-night scroll. Protect: my Sunday hike."
                  rows={3}
                  style={{ width:"100%", padding:"10px 12px", fontSize:14, fontFamily:"var(--sans)",
                    background:"var(--bg)", border:"1px solid var(--border)", borderRadius:8, color:"var(--text)",
                    outline:"none", resize:"vertical", lineHeight:1.6 }} />
              </div>

              {/* REFLECTION */}
              {(() => {
                const cfg = reflectionTone === "advocate"
                  ? { color: A3_TEAL, label: "Protect what's working", text: "Your environment is mostly working for you. That's rare — and it's a quiet kind of wealth. What would it mean to protect it more deliberately instead of taking it for granted?" }
                  : reflectionTone === "anchor"
                    ? { color: A3_RED, label: "Information, not failure", text: "If more of your environment is anchoring than supporting, that's information — not a failure. Environments accumulate by default. You only get to shape them on purpose once you see them clearly. Which anchor would cost you the least to change first?" }
                    : { color: A3_AMBER, label: "One thing to notice", text: "What do you notice? Be curious, not critical. Every item on this list is telling you something about the environment you've built — what's supporting you and what's quietly in the way." };
                return (
                  <div style={{ padding:"18px 22px", background:`${cfg.color}11`, borderLeft:`3px solid ${cfg.color}`, borderRadius:8, marginBottom:24 }}>
                    <div style={{ fontSize:10, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color: cfg.color, marginBottom:10, fontFamily:"var(--sans)" }}>{cfg.label}</div>
                    <div style={{ fontFamily:"var(--serif)", fontSize:18, fontStyle:"italic", color:"var(--text2)", lineHeight:1.75 }}>{cfg.text}</div>
                  </div>
                );
              })()}

              {/* CLOSING */}
              <div style={{ marginBottom:30 }}>
                <div style={{ fontFamily:"var(--serif)", fontSize:22, fontWeight:400, color:"var(--text)", marginBottom:12 }}>You don't have to do it all.</div>
                <p style={{ fontFamily:"var(--sans)", fontSize:16, color:"var(--text2)", lineHeight:1.8, marginBottom:10, maxWidth:640 }}>
                  A3 isn't asking you to overhaul your whole life. <strong style={{ color: A3_TEAL, fontWeight:700 }}>One or two changes</strong> are usually enough — the smallest shift in habit or environment can unlock everything downstream. The rest will follow when it's ready.
                </p>
                <p style={{ fontFamily:"var(--sans)", fontSize:16, color:"var(--text2)", lineHeight:1.8, maxWidth:640 }}>
                  Next up is <strong style={{ color: A3_TEAL, fontWeight:700 }}>Thoughts</strong>, where you turn the same lens inward. It's where this whole phase lands.
                </p>
              </div>
            </>
          )}

          {/* STEP FOOTER */}
          <div style={{ marginTop:8, paddingTop:18, borderTop:"1px solid var(--border)", display:"flex", alignItems:"center", justifyContent:"space-between", gap:14 }}>
            <button onClick={() => setA3EnvPhase(1)}
              style={{ padding:"8px 16px", fontSize:12, fontWeight:600, letterSpacing:0.5, fontFamily:"var(--sans)", background:"transparent", color:"var(--text2)", border:"1px solid var(--border)", borderRadius:999, cursor:"pointer" }}>
              ← Back to naming
            </button>
            <div style={{ display:"flex", alignItems:"center", gap:14 }}>
              <span style={{ fontSize:12, color:"var(--text4)", fontFamily:"var(--sans)" }}>Next up · Thoughts</span>
              <button onClick={() => setA3Step("thoughts")}
                style={{ padding:"9px 18px", fontSize:12, fontWeight:700, letterSpacing:0.5, fontFamily:"var(--sans)", background: A3_TEAL, color:"#0d1b2e", border:"none", borderRadius:999, cursor:"pointer" }}>
                Continue →
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
function A3ThoughtsStub({ setA3Step, map, set }: any) {
  const DEFAULT_TRIGGERS = [
    { id: "t1", q: "When you fail or mess up, what do you tell yourself?",     placeholder: 'e.g. "You should have known better…"' },
    { id: "t2", q: "When life is hard, what do you say to yourself?",          placeholder: 'e.g. "Just push through — no one else will save you."' },
    { id: "t3", q: "When you think about money, what's the story?",            placeholder: 'e.g. "There\'s never enough."' },
    { id: "t4", q: "When you think about success, what runs in your head?",    placeholder: 'e.g. "Other people just get lucky."' },
    { id: "t5", q: "When you look in the mirror, what's the voice?",           placeholder: 'e.g. "You\'re getting old." / "You look tired."' },
  ];

  const triggers: any[] = (map.a3_triggers && map.a3_triggers.length)
    ? map.a3_triggers
    : DEFAULT_TRIGGERS.map(t => ({ ...t, thoughts: "", isCustom: false, customQ: "" }));
  const thoughts: any[] = map.a3_thoughts || [];
  const bestFriend: string = map.a3_best_friend || "";

  const [a3ThoughtsPhase, setA3ThoughtsPhase] = useState<1|2>(thoughts.length > 0 ? 2 : 1);
  const [reframingId, setReframingId] = useState<number|null>(null);
  const [reframeInputValue, setReframeInputValue] = useState("");
  const [focusedTriggerIdx, setFocusedTriggerIdx] = useState<number|null>(null);

  const updateTrigger = (idx: number, patch: any) => {
    const next = triggers.map((t, i) => i === idx ? { ...t, ...patch } : t);
    set("a3_triggers", next);
  };
  const addCustomTrigger = () => {
    set("a3_triggers", [...triggers, { id: `c${Date.now()}`, q: "", placeholder: "Write what shows up…", thoughts: "", isCustom: true, customQ: "" }]);
  };
  const removeTrigger = (idx: number) => {
    set("a3_triggers", triggers.filter((_, i) => i !== idx));
  };

  const anyThoughtWritten = triggers.some((t: any) => (t.thoughts || "").split("\n").map((s: string) => s.trim()).filter(Boolean).length > 0);

  const compileThoughts = () => {
    const existingByText = new Map<string, any>();
    thoughts.forEach((th: any) => {
      if (th.text) existingByText.set(th.text.toLowerCase().trim(), th);
      if (th.originalText) existingByText.set(th.originalText.toLowerCase().trim(), th);
    });
    let nextId = thoughts.reduce((m: number, th: any) => Math.max(m, th.id || 0), 0) + 1;
    const compiled: any[] = [];
    const seen = new Set<number>();
    triggers.forEach((t: any, idx: number) => {
      const lines = (t.thoughts || "").split("\n").map((s: string) => s.trim()).filter(Boolean);
      lines.forEach((line: string) => {
        const existing = existingByText.get(line.toLowerCase());
        if (existing && !seen.has(existing.id)) {
          seen.add(existing.id);
          compiled.push(existing);
        } else {
          const newTh = { id: nextId++, text: line, originalText: null, triggerIdx: idx, rating: null, emphasized: false };
          compiled.push(newTh);
        }
      });
    });
    set("a3_thoughts", compiled);
    setA3ThoughtsPhase(2);
  };

  const rate = (id: number, val: string) => {
    set("a3_thoughts", thoughts.map((th: any) => {
      if (th.id !== id) return th;
      const newRating = th.rating === val ? null : val;
      const newEmphasized = newRating === "advocate" ? th.emphasized : false;
      return { ...th, rating: newRating, emphasized: newEmphasized };
    }));
  };
  const toggleEmphasized = (id: number) => {
    set("a3_thoughts", thoughts.map((th: any) => th.id === id ? { ...th, emphasized: !th.emphasized } : th));
  };
  const openReframe = (id: number) => { setReframingId(id); setReframeInputValue(""); };
  const closeReframe = () => { setReframingId(null); setReframeInputValue(""); };
  const saveReframe = () => {
    const trimmed = reframeInputValue.trim();
    if (!trimmed || reframingId === null) { closeReframe(); return; }
    set("a3_thoughts", thoughts.map((th: any) => th.id === reframingId
      ? { ...th, originalText: th.text, text: trimmed, rating: "advocate", emphasized: false }
      : th));
    closeReframe();
  };

  // Group thoughts by zone (unrated → neutral)
  const advThoughts = thoughts.filter((th: any) => th.rating === "advocate");
  const neuThoughts = thoughts.filter((th: any) => !th.rating || th.rating === "neutral");
  const ancThoughts = thoughts.filter((th: any) => th.rating === "anchor");

  const renderBubble = (th: any) => {
    const r = th.rating;
    const offset = ((th.id * 17) % 12) - 6;
    const borderColor = r === "advocate" ? A3_TEAL : r === "neutral" ? A3_GREY : r === "anchor" ? A3_RED : "var(--border)";
    const tint = r === "advocate" ? "rgba(93,202,165,.06)" : r === "anchor" ? "rgba(239,68,68,.05)" : "var(--bg2)";
    const dashed = !r;
    const emph = th.emphasized && r === "advocate";
    const ratingPill = (val: string, label: string, color: string, tintBg: string) => {
      const sel = r === val;
      return (
        <button onClick={() => rate(th.id, val)}
          style={{ padding:"3px 9px", fontSize:10, fontWeight:700, letterSpacing:0.5, fontFamily:"var(--sans)",
            background: sel ? tintBg : "transparent",
            color: sel ? color : "var(--text4)",
            border: `1px solid ${sel ? color : "var(--border)"}`,
            borderRadius:5, cursor:"pointer", transition:"all .15s" }}>
          {label}
        </button>
      );
    };
    return (
      <div key={th.id} style={{
        background: tint,
        border: `${emph ? 2 : 1}px ${dashed ? "dashed" : "solid"} ${borderColor}`,
        borderRadius: 10,
        padding: emph ? "13px 17px" : "11px 15px",
        maxWidth: 520,
        marginTop: offset,
        marginBottom: 4,
        opacity: dashed ? 0.78 : 1,
        transition: "all .2s",
      }}>
        {th.originalText && (
          <div style={{ fontFamily:"var(--serif)", fontSize:13, color:"var(--text4)", textDecoration:"line-through", marginBottom:5, fontStyle:"italic" }}>
            {th.originalText}
          </div>
        )}
        <div style={{ fontFamily:"var(--serif)", fontSize: emph ? 18 : 16, fontWeight: emph ? 500 : 400, color:"var(--text)", lineHeight:1.5 }}>
          {th.text}
        </div>
        <div style={{ marginTop:10, paddingTop:8, borderTop:`1px solid ${dashed ? "var(--border)" : borderColor}33`, display:"flex", alignItems:"center", justifyContent:"space-between", gap:10 }}>
          <div style={{ display:"flex", gap:4 }}>
            {ratingPill("advocate", "Adv", A3_TEAL, "rgba(93,202,165,.2)")}
            {ratingPill("neutral",  "Neu", A3_GREY, "rgba(156,163,175,.2)")}
            {ratingPill("anchor",   "Anc", A3_RED,  "rgba(239,68,68,.18)")}
          </div>
          {r === "advocate" && (
            <button onClick={() => toggleEmphasized(th.id)}
              style={{ padding:"3px 10px", fontSize:10, fontWeight:700, letterSpacing:0.5, fontFamily:"var(--sans)",
                background: th.emphasized ? "rgba(93,202,165,.2)" : "transparent",
                color: A3_TEAL, border:`1px solid ${A3_TEAL}`, borderRadius:5, cursor:"pointer" }}>
              {th.emphasized ? "↓ Un-grow" : "↑ Grow"}
            </button>
          )}
          {r === "anchor" && !th.originalText && (
            <button onClick={() => openReframe(th.id)}
              style={{ padding:"3px 10px", fontSize:10, fontWeight:700, letterSpacing:0.5, fontFamily:"var(--sans)",
                background:"transparent", color: A3_TEAL, border:`1px solid ${A3_TEAL}`, borderRadius:5, cursor:"pointer" }}>
              ↗ Reframe
            </button>
          )}
        </div>
      </div>
    );
  };

  return (
    <div>
      {/* BREADCRUMB + H1 + LEAD */}
      <div style={{ fontSize:11, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color: A3_TEAL, marginBottom:11 }}>A3 · Energy Audit · Thoughts</div>
      <h2 style={{ fontFamily:"var(--serif)", fontSize:40, fontWeight:300, lineHeight:1.15, marginBottom:14, letterSpacing:"-0.5px" }}>
        Your Inner Landscape.
      </h2>
      <p style={{ fontFamily:"var(--sans)", fontSize:15, color:"var(--text2)", lineHeight:1.85, marginBottom:20, maxWidth:640 }}>
        People and Environment are what surrounds you. This is what runs inside — the voice that speaks even when no one else is in the room.
      </p>

      {/* FRAMING CARD */}
      <div style={{ background:"var(--bg2)", border:"1px solid var(--border)", borderLeft:`3px solid ${A3_TEAL}`, borderRadius:11, padding:"18px 22px", marginBottom:26 }}>
        <div style={{ fontSize:10, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color: A3_TEAL, marginBottom:10, fontFamily:"var(--sans)" }}>Why this page is different</div>
        <div style={{ fontFamily:"var(--sans)", fontSize:16, color:"var(--text2)", lineHeight:1.75 }}>
          You can't brain-dump thoughts the way you can name people and places. The ones that matter don't come up on demand — they show up in context. So instead of asking "what are your thoughts?", this page asks <em style={{ color: A3_TEAL, fontStyle:"italic", fontWeight:600 }}>what do you tell yourself when…</em> — a few honest scenarios that usually surface the real voice. Then we'll shape what you find.
        </div>
      </div>

      {/* PHASE TRACKER */}
      <div style={{ display:"flex", alignItems:"center", gap:14, marginBottom:30 }}>
        {[1,2].map((step, idx) => {
          const isCurrent = a3ThoughtsPhase === step;
          const isDone = a3ThoughtsPhase > step;
          const label = step === 1 ? "Listen" : "The Landscape";
          const circleStyle: any = {
            width:26, height:26, borderRadius:"50%", display:"flex", alignItems:"center", justifyContent:"center",
            fontSize:12, fontWeight:700, fontFamily:"var(--sans)",
            ...(isDone
              ? { background: A3_TEAL, color:"#0d1b2e", border:`1px solid ${A3_TEAL}` }
              : isCurrent
                ? { background:"transparent", color: A3_TEAL, border:`1.5px solid ${A3_TEAL}` }
                : { background:"transparent", color:"var(--text4)", border:"1px solid var(--border)" }),
          };
          const textColor = isCurrent || isDone ? A3_TEAL : "var(--text4)";
          return (
            <React.Fragment key={step}>
              <div style={{ display:"flex", alignItems:"center", gap:9 }}>
                <div style={circleStyle}>{isDone ? "✓" : step}</div>
                <span style={{ fontSize:12, fontFamily:"var(--sans)", fontWeight:600, color: textColor, letterSpacing:0.4 }}>{label}</span>
              </div>
              {idx === 0 && <div style={{ flex:"0 0 40px", height:1, background:"var(--border)" }} />}
            </React.Fragment>
          );
        })}
      </div>

      {/* PHASE 1 */}
      {a3ThoughtsPhase === 1 && (
        <>
          <div style={{ display:"flex", flexDirection:"column", gap:14, marginBottom:18 }}>
            {triggers.map((t: any, idx: number) => {
              const focused = focusedTriggerIdx === idx;
              return (
                <div key={t.id}
                  onFocus={() => setFocusedTriggerIdx(idx)}
                  onBlur={() => setFocusedTriggerIdx(null)}
                  style={{ background:"var(--bg2)", border:"1px solid var(--border)", borderLeft:`3px solid ${focused ? A3_TEAL : "var(--border)"}`, borderRadius:11, padding:"18px 22px", transition:"border-color .15s" }}>
                  {t.isCustom ? (
                    <>
                      <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:10 }}>
                        <span style={{ fontSize:10, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color: A3_TEAL, fontFamily:"var(--sans)" }}>Your own trigger</span>
                        <button onClick={() => removeTrigger(idx)} title="Remove trigger"
                          onMouseEnter={(e: any) => e.currentTarget.style.color = A3_RED}
                          onMouseLeave={(e: any) => e.currentTarget.style.color = "var(--text4)"}
                          style={{ width:22, height:22, borderRadius:"50%", background:"transparent", border:"none", color:"var(--text4)", cursor:"pointer", fontSize:14, lineHeight:1, padding:0, transition:"color .15s" }}>×</button>
                      </div>
                      <input value={t.customQ || ""} onChange={e => updateTrigger(idx, { customQ: e.target.value })}
                        placeholder="Write your own trigger question…"
                        style={{ width:"100%", padding:"8px 10px", fontSize:16, fontFamily:"var(--serif)",
                          background:"var(--bg)", border:"1px solid var(--border)", borderRadius:7, color:"var(--text)",
                          outline:"none", marginBottom:10, fontStyle: t.customQ ? "normal" : "italic" }} />
                    </>
                  ) : (
                    <div style={{ fontFamily:"var(--serif)", fontSize:19, fontWeight:400, color:"var(--text)", marginBottom:12, lineHeight:1.4 }}>{t.q}</div>
                  )}
                  <textarea value={t.thoughts || ""} onChange={e => updateTrigger(idx, { thoughts: e.target.value })}
                    placeholder={t.placeholder} rows={2}
                    style={{ width:"100%", padding:"10px 12px", fontSize:14, fontFamily:"var(--sans)",
                      background:"var(--bg)", border:"1px solid var(--border)", borderRadius:7, color:"var(--text)",
                      outline:"none", resize:"vertical", lineHeight:1.6 }} />
                  <div style={{ marginTop:6, fontSize:11, color:"var(--text4)", fontFamily:"var(--sans)", fontStyle:"italic" }}>
                    One or two is enough. Separate them with a new line if more than one.
                  </div>
                </div>
              );
            })}
          </div>

          <div style={{ marginBottom:30 }}>
            <button onClick={addCustomTrigger}
              style={{ padding:"8px 16px", fontSize:12, fontWeight:600, letterSpacing:0.5, fontFamily:"var(--sans)", background:"transparent", color: A3_TEAL, border:`1px solid ${A3_TEAL}`, borderRadius:999, cursor:"pointer" }}>
              + Add your own trigger
            </button>
          </div>

          {/* Step footer */}
          <div style={{ marginTop:8, paddingTop:18, borderTop:"1px solid var(--border)", display:"flex", alignItems:"center", justifyContent:"space-between", gap:14 }}>
            <button onClick={() => setA3Step("environment")}
              style={{ padding:"8px 16px", fontSize:12, fontWeight:600, letterSpacing:0.5, fontFamily:"var(--sans)", background:"transparent", color:"var(--text2)", border:"1px solid var(--border)", borderRadius:999, cursor:"pointer" }}>
              ← Back to Environment
            </button>
            <div style={{ display:"flex", alignItems:"center", gap:14 }}>
              <span style={{ fontSize:12, color:"var(--text4)", fontFamily:"var(--sans)" }}>
                {anyThoughtWritten ? "Ready when you are." : "Write at least one thought to continue."}
              </span>
              <button onClick={compileThoughts} disabled={!anyThoughtWritten}
                style={{ padding:"9px 18px", fontSize:12, fontWeight:700, letterSpacing:0.5, fontFamily:"var(--sans)",
                  background: !anyThoughtWritten ? "var(--border)" : A3_TEAL, color:"#0d1b2e", border:"none", borderRadius:999,
                  cursor: !anyThoughtWritten ? "not-allowed" : "pointer", opacity: !anyThoughtWritten ? 0.55 : 1 }}>
                Next · The Landscape →
              </button>
            </div>
          </div>
        </>
      )}

      {/* PHASE 2 */}
      {a3ThoughtsPhase === 2 && (
        <>
          {thoughts.length === 0 && (
            <div style={{ padding:"40px 30px", textAlign:"center", background:"var(--bg2)", border:"1px solid var(--border)", borderRadius:11, marginBottom:30 }}>
              <div style={{ fontFamily:"var(--serif)", fontSize:22, color:"var(--text2)", marginBottom:10 }}>No thoughts yet.</div>
              <div style={{ fontSize:14, color:"var(--text3)", lineHeight:1.6, marginBottom:20, maxWidth:380, marginLeft:"auto", marginRight:"auto" }}>
                Head back to Phase 1 and answer at least one trigger.
              </div>
              <button onClick={() => setA3ThoughtsPhase(1)}
                style={{ padding:"8px 16px", fontSize:12, fontWeight:600, letterSpacing:0.5, fontFamily:"var(--sans)", background:"transparent", color: A3_TEAL, border:`1px solid ${A3_TEAL}`, borderRadius:999, cursor:"pointer" }}>
                ← Back to Listen
              </button>
            </div>
          )}

          {thoughts.length > 0 && (
            <>
              {/* Phase 2 intro card */}
              <div style={{ background:"var(--bg2)", border:"1px solid var(--border)", borderRadius:11, padding:"20px 24px", marginBottom:18 }}>
                <div style={{ fontSize:10, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color: A3_TEAL, marginBottom:8, fontFamily:"var(--sans)" }}>Phase 2 · The Landscape</div>
                <div style={{ fontFamily:"var(--serif)", fontSize:22, fontWeight:400, color:"var(--text)", marginBottom:10 }}>Shape your inner landscape.</div>
                <div style={{ fontFamily:"var(--sans)", fontSize:16, color:"var(--text2)", lineHeight:1.75 }}>
                  Each thought you wrote is a card. Rate it and it moves to where it lives — advocates rise, anchors sink. Tap <strong style={{ color: A3_TEAL, fontWeight:700 }}>Grow</strong> on an advocate to emphasize it. Tap <strong style={{ color: A3_TEAL, fontWeight:700 }}>Reframe</strong> on an anchor to rewrite it — the original stays as a strike-through above the new words.
                </div>
              </div>

              {/* Legend */}
              <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", flexWrap:"wrap", gap:12, marginBottom:14 }}>
                <div style={{ display:"flex", gap:16, fontSize:11, fontFamily:"var(--sans)", fontWeight:600, letterSpacing:0.4 }}>
                  <span style={{ color: A3_TEAL }}>● Advocate rises</span>
                  <span style={{ color: A3_GREY }}>● Neutral drifts</span>
                  <span style={{ color: A3_RED }}>● Anchor sinks</span>
                </div>
                <span style={{ fontSize:11, color:"var(--text4)", fontFamily:"var(--sans)", fontStyle:"italic" }}>Pick the rating on each card first</span>
              </div>

              {/* LANDSCAPE */}
              <div style={{ border:"1px solid var(--border)", borderRadius:12, overflow:"hidden", marginBottom:24 }}>
                {/* Advocate zone */}
                <div style={{ background:"rgba(93,202,165,.04)", padding:"22px 22px 26px" }}>
                  <div style={{ display:"flex", justifyContent:"flex-end", marginBottom:10 }}>
                    <span style={{ fontSize:10, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color: A3_TEAL, opacity:0.8, fontFamily:"var(--sans)" }}>Advocate ↑</span>
                  </div>
                  <div style={{ display:"flex", flexDirection:"column", gap:8, alignItems:"flex-start" }}>
                    {advThoughts.length === 0
                      ? <div style={{ fontSize:12, color:"var(--text4)", fontStyle:"italic", fontFamily:"var(--sans)" }}>Nothing risen yet.</div>
                      : advThoughts.map(renderBubble)}
                  </div>
                </div>
                {/* Divider */}
                <div style={{ height:1, background:"var(--border)" }} />
                {/* Neutral zone */}
                <div style={{ padding:"20px 22px" }}>
                  <div style={{ display:"flex", justifyContent:"flex-end", marginBottom:10 }}>
                    <span style={{ fontSize:10, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color: A3_GREY, opacity:0.8, fontFamily:"var(--sans)" }}>Neutral</span>
                  </div>
                  <div style={{ display:"flex", flexDirection:"column", gap:8, alignItems:"center" }}>
                    {neuThoughts.length === 0
                      ? <div style={{ fontSize:12, color:"var(--text4)", fontStyle:"italic", fontFamily:"var(--sans)" }}>Nothing drifting.</div>
                      : neuThoughts.map(renderBubble)}
                  </div>
                </div>
                {/* Divider */}
                <div style={{ height:1, background:"var(--border)" }} />
                {/* Anchor zone */}
                <div style={{ background:"rgba(239,68,68,.04)", padding:"22px 22px 32px" }}>
                  <div style={{ display:"flex", justifyContent:"flex-end", marginBottom:10 }}>
                    <span style={{ fontSize:10, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color: A3_RED, opacity:0.8, fontFamily:"var(--sans)" }}>Anchor ↓</span>
                  </div>
                  <div style={{ display:"flex", flexDirection:"column", gap:8, alignItems:"flex-end" }}>
                    {ancThoughts.length === 0
                      ? <div style={{ fontSize:12, color:"var(--text4)", fontStyle:"italic", fontFamily:"var(--sans)" }}>Nothing sunk.</div>
                      : ancThoughts.map(renderBubble)}
                  </div>
                </div>
              </div>

              {/* BEST FRIEND CARD */}
              <div style={{ padding:"18px 22px", background:"rgba(201,168,76,.07)", borderLeft:`3px solid ${A3_AMBER}`, borderRadius:8, marginBottom:24 }}>
                <div style={{ fontSize:10, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color: A3_AMBER, marginBottom:10, fontFamily:"var(--sans)" }}>The question behind all of this</div>
                <div style={{ fontFamily:"var(--serif)", fontSize:20, fontWeight:400, color:"var(--text)", marginBottom:10, lineHeight:1.45 }}>
                  Are you speaking to yourself like a best friend — or like your worst enemy?
                </div>
                <div style={{ fontFamily:"var(--sans)", fontSize:13, color:"var(--text3)", lineHeight:1.7, marginBottom:12 }}>
                  Look at your landscape. Look at what rose, and what sank. Look at what you had to reframe just to feel okay. Write honestly — no one else reads this.
                </div>
                <textarea value={bestFriend} onChange={e => set("a3_best_friend", e.target.value)}
                  placeholder="Honestly… when I look at this I see…"
                  rows={4}
                  style={{ width:"100%", padding:"10px 12px", fontSize:14, fontFamily:"var(--sans)",
                    background:"var(--bg)", border:"1px solid var(--border)", borderRadius:8, color:"var(--text)",
                    outline:"none", resize:"vertical", lineHeight:1.6 }} />
              </div>

              {/* CLOSING */}
              <div style={{ marginBottom:30 }}>
                <div style={{ fontFamily:"var(--serif)", fontSize:22, fontWeight:400, color:"var(--text)", marginBottom:12 }}>This is the page you come back to.</div>
                <p style={{ fontFamily:"var(--sans)", fontSize:16, color:"var(--text2)", lineHeight:1.8, marginBottom:10, maxWidth:640 }}>
                  Your inner landscape isn't fixed. Thoughts rise and fall. The voice that speaks <strong style={{ color: A3_TEAL, fontWeight:700 }}>to</strong> you today can be replaced by one that speaks <strong style={{ color: A3_TEAL, fontWeight:700 }}>with</strong> you — but only if you keep listening honestly, and keep reframing when the old voice takes over.
                </p>
                <p style={{ fontFamily:"var(--sans)", fontSize:16, color:"var(--text2)", lineHeight:1.8, maxWidth:640 }}>
                  Your landscape and your Best Friend response come forward to your <strong style={{ color: A3_TEAL, fontWeight:700 }}>Map of Me™</strong>, where they live alongside everything you built in A3.
                </p>
              </div>
            </>
          )}

          {/* STEP FOOTER */}
          <div style={{ marginTop:8, paddingTop:18, borderTop:"1px solid var(--border)", display:"flex", alignItems:"center", justifyContent:"space-between", gap:14 }}>
            <button onClick={() => setA3ThoughtsPhase(1)}
              style={{ padding:"8px 16px", fontSize:12, fontWeight:600, letterSpacing:0.5, fontFamily:"var(--sans)", background:"transparent", color:"var(--text2)", border:"1px solid var(--border)", borderRadius:999, cursor:"pointer" }}>
              ← Back to listening
            </button>
            <div style={{ display:"flex", alignItems:"center", gap:14 }}>
              <span style={{ fontSize:12, color:"var(--text4)", fontFamily:"var(--sans)" }}>Next up · The Board</span>
              <button onClick={() => setA3Step("energymap")}
                style={{ padding:"9px 18px", fontSize:12, fontWeight:700, letterSpacing:0.5, fontFamily:"var(--sans)", background: A3_TEAL, color:"#0d1b2e", border:"none", borderRadius:999, cursor:"pointer" }}>
                Continue →
              </button>
            </div>
          </div>
        </>
      )}

      {/* REFRAME OVERLAY */}
      {reframingId !== null && (() => {
        const th = thoughts.find((t: any) => t.id === reframingId);
        if (!th) return null;
        return (
          <div onClick={closeReframe}
            style={{ position:"fixed", inset:0, background:"rgba(0,0,0,.65)", zIndex:1000, display:"flex", alignItems:"center", justifyContent:"center", padding:20 }}>
            <div onClick={e => e.stopPropagation()}
              style={{ background:"var(--bg)", border:"1px solid var(--border)", borderRadius:14, padding:"26px 28px", maxWidth:560, width:"100%", boxShadow:"0 20px 60px rgba(0,0,0,.5)" }}>
              <div style={{ fontSize:10, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color: A3_TEAL, marginBottom:14, fontFamily:"var(--sans)" }}>Reframe this thought</div>
              <div style={{ fontSize:10, fontWeight:600, letterSpacing:1.5, textTransform:"uppercase", color:"var(--text4)", marginBottom:6, fontFamily:"var(--sans)" }}>The original</div>
              <div style={{ fontFamily:"var(--serif)", fontSize:14, color:"var(--text3)", marginBottom:18, fontStyle:"italic", padding:"8px 12px", background:"var(--bg2)", borderRadius:7, borderLeft:`2px solid ${A3_RED}` }}>
                {th.text}
              </div>
              <div style={{ fontFamily:"var(--serif)", fontSize:17, fontStyle:"italic", color:"var(--text2)", marginBottom:12, lineHeight:1.5 }}>
                If a best friend were listening — what would you want to say to yourself instead?
              </div>
              <textarea value={reframeInputValue} onChange={e => setReframeInputValue(e.target.value)}
                placeholder="Write the new version in your own words…"
                autoFocus rows={4}
                style={{ width:"100%", padding:"12px 14px", fontSize:15, fontFamily:"var(--sans)",
                  background:"var(--bg2)", border:"1px solid var(--border)", borderRadius:8, color:"var(--text)",
                  outline:"none", resize:"vertical", lineHeight:1.6, marginBottom:18 }} />
              <div style={{ display:"flex", justifyContent:"flex-end", gap:10 }}>
                <button onClick={closeReframe}
                  style={{ padding:"8px 18px", fontSize:12, fontWeight:600, letterSpacing:0.5, fontFamily:"var(--sans)", background:"transparent", color:"var(--text2)", border:"1px solid var(--border)", borderRadius:999, cursor:"pointer" }}>
                  Cancel
                </button>
                <button onClick={saveReframe}
                  style={{ padding:"9px 20px", fontSize:12, fontWeight:700, letterSpacing:0.5, fontFamily:"var(--sans)", background: A3_TEAL, color:"#0d1b2e", border:"none", borderRadius:999, cursor:"pointer" }}>
                  Save reframe
                </button>
              </div>
            </div>
          </div>
        );
      })()}
    </div>
  );
}
function a3HashStr(s: string) {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = ((h << 5) - h + s.charCodeAt(i)) | 0;
  return Math.abs(h);
}
function a3GetInitials(name: string) {
  const parts = (name || "").trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return "?";
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}
function A3EnergyMapBullseye({ setA3Step, map }: any) {
  const [selectedId, setSelectedId] = useState<string|null>(null);

  const getInitials = (name: string) => {
    const parts = (name || "").trim().split(/\s+/).filter(Boolean);
    if (parts.length === 0) return "?";
    if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
  };
  const hashStr = (s: string) => {
    let h = 0;
    for (let i = 0; i < s.length; i++) h = ((h << 5) - h + s.charCodeAt(i)) | 0;
    return Math.abs(h);
  };

  const buildPersonNote = (p: any) => {
    const parts = [p.action, p.how].filter((x: string) => x && x.trim());
    if (parts.length === 0) return "";
    const joined = parts.join(" · ");
    return /[.!?]$/.test(joined) ? joined : joined + ".";
  };

  const people = (map.a3_people || []).filter((p: any) => p.rating).map((p: any) => ({
    id: "p_" + p.id,
    name: p.name || "(unnamed)",
    kind: "person" as const,
    rating: p.rating,
    role: p.role || "",
    note: buildPersonNote(p),
    _x: 0, _y: 0,
  }));
  const envs = (map.a3_env_items || []).filter((e: any) => e.rating).map((e: any) => ({
    id: "e_" + e.id,
    name: e.name || "(unnamed)",
    kind: (e.kind === "place" ? "place" : "habit") as "habit" | "place",
    rating: e.rating,
    role: "",
    note: "",
    _x: 0, _y: 0,
  }));
  const items = [...people, ...envs];

  const advocates = items.filter(i => i.rating === "advocate");
  const neutrals  = items.filter(i => i.rating === "neutral");
  const anchors   = items.filter(i => i.rating === "anchor");

  const RING_ADVOCATE = 110, RING_NEUTRAL = 175, RING_ANCHOR = 235;
  const placeItemsOnRing = (list: any[], radius: number) => {
    const n = list.length;
    if (n === 0) return;
    const startAngle = -Math.PI / 2 + (Math.PI / n * 0.5);
    list.forEach((it, i) => {
      const baseAngle = startAngle + (i * (2 * Math.PI / n));
      const idHash = hashStr(it.id);
      const radiusJitter = ((idHash % 22) - 11);
      const angleJitter = (((idHash * 7) % 60) - 30) * (Math.PI / 180) * 0.15;
      const r = radius + radiusJitter;
      const a = baseAngle + angleJitter;
      it._x = 360 + r * Math.cos(a);
      it._y = 260 + r * Math.sin(a);
    });
  };
  placeItemsOnRing(advocates, RING_ADVOCATE);
  placeItemsOnRing(neutrals,  RING_NEUTRAL);
  placeItemsOnRing(anchors,   RING_ANCHOR);

  const total = items.length;
  const advCount = advocates.length;
  const neuCount = neutrals.length;
  const ancCount = anchors.length;
  const advPct = total ? advCount / total : 0;
  const neuPct = total ? neuCount / total : 0;
  const ancPct = total ? ancCount / total : 0;

  const selected = items.find(i => i.id === selectedId) || null;

  const A3_NEU_HEX = "#9ca3af";

  let reflectionText = "";
  if (total < 4) {
    reflectionText = "Look at the whole picture. Even with a few things named, the shape starts to show.";
  } else if (advPct >= 0.55 && ancPct <= 0.2) {
    reflectionText = "What's close to you is supporting the life you're building. Protect it on purpose.";
  } else if (ancPct >= 0.4) {
    reflectionText = "That's a lot sitting on the edge. What's one thing you'd set down this week if you could?";
  } else {
    reflectionText = "What are you keeping close — and what are you still carrying that doesn't serve you?";
  }

  const renderItem = (it: any) => {
    const isSelected = it.id === selectedId;
    const baseSize = it.rating === "advocate" ? 15 : 13;
    const size = isSelected ? baseSize + 3 : baseSize;
    const fill = it.rating === "advocate" ? "rgba(93,202,165,.32)"
               : it.rating === "neutral"  ? "rgba(156,163,175,.15)"
               : "rgba(239,68,68,.1)";
    const stroke = it.rating === "advocate" ? A3_TEAL
                 : it.rating === "neutral"  ? A3_NEU_HEX
                 : A3_RED;
    const strokeWidth = it.rating === "advocate" ? 2 : 1.5;
    const filterStyle = it.rating === "advocate" ? "drop-shadow(0 0 10px rgba(93,202,165,.55))" : undefined;
    const fontSize = it.rating === "advocate" ? (isSelected ? 11 : 10) : (isSelected ? 10 : 9);

    if (it.kind === "person") {
      return (
        <g key={it.id} onClick={() => setSelectedId(it.id)} style={{ cursor:"pointer", filter: filterStyle }}>
          <circle cx={it._x} cy={it._y} r={size} fill={fill} stroke={stroke} strokeWidth={strokeWidth} />
          <text x={it._x} y={it._y + 3} textAnchor="middle" fontSize={fontSize} fontWeight={600} fill={stroke} fontFamily="var(--sans)" style={{ pointerEvents:"none", userSelect:"none" }}>
            {getInitials(it.name)}
          </text>
        </g>
      );
    }
    const cx = it._x, cy = it._y, s = size;
    const points = `${cx},${cy - s} ${cx + s},${cy} ${cx},${cy + s} ${cx - s},${cy}`;
    const glyph = it.kind === "habit" ? "H" : "P";
    return (
      <g key={it.id} onClick={() => setSelectedId(it.id)} style={{ cursor:"pointer", filter: filterStyle }}>
        <polygon points={points} fill={fill} stroke={stroke} strokeWidth={strokeWidth} />
        <text x={cx} y={cy + 3} textAnchor="middle" fontSize={fontSize} fontWeight={600} fill={stroke} fontFamily="var(--sans)" style={{ pointerEvents:"none", userSelect:"none" }}>
          {glyph}
        </text>
      </g>
    );
  };

  const detailRatingColor = selected
    ? (selected.rating === "advocate" ? A3_TEAL : selected.rating === "neutral" ? A3_NEU_HEX : A3_RED)
    : "var(--border)";

  return (
    <div>
      {/* BREADCRUMB + H1 + LEAD */}
      <div style={{ fontSize:11, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color: A3_TEAL, marginBottom:11 }}>A3 · Energy Map</div>
      <h2 style={{ fontFamily:"var(--serif)", fontSize:40, fontWeight:300, lineHeight:1.15, marginBottom:14, letterSpacing:"-0.5px" }}>
        What and who are you carrying?
      </h2>
      <p style={{ fontFamily:"var(--sans)", fontSize:15, color:"var(--text2)", lineHeight:1.85, marginBottom:18, maxWidth:660 }}>
        Every person, habit, and place you named, arranged by how close you've kept each one. Advocates near the center — part of you. Anchors on the edge — weight you're still choosing to carry.
      </p>

      {/* "It starts with you" strip */}
      <div style={{ display:"flex", alignItems:"flex-start", gap:10, padding:"11px 16px", background:"rgba(201,168,76,.06)", border:"1px solid rgba(201,168,76,.2)", borderRadius:8, marginBottom:24 }}>
        <span style={{ color: A3_AMBER, fontSize:14, lineHeight:"21px", marginTop:1 }}>◆</span>
        <span style={{ fontFamily:"var(--sans)", fontSize:13, color:"var(--text2)", lineHeight:1.7 }}>
          It starts with you. Nothing here is acting <em style={{ fontStyle:"italic", color: A3_AMBER }}>on</em> you — every item on this map is something you chose to keep close, or haven't yet set down.
        </span>
      </div>

      {/* STATS, LEGEND, MAP — all hidden when items.length === 0 */}
      {items.length > 0 && (
        <>
          {/* STATS GRID */}
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:12, marginBottom:22 }}>
            <div style={{ padding:"14px 16px", background:"var(--bg2)", border:`1px solid ${A3_TEAL}`, borderRadius:9 }}>
              <div style={{ fontFamily:"var(--serif)", fontSize:32, fontWeight:300, color: A3_TEAL, lineHeight:1, marginBottom:6 }}>{advCount}</div>
              <div style={{ fontSize:12, fontWeight:600, color:"var(--text)", fontFamily:"var(--sans)", marginBottom:2 }}>Close to you</div>
              <div style={{ fontSize:11, color:"var(--text4)", fontFamily:"var(--sans)" }}>{Math.round(advPct * 100)}% supporting you</div>
            </div>
            <div style={{ padding:"14px 16px", background:"var(--bg2)", border:`1px solid ${A3_NEU_HEX}`, borderRadius:9 }}>
              <div style={{ fontFamily:"var(--serif)", fontSize:32, fontWeight:300, color: A3_NEU_HEX, lineHeight:1, marginBottom:6 }}>{neuCount}</div>
              <div style={{ fontSize:12, fontWeight:600, color:"var(--text)", fontFamily:"var(--sans)", marginBottom:2 }}>Drifting</div>
              <div style={{ fontSize:11, color:"var(--text4)", fontFamily:"var(--sans)" }}>{Math.round(neuPct * 100)}% neither way</div>
            </div>
            <div style={{ padding:"14px 16px", background:"var(--bg2)", border:`1px solid ${A3_RED}`, borderRadius:9 }}>
              <div style={{ fontFamily:"var(--serif)", fontSize:32, fontWeight:300, color: A3_RED, lineHeight:1, marginBottom:6 }}>{ancCount}</div>
              <div style={{ fontSize:12, fontWeight:600, color:"var(--text)", fontFamily:"var(--sans)", marginBottom:2 }}>Still carrying</div>
              <div style={{ fontSize:11, color:"var(--text4)", fontFamily:"var(--sans)" }}>{Math.round(ancPct * 100)}% sitting on the edge</div>
            </div>
          </div>

          {/* LEGEND */}
          <div style={{ display:"flex", gap:18, flexWrap:"wrap", marginBottom:14, fontSize:11, fontFamily:"var(--sans)", color:"var(--text3)" }}>
            <span><span style={{ color: A3_TEAL, fontSize:13 }}>●</span> People · advocate</span>
            <span><span style={{ color: A3_RED, fontSize:13 }}>●</span> People · anchor</span>
            <span><span style={{ color: A3_TEAL, fontSize:13 }}>◆</span> Environment · advocate</span>
            <span><span style={{ color: A3_RED, fontSize:13 }}>◆</span> Environment · anchor</span>
          </div>

          {/* MAP CONTAINER */}
          <div style={{ background:"var(--bg2)", border:"1px solid var(--border)", borderRadius:12, padding:"22px 24px", marginBottom:24 }}>
            <div style={{ fontFamily:"var(--serif)", fontSize:18, fontWeight:400, color:"var(--text)", marginBottom:4 }}>The View</div>
            <div style={{ fontSize:12, color:"var(--text4)", fontFamily:"var(--sans)", marginBottom:14, lineHeight:1.6 }}>
              You at the center. What supports you, what you're carrying, and what sits on the edge.
            </div>

            <svg viewBox="0 0 720 520" style={{ display:"block", width:"100%", maxWidth:720, margin:"0 auto", height:"auto" }}>
              <defs>
                <radialGradient id="mapGrad" cx="50%" cy="50%" r="50%">
                  <stop offset="0%"  stopColor="rgba(93,202,165,.08)" />
                  <stop offset="40%" stopColor="rgba(201,168,76,.03)" />
                  <stop offset="100%" stopColor="rgba(239,68,68,.02)" />
                </radialGradient>
                <radialGradient id="centerGlow" cx="50%" cy="50%" r="50%">
                  <stop offset="0%"  stopColor="rgba(201,168,76,.35)" />
                  <stop offset="100%" stopColor="rgba(201,168,76,0)" />
                </radialGradient>
              </defs>

              <rect x={0} y={0} width={720} height={520} rx={10} fill="url(#mapGrad)" />

              {/* Rings */}
              <circle cx={360} cy={260} r={RING_ANCHOR}   fill="none" stroke="rgba(239,68,68,.28)"   strokeWidth={1} />
              <circle cx={360} cy={260} r={RING_NEUTRAL}  fill="none" stroke="rgba(244,241,235,.2)"  strokeWidth={1} />
              <circle cx={360} cy={260} r={RING_ADVOCATE} fill="none" stroke="rgba(93,202,165,.38)"  strokeWidth={1.5} />

              {/* Ring labels */}
              <text x={360} y={260 - RING_ANCHOR - 8}   textAnchor="middle" fontSize={9} fontWeight={700} letterSpacing={2} fill="rgba(239,68,68,.5)"   fontFamily="var(--sans)">ANCHOR</text>
              <text x={360} y={260 - RING_NEUTRAL - 8}  textAnchor="middle" fontSize={9} fontWeight={700} letterSpacing={2} fill="rgba(244,241,235,.45)" fontFamily="var(--sans)">NEUTRAL</text>
              <text x={360} y={260 - RING_ADVOCATE - 8} textAnchor="middle" fontSize={9} fontWeight={700} letterSpacing={2} fill="rgba(93,202,165,.55)"  fontFamily="var(--sans)">ADVOCATE</text>

              {/* Center "you" */}
              <circle cx={360} cy={260} r={36} fill="url(#centerGlow)" />
              <circle cx={360} cy={260} r={22} fill="var(--bg)" stroke={A3_AMBER} strokeWidth={1.5} />
              <text x={360} y={264} textAnchor="middle" fontSize={11} fill="var(--text2)" fontFamily="var(--serif)" fontStyle="italic">you</text>

              {/* Items */}
              {items.map(renderItem)}
            </svg>

            {/* DETAIL CARD */}
            {selected && (() => {
              const sourceLabel = selected.kind === "person" ? "People"
                                : selected.kind === "habit"  ? "Habit"
                                : "Place";
              const sourceColor = selected.kind === "person" ? A3_TEAL : A3_AMBER;
              const sourceBg    = selected.kind === "person" ? "rgba(93,202,165,.12)" : "rgba(201,168,76,.12)";
              const ratingColor = selected.rating === "advocate" ? A3_TEAL : selected.rating === "neutral" ? A3_NEU_HEX : A3_RED;
              const ratingBg    = selected.rating === "advocate" ? "rgba(93,202,165,.15)" : selected.rating === "neutral" ? "rgba(156,163,175,.15)" : "rgba(239,68,68,.12)";
              return (
                <div style={{
                  marginTop:18,
                  background:"var(--bg)",
                  border:"1px solid var(--border)",
                  borderLeft:`3px solid ${detailRatingColor}`,
                  borderRadius:9,
                  padding:"14px 18px",
                }}>
                  <div style={{ display:"flex", alignItems:"flex-start", justifyContent:"space-between", gap:12, marginBottom:10 }}>
                    <div style={{ fontFamily:"var(--serif)", fontSize:18, fontWeight:400, color:"var(--text)" }}>{selected.name}</div>
                    <button onClick={() => setSelectedId(null)} title="Close"
                      style={{ width:24, height:24, borderRadius:"50%", background:"transparent", border:"none", color:"var(--text4)", cursor:"pointer", fontSize:16, lineHeight:1, padding:0 }}>×</button>
                  </div>
                  <div style={{ display:"flex", gap:6, flexWrap:"wrap", marginBottom: selected.note ? 10 : 0 }}>
                    <span style={{ fontSize:10, fontWeight:700, letterSpacing:1, textTransform:"uppercase", padding:"3px 8px", borderRadius:5, color: sourceColor, background: sourceBg, fontFamily:"var(--sans)" }}>{sourceLabel}</span>
                    {selected.kind === "person" && selected.role && (
                      <span style={{ fontSize:10, fontWeight:600, letterSpacing:0.6, padding:"3px 8px", borderRadius:5, color:"var(--text3)", background:"var(--bg2)", border:"1px solid var(--border)", fontFamily:"var(--sans)" }}>{selected.role}</span>
                    )}
                    <span style={{ fontSize:10, fontWeight:700, letterSpacing:1, textTransform:"uppercase", padding:"3px 8px", borderRadius:5, color: ratingColor, background: ratingBg, fontFamily:"var(--sans)" }}>{selected.rating}</span>
                  </div>
                  {selected.note
                    ? <div style={{ fontFamily:"var(--sans)", fontSize:13, color:"var(--text2)", lineHeight:1.7 }}>{selected.note}</div>
                    : selected.kind === "person" && <div style={{ fontFamily:"var(--sans)", fontSize:12, color:"var(--text4)", fontStyle:"italic" }}>(no note)</div>
                  }
                </div>
              );
            })()}
          </div>
        </>
      )}

      {/* EMPTY STATE */}
      {items.length === 0 && (
        <div style={{ padding:"40px 30px", textAlign:"center", background:"var(--bg2)", border:"1px solid var(--border)", borderRadius:12, marginBottom:24 }}>
          <div style={{ fontFamily:"var(--serif)", fontSize:20, color:"var(--text2)", marginBottom:10, lineHeight:1.5 }}>
            Nothing to plot yet.
          </div>
          <div style={{ fontSize:13, color:"var(--text3)", lineHeight:1.7, maxWidth:420, marginLeft:"auto", marginRight:"auto", fontFamily:"var(--sans)" }}>
            Rate some items on the People or Environment pages first — they'll show up here arranged by how close you've kept them.
          </div>
        </div>
      )}

      {/* REFLECTION */}
      <div style={{ padding:"16px 20px", background:"rgba(201,168,76,.07)", borderLeft:`3px solid ${A3_AMBER}`, borderRadius:8, marginBottom:30 }}>
        <div style={{ fontSize:10, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color: A3_AMBER, marginBottom:8, fontFamily:"var(--sans)" }}>One thing to notice</div>
        <div style={{ fontFamily:"var(--sans)", fontSize:16, color:"var(--text2)", lineHeight:1.75 }}>{reflectionText}</div>
      </div>

      {/* STEP FOOTER */}
      <div style={{ marginTop:8, paddingTop:18, borderTop:"1px solid var(--border)", display:"flex", alignItems:"center", justifyContent:"space-between", gap:14 }}>
        <button onClick={() => setA3Step("thoughts")}
          style={{ padding:"8px 16px", fontSize:12, fontWeight:600, letterSpacing:0.5, fontFamily:"var(--sans)", background:"transparent", color:"var(--text2)", border:"1px solid var(--border)", borderRadius:999, cursor:"pointer" }}>
          ← Back to Thoughts
        </button>
        <div style={{ display:"flex", alignItems:"center", gap:14 }}>
          <span style={{ fontSize:12, color:"var(--text4)", fontFamily:"var(--sans)" }}>Next up · The Board</span>
          <button onClick={() => setA3Step("board")}
            style={{ padding:"9px 18px", fontSize:12, fontWeight:700, letterSpacing:0.5, fontFamily:"var(--sans)", background: A3_TEAL, color:"#0d1b2e", border:"none", borderRadius:999, cursor:"pointer" }}>
            Continue →
          </button>
        </div>
      </div>
    </div>
  );
}
function A3EnergyMapHorizontal({ setA3Step, map }: any) {
  const [selectedId, setSelectedId] = useState<string|null>(null);

  const buildPersonNote = (p: any) => {
    const parts = [p.action, p.how].filter((x: string) => x && x.trim());
    if (parts.length === 0) return "";
    const joined = parts.join(" · ");
    return /[.!?]$/.test(joined) ? joined : joined + ".";
  };

  const people = (map.a3_people || []).filter((p: any) => p.rating).map((p: any) => ({
    id: "p_" + p.id,
    name: p.name || "(unnamed)",
    kind: "person" as const,
    rating: p.rating,
    role: p.role || "",
    note: buildPersonNote(p),
    _x: 0, _y: 0,
  }));
  const envs = (map.a3_env_items || []).filter((e: any) => e.rating).map((e: any) => ({
    id: "e_" + e.id,
    name: e.name || "(unnamed)",
    kind: (e.kind === "place" ? "place" : "habit") as "habit" | "place",
    rating: e.rating,
    role: "",
    note: "",
    _x: 0, _y: 0,
  }));
  const items = [...people, ...envs];

  const advocates = items.filter(i => i.rating === "advocate");
  const neutrals  = items.filter(i => i.rating === "neutral");
  const anchors   = items.filter(i => i.rating === "anchor");

  const BAND_TOP = 110, BAND_BOTTOM = 320;
  const placeItemsInBand = (list: any[], xMin: number, xMax: number) => {
    const n = list.length;
    if (n === 0) return;
    const bandHeight = BAND_BOTTOM - BAND_TOP;
    const xRange = xMax - xMin;
    const rows = n <= 4 ? 1 : n <= 8 ? 2 : 3;
    const cols = Math.ceil(n / rows);
    const colW = xRange / Math.max(cols, 1);
    const rowH = bandHeight / (rows + 1);
    list.forEach((it, i) => {
      const row = Math.floor(i / cols);
      const col = i % cols;
      const baseX = xMin + colW * (col + 0.5);
      const baseY = BAND_TOP + rowH * (row + 1);
      const idHash = a3HashStr(it.id);
      const jitterX = ((idHash % 18) - 9);
      const jitterY = (((idHash * 11) % 24) - 12);
      it._x = baseX + jitterX;
      it._y = baseY + jitterY;
    });
  };
  placeItemsInBand(anchors,   60,  350);
  placeItemsInBand(neutrals,  400, 560);
  placeItemsInBand(advocates, 600, 880);

  const total = items.length;
  const advCount = advocates.length;
  const neuCount = neutrals.length;
  const ancCount = anchors.length;
  const advPct = total ? advCount / total : 0;
  const neuPct = total ? neuCount / total : 0;
  const ancPct = total ? ancCount / total : 0;

  const selected = items.find(i => i.id === selectedId) || null;
  const A3_NEU_HEX = "#9ca3af";

  // BAG popup state — matches A1 DirectionTimeline_v2 pattern
  const [directionPopupOpen, setDirectionPopupOpen] = useState(false);
  const directionPopupRef = useRef<HTMLDivElement>(null);
  const beaconRef = useRef<SVGGElement>(null);

  // BAG sentences — identical fallback chain to A1 DirectionTimeline_v2 (line 1163-1168)
  const bagTime   = map.time_overall_sentence   || map.time_summary   || map.bag_time_sentence   || map.growth_time_sentence   || "";
  const bagWealth = map.wealth_overall_sentence || map.wealth_summary || map.bag_wealth_sentence || map.growth_wealth_sentence || "";
  const bagGrowth = map.growth_sentence || map.growth_summary || "";
  const bagAllEmpty = !bagTime.trim() && !bagWealth.trim() && !bagGrowth.trim();

  useEffect(() => {
    if (!directionPopupOpen) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") setDirectionPopupOpen(false); };
    const onDown = (e: MouseEvent) => {
      const t = e.target as Node;
      if (directionPopupRef.current?.contains(t)) return;
      if (beaconRef.current?.contains(t)) return;
      setDirectionPopupOpen(false);
    };
    document.addEventListener("keydown", onKey);
    document.addEventListener("mousedown", onDown);
    return () => {
      document.removeEventListener("keydown", onKey);
      document.removeEventListener("mousedown", onDown);
    };
  }, [directionPopupOpen]);

  let reflectionText = "";
  if (total < 4) {
    reflectionText = "Look at the whole picture. Even with a few things named, the shape starts to show.";
  } else if (advPct >= 0.55 && ancPct <= 0.2) {
    reflectionText = "What's close to you is supporting the life you're building. Protect it on purpose.";
  } else if (ancPct >= 0.4) {
    reflectionText = "That's a lot sitting on the edge. What's one thing you'd set down this week if you could?";
  } else {
    reflectionText = "Look left, then right. Where's the weight?";
  }

  const renderItem = (it: any) => {
    const isSelected = it.id === selectedId;
    const size = isSelected ? 16 : 13;
    const fill = it.rating === "advocate" ? "rgba(93,202,165,.18)"
               : it.rating === "neutral"  ? "rgba(156,163,175,.15)"
               : "rgba(239,68,68,.1)";
    const stroke = it.rating === "advocate" ? A3_TEAL
                 : it.rating === "neutral"  ? A3_NEU_HEX
                 : A3_RED;
    const filterStyle = it.rating === "advocate" ? "drop-shadow(0 0 6px rgba(93,202,165,.4))"
                      : it.rating === "anchor"   ? "drop-shadow(0 0 4px rgba(239,68,68,.25))"
                      : undefined;
    const fontSize = isSelected ? 10 : 9;

    if (it.kind === "person") {
      return (
        <g key={it.id} onClick={() => setSelectedId(it.id)} style={{ cursor:"pointer", filter: filterStyle }}>
          <circle cx={it._x} cy={it._y} r={size} fill={fill} stroke={stroke} strokeWidth={1.5} />
          <text x={it._x} y={it._y + 3} textAnchor="middle" fontSize={fontSize} fontWeight={600} fill={stroke} fontFamily="var(--sans)" style={{ pointerEvents:"none", userSelect:"none" }}>
            {a3GetInitials(it.name)}
          </text>
        </g>
      );
    }
    const cx = it._x, cy = it._y, s = size;
    const points = `${cx},${cy - s} ${cx + s},${cy} ${cx},${cy + s} ${cx - s},${cy}`;
    const glyph = it.kind === "habit" ? "H" : "P";
    return (
      <g key={it.id} onClick={() => setSelectedId(it.id)} style={{ cursor:"pointer", filter: filterStyle }}>
        <polygon points={points} fill={fill} stroke={stroke} strokeWidth={1.5} />
        <text x={cx} y={cy + 3} textAnchor="middle" fontSize={fontSize} fontWeight={600} fill={stroke} fontFamily="var(--sans)" style={{ pointerEvents:"none", userSelect:"none" }}>
          {glyph}
        </text>
      </g>
    );
  };

  const detailRatingColor = selected
    ? (selected.rating === "advocate" ? A3_TEAL : selected.rating === "neutral" ? A3_NEU_HEX : A3_RED)
    : "var(--border)";

  return (
    <div>
      {/* BREADCRUMB + H1 + LEAD */}
      <div style={{ fontSize:11, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color: A3_TEAL, marginBottom:11 }}>A3 · Energy Map</div>
      <h2 style={{ fontFamily:"var(--serif)", fontSize:40, fontWeight:300, lineHeight:1.15, marginBottom:14, letterSpacing:"-0.5px" }}>
        Your external ecosystem, end to end.
      </h2>
      <p style={{ fontFamily:"var(--sans)", fontSize:15, color:"var(--text2)", lineHeight:1.85, marginBottom:24, maxWidth:660 }}>
        You're in the middle, heading forward. What's behind you pulls back. What's ahead pulls you toward where you said you were going.
      </p>

      {items.length > 0 && (
        <>
          {/* STATS GRID */}
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:12, marginBottom:22 }}>
            <div style={{ padding:"14px 16px", background:"var(--bg2)", border:`1px solid ${A3_TEAL}`, borderRadius:9 }}>
              <div style={{ fontFamily:"var(--serif)", fontSize:32, fontWeight:300, color: A3_TEAL, lineHeight:1, marginBottom:6 }}>{advCount}</div>
              <div style={{ fontSize:12, fontWeight:600, color:"var(--text)", fontFamily:"var(--sans)", marginBottom:2 }}>Close to you</div>
              <div style={{ fontSize:11, color:"var(--text4)", fontFamily:"var(--sans)" }}>{Math.round(advPct * 100)}% supporting you</div>
            </div>
            <div style={{ padding:"14px 16px", background:"var(--bg2)", border:`1px solid ${A3_NEU_HEX}`, borderRadius:9 }}>
              <div style={{ fontFamily:"var(--serif)", fontSize:32, fontWeight:300, color: A3_NEU_HEX, lineHeight:1, marginBottom:6 }}>{neuCount}</div>
              <div style={{ fontSize:12, fontWeight:600, color:"var(--text)", fontFamily:"var(--sans)", marginBottom:2 }}>Drifting</div>
              <div style={{ fontSize:11, color:"var(--text4)", fontFamily:"var(--sans)" }}>{Math.round(neuPct * 100)}% neither way</div>
            </div>
            <div style={{ padding:"14px 16px", background:"var(--bg2)", border:`1px solid ${A3_RED}`, borderRadius:9 }}>
              <div style={{ fontFamily:"var(--serif)", fontSize:32, fontWeight:300, color: A3_RED, lineHeight:1, marginBottom:6 }}>{ancCount}</div>
              <div style={{ fontSize:12, fontWeight:600, color:"var(--text)", fontFamily:"var(--sans)", marginBottom:2 }}>Still carrying</div>
              <div style={{ fontSize:11, color:"var(--text4)", fontFamily:"var(--sans)" }}>{Math.round(ancPct * 100)}% sitting on the edge</div>
            </div>
          </div>

          {/* LEGEND */}
          <div style={{ display:"flex", gap:18, flexWrap:"wrap", marginBottom:14, fontSize:11, fontFamily:"var(--sans)", color:"var(--text3)" }}>
            <span><span style={{ color: A3_TEAL, fontSize:13 }}>●</span> People · advocate</span>
            <span><span style={{ color: A3_RED, fontSize:13 }}>●</span> People · anchor</span>
            <span><span style={{ color: A3_TEAL, fontSize:13 }}>◆</span> Environment · advocate</span>
            <span><span style={{ color: A3_RED, fontSize:13 }}>◆</span> Environment · anchor</span>
          </div>

          {/* JOURNEY CONTAINER */}
          <div style={{ background:"var(--bg2)", border:"1px solid var(--border)", borderRadius:12, padding:"22px 24px", marginBottom:24, position:"relative" }}>
            <div style={{ fontFamily:"var(--serif)", fontSize:18, fontWeight:400, color:"var(--text)", marginBottom:4 }}>The Horizon</div>
            <div style={{ fontSize:12, color:"var(--text4)", fontFamily:"var(--sans)", marginBottom:14, lineHeight:1.6 }}>
              Anchors behind. Neutrals drifting. Advocates ahead. Your direction at the edge.
            </div>

            <svg viewBox="0 0 960 420" style={{ display:"block", width:"100%", maxWidth:960, margin:"0 auto", height:"auto" }}>
              <defs>
                <linearGradient id="journeyBg" x1="0%" x2="100%" y1="0%" y2="0%">
                  <stop offset="0%"   stopColor="rgba(239,68,68,.04)" />
                  <stop offset="30%"  stopColor="rgba(30,53,84,.3)" />
                  <stop offset="60%"  stopColor="rgba(93,202,165,.04)" />
                  <stop offset="100%" stopColor="rgba(201,168,76,.1)" />
                </linearGradient>
                <radialGradient id="selfGlow" cx="50%" cy="50%" r="50%">
                  <stop offset="0%"   stopColor="rgba(201,168,76,.35)" />
                  <stop offset="100%" stopColor="rgba(201,168,76,0)" />
                </radialGradient>
                <radialGradient id="beaconGlow" cx="50%" cy="50%" r="50%">
                  <stop offset="0%"   stopColor="rgba(201,168,76,.45)" />
                  <stop offset="50%"  stopColor="rgba(201,168,76,.15)" />
                  <stop offset="100%" stopColor="rgba(201,168,76,0)" />
                </radialGradient>
              </defs>

              <rect x={0} y={0} width={960} height={420} rx={10} fill="url(#journeyBg)" />

              {/* Horizon line */}
              <line x1={30} y1={210} x2={930} y2={210} stroke="rgba(244,241,235,.22)" strokeWidth={1.5} strokeDasharray="5 7" />

              {/* Top zone labels */}
              <text x={65}  y={40} fontSize={10} fontWeight={700} letterSpacing={2} fill="rgba(239,68,68,.55)"  fontFamily="var(--sans)">← PULLING YOU BACK</text>
              <text x={480} y={40} fontSize={10} fontWeight={700} letterSpacing={2} fill="rgba(244,241,235,.35)" fontFamily="var(--sans)" textAnchor="middle">YOU ARE HERE</text>
              <text x={875} y={40} fontSize={10} fontWeight={700} letterSpacing={2} fill="rgba(93,202,165,.6)"   fontFamily="var(--sans)" textAnchor="end">PULLING YOU FORWARD →</text>

              {/* Bottom faint labels */}
              <text x={205} y={404} fontSize={9} fontStyle="italic" fill="rgba(239,68,68,.35)"  fontFamily="var(--sans)" textAnchor="middle">weight behind</text>
              <text x={740} y={404} fontSize={9} fontStyle="italic" fill="rgba(93,202,165,.4)"  fontFamily="var(--sans)" textAnchor="middle">wind ahead</text>

              {/* Beacon — clickable, opens BAG popup */}
              <g ref={beaconRef}
                 onClick={(e) => { e.stopPropagation(); setDirectionPopupOpen(o => !o); }}
                 style={{ cursor:"pointer" }}>
                <circle cx={932} cy={210} r={60} fill="url(#beaconGlow)" />
                <circle cx={932} cy={210} r={10} fill="rgba(201,168,76,.55)" />
                <circle cx={932} cy={210} r={4}  fill={A3_AMBER} />
                <text x={922} y={184} fontSize={9} fontWeight={700} letterSpacing={1.5} fill="rgba(201,168,76,.7)" fontFamily="var(--sans)" textAnchor="end">DIRECTION</text>
              </g>

              {/* "you" marker at center */}
              <circle cx={480} cy={210} r={44} fill="url(#selfGlow)" />
              <circle cx={480} cy={210} r={24} fill="transparent" stroke={A3_AMBER} strokeOpacity={0.55} strokeWidth={1.5} />
              <text x={480} y={215} fontSize={11} fill="var(--text2)" fontFamily="var(--serif)" fontStyle="italic" textAnchor="middle">you</text>

              {/* Items */}
              {items.map(renderItem)}
            </svg>

            {/* BAG DIRECTION POPUP — anchored to wrap card via position:absolute */}
            {directionPopupOpen && (
              <div ref={directionPopupRef}
                onClick={(e) => e.stopPropagation()}
                style={{
                  position:"absolute", right:70, top:150, maxWidth:340, zIndex:20,
                  background:"rgba(13,27,46,.97)",
                  border:"1px solid rgba(201,168,76,.4)",
                  borderRadius:8,
                  padding:"14px 16px",
                  boxShadow:"0 12px 36px rgba(0,0,0,.5)",
                }}>
                <div style={{
                  position:"absolute", right:-9, top:48, width:0, height:0,
                  borderTop:"8px solid transparent",
                  borderBottom:"8px solid transparent",
                  borderLeft:"9px solid rgba(201,168,76,.4)",
                }} />
                <div style={{
                  position:"absolute", right:-7, top:49, width:0, height:0,
                  borderTop:"7px solid transparent",
                  borderBottom:"7px solid transparent",
                  borderLeft:"8px solid rgba(13,27,46,.97)",
                }} />

                <div style={{ display:"flex", alignItems:"baseline", gap:10, marginBottom: bagAllEmpty ? 6 : 12 }}>
                  <span style={{ fontFamily:"var(--sans)", fontSize:10, letterSpacing:2, textTransform:"uppercase", fontWeight:700, color:"var(--warm)" }}>Direction · BAG</span>
                  <span style={{ fontSize:10, color:"var(--text4)", marginLeft:"auto", cursor:"pointer", padding:"2px 4px" }}
                        onClick={() => setDirectionPopupOpen(false)}>✕ close</span>
                </div>

                {bagAllEmpty ? (
                  <div style={{ fontFamily:"var(--serif)", fontSize:13, fontStyle:"italic", color:"var(--text3)", lineHeight:1.6, padding:"4px 0" }}>
                    Set your direction in A1 to see your BAG here.
                  </div>
                ) : (
                  <>
                    {[
                      { label: "Time",   text: bagTime,   color: "var(--warm)" },
                      { label: "Wealth", text: bagWealth, color: "#34d399" },
                      { label: "Growth", text: bagGrowth, color: "#a78bfa" },
                    ].map(row => (
                      <div key={row.label} style={{ display:"grid", gridTemplateColumns:"56px 1fr", gap:10, alignItems:"start", marginBottom:8 }}>
                        <span style={{ fontSize:9, color:"var(--text3)", letterSpacing:1.2, textTransform:"uppercase", fontWeight:600, paddingTop:6 }}>{row.label}</span>
                        <div style={{ minWidth:0 }}>
                          {row.text && row.text.trim() ? (
                            <div style={{
                              fontFamily:"var(--serif)", fontSize:13, lineHeight:1.6, fontStyle:"italic",
                              padding:"6px 11px", borderRadius:4,
                              background:"rgba(0,0,0,.25)", borderLeft:`2px solid ${row.color}`,
                              color:"var(--text)",
                            }}>"{row.text}"</div>
                          ) : (
                            <div style={{ fontSize:11, color:"var(--text4)", fontStyle:"italic", padding:"6px 11px" }}>
                              — not set yet —
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </>
                )}
              </div>
            )}

            {/* DETAIL CARD */}
            {selected && (() => {
              const sourceLabel = selected.kind === "person" ? "People"
                                : selected.kind === "habit"  ? "Habit"
                                : "Place";
              const sourceColor = selected.kind === "person" ? A3_TEAL : A3_AMBER;
              const sourceBg    = selected.kind === "person" ? "rgba(93,202,165,.12)" : "rgba(201,168,76,.12)";
              const ratingColor = selected.rating === "advocate" ? A3_TEAL : selected.rating === "neutral" ? A3_NEU_HEX : A3_RED;
              const ratingBg    = selected.rating === "advocate" ? "rgba(93,202,165,.15)" : selected.rating === "neutral" ? "rgba(156,163,175,.15)" : "rgba(239,68,68,.12)";
              return (
                <div style={{
                  marginTop:18,
                  background:"var(--bg)",
                  border:"1px solid var(--border)",
                  borderLeft:`3px solid ${detailRatingColor}`,
                  borderRadius:9,
                  padding:"14px 18px",
                }}>
                  <div style={{ display:"flex", alignItems:"flex-start", justifyContent:"space-between", gap:12, marginBottom:10 }}>
                    <div style={{ fontFamily:"var(--serif)", fontSize:18, fontWeight:400, color:"var(--text)" }}>{selected.name}</div>
                    <button onClick={() => setSelectedId(null)} title="Close"
                      style={{ width:24, height:24, borderRadius:"50%", background:"transparent", border:"none", color:"var(--text4)", cursor:"pointer", fontSize:16, lineHeight:1, padding:0 }}>×</button>
                  </div>
                  <div style={{ display:"flex", gap:6, flexWrap:"wrap", marginBottom: selected.note ? 10 : 0 }}>
                    <span style={{ fontSize:10, fontWeight:700, letterSpacing:1, textTransform:"uppercase", padding:"3px 8px", borderRadius:5, color: sourceColor, background: sourceBg, fontFamily:"var(--sans)" }}>{sourceLabel}</span>
                    {selected.kind === "person" && selected.role && (
                      <span style={{ fontSize:10, fontWeight:600, letterSpacing:0.6, padding:"3px 8px", borderRadius:5, color:"var(--text3)", background:"var(--bg2)", border:"1px solid var(--border)", fontFamily:"var(--sans)" }}>{selected.role}</span>
                    )}
                    <span style={{ fontSize:10, fontWeight:700, letterSpacing:1, textTransform:"uppercase", padding:"3px 8px", borderRadius:5, color: ratingColor, background: ratingBg, fontFamily:"var(--sans)" }}>{selected.rating}</span>
                  </div>
                  {selected.note
                    ? <div style={{ fontFamily:"var(--sans)", fontSize:13, color:"var(--text2)", lineHeight:1.7 }}>{selected.note}</div>
                    : selected.kind === "person" && <div style={{ fontFamily:"var(--sans)", fontSize:12, color:"var(--text4)", fontStyle:"italic" }}>(no note)</div>
                  }
                </div>
              );
            })()}
          </div>
        </>
      )}

      {/* EMPTY STATE */}
      {items.length === 0 && (
        <div style={{ padding:"40px 30px", textAlign:"center", background:"var(--bg2)", border:"1px solid var(--border)", borderRadius:12, marginBottom:24 }}>
          <div style={{ fontFamily:"var(--serif)", fontSize:20, color:"var(--text2)", marginBottom:10, lineHeight:1.5 }}>
            Nothing to plot yet.
          </div>
          <div style={{ fontSize:13, color:"var(--text3)", lineHeight:1.7, maxWidth:420, marginLeft:"auto", marginRight:"auto", fontFamily:"var(--sans)" }}>
            Rate some items on the People or Environment pages first — they'll show up here arranged by how close you've kept them.
          </div>
        </div>
      )}

      {/* REFLECTION */}
      <div style={{ padding:"16px 20px", background:"rgba(201,168,76,.07)", borderLeft:`3px solid ${A3_AMBER}`, borderRadius:8, marginBottom:30 }}>
        <div style={{ fontSize:10, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color: A3_AMBER, marginBottom:8, fontFamily:"var(--sans)" }}>One thing to notice</div>
        <div style={{ fontFamily:"var(--sans)", fontSize:16, color:"var(--text2)", lineHeight:1.75 }}>{reflectionText}</div>
      </div>

      {/* STEP FOOTER */}
      <div style={{ marginTop:8, paddingTop:18, borderTop:"1px solid var(--border)", display:"flex", alignItems:"center", justifyContent:"space-between", gap:14 }}>
        <button onClick={() => setA3Step("thoughts")}
          style={{ padding:"8px 16px", fontSize:12, fontWeight:600, letterSpacing:0.5, fontFamily:"var(--sans)", background:"transparent", color:"var(--text2)", border:"1px solid var(--border)", borderRadius:999, cursor:"pointer" }}>
          ← Back to Thoughts
        </button>
        <div style={{ display:"flex", alignItems:"center", gap:14 }}>
          <span style={{ fontSize:12, color:"var(--text4)", fontFamily:"var(--sans)" }}>Next up · The Board</span>
          <button onClick={() => setA3Step("board")}
            style={{ padding:"9px 18px", fontSize:12, fontWeight:700, letterSpacing:0.5, fontFamily:"var(--sans)", background: A3_TEAL, color:"#0d1b2e", border:"none", borderRadius:999, cursor:"pointer" }}>
            Continue →
          </button>
        </div>
      </div>
    </div>
  );
}
function A3BoardStub({ setA3Step, map, set }: any) {
  const uuid = () => (typeof crypto !== "undefined" && (crypto as any).randomUUID) ? (crypto as any).randomUUID() : String(Date.now()) + Math.random();

  const A3_TEAL = "#5DCAA5";
  const A3_TEAL_DEEP = "#0f4f41";
  const A3_AMBER = "#c9a84c";
  const A3_AMBER_DEEP = "#2a1f16";
  const A3_GREY_MUTED = "#9a9590";
  const A3_BG = "#0d1b2e";
  const A3_BORDER = "#254060";

  const userName: string = ((map?.name || "") as string).trim();
  const boardTitle = userName ? `${userName}'s Board` : "Your Board";

  const people: any[] = map?.a3_people || [];
  const advocates = people.filter((p: any) => p.rating === "advocate" && p.onBoard === "yes");
  const existingCands: any[] = map?.a3_board_candidates || [];
  const missing: any[] = map?.a3_board_missing || [];

  // Sync candidates with advocates by personId
  const byPersonId = new Map(existingCands.map((c: any) => [c.personId, c]));
  const synced = advocates.map((p: any) => byPersonId.get(p.id) || {
    id: uuid(), personId: p.id, strengths: [], primary: "", seatName: "", why: "",
  });
  const syncSig = synced.map((c: any) => c.personId).join("|");
  const existingSig = existingCands.map((c: any) => c.personId).join("|");
  useEffect(() => {
    if (syncSig !== existingSig) set("a3_board_candidates", synced);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [syncSig, existingSig]);

  const candidates: any[] = syncSig === existingSig ? existingCands : synced;

  // Local UI state
  const [advSectionOpen, setAdvSectionOpen] = useState(true);
  const [missSectionOpen, setMissSectionOpen] = useState(true);
  const [openCandidateId, setOpenCandidateId] = useState<string | null>(null);
  const [otherEditingId, setOtherEditingId] = useState<string | null>(null);
  const [otherDraft, setOtherDraft] = useState("");

  const personById = new Map(people.map((p: any) => [p.id, p]));

  const updateCandidate = (id: string, patch: any) => {
    set("a3_board_candidates", candidates.map((c: any) => c.id === id ? { ...c, ...patch } : c));
  };
  const isLocked = (s: string) => A3_BOARD_STRENGTHS.includes(s);

  const toggleStrength = (cand: any, s: string) => {
    const has = cand.strengths.includes(s);
    if (!has) {
      const newStrengths = [...cand.strengths, s];
      const patch: any = { strengths: newStrengths };
      if (!cand.primary) {
        patch.primary = s;
        if (!cand.seatName) patch.seatName = "The " + s;
      }
      updateCandidate(cand.id, patch);
    } else if (cand.primary !== s) {
      const patch: any = { primary: s };
      if (!cand.seatName || cand.seatName === ("The " + cand.primary)) {
        patch.seatName = "The " + s;
      }
      updateCandidate(cand.id, patch);
    } else {
      const newStrengths = cand.strengths.filter((x: string) => x !== s);
      const patch: any = { strengths: newStrengths };
      if (newStrengths.length > 0) {
        patch.primary = newStrengths[0];
        if (!cand.seatName || cand.seatName === ("The " + cand.primary)) {
          patch.seatName = "The " + newStrengths[0];
        }
      } else {
        patch.primary = "";
        patch.seatName = "";
      }
      updateCandidate(cand.id, patch);
    }
  };

  const customStrengthOf = (cand: any): string =>
    cand.strengths.find((s: string) => !isLocked(s)) || "";

  const commitOther = (cand: any) => {
    const val = otherDraft.trim();
    setOtherEditingId(null);
    setOtherDraft("");
    if (!val) return;
    const existingCustom = customStrengthOf(cand);
    let newStrengths = cand.strengths.filter((s: string) => s !== existingCustom);
    newStrengths = [...newStrengths, val];
    const patch: any = { strengths: newStrengths };
    if (cand.primary === existingCustom || !cand.primary) {
      patch.primary = val;
      if (!cand.seatName || cand.seatName === ("The " + (cand.primary || existingCustom))) {
        patch.seatName = "The " + val;
      }
    }
    updateCandidate(cand.id, patch);
  };

  // Missing seats
  const updateMissing = (id: string, patch: any) => {
    set("a3_board_missing", missing.map((m: any) => m.id === id ? { ...m, ...patch } : m));
  };
  const removeMissing = (id: string) => set("a3_board_missing", missing.filter((m: any) => m.id !== id));
  const addMissing = () => set("a3_board_missing", [...missing, { id: uuid(), title: "", note: "" }]);

  // Build occupants for SVG
  const seatedCands = candidates.filter((c: any) => c.primary && c.seatName);
  const namedMissing = missing.filter((m: any) => (m.title || "").trim());
  const occupants: any[] = [
    ...seatedCands.map((c: any) => {
      const p = personById.get(c.personId);
      return { kind: "person", name: p?.name || "(unnamed)", title: c.seatName };
    }),
    ...namedMissing.map((m: any) => ({ kind: "missing", name: "", title: m.title })),
  ].slice(0, 12);

  const filledCount = occupants.length;

  // SVG geometry
  const cx = 320, cy = 210, tableRx = 180, tableRy = 95;
  const ringRx = tableRx + 42, ringRy = tableRy + 48;
  const labelRx = ringRx + 48, labelRy = ringRy + 46;

  const initialsOf = (name: string) => {
    const parts = (name || "").trim().split(/\s+/).filter(Boolean);
    if (parts.length === 0) return "?";
    if (parts.length === 1) return parts[0][0].toUpperCase();
    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
  };

  const sectionHeader = (label: string, count: string, open: boolean, toggle: () => void) => (
    <button onClick={toggle} style={{
      width: "100%", display: "flex", alignItems: "center", gap: 10,
      background: "transparent", border: "none", padding: "14px 0",
      borderTop: "1px solid var(--border)", cursor: "pointer",
      textAlign: "left", color: "var(--text)",
    }}>
      <span style={{ fontFamily: "var(--serif)", fontSize: 22, fontWeight: 400 }}>{label}</span>
      <span style={{ fontFamily: "var(--sans)", fontSize: 11, color: "var(--text4)", letterSpacing: 0.5 }}>· {count}</span>
      <span style={{ marginLeft: "auto", color: "var(--text4)", fontSize: 14, transform: open ? "rotate(180deg)" : "none", transition: "transform .2s" }}>▾</span>
    </button>
  );

  return (
    <div>
      <div style={{ fontSize:11, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color: A3_TEAL, marginBottom:11 }}>A3 · The Board</div>
      <h2 style={{ fontFamily:"var(--serif)", fontSize:40, fontWeight:300, lineHeight:1.2, marginBottom:13, letterSpacing:"-0.5px" }}>Build your table.</h2>
      <p style={{ fontFamily:"var(--sans)", fontSize:15, color:"var(--text2)", lineHeight:1.85, marginBottom:24, maxWidth:620 }}>
        You named the people who advocate for you. Now you decide their seats — and see what's missing.
      </p>

      {/* Framing card */}
      <div style={{ background:"var(--bg2)", border:"1px solid var(--border)", borderLeft:`3px solid ${A3_TEAL}`, borderRadius:10, padding:"18px 22px", marginBottom:26 }}>
        <div style={{ fontSize:10, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color: A3_TEAL, marginBottom:8, fontFamily:"var(--sans)" }}>What is your Board?</div>
        <div style={{ fontFamily:"var(--serif)", fontSize:22, fontWeight:400, color:"var(--text)", lineHeight:1.4, marginBottom:12 }}>
          A tight-knit group whose job is to <span style={{ color: A3_TEAL, fontWeight:600 }}>advocate for you</span> as you move forward.
        </div>
        <p style={{ fontFamily:"var(--sans)", fontSize:13, color:"var(--text2)", lineHeight:1.75, marginBottom:10 }}>
          They're not your friends list. They're not everyone who loves you. They're the <span style={{ color: A3_TEAL, fontWeight:600 }}>specific people you trust enough to seek counsel from</span> when it matters.
        </p>
        <p style={{ fontFamily:"var(--sans)", fontSize:13, color:"var(--text2)", lineHeight:1.75, marginBottom:10 }}>
          A great Board has variety. Someone who listens. Someone who challenges. Someone who tells you the truth when you don't want to hear it. <span style={{ color: A3_TEAL, fontWeight:600 }}>Each seat serves a different purpose.</span>
        </p>
        <p style={{ fontFamily:"var(--sans)", fontSize:13, color:"var(--text2)", lineHeight:1.75 }}>
          Up to 12 seats. You don't have to fill them all — <span style={{ color: A3_TEAL, fontWeight:600 }}>empty seats are information too.</span>
        </p>
      </div>

      {/* Table visual */}
      <div style={{ background: A3_BG, border: `1px solid ${A3_BORDER}`, borderRadius: 12, padding: "20px 22px", marginBottom: 26 }}>
        <div style={{ display:"flex", alignItems:"baseline", justifyContent:"space-between", marginBottom: 12 }}>
          <div style={{ fontFamily:"var(--serif)", fontSize:18, fontWeight:400, color:"var(--text)" }}>Your Board · 12 seats</div>
          <div style={{ display:"flex", alignItems:"baseline", gap:8 }}>
            <span style={{ fontFamily:"var(--serif)", fontSize:28, fontWeight:300, color: A3_TEAL }}>{filledCount}</span>
            <span style={{ fontFamily:"var(--sans)", fontSize:10, fontWeight:700, letterSpacing:1.5, textTransform:"uppercase", color:"var(--text4)" }}>of 12 seats filled</span>
          </div>
        </div>

        <svg viewBox="0 0 640 420" style={{ display:"block", width:"100%", maxWidth:640, margin:"0 auto", height:"auto" }}>
          <defs>
            <radialGradient id="tableGrad" cx="50%" cy="50%" r="60%">
              <stop offset="0%" stopColor="#1a2f4a" />
              <stop offset="100%" stopColor="#0d1b2e" />
            </radialGradient>
          </defs>

          {/* Table */}
          <ellipse cx={cx} cy={cy} rx={tableRx} ry={tableRy} fill="url(#tableGrad)" stroke={A3_BORDER} strokeWidth={1.5} />
          <ellipse cx={cx} cy={cy} rx={tableRx - 14} ry={tableRy - 14} fill="none" stroke="#1e3554" strokeWidth={1} strokeDasharray="3 5" opacity={0.6} />

          <text x={cx} y={cy - 2} textAnchor="middle" fontFamily="var(--serif)" fontSize={20} fontStyle="italic" fill={A3_AMBER}>{boardTitle}</text>
          <text x={cx} y={cy + 22} textAnchor="middle" fontFamily="var(--sans)" fontSize={10} letterSpacing={2} fill={A3_GREY_MUTED}>{filledCount} / 12 SEATS</text>

          {/* 12 chairs */}
          {Array.from({ length: 12 }).map((_, i) => {
            const a = -Math.PI / 2 + i * (2 * Math.PI / 12);
            const ca = Math.cos(a), sa = Math.sin(a);
            const x = cx + ringRx * ca;
            const y = cy + ringRy * sa;
            const occ = occupants[i];
            const lx = cx + labelRx * ca;
            const ly = cy + labelRy * sa;
            const anchor = Math.abs(ca) < 0.3 ? "middle" : (ca > 0 ? "start" : "end");

            let fill = A3_BG, stroke = A3_BORDER;
            if (occ?.kind === "person") { fill = A3_TEAL_DEEP; stroke = A3_TEAL; }
            else if (occ?.kind === "missing") { fill = A3_AMBER_DEEP; stroke = A3_AMBER; }

            return (
              <g key={i}>
                <circle cx={x} cy={y} r={26} fill={fill} stroke={stroke} strokeWidth={1.5} />
                {!occ && (
                  <text x={x} y={y + 4} textAnchor="middle" fontFamily="var(--serif)" fontSize={12} fontStyle="italic" fill={A3_GREY_MUTED}>{i + 1}</text>
                )}
                {occ?.kind === "person" && (
                  <text x={x} y={y + 5} textAnchor="middle" fontFamily="var(--sans)" fontSize={13} fontWeight={600} fill={A3_TEAL}>{initialsOf(occ.name)}</text>
                )}
                {occ?.kind === "missing" && (
                  <text x={x} y={y + 6} textAnchor="middle" fontFamily="var(--serif)" fontSize={16} fill={A3_AMBER}>◇</text>
                )}
                {occ?.kind === "person" && (
                  <>
                    <text x={lx} y={ly - 4} textAnchor={anchor} fontFamily="var(--serif)" fontSize={12} fontStyle="italic" fill={A3_TEAL}>{occ.title}</text>
                    <text x={lx} y={ly + 10} textAnchor={anchor} fontFamily="var(--sans)" fontSize={10} fill={A3_GREY_MUTED}>{occ.name}</text>
                  </>
                )}
                {occ?.kind === "missing" && (
                  <>
                    <text x={lx} y={ly - 4} textAnchor={anchor} fontFamily="var(--serif)" fontSize={12} fontStyle="italic" fill={A3_AMBER}>{occ.title}</text>
                    <text x={lx} y={ly + 10} textAnchor={anchor} fontFamily="var(--sans)" fontSize={10} fill="rgba(201,168,76,.55)">gap</text>
                  </>
                )}
              </g>
            );
          })}
        </svg>
      </div>

      {/* Advocates section */}
      {sectionHeader("Your Advocates", `${seatedCands.length} of ${candidates.length} seated`, advSectionOpen, () => setAdvSectionOpen(o => !o))}
      {advSectionOpen && (
        <div style={{ marginBottom: 28 }}>
          <p style={{ fontFamily:"var(--sans)", fontSize:13, color:"var(--text3)", lineHeight:1.7, marginBottom: 14, marginTop: 4 }}>
            Everyone you marked as an Advocate + Yes to the Board on the previous page. Click to give them their seat.
          </p>
          {candidates.length === 0 ? (
            <div style={{ background:"var(--bg2)", border:"1px solid var(--border)", borderRadius:10, padding:"22px 24px" }}>
              <div style={{ fontFamily:"var(--serif)", fontSize:18, color:"var(--text2)", marginBottom:8 }}>No one on your Board yet.</div>
              <div style={{ fontFamily:"var(--sans)", fontSize:13, color:"var(--text3)", lineHeight:1.7 }}>
                Head back to the People page and mark at least one Advocate "Yes" for the Board.
              </div>
            </div>
          ) : candidates.map((cand: any) => {
            const p = personById.get(cand.personId);
            const isOpen = openCandidateId === cand.id;
            const seated = !!(cand.primary && cand.seatName);
            const customStr = customStrengthOf(cand);
            const editingOther = otherEditingId === cand.id;

            return (
              <div key={cand.id} style={{
                background:"var(--bg2)",
                border:"1px solid var(--border)",
                borderLeft: seated ? `3px solid ${A3_TEAL}` : "1px solid var(--border)",
                borderRadius:10, padding:"14px 18px", marginBottom: 10,
              }}>
                <button onClick={() => setOpenCandidateId(isOpen ? null : cand.id)} style={{
                  width:"100%", display:"flex", alignItems:"center", gap:14,
                  background:"transparent", border:"none", padding:0, cursor:"pointer", textAlign:"left", color:"var(--text)",
                }}>
                  <div style={{ flex:1, minWidth:0 }}>
                    <div style={{ fontFamily:"var(--serif)", fontSize:17, color:"var(--text)" }}>{p?.name || "(unnamed)"}</div>
                    {p?.role && (
                      <div style={{ fontSize:10, fontWeight:600, letterSpacing:1.2, textTransform:"uppercase", color:"var(--text4)", marginTop:3, fontFamily:"var(--sans)" }}>{p.role}</div>
                    )}
                  </div>
                  <div style={{ textAlign:"right" }}>
                    {seated
                      ? <div style={{ fontFamily:"var(--serif)", fontSize:14, fontStyle:"italic", color: A3_TEAL }}>{cand.seatName}</div>
                      : <div style={{ fontSize:12, fontStyle:"italic", color:"var(--text4)", fontFamily:"var(--sans)" }}>No seat yet</div>}
                  </div>
                  <span style={{ color:"var(--text4)", fontSize:14, transform: isOpen ? "rotate(180deg)" : "none", transition:"transform .2s" }}>▾</span>
                </button>

                {isOpen && (
                  <div style={{ marginTop:14, paddingTop:14, borderTop:"1px solid var(--border)" }}>
                    <div style={{ fontSize:10, fontWeight:700, letterSpacing:1.5, textTransform:"uppercase", color:"var(--text3)", marginBottom:10, fontFamily:"var(--sans)" }}>
                      Their strengths · pick all that apply
                    </div>
                    <div style={{ display:"flex", flexWrap:"wrap", gap:6, marginBottom:10 }}>
                      {A3_BOARD_STRENGTHS.map(s => {
                        const isSelected = cand.strengths.includes(s);
                        const isPrimary = cand.primary === s;
                        let bg = "transparent", color = "var(--text3)", border = "1px solid var(--border)";
                        if (isPrimary) { bg = A3_TEAL; color = "#0a1f1a"; border = `1px solid ${A3_TEAL}`; }
                        else if (isSelected) { bg = "rgba(93,202,165,.15)"; color = A3_TEAL; border = `1px solid rgba(93,202,165,.4)`; }
                        return (
                          <button key={s} onClick={() => toggleStrength(cand, s)} style={{
                            background: bg, color, border, borderRadius: 999, padding:"5px 11px",
                            fontSize:11, fontWeight: isPrimary ? 700 : 500, cursor:"pointer", fontFamily:"var(--sans)",
                          }}>
                            {isPrimary ? "★ " : ""}{s}
                          </button>
                        );
                      })}
                      {/* Other chip */}
                      {editingOther ? (
                        <input
                          autoFocus
                          value={otherDraft}
                          onChange={(e) => setOtherDraft(e.target.value)}
                          onBlur={() => commitOther(cand)}
                          onKeyDown={(e) => {
                            if (e.key === "Enter") { e.preventDefault(); commitOther(cand); }
                            if (e.key === "Escape") { setOtherEditingId(null); setOtherDraft(""); }
                          }}
                          placeholder="Type a strength…"
                          style={{
                            background:"var(--bg)", color:"var(--text)", border:`1px solid ${A3_TEAL}`,
                            borderRadius:999, padding:"5px 11px", fontSize:11, fontFamily:"var(--sans)", outline:"none", minWidth:140,
                          }}
                        />
                      ) : (() => {
                        const isSelected = !!customStr;
                        const isPrimary = isSelected && cand.primary === customStr;
                        let bg = "transparent", color = "var(--text3)", border = "1px solid var(--border)";
                        if (isPrimary) { bg = A3_TEAL; color = "#0a1f1a"; border = `1px solid ${A3_TEAL}`; }
                        else if (isSelected) { bg = "rgba(93,202,165,.15)"; color = A3_TEAL; border = `1px solid rgba(93,202,165,.4)`; }
                        return (
                          <button onClick={() => {
                            if (isSelected && !isPrimary) {
                              // promote to primary
                              const patch: any = { primary: customStr };
                              if (!cand.seatName || cand.seatName === ("The " + cand.primary)) patch.seatName = "The " + customStr;
                              updateCandidate(cand.id, patch);
                            } else {
                              setOtherEditingId(cand.id);
                              setOtherDraft(customStr || "");
                            }
                          }} style={{
                            background: bg, color, border, borderRadius: 999, padding:"5px 11px",
                            fontSize:11, fontWeight: isPrimary ? 700 : 500, cursor:"pointer", fontFamily:"var(--sans)", fontStyle: customStr ? "normal" : "italic",
                          }}>
                            {isPrimary ? "★ " : ""}{customStr || "Other…"}
                          </button>
                        );
                      })()}
                    </div>

                    <div style={{ fontSize:11, color:"var(--text4)", fontStyle:"italic", marginBottom: cand.primary ? 16 : 0, fontFamily:"var(--sans)" }}>
                      {cand.strengths.length === 0 && "Pick at least one strength. The first becomes their seat — click another to change it."}
                      {cand.strengths.length === 1 && "Click another strength to add it. Click the ★ strength again to remove it."}
                      {cand.strengths.length >= 2 && "Click a selected strength to make it their primary (★). That becomes their seat."}
                    </div>

                    {cand.primary && (
                      <>
                        <div style={{ marginTop:6 }}>
                          <div style={{ fontSize:10, fontWeight:700, letterSpacing:1.5, textTransform:"uppercase", color:"var(--text3)", marginBottom:6, fontFamily:"var(--sans)" }}>
                            Their seat at the table
                          </div>
                          <input
                            value={cand.seatName}
                            placeholder={"The " + cand.primary}
                            onChange={(e) => updateCandidate(cand.id, { seatName: e.target.value })}
                            style={{
                              width:"100%", background:"var(--bg)", color:"var(--text)",
                              border:"1px solid var(--border)", borderRadius:8, padding:"9px 12px",
                              fontFamily:"var(--serif)", fontSize:14, fontStyle:"italic", outline:"none",
                            }}
                          />
                        </div>
                        <div style={{ marginTop:14 }}>
                          <div style={{ fontSize:10, fontWeight:700, letterSpacing:1.5, textTransform:"uppercase", color:"var(--text3)", marginBottom:6, fontFamily:"var(--sans)" }}>
                            Why this seat? <span style={{ color:"var(--text4)", fontWeight:400, fontStyle:"italic", textTransform:"none", letterSpacing:0 }}>optional</span>
                          </div>
                          <textarea
                            value={cand.why || ""}
                            placeholder="What does this person bring that no one else does?"
                            onChange={(e) => updateCandidate(cand.id, { why: e.target.value })}
                            rows={2}
                            style={{
                              width:"100%", background:"var(--bg)", color:"var(--text)",
                              border:"1px solid var(--border)", borderRadius:8, padding:"9px 12px",
                              fontFamily:"var(--sans)", fontSize:13, lineHeight:1.6, outline:"none", resize:"vertical",
                            }}
                          />
                        </div>
                      </>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Missing seats section */}
      {sectionHeader("What's missing from your table?", `${missing.length} named`, missSectionOpen, () => setMissSectionOpen(o => !o))}
      {missSectionOpen && (
        <div style={{ marginBottom: 28 }}>
          <p style={{ fontFamily:"var(--sans)", fontSize:13, color:"var(--text3)", lineHeight:1.7, marginBottom: 14, marginTop: 4 }}>
            The seats you know you need but haven't filled yet. A workout partner. A peer in your industry. Someone who challenges you spiritually. Name the gap — we'll help you find the person later.
          </p>

          {missing.map((m: any) => (
            <div key={m.id} style={{
              background:"var(--bg2)", border:"1px solid var(--border)",
              borderLeft: (m.title || "").trim() ? `3px solid ${A3_AMBER}` : "1px solid var(--border)",
              borderRadius:10, padding:"12px 14px", marginBottom:8,
              display:"grid", gridTemplateColumns:"1fr 1fr auto", gap:10, alignItems:"center",
            }}>
              <input
                value={m.title || ""}
                placeholder="e.g. The Workout Partner"
                onChange={(e) => updateMissing(m.id, { title: e.target.value })}
                style={{
                  background:"var(--bg)", color:"var(--text)", border:"1px solid var(--border)",
                  borderRadius:8, padding:"8px 11px", fontFamily:"var(--serif)", fontStyle:"italic",
                  fontSize:13, outline:"none", minWidth:0,
                }}
              />
              <input
                value={m.note || ""}
                placeholder="What would they do? (optional)"
                onChange={(e) => updateMissing(m.id, { note: e.target.value })}
                style={{
                  background:"var(--bg)", color:"var(--text)", border:"1px solid var(--border)",
                  borderRadius:8, padding:"8px 11px", fontFamily:"var(--sans)", fontSize:13,
                  outline:"none", minWidth:0,
                }}
              />
              <button onClick={() => removeMissing(m.id)} title="Remove" style={{
                width:28, height:28, borderRadius:"50%", background:"transparent",
                border:"1px solid var(--border)", color:"var(--text4)", cursor:"pointer",
                fontSize:14, lineHeight:1, padding:0,
              }}>×</button>
            </div>
          ))}

          <button onClick={addMissing} style={{
            background:"transparent", border:`1px solid ${A3_TEAL}`, color: A3_TEAL,
            borderRadius: 999, padding:"7px 16px", fontSize:12, fontWeight:600, cursor:"pointer",
            fontFamily:"var(--sans)", marginTop:6,
          }}>+ Add a missing seat</button>
        </div>
      )}

      {/* Reflection card */}
      <div style={{ background:"var(--bg2)", border:"1px solid var(--border)", borderLeft:`3px solid ${A3_AMBER}`, borderRadius:10, padding:"16px 22px", marginBottom: 22 }}>
        <div style={{ fontSize:10, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color: A3_AMBER, marginBottom:8, fontFamily:"var(--sans)" }}>One thing to notice</div>
        <p style={{ fontFamily:"var(--serif)", fontSize:15, color:"var(--text2)", lineHeight:1.7, fontStyle:"italic", margin:0 }}>
          Look at your table. Who's there, and who isn't. An empty seat isn't a failure — it's the clearest signal of what you need next.
        </p>
      </div>

      {/* Closing card */}
      <div style={{ background:"var(--bg2)", border:"1px solid var(--border)", borderRadius:11, padding:"20px 24px", marginBottom: 26 }}>
        <div style={{ fontFamily:"var(--serif)", fontSize:22, fontWeight:400, color:"var(--text)", marginBottom:10 }}>This is a living table.</div>
        <p style={{ fontFamily:"var(--sans)", fontSize:13, color:"var(--text2)", lineHeight:1.75, marginBottom:10 }}>
          People earn seats. People leave them. Seats stay empty until the right person arrives. Your Board today is not your Board forever — and that's how it should be.
        </p>
        <p style={{ fontFamily:"var(--sans)", fontSize:13, color:"var(--text2)", lineHeight:1.75, margin:0 }}>
          The named advocates and the missing seats both come with you into <span style={{ color: A3_TEAL, fontWeight:700 }}>A4 and A5</span>, where you'll build the rhythm of how you actually consult this Board — not just hold it in your head.
        </p>
      </div>

      {/* Step footer */}
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", paddingTop:14, borderTop:"1px solid var(--border)" }}>
        <button onClick={() => setA3Step("energymap")} style={{
          background:"transparent", border:"1px solid var(--border)", color:"var(--text3)",
          borderRadius:8, padding:"8px 14px", fontSize:12, cursor:"pointer", fontFamily:"var(--sans)",
        }}>← Back to Energy Map</button>
        <div style={{ display:"flex", alignItems:"center", gap:10 }}>
          <span style={{ fontSize:11, color:"var(--text4)", fontFamily:"var(--sans)", fontStyle:"italic" }}>Next up · A4 coming soon</span>
          <button disabled style={{
            background:"transparent", border:"1px solid var(--border)", color:"var(--text4)",
            borderRadius:8, padding:"8px 14px", fontSize:12, cursor:"not-allowed", fontFamily:"var(--sans)", opacity:0.5,
          }}>Continue →</button>
        </div>
      </div>
    </div>
  );
}

function A3({ intake, onDone, phase, setPhase }: any) {
  const [a3Step, setA3Step] = useState("intro");
  const a3Goto = (s: string) => { setA3Step(s); window.scrollTo({ top: 0, behavior: "smooth" }); };
  const [voice, setVoice] = useState(intake?.defaultVoice || "coach");
  useEffect(() => { loadData(KEYS.voice).then((v: any) => { if (v) setVoice(v); }); }, []);
  const setVoicePersist = (v: any) => { setVoice(v); saveData(KEYS.voice, v); };

  const [map, setMap] = useState<any>({});
  useEffect(() => { loadData(KEYS.map).then((m: any) => { if (m) setMap(m); }); }, []);
  const saveTimer = useRef<any>(null);
  const saveMap = useCallback((next: any) => {
    clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => { saveData(KEYS.map, next); }, 800);
  }, []);
  const set = useCallback((key: string, val: any) => {
    setMap((prev: any) => { const next = { ...prev, [key]: val }; saveMap(next); return next; });
  }, [saveMap]);

  const phaseTabs = (
    <div style={{ display:"flex", gap:5 }}>
      {["A1","A2","A3","A4","A5"].map((a) => {
        const key = a.toLowerCase();
        const isActive = phase === key;
        const isAvailable = key === "a1" || key === "a2" || key === "a3" || phase === "done";
        return (
          <div key={a}
            onClick={() => { if (isAvailable) setPhase(key); }}
            title={isAvailable ? (isActive ? `You are in ${a}` : `Jump to ${a}`) : `${a} coming soon`}
            style={{ width:25, height:25, borderRadius:"50%", background: isActive ? "rgba(201,168,76,.18)" : "transparent", border:`1px solid ${isActive ? "rgba(232,149,109,.55)" : "var(--border)"}`, display:"flex", alignItems:"center", justifyContent:"center", cursor: isAvailable ? "pointer" : "not-allowed", opacity: isAvailable ? 1 : 0.4 }}>
            <span style={{ fontFamily:"var(--sans)", fontSize:10, color: isActive ? "var(--warm)" : "var(--text4)", fontWeight: isActive ? 700 : 500 }}>{a}</span>
          </div>
        );
      })}
    </div>
  );
  const hdr = (
    <div style={{ borderBottom:"1px solid #1a1a16", padding:"11px 28px", display:"flex", justifyContent:"space-between", alignItems:"center", position:"sticky", top:0, background:"rgba(13,27,46,.96)", backdropFilter:"blur(12px)", zIndex:50 }}>
      <div style={{ display:"flex", alignItems:"center", gap:11 }}>
        <div style={{ width:6, height:6, borderRadius:"50%", background:"var(--warm)", animation:"pulse 3s ease-in-out infinite" }} />
        <div style={{ fontFamily:"var(--sans)", fontSize:13, fontWeight:700 }}>True Ownership™</div>
        <div style={{ fontFamily:"var(--sans)", fontSize:12, color:"var(--text4)" }}>· {intake?.name || ""}</div>
      </div>
      <div style={{ display:"flex", alignItems:"center", gap:14 }}>
        {phaseTabs}
        <AdminBar phase={phase} onAdminClick={() => setPhase("_admin")} mode="inline" />
        <AccountMenu mode="inline" />
      </div>
    </div>
  );
  const sidebar = (
    <div style={{ width:206, flexShrink:0, paddingRight:22, borderRight:"1px solid var(--border)" }}>
      <div style={{ fontSize:11, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color:"var(--text2)", marginBottom:15, fontFamily:"var(--sans)" }}>Advocate For It · A3</div>
      {A3_STEPS.map(s => {
        const active = a3Step === s.id;
        return (
          <button key={s.id} className={`sidebar-btn${active ? " active" : ""}`} onClick={() => {
            if (s.id === "map") { saveData("to_mapofme_origin", "a3"); setPhase("_mapofme"); return; }
            a3Goto(s.id);
          }}>
            <div style={{ width:7, height:7, borderRadius:"50%", background: active ? "var(--warm)" : "var(--border2)", flexShrink:0, transition:"background .3s" }} />
            <span style={{ fontSize:12, color: active ? "var(--warm)" : "var(--text2)", fontWeight: active ? 500 : 400, lineHeight:1.3 }}>{s.label}</span>
          </button>
        );
      })}
      <div style={{ marginTop:18, paddingTop:14, borderTop:"1px solid var(--border)" }}>
        <div style={{ fontSize:10, fontWeight:500, letterSpacing:2, textTransform:"uppercase", color:"var(--text4)", marginBottom:7, fontFamily:"var(--sans)" }}>Voice</div>
        <VoiceDropdown voiceId={voice} onSelect={setVoicePersist} />
      </div>
    </div>
  );
  const wrapA3 = (children: any) => (
    <>
      {hdr}
      <div style={{ display:"flex", gap:32, padding:"32px 28px 80px", maxWidth:980, margin:"0 auto" }}>
        {sidebar}
        <div style={{ flex:1, minWidth:0 }} className="fade-up">{children}</div>
      </div>
    </>
  );

  if (a3Step === "intro")       return wrapA3(<A3IntroStub       setA3Step={a3Goto} />);
  if (a3Step === "people")      return wrapA3(<A3PeopleStub      setA3Step={a3Goto} map={map} set={set} />);
  if (a3Step === "environment") return wrapA3(<A3EnvironmentStub setA3Step={a3Goto} map={map} set={set} />);
  if (a3Step === "thoughts")    return wrapA3(<A3ThoughtsStub    setA3Step={a3Goto} map={map} set={set} />);
  if (a3Step === "energymap")   return wrapA3(<A3EnergyMapHorizontal setA3Step={a3Goto} map={map} />);
  if (a3Step === "board")       return wrapA3(<A3BoardStub       setA3Step={a3Goto} map={map} set={set} />);
  return wrapA3(<div>Unknown A3 step: {a3Step}</div>);
}

function Intake({ onDone }) {
  const [step, setStep] = useState(0);
  const [name, setName] = useState("");
  const [q1, setQ1] = useState("");
  const [q2, setQ2] = useState("");
  const [q3, setQ3] = useState("");
  const [busy, setBusy] = useState(false);
  const [assigned, setAssigned] = useState(null);
  const [chosen, setChosen] = useState(null);
  const submit3 = async () => { setBusy(true); await new Promise(r => setTimeout(r, 800)); const v = detectVoice(q3); setAssigned(v); setChosen(v); setBusy(false); setStep(4); };
  const KNote = ({ children }) => (
    <div style={{ padding:"13px 17px", background:"rgba(201,168,76,.07)", border:"1px solid rgba(201,168,76,.14)", borderRadius:9, marginBottom:18 }}>
      <div style={{ fontFamily:"var(--serif)", fontSize:15, fontStyle:"italic", color:"var(--text2)", lineHeight:1.7 }}>{children}</div>
    </div>
  );
  const screens = [
    <div key="n" className="fade-up" style={{ maxWidth:540 }}>
      <div style={{ fontSize:11, fontWeight:700, letterSpacing:4, textTransform:"uppercase", color:"#c9a84c", marginBottom:14, fontFamily:"var(--sans)" }}>AG45™ · True Ownership™</div>
      <h1 style={{ fontFamily:"var(--serif)", fontSize:52, fontWeight:400, lineHeight:1.0, letterSpacing:"-0.5px", marginBottom:18 }}>
        To own your life,<br /><em>you must first<br />belong to yourself.</em>
      </h1>
      <p style={{ fontSize:15, color:"var(--text2)", lineHeight:1.85, maxWidth:480, marginBottom:22 }}>
        True Ownership is not about your business or your role. It is about being the CEO of your life -- knowing who you are, what you want, and where you are going. And beginning to live by that person.
      </p>
      <p style={{ fontSize:15, color:"var(--text2)", lineHeight:1.85, maxWidth:480, marginBottom:28 }}>
        That means trusting yourself -- your intuition, your logic, your experiences. It also means building the right advocates around you. But you cannot choose them wisely until you are clear about yourself. Everything starts with you.
      </p>
      {/* The 5 As */}
      <div style={{ marginBottom:28, padding:"18px 20px", background:"var(--bg2)", border:"1px solid var(--border2)", borderRadius:11 }}>
        <div style={{ fontSize:10, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color:"var(--warm)", marginBottom:14, fontFamily:"var(--sans)" }}>The Five As™ -- Your Journey</div>
        {[
          { a:"A1", label:"All In It",     color:"var(--warm)", desc:"Know yourself. Purpose, identity, values and direction. The foundation everything is built on." },
          { a:"A2", label:"Align With It", color:"#c9a84c",     desc:"Does how you spend your time, energy and money match who you are and where you are going?" },
          { a:"A3", label:"Advocate",      color:"#a78bfa",     desc:"Build your board. Who belongs around you? You cannot choose your advocates wisely until you know yourself." },
          { a:"A4", label:"Act On It",     color:"#34d399",     desc:"Your goals and daily behaviours. The bridge between who you are and the life you are building." },
          { a:"A5", label:"Accountable",   color:"#f59e0b",     desc:"Own your commitments. Track, reflect, adjust. This is where ownership becomes a daily practice." },
        ].map((item, i) => (
          <div key={item.a} style={{ display:"flex", alignItems:"flex-start", gap:13, marginBottom: i < 4 ? 13 : 0, paddingBottom: i < 4 ? 13 : 0, borderBottom: i < 4 ? "1px solid var(--border)" : "none" }}>
            <div style={{ width:30, height:30, borderRadius:"50%", background: i === 0 ? "rgba(201,168,76,.15)" : "var(--bg3)", border:`1px solid ${i === 0 ? "rgba(201,168,76,.4)" : "var(--border2)"}`, display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0, marginTop:1 }}>
              <span style={{ fontFamily:"var(--sans)", fontSize:10, fontWeight:700, color: i === 0 ? "var(--warm)" : "var(--text4)" }}>{item.a}</span>
            </div>
            <div>
              <div style={{ fontFamily:"var(--sans)", fontSize:13, fontWeight:700, color: i === 0 ? item.color : "var(--text3)", marginBottom:3 }}>{item.label}{i === 0 ? " · Where we begin" : ""}</div>
              <div style={{ fontSize:13, color: i === 0 ? "var(--text2)" : "var(--text4)", lineHeight:1.6 }}>{item.desc}</div>
            </div>
          </div>
        ))}
      </div>
      <div style={{ padding:"14px 18px", background:"rgba(201,168,76,.06)", border:"1px solid rgba(201,168,76,.14)", borderRadius:9, marginBottom:28 }}>
        <div style={{ fontFamily:"var(--serif)", fontSize:16, fontStyle:"italic", color:"var(--text)", lineHeight:1.8 }}>
          "This system is one of your board of advisors -- a mirror that reflects your own thinking back more clearly. It does not think for you. You are the authority on your own life."
        </div>
      </div>
      <label style={{ display:"block", fontFamily:"var(--sans)", fontSize:13, color:"var(--text3)", marginBottom:7 }}>What's your first name?</label>
      <TextInput value={name} onChange={setName} placeholder="Your name..." style={{ fontSize:13, fontWeight:500, padding:"15px 19px", marginBottom:20 }} />
      <button className="btn" disabled={!name.trim()} onClick={() => setStep(1)}>Begin →</button>
    </div>,
    <div key="q1" className="fade-up" style={{ maxWidth:520 }}>
      <div className="lbl" style={{ marginBottom:9 }}>Question 1 of 3</div>
      <h2 style={{ fontFamily:"var(--serif)", fontSize:36, fontWeight:400, lineHeight:1.15, marginBottom:18, letterSpacing:"-0.4px" }}>What brought you here, {name}?</h2>
      <KNote>"In one sentence -- what's the thing that finally made you say: I need to do this work."</KNote>
      <TextArea value={q1} onChange={setQ1} rows={4} placeholder="What brought me here is..." style={{ marginBottom:16 }} />
      <div style={{ display:"flex", justifyContent:"space-between" }}>
        <button className="btn-g" onClick={() => setStep(0)}>← Back</button>
        <button className="btn" disabled={!q1.trim()} onClick={() => setStep(2)}>Next →</button>
      </div>
    </div>,
    <div key="q2" className="fade-up" style={{ maxWidth:520 }}>
      <div className="lbl" style={{ marginBottom:9 }}>Question 2 of 3</div>
      <h2 style={{ fontFamily:"var(--serif)", fontSize:36, fontWeight:400, lineHeight:1.15, marginBottom:18, letterSpacing:"-0.4px" }}>Who are you becoming?</h2>
      <KNote>"Don't think about your business or role. In 3 years, living fully as yourself -- what's one word or phrase that describes who that person is?"</KNote>
      <TextArea value={q2} onChange={setQ2} rows={4} placeholder="In 3 years, I am..." style={{ marginBottom:16 }} />
      <div style={{ display:"flex", justifyContent:"space-between" }}>
        <button className="btn-g" onClick={() => setStep(1)}>← Back</button>
        <button className="btn" disabled={!q2.trim()} onClick={() => setStep(3)}>Next →</button>
      </div>
    </div>,
    <div key="q3" className="fade-up" style={{ maxWidth:520 }}>
      <div className="lbl" style={{ marginBottom:9 }}>Question 3 of 3</div>
      <h2 style={{ fontFamily:"var(--serif)", fontSize:36, fontWeight:400, lineHeight:1.15, marginBottom:18, letterSpacing:"-0.4px" }}>What do you most need?</h2>
      <KNote>"What do you most need from this experience -- permission, clarity, a push, or something else? Say it in your own words."</KNote>
      <TextArea value={q3} onChange={setQ3} rows={4} placeholder="What I most need is..." style={{ marginBottom:16 }} />
      <div style={{ display:"flex", justifyContent:"space-between" }}>
        <button className="btn-g" onClick={() => setStep(2)}>← Back</button>
        <button className="btn" disabled={!q3.trim() || busy} onClick={submit3}>{busy ? <span className="dot-l"><span /><span /><span /></span> : "Find my voice →"}</button>
      </div>
    </div>,
    <div key="v" className="fade-up" style={{ maxWidth:590 }}>
      {assigned && chosen && (() => {
        const av = VOICES[assigned];
        return <>
          <div className="lbl" style={{ marginBottom:13 }}>Your default voice</div>
          <h2 style={{ fontFamily:"var(--serif)", fontSize:34, fontWeight:400, lineHeight:1.2, marginBottom:9, letterSpacing:"-0.3px" }}>Based on what you shared,<br /><em>I'm starting you with:</em></h2>
          <div style={{ padding:"19px 22px", background:av.muted, border:`1px solid ${av.border}`, borderRadius:13, marginBottom:7 }}>
            <div style={{ display:"flex", alignItems:"center", gap:11, marginBottom:9 }}>
              <span style={{ color:av.color, fontSize:24 }}>{av.icon}</span>
              <div style={{ fontFamily:"var(--serif)", fontSize:21, color:av.color, fontWeight:400 }}>{av.label}</div>
            </div>
            <div style={{ fontFamily:"var(--sans)", fontSize:13, color:"var(--text2)", lineHeight:1.7, marginBottom:7 }}>{VOICE_DESC[assigned]}</div>
            <div style={{ fontFamily:"var(--sans)", fontSize:14, color:"var(--text3)", fontStyle:"italic" }}>Why: {VOICE_REASON[assigned]}</div>
          </div>
          <div style={{ padding:"9px 13px", background:"var(--bg2)", border:"1px solid var(--border)", borderRadius:8, marginBottom:12 }}>
            <span style={{ fontFamily:"var(--sans)", fontSize:12, color:"var(--text2)", fontWeight:500 }}>Not right for today? </span>
            <span style={{ fontFamily:"var(--sans)", fontSize:12, color:"var(--text3)" }}>Choose the voice you actually need -- you can switch any time.</span>
          </div>
          <VoiceGrid selected={chosen} onSelect={setChosen} />
          <div style={{ marginTop:18 }}>
            <button className="btn" onClick={() => onDone({ name, q1, q2, q3, defaultVoice:chosen })}>Begin All In It →</button>
          </div>
        </>
      })()}
    </div>,
  ];
  return (
    <div style={{ minHeight:"100vh", display:"flex", alignItems:"center", justifyContent:"center", padding:"36px 22px 80px" }}>
      {screens[step]}
      <div style={{ position:"fixed", bottom:42, left:0, right:0, background:"rgba(13,27,46,.95)", borderTop:"1px solid #254060", padding:"8px 28px", display:"flex", alignItems:"center", gap:8, zIndex:40 }}>
        <div style={{ width:6, height:6, borderRadius:"50%", background:"var(--warm)", animation:"pulse 2s infinite", flexShrink:0 }} />
        <span style={{ fontFamily:"var(--sans)", fontSize:11, color:"var(--text4)" }}>Your answers are saved automatically -- you can come back to this any time</span>
      </div>
    </div>
  );
}
const STEPS = [
  { id:"to_intro", label:"True Ownership™" },
  { id:"intro",   label:"Introduction" },
  { id:"mirror1", label:"Purpose · Direction" },
  { id:"direction_3yr",   label:"Direction · 3-YEAR" },
  { id:"mirror2", label:"Identity · Superpowers" },
  { id:"mirror3", label:"Values · Behaviors" },
  { id:"direction_1yr",   label:"Direction · 1-YEAR" },
  { id:"direction_align", label:"Direction Alignment" },
  { id:"align",   label:"Alignment Check" },
  { id:"map",     label:"My Map of Me™" },
];
const EMPTY_MAP = {
  purpose_layers: [""],
  purpose_draft: "", purpose_final: "",
  bag_year: "",
  life_areas: [],
  bag_retirement: "", bag_assets: "", bag_cashflow: "", bag_other: "",
  wealth_chips: [], bag_wealth_items: {},
  // W.1a: new wealth state shape (prototype parity)
  wealth_picked: [], wealth_items: {},
  wealth_see_hear_feel: { see: "", hear: "", feel: "" },
  wealth_overall_sentence: "", wealth_overall_confirmed: false,
  // W.1a-ext: new time state shape (prototype parity)
  time_picked: [], time_items: {},
  time_see_hear_feel: { see: "", hear: "", feel: "" },
  time_overall_sentence: "", time_overall_confirmed: false,
  // W.1a-ext: new growth state shape (prototype parity — no cards, just S/H/F + sentence)
  growth_see_hear_feel: { see: "", hear: "", feel: "" },
  growth_sentence: "", growth_confirmed: false,
  // W.1c: tier ranking state for BAG
  bag_tiers: {}, bag_ranking_confirmed: false,
  // W.2: Direction · 3-Year state (pre-fills from BAG)
  threeyr_time_items: {}, threeyr_wealth_items: {},
  threeyr_time_sentence: "", threeyr_time_confirmed: false,
  threeyr_wealth_sentence: "", threeyr_wealth_confirmed: false,
  threeyr_growth_text: "",
  threeyr_growth_sentence: "", threeyr_growth_confirmed: false,
  threeyr_tiers: {}, threeyr_ranking_confirmed: false,
  // W.2: Direction · 1-Year state (pre-fills from BAG; Growth pulls from Identity/Values lowest scores)
  oneyr_time_items: {}, oneyr_wealth_items: {},
  oneyr_time_sentence: "", oneyr_time_confirmed: false,
  oneyr_wealth_sentence: "", oneyr_wealth_confirmed: false,
  oneyr_growth_text: "",
  oneyr_growth_sentence: "", oneyr_growth_confirmed: false,
  oneyr_growth_accepted: {}, oneyr_growth_edited_labels: {},
  oneyr_growth_removed: {}, oneyr_growth_custom: [],
  oneyr_tiers: {}, oneyr_ranking_confirmed: false,
  time_summary: "", wealth_summary: "", growth_summary: "",
  mirror1_reflection: "", mirror1_reflection_done: false,
  mirror2_sub: "qualities",
  mirror3_sub: "values",
  lovedones_who: "", lovedones_input: "", lovedones_reflection: "",
  bag_growth: "",
  identity_adjectives: "",
  identity_chips: [],
  animals: [{ name:"", adj1:"", adj2:"", adjective1:"", adjective2:"", alignment:5 }],
  capabilities_note: "",
  values_irks: "",
  values: [{ name:"", irk:"", behaviors:"" }],
  behaviors_note: "",
  align_direction:5, align_superpowers:5, align_behaviors:5,
};
const MIRROR_CARDS = [
  { side:"internal", id:"purpose",    icon:"🔥", label:"Purpose",    color:"#c9a84c", colorMuted:"rgba(232,149,109,0.08)", colorBorder:"rgba(232,149,109,0.2)", pair:"mirror1", tagline:"Your internal north star",          description:"Purpose is the internal reason you exist -- the impact your presence creates regardless of any role or outcome. Not your business, not your family -- those are expressions of it. Your purpose stays constant when everything else changes. Short enough to say in the car. True enough to get you out of bed on a hard day.", katherine:"\"When I ask people what their purpose is, they usually say their kids or their business. That's not purpose -- those are attachments. Purpose needs to be 100% internal to you.\"" },
  { side:"internal", id:"identity",   icon:"🦁", label:"Identity",   color:"#c9a84c", colorMuted:"rgba(79,203,242,0.08)",  colorBorder:"rgba(79,203,242,0.2)",  pair:"mirror2", tagline:"Who you are at your best",           description:"Identity is your internal superpowers anchored to animals -- because people remember images, not word lists. Two adjectives make it specific to you, not the generic animal. And if you're too aligned with one animal, you might be in detriment of the others.", katherine:"\"I had a client tell me: 'I was in my crazy monkey and I realized I needed to bring the lion out.' That's how this works -- you glance at it and immediately know what you need.\"" },
  { side:"internal", id:"values",     icon:"⚖️", label:"Values",     color:"#34d399", colorMuted:"rgba(52,211,153,0.08)",  colorBorder:"rgba(52,211,153,0.2)",  pair:"mirror3", tagline:"The standards you live by",           description:"Values are how you make decisions and set boundaries -- the standards that, when violated, make your blood boil. The fastest way to find them: what behaviors in others do you absolutely cannot stand? Peel back one layer and you'll find your value underneath.", katherine:"\"Someone told me she hated people who weren't accountable. Two minutes later we'd identified accountability as her top value -- she'd just never named it.\"" },
  { side:"external", id:"direction",  icon:"⛰️", label:"Direction",  color:"#c9a84c", colorMuted:"rgba(79,203,242,0.08)",  colorBorder:"rgba(79,203,242,0.2)",  pair:"mirror1", tagline:"Your Big Ass Goal -- the summit",       description:"Your BAG -- Big Ass Goal -- is the 10–15 year dream across Time (how you live your days), Wealth (financial freedom), and Growth (who you're becoming as a person). It should feel dreamy and a bit scary. About 25% believable. If you can see exactly how to get there, it's not big enough.", katherine:"\"Start at the top of the mountain. We work backwards from there. Most people set goals from where they are. We set them from where we want to be.\"" },
  { side:"external", id:"superpowers",icon:"⚡", label:"Superpowers",color:"#a78bfa", colorMuted:"rgba(167,139,250,0.08)", colorBorder:"rgba(167,139,250,0.2)", pair:"mirror2", tagline:"How your identity shows up in the world",description:"Each animal has a superpower and a detriment. The superpower is what it enables when working for you. The detriment is what happens when it goes too far. Knowing both lets you call on the right animal at the right moment -- and catch yourself when one is running unchecked.", katherine:"\"The superpower is why you chose this animal. The dark side is the thing that costs you when it's out of balance. Both are data.\"" },
  { side:"external", id:"behaviors",  icon:"🎯", label:"Behaviors",  color:"#34d399", colorMuted:"rgba(52,211,153,0.08)",  colorBorder:"rgba(52,211,153,0.2)",  pair:"mirror3", tagline:"How your values show up in action",     description:"Behaviors are the external proof of your values. Not what you believe -- how you act when it costs you something. For each value we define what living it looks like, and the violation signal that tells you it's being stomped on. Values become a decision filter, not a motivational poster.", katherine:"\"A value without a behavior attached to it is just a word on a wall. We define the behavior so you can actually use it.\"" },
];
function SoWhatLayer({ index, value, onChange, isLatest, onGoDeeper, onReachedBottom, loading, done }) {
  const ref = useRef(null);
  const lastVal = useRef(value);
  const isFirst = index === 0;
  const depth = Math.min(index + 1, 5);
  const depthColor = ["rgba(201,168,76,0.45)","rgba(201,168,76,0.6)","rgba(201,168,76,0.75)","rgba(201,168,76,0.9)","#c9a84c"][depth - 1];
  useEffect(() => { if (!isFirst && isLatest && ref.current && !done) { setTimeout(() => ref.current?.focus(), 80); } }, [isLatest, isFirst, done]);
  useEffect(() => { if (ref.current && document.activeElement !== ref.current) { ref.current.value = value || ""; lastVal.current = value; } }, [value]);
  const handleChange = useCallback((e) => { lastVal.current = e.target.value; onChange(e.target.value); }, [onChange]);
  const handleBlur = useCallback((e) => { lastVal.current = e.target.value; onChange(e.target.value); e.target.style.borderColor = "var(--border2)"; e.target.style.boxShadow = "none"; }, [onChange]);
  const hasAnswer = (ref.current?.value || value || "").trim().length > 0;
  return (
    <div className={isFirst ? "" : "fade-up"} style={{ marginBottom: isFirst ? 20 : 0 }}>
      {!isFirst && (
        <div style={{ display:"flex", alignItems:"center", gap:10, margin:"18px 0 14px" }}>
          <div style={{ width:24, height:24, borderRadius:"50%", background:"var(--bg3)", border:`2px solid ${depthColor}`, display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0 }}>
            <span style={{ fontSize:9, color:depthColor, fontWeight:700 }}>{index + 1}</span>
          </div>
          <div style={{ flex:1, height:1, background:`linear-gradient(to right, ${depthColor}44, transparent)` }} />
          {index >= 3 && <div style={{ fontFamily:"var(--sans)", fontSize:10, color:"var(--text4)", fontStyle:"italic", flexShrink:0 }}>{index === 3 ? "Getting deeper..." : index === 4 ? "Almost there..." : "Keep going..."}</div>}
        </div>
      )}
      <div style={{ paddingLeft: isFirst ? 0 : 14, borderLeft: isFirst ? "none" : `2px solid ${depthColor}` }}>
      <div style={{ marginBottom:7 }}>
        {isFirst ? (
          <>
            <div style={{ fontFamily:"var(--sans)", fontSize:13, fontWeight:700, color:"var(--text)", marginBottom:3 }}>When are you most alive?</div>
            <div style={{ fontFamily:"var(--sans)", fontSize:12, color:"var(--text3)", lineHeight:1.5 }}>Describe what you're DOING -- not just the feeling. What are you creating, solving, connecting?</div>
          </>
        ) : (
          <>
            <div style={{ fontFamily:"var(--sans)", fontSize:12, fontWeight:700, letterSpacing:1.5, textTransform:"uppercase", color:depthColor, marginBottom:4 }}>So what's that give you?</div>
            <div style={{ fontFamily:"var(--sans)", fontSize:12, color:"var(--text3)", lineHeight:1.5 }}>{index === 1 ? "What does that give you? What does it give others? Don't settle for the first answer." : "And what does THAT mean at a deeper level? Keep asking until something feels final."}</div>
          </>
        )}
      </div>
      <textarea ref={ref} rows={3} placeholder={isFirst ? "I feel most alive when I'm..." : "And that gives me / means..."}
        defaultValue={value || ""} onChange={handleChange} onBlur={handleBlur} disabled={done && !isLatest}
        className="purpose-peel-ta"
        style={{ width:"100%", background:"var(--bg4)", border:"1px solid var(--border2)", borderRadius:10, color:"var(--warm)", fontFamily:"var(--sans)", fontSize:13, lineHeight:1.7, padding:"12px 14px", outline:"none", resize:"none", opacity:done && !isLatest ? 0.6 : 1 }}
        onFocus={e => { e.target.style.borderColor = "var(--warm)"; e.target.style.boxShadow = "0 0 0 3px rgba(201,168,76,0.12)"; }}
      />
      </div>
      {isLatest && hasAnswer && !done && (
        <div className="fade-up" style={{ display:"flex", gap:9, marginTop:12, flexWrap:"wrap", alignItems:"center" }}>
          <button onClick={onGoDeeper} disabled={loading}
            style={{ background:"none", border:"1px solid var(--border2)", borderRadius:20, color:"var(--text2)", cursor:"pointer", fontFamily:"var(--sans)", fontSize:12, fontWeight:500, padding:"8px 20px", transition:"all .2s" }}
            onMouseEnter={e => { e.currentTarget.style.borderColor = "var(--warm)"; e.currentTarget.style.color = "var(--warm)"; }}
            onMouseLeave={e => { e.currentTarget.style.borderColor = "var(--border2)"; e.currentTarget.style.color = "var(--text2)"; }}>
            {loading ? <span className="dot-l" style={{ color:"var(--warm)" }}><span /><span /><span /></span> : "↓ Go deeper -- so what's?"}
          </button>
          <div style={{ width:1, height:18, background:"var(--border2)" }} />
          <button onClick={onReachedBottom} disabled={loading}
            style={{ background:"rgba(201,168,76,.12)", border:"1px solid rgba(201,168,76,.4)", borderRadius:20, color:"var(--warm)", cursor:"pointer", fontFamily:"var(--sans)", fontSize:12, fontWeight:700, padding:"8px 20px", transition:"all .2s" }}
            onMouseEnter={e => { e.currentTarget.style.background = "rgba(201,168,76,.22)"; }}
            onMouseLeave={e => { e.currentTarget.style.background = "rgba(201,168,76,.12)"; }}>
            ✓ This is my bottom -- get my purpose
          </button>
        </div>
      )}
    </div>
  );
}
function PurposePeelingInline({ layers, onLayersChange, purposeFinal, onFinalChange, purposeResult, onResult, name, intake, allSessions, onSessionSave, onContinueToNext }) {
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(!!purposeResult);
  const [sessionKey, setSessionKey] = useState(0);
  const [peelingExpanded, setPeelingExpanded] = useState(false);
  const [confirmedNow, setConfirmedNow] = useState(false);
  const [livingOpen, setLivingOpen] = useState(false);
  const [activeStep, setActiveStep] = useState(1);
  const step1Ref = useRef(null);
  const step2Ref = useRef(null);
  const sessions = allSessions || [];
  const updateLayer = useCallback((i, val) => {
    const next = [...layers]; next[i] = val; onLayersChange(next);
  }, [layers, onLayersChange]);
  const goDeeper = useCallback(() => {
    const domTextareas = document.querySelectorAll('.purpose-peel-ta');
    if (domTextareas.length > 0) {
      const domValues = Array.from(domTextareas).map(ta => ta.value || "");
      onLayersChange([...domValues, ""]);
    } else {
      onLayersChange([...layers, ""]);
    }
  }, [layers, onLayersChange]);
  const reachedBottom = useCallback(async () => {
    const domTextareas = document.querySelectorAll('.purpose-peel-ta');
    const currentLayers = domTextareas.length > 0 ? Array.from(domTextareas).map(ta => ta.value || "") : layers;
    const filledLayers = currentLayers.filter(l => (l || "").trim());
    if (filledLayers.length === 0) return;
    setLoading(true);
    let errorMsg = null;
    try {
      const layerText = currentLayers.map((l, i) => i === 0 ? `Most alive: "${l}"` : `So what's ${i}: "${l}"`).join("\n");
      const prevContext = sessions.length > 0 ? `\nPrevious sessions: ${sessions.map((s, si) => `Session ${si + 1} draft: "${s.draft || ""}" verbs: ${(s.verbs || []).join(", ")}`).join("; ")}` : "";
      const res = await fetch("/api/claude", {
        method:"POST", headers:{"Content-Type":"application/json"},
        body: JSON.stringify({ model:"claude-sonnet-4-20250514", max_tokens:600,
          messages:[{ role:"user", content:`You are Katherine Breuss. ${name} just completed a purpose peeling exercise. Read their EXACT words carefully and respond based on what THEY specifically wrote -- not generic coaching language.\n\nTheir peeling layers:\n${layerText}\n\nWhat brought them here: "${intake?.q1 || ""}"\n${prevContext}\n${sessions.length > 0 ? "This is a return session." : ""}\n\nRespond ONLY with a JSON object. No preamble, no markdown, no explanation. Just the JSON:\n{"working":"1 sentence quoting their actual words","verbs":["verb1","verb2","verb3"],"draft":"short purpose statement built from their specific words -- must sound like them not a template","refining_question":"one question specific to what they wrote","deeper_note":"${sessions.length > 0 ? "1 sentence on how this session differs from previous ones" : ""}"}` }]
        })
      });
      const data = await res.json();
      if (data.error) throw new Error(`API error: ${data.error.message}`);
      const rawText = data.content?.map(b => b.text || "").join("") || "";
      if (!rawText) throw new Error("Empty response from API");
      const jsonMatch = rawText.match(/\{[\s\S]*\}/);
      if (!jsonMatch) throw new Error(`No JSON found in: ${rawText.slice(0, 100)}`);
      const parsed = JSON.parse(jsonMatch[0]);
      if (!parsed.draft) throw new Error(`Missing draft field in: ${JSON.stringify(parsed)}`);
      if (onSessionSave) onSessionSave({ ...parsed, layers:[...currentLayers], date:new Date().toLocaleDateString() });
      onResult({ ...parsed });
      onFinalChange(parsed.draft || "");
      setDone(true);
    } catch (e) {
      errorMsg = e.message;
      const lastLayer = currentLayers.filter(l => (l||"").trim()).slice(-1)[0] || "";
      const firstLayer = currentLayers[0] || "";
      const fallback = { working:`You went ${currentLayers.filter(l=>(l||"").trim()).length} layers deep -- that takes honesty.`, verbs:firstLayer.split(/\s+/).filter(w => w.length > 4).slice(0, 3), draft:lastLayer.length > 10 ? lastLayer.slice(0, 120) : firstLayer.slice(0, 120), refining_question:"Read back what you wrote in your deepest layer. Is that your purpose, or is there still one more 'so what's?' left?", deeper_note:sessions.length > 0 ? "You returned -- that alone tells you something." : "", _error:errorMsg };
      if (onSessionSave) onSessionSave({ ...fallback, layers:[...currentLayers], date:new Date().toLocaleDateString() });
      onResult({ ...fallback });
      onFinalChange(fallback.draft);
      setDone(true);
    }
    setLoading(false);
  }, [name, intake, onResult, onFinalChange, sessions, onSessionSave, purposeFinal, layers]);
  const latestIndex = layers.length - 1;
  const restartPeeling = useCallback(() => {
    onLayersChange([""]);
    onResult(null);
    onFinalChange("");
    setDone(false);
    setPeelingExpanded(false);
    setConfirmedNow(false);
    setLivingOpen(false);
    setActiveStep(1);
    setSessionKey(k => k + 1);
  }, [onLayersChange, onResult, onFinalChange]);
  const StepHeader = ({ n, label, title, headerRef }) => {
    const state = n < activeStep ? "done" : n === activeStep ? "active" : "pending";
    const isActive = state === "active";
    const isDone = state === "done";
    const badgeBg = isActive ? "var(--warm)" : isDone ? "rgba(52,211,153,0.14)" : "var(--bg3)";
    const badgeColor = isActive ? "#fff" : isDone ? "#34d399" : "var(--text4)";
    const badgeBorder = isActive ? "2px solid var(--warm)" : isDone ? "1.5px solid rgba(52,211,153,0.55)" : "1px solid var(--border2)";
    const badgeShadow = isActive ? "0 0 0 4px rgba(201,168,76,0.18), 0 2px 8px rgba(201,168,76,0.4)" : "none";
    const labelColor = isActive ? "var(--warm)" : isDone ? "#34d399" : "var(--text4)";
    const titleColor = isActive ? "var(--text)" : "var(--text3)";
    const opacity = isActive ? 1 : isDone ? 0.85 : 0.55;
    return (
      <div ref={headerRef} style={{ display:"flex", alignItems:"center", gap:11, margin: n===1 ? "22px 0 12px" : "24px 0 12px", scrollMarginTop:90, opacity, transition:"opacity .25s ease" }}>
        <div style={{ width:30, height:30, borderRadius:"50%", background:badgeBg, color:badgeColor, border:badgeBorder, fontSize:13, fontWeight:700, display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0, boxShadow:badgeShadow, transition:"all .25s ease" }}>
          {isDone ? "✓" : n}
        </div>
        <div style={{ flex:1, minWidth:0 }}>
          <div style={{ fontSize:10, fontWeight:700, letterSpacing:1.5, textTransform:"uppercase", color:labelColor, marginBottom:1, transition:"color .25s ease" }}>Step {n} · {label}</div>
          <div style={{ fontFamily:"var(--sans)", fontSize:13, fontWeight:600, color:titleColor, lineHeight:1.4, transition:"color .25s ease" }}>{title}</div>
        </div>
      </div>
    );
  };
  return (
    <div>
      {sessions.length > 0 && (
        <div style={{ marginBottom:16, padding:"11px 14px", background:"var(--bg2)", border:"1px solid var(--border2)", borderRadius:9 }}>
          <div style={{ fontSize:10, fontWeight:700, letterSpacing:1.5, textTransform:"uppercase", color:"var(--text4)", marginBottom:8 }}>Previous sessions</div>
          {sessions.map((s, i) => (
            <div key={i} style={{ display:"flex", alignItems:"flex-start", gap:10, marginBottom:i < sessions.length - 1 ? 8 : 0, paddingBottom:i < sessions.length - 1 ? 8 : 0, borderBottom:i < sessions.length - 1 ? "1px solid var(--border)" : "none" }}>
              <div style={{ fontSize:10, color:"var(--text4)", flexShrink:0, marginTop:2 }}>{s.date || `Session ${i + 1}`}</div>
              <div style={{ fontFamily:"var(--serif)", fontSize:13, fontStyle:"italic", color:"var(--text3)", lineHeight:1.5, flex:1 }}>"{s.draft || ""}"</div>
              <div style={{ fontSize:10, color:"var(--text4)", flexShrink:0 }}>{(s.layers || []).length} layers</div>
            </div>
          ))}
        </div>
      )}
      <div style={{ padding:"11px 14px", background:"rgba(201,168,76,.07)", border:"1px solid rgba(201,168,76,.18)", borderRadius:9, marginBottom:18 }}>
        <div style={{ fontFamily:"var(--serif)", fontSize:14, fontStyle:"italic", color:"var(--text2)", lineHeight:1.7 }}>
          {sessions.length > 0 ? `"Welcome back, ${name}. Each time you return to this, you go deeper. What surfaces today may be different -- and that is the point."` : '"Purpose is discovered by peeling -- not by thinking hard. Answer each so what\'s? until something feels final."'}
        </div>
      </div>
      {/* COLLAPSED VIEW */}
      {done && !peelingExpanded && (
        <div className="fade-in" style={{ marginBottom:14, padding:"12px 14px", background:"rgba(201,168,76,.06)", border:"1px solid rgba(201,168,76,.18)", borderRadius:9 }}>
          <div style={{ fontSize:10, fontWeight:700, letterSpacing:1.5, textTransform:"uppercase", color:"var(--text4)", marginBottom:6 }}>Your purpose statement</div>
          <div style={{ fontFamily:"var(--serif)", fontSize:16, fontStyle:"italic", color:"var(--warm)", lineHeight:1.6, marginBottom:10 }}>"{purposeFinal || "Not yet written"}"</div>
          <button onClick={() => setPeelingExpanded(true)} style={{ background:"none", border:"1px solid var(--border2)", borderRadius:20, color:"var(--text3)", cursor:"pointer", fontFamily:"var(--sans)", fontSize:11, padding:"5px 14px" }}>▾ Show peeling layers</button>
        </div>
      )}
      {/* EXPANDED VIEW */}
      {(!done || peelingExpanded) && (
        <>
          {layers.map((layer, i) => (
            <SoWhatLayer key={`${sessionKey}-${i}`} index={i} value={layer}
              onChange={v => updateLayer(i, v)}
              isLatest={i === latestIndex} onGoDeeper={goDeeper}
              onReachedBottom={reachedBottom} loading={loading} done={done} />
          ))}
          {loading && (
            <div style={{ display:"flex", alignItems:"center", gap:9, padding:"12px 0", color:"var(--warm)" }}>
              <span className="dot-l"><span /><span /><span /></span>
              <span style={{ fontFamily:"var(--sans)", fontSize:13 }}>Katherine is reading your layers...</span>
            </div>
          )}
        </>
      )}
      {purposeResult && (
        <div className="fade-in" style={{ marginTop:8 }}>
          {purposeResult._error && (
            <div style={{ padding:"8px 12px", background:"rgba(239,68,68,.08)", border:"1px solid rgba(239,68,68,.2)", borderRadius:7, marginBottom:10 }}>
              <div style={{ fontSize:10, fontWeight:700, color:"#ef4444", letterSpacing:1, textTransform:"uppercase", marginBottom:3 }}>API fallback fired</div>
              <div style={{ fontSize:11, color:"var(--text4)", fontFamily:"var(--sans)" }}>Error: {purposeResult._error}</div>
            </div>
          )}
          <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:10, padding:"9px 14px", background:"rgba(201,168,76,.06)", border:"1px solid rgba(201,168,76,.14)", borderRadius:7 }}>
            <div style={{ fontFamily:"var(--sans)", fontSize:11, color:"var(--text3)" }}>
              You peeled <span style={{ color:"var(--warm)", fontWeight:700 }}>{layers.length} layer{layers.length !== 1 ? "s" : ""}</span> deep
              {layers.length >= 3 && <span style={{ color:"var(--warm)" }}> · Good work</span>}
              {sessions.length > 0 && <span style={{ color:"var(--text4)" }}> · Session {sessions.length}</span>}
            </div>
          </div>
          {purposeResult.deeper_note && (
            <div style={{ padding:"10px 14px", background:"rgba(201,168,76,.05)", border:"1px solid rgba(201,168,76,.15)", borderRadius:7, marginBottom:10 }}>
              <div style={{ fontSize:10, fontWeight:700, letterSpacing:1.5, textTransform:"uppercase", color:"var(--warm)", marginBottom:4 }}>Since last time</div>
              <div style={{ fontFamily:"var(--serif)", fontSize:13, fontStyle:"italic", color:"var(--text2)", lineHeight:1.6 }}>{purposeResult.deeper_note}</div>
            </div>
          )}

          <StepHeader n={1} label="Read" title="Here's what surfaced. Read it back to yourself." headerRef={step1Ref} />
          <div onMouseDown={() => { if (activeStep < 1) setActiveStep(1); }}
            style={{ paddingLeft:14, borderLeft: activeStep === 1 ? "2px solid var(--warm)" : "2px solid rgba(201,168,76,0.25)", marginBottom:6, transition:"border-color .25s ease" }}>
            <ResultCard color="#34d399" label="What is working">{purposeResult.working}</ResultCard>
            {purposeResult.verbs && (
              <div style={{ padding:"11px 14px", background:"var(--bg3)", borderLeft:"2px solid var(--warm)", borderRadius:"0 7px 7px 0", marginBottom:7 }}>
                <div style={{ fontSize:10, fontWeight:700, letterSpacing:1.5, textTransform:"uppercase", color:"var(--warm)", marginBottom:7 }}>Your verbs</div>
                <div style={{ display:"flex", gap:7, flexWrap:"wrap" }}>
                  {purposeResult.verbs.map((v, i) => <div key={i} style={{ padding:"4px 13px", background:"rgba(201,168,76,.1)", border:"1px solid rgba(201,168,76,.25)", borderRadius:20, fontFamily:"var(--serif)", fontSize:14, fontStyle:"italic", color:"var(--warm)" }}>{v}</div>)}
                </div>
              </div>
            )}
            <div style={{ padding:"14px 16px", background:"rgba(201,168,76,.05)", border:"1px solid rgba(201,168,76,.22)", borderRadius:9, marginBottom:7 }}>
              <div style={{ fontSize:10, fontWeight:700, letterSpacing:1.5, textTransform:"uppercase", color:"var(--warm)", marginBottom:8 }}>A purpose statement to consider</div>
              <div style={{ fontFamily:"var(--serif)", fontSize:18, fontStyle:"italic", fontWeight:400, color:"var(--text)", lineHeight:1.6, marginBottom:3 }}>"{purposeResult.draft || ""}"</div>
              <div style={{ fontSize:11, color:"var(--text4)" }}>Starting point -- not a verdict. You'll edit it in Step 2.</div>
            </div>
            {purposeResult.refining_question && (
              <div style={{ padding:"11px 14px", background:"var(--bg2)", border:"1px solid var(--border2)", borderRadius:7 }}>
                <div style={{ fontSize:10, fontWeight:700, letterSpacing:1.5, textTransform:"uppercase", color:"var(--text4)", marginBottom:4 }}>A question to sit with</div>
                <div style={{ fontFamily:"var(--serif)", fontSize:14, fontStyle:"italic", color:"var(--text2)", lineHeight:1.6 }}>{purposeResult.refining_question}</div>
              </div>
            )}
          </div>

          <StepHeader n={2} label="Refine" title="Make it yours. Edit until it sounds like you say it out loud." headerRef={step2Ref} />
          <div onMouseDown={() => setActiveStep(s => s < 2 ? 2 : s)}
            style={{ paddingLeft:14, borderLeft: activeStep === 2 ? "2px solid var(--warm)" : "2px solid rgba(201,168,76,0.25)", transition:"border-color .25s ease" }}>
            <div style={{ fontFamily:"var(--sans)", fontSize:12, color:"var(--text3)", marginBottom:8, lineHeight:1.5 }}>Short enough to say in the car. True enough to feel it.</div>
            <textarea value={purposeFinal}
              onChange={e => { onFinalChange(e.target.value); if (confirmedNow) { setConfirmedNow(false); setActiveStep(2); } }}
              rows={2}
              placeholder="My purpose is to..."
              style={{ width:"100%", background:"var(--bg4)", border:"1px solid var(--border2)", borderRadius:10, color:"var(--warm)", fontFamily:"var(--serif)", fontSize:17, fontStyle:"italic", fontWeight:400, lineHeight:1.7, padding:"12px 14px", outline:"none", resize:"none" }}
              onFocus={e => { setActiveStep(2); if (confirmedNow) setConfirmedNow(false); e.target.style.borderColor = "var(--warm)"; e.target.style.boxShadow = "0 0 0 3px rgba(201,168,76,0.12)"; }}
              onBlur={e => { e.target.style.borderColor = "var(--border2)"; e.target.style.boxShadow = "none"; }}
            />
          </div>

          <StepHeader n={3} label="Own it" title="Read your statement back to yourself. Does it actually land?" />
          <div onMouseDown={() => setActiveStep(s => s < 3 ? 3 : s)} onFocus={() => setActiveStep(s => s < 3 ? 3 : s)}
            style={{ paddingLeft:14, borderLeft: activeStep === 3 ? "2px solid var(--warm)" : "2px solid rgba(201,168,76,0.25)", transition:"border-color .25s ease" }}>
            <div style={{ fontFamily:"var(--sans)", fontSize:12, color:"var(--text3)", marginBottom:4, lineHeight:1.5 }}>Score how it feels in your body, whether it lights you up, and whether it sounds like what you're meant to do. Then confirm.</div>
            <OwnItCheck context="purpose feedback" storageKey="ownit_purpose"
              onComplete={r => {
                const yes = !!(r && r.confirmed);
                setConfirmedNow(yes);
                if (yes) {
                  setActiveStep(4);
                } else {
                  setActiveStep(2);
                  setTimeout(() => step2Ref.current?.scrollIntoView({ behavior: "smooth", block: "start" }), 60);
                }
              }}
              purposeFinal={purposeFinal} onFinalChange={onFinalChange} />
          </div>

          {confirmedNow && (
            <div className="fade-in" style={{ marginTop:18, padding:"16px 18px", background:"linear-gradient(135deg, rgba(52,211,153,.12), rgba(52,211,153,.04))", border:"1px solid rgba(52,211,153,.4)", borderRadius:12 }}>
              <div style={{ display:"flex", alignItems:"center", gap:9, marginBottom:6 }}>
                <span style={{ fontSize:18, color:"#34d399" }}>✓</span>
                <div style={{ fontFamily:"var(--sans)", fontSize:12, fontWeight:700, letterSpacing:1.5, textTransform:"uppercase", color:"#34d399" }}>Purpose locked in</div>
              </div>
              <div style={{ fontFamily:"var(--serif)", fontSize:15, fontStyle:"italic", color:"var(--text2)", lineHeight:1.6, marginBottom:12 }}>"{purposeFinal}"</div>
              {onContinueToNext && (
                <button onClick={onContinueToNext}
                  style={{ width:"100%", padding:"11px 18px", background:"#34d399", border:"1px solid #34d399", borderRadius:9, color:"#0a1f17", cursor:"pointer", fontFamily:"var(--sans)", fontSize:13, fontWeight:700, letterSpacing:0.3, transition:"all .2s", boxShadow:"0 3px 10px rgba(52,211,153,0.25)" }}
                  onMouseEnter={e => { e.currentTarget.style.background = "#2bc189"; e.currentTarget.style.borderColor = "#2bc189"; }}
                  onMouseLeave={e => { e.currentTarget.style.background = "#34d399"; e.currentTarget.style.borderColor = "#34d399"; }}>
                  Continue to Direction → Your BAG  →
                </button>
              )}
            </div>
          )}

          <div style={{ marginTop:18 }}>
            <button onClick={() => setLivingOpen(o => !o)}
              style={{ width:"100%", display:"flex", alignItems:"center", justifyContent:"space-between", gap:10, padding:"9px 14px", background:"none", border:"1px solid var(--border)", borderRadius:8, cursor:"pointer", fontFamily:"var(--sans)", fontSize:11, color:"var(--text4)", textAlign:"left" }}>
              <span><span style={{ marginRight:8 }}>↻</span>This is a living exercise -- you can peel again anytime</span>
              <span style={{ fontSize:10, opacity:0.7 }}>{livingOpen ? "▴" : "▾"}</span>
            </button>
            {livingOpen && (
              <div className="fade-in" style={{ marginTop:8, padding:"12px 14px", background:"var(--bg2)", border:"1px solid var(--border2)", borderRadius:9 }}>
                <div style={{ fontFamily:"var(--sans)", fontSize:12, color:"var(--text3)", lineHeight:1.7, marginBottom:10 }}>Purpose is not always found in a single sitting. Return when you have fresh eyes -- days, weeks, or even months later. Your previous sessions are saved and Katherine will read them alongside your new answers, tracking how you are going deeper each time.</div>
                <button onClick={restartPeeling}
                  style={{ background:"none", border:"1px solid var(--border2)", borderRadius:20, color:"var(--text2)", cursor:"pointer", fontFamily:"var(--sans)", fontSize:12, fontWeight:500, padding:"7px 16px" }}
                  onMouseEnter={e => { e.currentTarget.style.borderColor = "var(--warm)"; e.currentTarget.style.color = "var(--warm)"; }}
                  onMouseLeave={e => { e.currentTarget.style.borderColor = "var(--border2)"; e.currentTarget.style.color = "var(--text2)"; }}>
                  ↩ Go deeper -- peel again
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
function ResultCard({ color, label, children, serif }) {
  return (
    <div style={{ padding:"9px 13px", background:"var(--bg3)", borderLeft:`2px solid ${color}`, borderRadius:"0 7px 7px 0", marginBottom:7 }}>
      <div style={{ fontSize:11, fontWeight:700, letterSpacing:1.5, textTransform:"uppercase", color, marginBottom:4 }}>{label}</div>
      <div style={serif ? { fontFamily:"var(--serif)", fontSize:16, fontStyle:"italic", fontWeight:300, color:"var(--text)", lineHeight:1.6 } : { fontSize:13, color:"var(--text)", lineHeight:1.55 }}>{children}</div>
    </div>
  );
}
function MirrorCard({ card, isOpen, onToggle, onGoto }) {
  return (
    <div onClick={() => onToggle(card.id)} style={{ background:isOpen ? card.colorMuted : "var(--bg3)", border:`1px solid ${isOpen ? card.colorBorder : "var(--border2)"}`, borderRadius:10, cursor:"pointer", transition:"background .22s, border-color .22s", overflow:"hidden", marginBottom:7, minHeight:80 }}>
      <div style={{ padding:"11px 14px", display:"flex", alignItems:"center", gap:9 }}>
        <span style={{ fontSize:16, lineHeight:1, flexShrink:0 }}>{card.icon}</span>
        <div style={{ flex:1, minWidth:0 }}>
          <div style={{ fontFamily:"var(--sans)", fontSize:13, fontWeight:500, color:isOpen ? card.color : "var(--text2)", transition:"color .2s", lineHeight:1.2 }}>{card.label}</div>
          <div style={{ fontFamily:"var(--sans)", fontSize:11, color:"var(--text4)", marginTop:2, lineHeight:1.3 }}>{card.tagline}</div>
        </div>
        <div style={{ fontSize:10, color:isOpen ? card.color : "var(--text4)", transition:"transform .2s, color .2s", transform:isOpen ? "rotate(180deg)" : "rotate(0deg)", flexShrink:0 }}>▾</div>
      </div>
      {isOpen && (
        <div className="fade-in" style={{ padding:"0 14px 14px" }}>
          <div style={{ height:1, background:card.colorBorder, marginBottom:12 }} />
          <div style={{ fontFamily:"var(--sans)", fontSize:13, color:"var(--text2)", lineHeight:1.75, marginBottom:12 }}>{card.description}</div>
          <div style={{ padding:"10px 13px", background:"var(--bg4)", borderLeft:`2px solid ${card.colorBorder}`, borderRadius:"0 7px 7px 0", marginBottom:12 }}>
            <div style={{ fontFamily:"var(--serif)", fontSize:13, fontStyle:"italic", color:"var(--text3)", lineHeight:1.7 }}>{card.katherine}</div>
          </div>
          <button onClick={(e) => { e.stopPropagation(); onGoto(card.pair); }} style={{ background:"none", border:`1px solid ${card.colorBorder}`, borderRadius:20, color:card.color, cursor:"pointer", fontFamily:"var(--sans)", fontSize:11, fontWeight:500, padding:"5px 14px" }}>Go to this section →</button>
        </div>
      )}
    </div>
  );
}
const MirrorIntroCards = React.memo(function MirrorIntroCards({ goto }) {
  const [expanded, setExpanded] = useState(null);
  const toggle = useCallback((id) => setExpanded(prev => prev === id ? null : id), []);
  const internal = MIRROR_CARDS.filter(c => c.side === "internal");
  const external = MIRROR_CARDS.filter(c => c.side === "external");
  return (
    <div style={{ padding:"17px 20px", background:"var(--bg2)", border:"1px solid var(--border)", borderRadius:11, marginBottom:24 }}>
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:14 }}>
        <div style={{ fontSize:10, fontWeight:500, letterSpacing:2, textTransform:"uppercase", color:"var(--text4)", fontFamily:"var(--sans)" }}>The Mirror Structure</div>
        <div style={{ fontSize:11, color:"var(--text4)", fontFamily:"var(--sans)", fontStyle:"italic" }}>Tap any card to learn more</div>
      </div>
      <div style={{ display:"grid", gridTemplateColumns:"1fr 30px 1fr", gap:0, alignItems:"start" }}>
        <div>
          <div style={{ fontSize:10, fontWeight:500, letterSpacing:1.5, textTransform:"uppercase", color:"var(--warm)", fontFamily:"var(--sans)", marginBottom:9, paddingLeft:2 }}>Internal</div>
          {internal.map(card => <MirrorCard key={card.id} card={card} isOpen={expanded === card.id} onToggle={toggle} onGoto={goto} />)}
        </div>
        <div style={{ display:"flex", flexDirection:"column", alignItems:"center", paddingTop:26 }}>
          <div style={{ width:1, height:24, background:"var(--border)", opacity:0.5 }} />
          <div style={{ fontSize:14, color:"var(--text4)", margin:"4px 0" }}>🪞</div>
          <div style={{ width:1, flex:1, background:"var(--border)", opacity:0.5 }} />
        </div>
        <div>
          <div style={{ fontSize:10, fontWeight:500, letterSpacing:1.5, textTransform:"uppercase", color:"var(--accent)", fontFamily:"var(--sans)", marginBottom:9, paddingLeft:2 }}>External</div>
          {external.map(card => <MirrorCard key={card.id} card={card} isOpen={expanded === card.id} onToggle={toggle} onGoto={goto} />)}
        </div>
      </div>
      <div style={{ marginTop:14, paddingTop:12, borderTop:"1px solid var(--border)", display:"flex", gap:8, flexWrap:"wrap" }}>
        {[{ left:"Purpose", right:"Direction", color:"#c9a84c" }, { left:"Identity", right:"Superpowers", color:"#c9a84c" }, { left:"Values", right:"Behaviors", color:"#34d399" }].map(p => (
          <div key={p.left} style={{ display:"flex", alignItems:"center", gap:5, padding:"4px 10px", background:"var(--bg3)", border:"1px solid var(--border)", borderRadius:20 }}>
            <div style={{ width:5, height:5, borderRadius:"50%", background:p.color, flexShrink:0 }} />
            <span style={{ fontFamily:"var(--sans)", fontSize:11, color:"var(--text4)" }}>{p.left}</span>
            <span style={{ fontFamily:"var(--sans)", fontSize:10, color:"var(--text4)" }}>🪞</span>
            <span style={{ fontFamily:"var(--sans)", fontSize:11, color:"var(--text4)" }}>{p.right}</span>
          </div>
        ))}
      </div>
    </div>
  );
});
const STOP_WORDS = new Set(["i","a","an","the","and","or","but","in","on","at","to","for","of","with","it","is","are","was","were","be","been","being","have","has","had","do","does","did","will","would","could","should","may","might","this","that","these","those","my","your","their","our","what","how","when","where","who","which","not","no","so","as","if","by","from","up","about","into","than","then","its","me","him","her","us","them","can","get","got","just","also","very","more","most","some","any","all","both","each","few","much","many","other","own","same","too","only","over","such","even","after","before","there","here","out","one","two","three","way","time","day","make","made","like","go","come","know","take","see","think","really","actually","show","shows","something","someone","things","thing","because","able","often","well","always","never","still","yet","already","now","back","first","last","through","every","another","again","around","new","good","great","right","down","off","really","it's","i'm","don't","won't","isn't","wasn't","doesn't","didn't","can't","that's","they're","we're","you're"]);
function extractKeywords(text: string, n = 6): string[] {
  const words = text.toLowerCase().match(/\b[a-z]{4,}\b/g) || [];
  const freq: Record<string, number> = {};
  words.forEach(w => { if (!STOP_WORDS.has(w)) freq[w] = (freq[w] || 0) + 1; });
  return Object.entries(freq).sort((a, b) => b[1] - a[1]).slice(0, n).map(([w]) => w);
}
function CapAnimalCard({ animal, animalIdx, m2animals, set, map }) {
  const [isOpen, setIsOpen] = useState(false);
  const [collapsedCaps, setCollapsedCaps] = useState<Record<number,boolean>>({});
  const [chipInputs, setChipInputs] = useState<Record<number,string>>({});
  // Find true index in full m2animals array (chips use this index)
  const trueIdx = m2animals.findIndex(a => a.name === animal.name && a.name);
  const idx = trueIdx >= 0 ? trueIdx : animalIdx;
  // Build caps from assigned chips - source of truth
  const assignedChips = (map?.identity_chips || []).filter(c => c.assignedTo === idx);
  const existingCaps = animal.capabilities || [];
  const caps = assignedChips.length > 0
    ? assignedChips.map(chip => {
        const ex = existingCaps.find(c => c.name.toLowerCase() === chip.label.toLowerCase());
        return ex || { name: chip.label, description:"", example1:"", example2:"", score:7 };
      })
    : existingCaps.filter(c => c.name);
  const filledCaps = caps.filter(c => c.name);
  const avgScore = filledCaps.length > 0
    ? Math.round(filledCaps.reduce((sum, c) => sum + (c.score || 5), 0) / filledCaps.length * 10) / 10
    : null;
  const avgCol = avgScore == null ? "var(--text4)" : avgScore >= 7 ? "#34d399" : avgScore >= 5 ? "#f59e0b" : "#ef4444";
  const animalTitle = [animal.adj1, animal.adj2, animal.name].filter(Boolean).join(" ");
  const updateCap = (ci, field, val) => {
    const nextAnimals = [...m2animals];
    const nextCaps = [...caps];
    nextCaps[ci] = { ...nextCaps[ci], [field]: val };
    nextAnimals[animalIdx] = { ...nextAnimals[animalIdx], capabilities: nextCaps };
    set("animals", nextAnimals);
  };
  const addCap = () => {
    const nextAnimals = [...m2animals];
    const nextCaps = [...caps, { name:"", description:"", example1:"", example2:"", score:7 }];
    nextAnimals[animalIdx] = { ...nextAnimals[animalIdx], capabilities: nextCaps };
    set("animals", nextAnimals);
  };
  return (
    <div style={{ marginBottom:14, background:"var(--bg2)", border:"1px solid var(--border)", borderRadius:11, overflow:"hidden" }}>
      {/* Collapsible header */}
      <div style={{ display:"flex", alignItems:"center", gap:10, padding:"12px 16px" }}>
        <span style={{ fontFamily:"var(--serif)", fontSize:16, fontStyle:"italic", color:"var(--warm)", flex:1 }}>{animalTitle}</span>
        {avgScore != null && (
          <span style={{ fontSize:11, fontWeight:700, color:avgCol, padding:"2px 8px", background:`rgba(${avgCol === "#34d399" ? "52,211,153" : avgCol === "#f59e0b" ? "245,158,11" : "239,68,68"},.1)`, border:`1px solid ${avgCol}`, borderRadius:20, flexShrink:0 }}>
            avg {avgScore}/10
          </span>
        )}
        <div style={{ width:28, height:28, borderRadius:"50%", background: isOpen ? "rgba(201,168,76,.15)" : "var(--bg4)", border: `1px solid ${isOpen ? "rgba(201,168,76,.4)" : "var(--border2)"}`, display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0, transition:"all .2s", cursor:"pointer" }} onClick={() => setIsOpen(o => !o)}>
          <span style={{ fontSize:13, color: isOpen ? "var(--warm)" : "var(--text3)", transform: isOpen ? "rotate(180deg)" : "none", transition:"transform .2s", display:"block", lineHeight:1 }}>▾</span>
        </div>
      </div>
      {/* Collapsible body */}
      {isOpen && (
        <div style={{ padding:"0 14px 14px 14px" }}>
          {caps.map((cap, ci) => {
            const isCapOpen = !collapsedCaps[ci];
            const autoKw = cap.description ? extractKeywords(cap.description) : [];
            const supChips: string[] = cap.superpower_chips || [];
            const allChips = [...new Set([...autoKw, ...supChips])];
            const chipInput = chipInputs[ci] || "";
            const PRESET_SUP = ["decisive","clear-headed","visionary","strategic","innovative","empathetic","calm","focused","bold","precise","adaptive","inspiring","direct","perceptive","resilient","connected"];
            return (
              <div key={ci} style={{ marginBottom:9, background:"var(--bg3)", border:"1px solid var(--border2)", borderRadius:10, overflow:"hidden" }}>
                {/* Cap header row */}
                <div style={{ display:"flex", alignItems:"center", gap:10, padding:"10px 14px", cursor:"pointer" }}
                  onClick={() => setCollapsedCaps(p => ({ ...p, [ci]: !p[ci] }))}>
                  <div style={{ flex:1 }}>
                    <span style={{ fontSize:10, fontWeight:700, letterSpacing:1.5, textTransform:"uppercase", color:"var(--text4)" }}>Superpower {ci+1}</span>
                    {cap.name && <span style={{ fontSize:10, color:"var(--text3)", letterSpacing:1.5, textTransform:"uppercase" }}> · {cap.name}</span>}
                  </div>
                  <div style={{ width:24, height:24, borderRadius:"50%", background: isCapOpen ? "rgba(201,168,76,.15)" : "var(--bg4)", border: `1px solid ${isCapOpen ? "rgba(201,168,76,.4)" : "var(--border2)"}`, display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0, transition:"all .2s" }}>
                    <span style={{ fontSize:12, color: isCapOpen ? "var(--warm)" : "var(--text3)", transform: isCapOpen ? "rotate(180deg)" : "none", transition:"transform .2s", display:"block", lineHeight:1 }}>▾</span>
                  </div>
                </div>
                {/* Cap body */}
                {isCapOpen && (
                  <div style={{ padding:"0 14px 14px 14px" }}>
                    {/* Name */}
                    <div style={{ marginBottom:10 }}>
                      <label style={{ display:"block", fontSize:11, color:"var(--text3)", marginBottom:4, fontWeight:500 }}>Name this capability</label>
                      <TextInput value={cap.name || ""} onChange={v => updateCap(ci, "name", v)} placeholder="e.g. Strategic clarity under pressure" style={{ fontSize:13 }} />
                    </div>
                    {cap.name && (<>
                      {/* Field 1: Superpower description */}
                      <div style={{ marginBottom:8 }}>
                        <label style={{ display:"block", fontSize:11, color:"var(--warm)", marginBottom:4, fontWeight:600 }}>Describe it in your own words when it's your superpower</label>
                        <TextArea value={cap.description || ""} onChange={v => updateCap(ci, "description", v)} rows={2} placeholder="What does this capability actually enable? How does it show up at its best?" style={{ fontSize:13 }} />
                      </div>
                {/* Field 2: Superpower keyword chips */}
                <div style={{ marginBottom:12 }}>
                  <label style={{ display:"block", fontSize:11, color:"var(--warm)", marginBottom:4, fontWeight:500 }}>
                    Superpower keywords — tap to add, × to remove
                  </label>
                  <div style={{ fontSize:11, color:"var(--text3)", marginBottom:6 }}>Choose words that describe this capability at its best.</div>
                  {/* Preset chips */}
                  <div style={{ display:"flex", flexWrap:"wrap", gap:5, marginBottom:8 }}>
                    {PRESET_SUP.map((word: string) => {
                      const on = supChips.includes(word);
                      return (
                        <button key={word}
                          onClick={() => updateCap(ci, "superpower_chips", on ? supChips.filter((w:string) => w !== word) : [...supChips, word])}
                          style={{ display:"inline-flex", alignItems:"center", gap:4, fontSize:11, padding:"3px 10px", borderRadius:20, border:`1px solid ${on ? "rgba(201,168,76,.7)" : "var(--border2)"}`, background: on ? "rgba(201,168,76,.18)" : "transparent", color: on ? "var(--warm)" : "var(--text3)", cursor:"pointer", fontFamily:"var(--sans)", transition:"all .15s" }}>
                          {on && <span onClick={e => { e.stopPropagation(); updateCap(ci, "superpower_chips", supChips.filter((w:string) => w !== word)); }} style={{ fontWeight:700, fontSize:10, opacity:.7 }}>×</span>}
                          {word}
                        </button>
                      );
                    })}
                    {/* Custom chips */}
                    {supChips.filter((w:string) => !PRESET_SUP.includes(w)).map((word:string) => (
                      <button key={word}
                        style={{ display:"inline-flex", alignItems:"center", gap:4, fontSize:11, padding:"3px 10px", borderRadius:20, border:"1px solid rgba(201,168,76,.7)", background:"rgba(201,168,76,.18)", color:"var(--warm)", cursor:"pointer", fontFamily:"var(--sans)" }}>
                        <span onClick={() => updateCap(ci, "superpower_chips", supChips.filter((w2:string) => w2 !== word))} style={{ fontWeight:700, fontSize:10, opacity:.7 }}>×</span>
                        {word}
                      </button>
                    ))}
                  </div>
                  {/* Add custom word */}
                  <div style={{ display:"flex", gap:5, marginBottom:4 }}>
                    <input value={chipInputs[ci] || ""} onChange={e => setChipInputs(p => ({ ...p, [ci]: e.target.value }))}
                      onKeyDown={e => { if (e.key === "Enter" && (chipInputs[ci]||"").trim()) { updateCap(ci, "superpower_chips", [...supChips, (chipInputs[ci]||"").trim()]); setChipInputs(p => ({ ...p, [ci]: "" })); }}}
                      placeholder="Add a keyword…" style={{ flex:1, fontSize:11, padding:"4px 9px", borderRadius:6, border:"1px solid var(--border2)", background:"var(--bg4)", color:"var(--text)", fontFamily:"var(--sans)" }} />
                    <button onClick={() => { const v=(chipInputs[ci]||"").trim(); if(v){ updateCap(ci,"superpower_chips",[...supChips,v]); setChipInputs(p=>({...p,[ci]:""})); }}}
                      style={{ fontSize:11, padding:"4px 10px", borderRadius:6, border:"1px solid rgba(201,168,76,.3)", background:"rgba(201,168,76,.1)", color:"var(--warm)", cursor:"pointer", fontFamily:"var(--sans)" }}>Add</button>
                  </div>
                </div>
                      {/* Field 3: Example 1 */}
                      <div style={{ marginBottom:9 }}>
                        <label style={{ display:"block", fontSize:11, color:"var(--text3)", marginBottom:4, fontWeight:500 }}>Example 1 — a real time you demonstrated this</label>
                        <TextArea value={cap.example1 || ""} onChange={v => updateCap(ci, "example1", v)} rows={2} placeholder="A specific moment — what happened, what did you do?" style={{ fontSize:13 }} />
                      </div>
                      {/* Field 4: Example 2 */}
                      <div style={{ marginBottom:4 }}>
                        <label style={{ display:"block", fontSize:11, color:"var(--text3)", marginBottom:4, fontWeight:500 }}>Example 2 — another real moment</label>
                        <TextArea value={cap.example2 || ""} onChange={v => updateCap(ci, "example2", v)} rows={2} placeholder="Another specific moment — different context if possible" style={{ fontSize:13 }} />
                      </div>
                    </>)}
                  </div>
                )}
              </div>
            );
          })}
          {caps.length < 5 && (
            <button onClick={addCap} style={{ width:"100%", padding:"9px", background:"transparent", border:"1.5px dashed var(--border2)", borderRadius:7, color:"var(--text4)", cursor:"pointer", fontFamily:"var(--sans)", fontSize:12 }}>
              + Add capability
            </button>
          )}
        </div>
      )}
    </div>
  );
}
function A1({ intake, onDone, phase, setPhase }) {
  const [step, setStep] = useState("to_intro");
  const [voice, setVoice] = useState(intake.defaultVoice);
  const [done, setDone] = useState([]);
  const [map, setMap] = useState(EMPTY_MAP);
  const [ai, setAi] = useState({});
  const [busy, setBusy] = useState({});
  const [savedAt, setSavedAt] = useState(null);
  const [chipInput, setChipInput] = useState("");
  const [dragOver, setDragOver] = useState(null);
  const [spineHoverRow, setSpineHoverRow] = useState(null);
  const saveTimer = useRef(null);
  const { name } = intake;
  useEffect(() => {
    Promise.all([loadData(KEYS.map), loadData(KEYS.done), loadData(KEYS.step), loadData(KEYS.voice)]).then(([m, d, s, v]) => {
      if (m) setMap({ ...EMPTY_MAP, ...m });
      if (d) setDone(d);
      if (s === "map") {
        saveData("to_mapofme_origin", "a1");
        saveData(KEYS.step, "to_intro");
        setPhase("_mapofme");
      } else if (s) setStep(s);
      if (v) setVoice(v);
    });
  }, []);
  const saveMap = useCallback((next) => {
    clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(async () => { await saveData(KEYS.map, next); setSavedAt(new Date()); }, 800);
  }, []);
  const set = useCallback((key, val) => {
    setMap(prev => { const next = { ...prev, [key]:val }; saveMap(next); return next; });
  }, [saveMap]);
  // Auto-seed capabilities from chips when entering capabilities step
  useEffect(() => {
    if (map.mirror2_sub !== "capabilities") return;
    const animals = map.animals || [];
    const chips = map.identity_chips || [];
    if (!chips.length) return;
    let changed = false;
    const nextAnimals = animals.map((animal, i) => {
      if ((animal.capabilities || []).some(c => c.name)) return animal;
      const assigned = chips.filter(c => c.assignedTo === i);
      if (!assigned.length) return animal;
      changed = true;
      return { ...animal, capabilities: assigned.map(ch => ({ name: ch.label, description:"", example1:"", example2:"", score:7 })) };
    });
    if (!changed) return;
    const next = { ...map, animals: nextAnimals };
    setMap(next);
    saveMap(next);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [map.mirror2_sub]);
  const setVoicePersist = (v) => { setVoice(v); saveData(KEYS.voice, v); };
  const goto = (s) => { setStep(s); saveData(KEYS.step, s); window.scrollTo({ top:0, behavior:"smooth" }); };
  const markDone = (s) => setDone(prev => { const n = [...new Set([...prev, s])]; saveData(KEYS.done, n); return n; });
  const runAI = async (key, prompt) => { setBusy(b => ({ ...b, [key]:true })); const r = await callStructured(prompt); setAi(a => ({ ...a, [key]:r })); setBusy(b => ({ ...b, [key]:false })); };
  const hdr = (
    <div style={{ borderBottom:"1px solid #1a1a16", padding:"11px 28px", display:"flex", justifyContent:"space-between", alignItems:"center", position:"sticky", top:0, background:"rgba(13,27,46,.96)", backdropFilter:"blur(12px)", zIndex:50 }}>
      <div style={{ display:"flex", alignItems:"center", gap:11 }}>
        <div style={{ width:6, height:6, borderRadius:"50%", background:"var(--warm)", animation:"pulse 3s ease-in-out infinite" }} />
        <div style={{ fontFamily:"var(--sans)", fontSize:13, fontWeight:700 }}>True Ownership™</div>
        <div style={{ fontFamily:"var(--sans)", fontSize:12, color:"var(--text4)" }}>· {name}</div>
      </div>
      <div style={{ display:"flex", alignItems:"center", gap:12 }}>
        <div style={{ display:"flex", alignItems:"center", gap:5, opacity:savedAt ? 1 : 0, transition:"opacity .4s" }}>
          <div style={{ width:5, height:5, borderRadius:"50%", background:"#34d399" }} />
          <span style={{ fontFamily:"var(--sans)", fontSize:11, color:"#34d399" }}>{savedAt ? `Saved ${savedAt.toLocaleTimeString([], { hour:"2-digit", minute:"2-digit" })}` : ""}</span>
        </div>
        <div style={{ display:"flex", gap:5 }}>
          {["A1","A2","A3","A4","A5"].map((a, i) => {
            const key = a.toLowerCase();
            const isActive = phase === key;
            const isAvailable = key === "a1" || key === "a2" || key === "a3" || phase === "done";
            return (
              <div key={a}
                onClick={() => { if (isAvailable) setPhase(key); }}
                title={isAvailable ? (isActive ? `You are in ${a}` : `Jump to ${a}`) : `${a} coming soon`}
                style={{ width:25, height:25, borderRadius:"50%", background: isActive ? "rgba(201,168,76,.18)" : "transparent", border:`1px solid ${isActive ? "rgba(232,149,109,.55)" : "var(--border)"}`, display:"flex", alignItems:"center", justifyContent:"center", cursor: isAvailable ? "pointer" : "not-allowed", opacity: isAvailable ? 1 : 0.4, transition:"background .15s, border-color .15s" }}>
                <span style={{ fontFamily:"var(--sans)", fontSize:10, color: isActive ? "var(--warm)" : "var(--text4)", fontWeight: isActive ? 700 : 500 }}>{a}</span>
              </div>
            );
          })}
        </div>
        <AdminBar phase={phase} onAdminClick={() => setPhase("_admin")} mode="inline" />
        <AccountMenu mode="inline" />
      </div>
    </div>
  );
  const sidebar = (
    <div style={{ width:186, flexShrink:0, paddingRight:22, borderRight:"1px solid var(--border)" }}>
      <div style={{ fontSize:11, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color:"var(--text2)", marginBottom:15, fontFamily:"var(--sans)" }}>All In It · A1</div>
      {STEPS.filter(s => s.id !== "direction_align" && s.id !== "align").map(s => {
        const autoDone = (s.id === "intro"  && (((map.purpose_layers || [])[0] || "").trim() || step !== "intro")) ||
                         (s.id === "mirror2" && (map.animals?.length >= 1 && map.animals[0]?.name));
        const active = step === s.id, isDone = done.includes(s.id) || !!autoDone;
        return (
          <button key={s.id} className={`sidebar-btn${active ? " active" : ""}`} onClick={() => {
            if (s.id === "map") { saveData("to_mapofme_origin", "a1"); setPhase("_mapofme"); return; }
            if (s.id === "mirror1") set("mirror1_sub", "purpose"); goto(s.id);
          }}>
            <div style={{ width:7, height:7, borderRadius:"50%", background:isDone ? "#34d399" : active ? "var(--warm)" : "var(--border2)", flexShrink:0, transition:"background .3s" }} />
            <span style={{ fontSize:12, color:active ? "var(--warm)" : isDone ? "var(--text)" : "var(--text2)", fontWeight:active ? 500 : 400, lineHeight:1.3 }}>{s.label}</span>
          </button>
        );
      })}
      <div style={{ marginTop:18, paddingTop:14, borderTop:"1px solid var(--border)" }}>
        <div style={{ fontSize:10, fontWeight:500, letterSpacing:2, textTransform:"uppercase", color:"var(--text4)", marginBottom:7, fontFamily:"var(--sans)" }}>Voice</div>
        <VoiceDropdown voiceId={voice} onSelect={setVoicePersist} />
      </div>
    </div>
  );
  const wrapContent = (children) => (
    <>
      {hdr}
      <div style={{ display:"flex", gap:32, padding:"32px 28px 80px", maxWidth:980, margin:"0 auto" }}>
        {sidebar}
        <div style={{ flex:1, minWidth:0 }} className="fade-up">{children}</div>
      </div>
      <div style={{ position:"fixed", bottom:42, left:0, right:0, background:"var(--bg2)", borderTop:"1px solid var(--border2)", padding:"8px 28px", display:"flex", alignItems:"center", justifyContent:"space-between", zIndex:40 }}>
        <div style={{ display:"flex", alignItems:"center", gap:8 }}>
          {savedAt ? (<><div style={{ width:6, height:6, borderRadius:"50%", background:"#34d399", flexShrink:0 }} /><span style={{ fontFamily:"var(--sans)", fontSize:11, color:"#34d399" }}>Auto-saved · {savedAt.toLocaleTimeString([], { hour:"2-digit", minute:"2-digit" })}</span></>) : (<><div style={{ width:6, height:6, borderRadius:"50%", background:"var(--text4)", flexShrink:0 }} /><span style={{ fontFamily:"var(--sans)", fontSize:11, color:"var(--text4)" }}>Auto-saving your answers as you type</span></>)}
        </div>
        <span style={{ fontFamily:"var(--sans)", fontSize:11, color:"var(--text4)" }}>Your progress is safe -- come back any time</span>
      </div>
    </>
  );
  if (step === "direction_1yr") {
    return wrapContent(<>
      <DirectionTimeline_v2 activeHorizon="oneyr" map={map} />
      <div className="lbl" style={{ marginBottom:12 }}>Direction · 1-YEAR</div>
      <h2 style={{ fontFamily:"var(--serif)", fontSize:34, fontWeight:400, lineHeight:1.2, marginBottom:7, letterSpacing:"-0.3px" }}>
        1-YEAR · {new Date().getFullYear() + 1}
      </h2>
      <p style={{ fontSize:16, color:"var(--text2)", lineHeight:1.75, marginBottom:20, maxWidth:560 }}>
        Closest horizon. This is what you can commit to. Your 1-year Growth draws
        from your Identity &amp; Values alignment -- the lowest-scoring items surface below as suggestions.
      </p>
      <OneYearPage map={map} set={set} voiceId={voice} name={name} intake={intake} />
      <div style={{ marginBottom:22, marginTop:18 }}>
        <AIChat voiceId={voice} onVoiceChange={setVoicePersist} name={name} intake={intake} mapData={map}
          sectionLabel="1-year direction"
          placeholder="Ask Katherine about your 1-year commitments..." />
      </div>
      <div style={{ display:"flex", justifyContent:"space-between", paddingTop:18, borderTop:"1px solid var(--border)" }}>
        <button className="btn-g" onClick={() => goto("mirror3")}>← Values · Behaviors</button>
        <button className="btn" onClick={() => { markDone("direction_1yr"); saveData("to_mapofme_origin", "a1"); setPhase("_mapofme"); }}>My Map of Me™ →</button>
      </div>
    </>);
  }
  if (step === "direction_align") {
    return wrapContent(<>
      <DirectionTimeline_v2 map={map} />
      <div className="lbl" style={{ marginBottom:12 }}>Direction Alignment</div>
      <h2 style={{ fontFamily:"var(--serif)", fontSize:34, fontWeight:400, lineHeight:1.2, marginBottom:7, letterSpacing:"-0.3px" }}>
        Direction Alignment
      </h2>
      <p style={{ fontSize:16, color:"var(--text2)", lineHeight:1.75, marginBottom:20, maxWidth:560 }}>
        You've built your ladder. Now score TODAY's reality against each horizon.
        The further the horizon, the bigger the gap should be -- unless something's misaligned.
      </p>
      <DirectionAlignmentPage map={map} set={set} />
      <div style={{ marginBottom:22, marginTop:18 }}>
        <AIChat voiceId={voice} onVoiceChange={setVoicePersist} name={name} intake={intake} mapData={map}
          sectionLabel="direction alignment"
          placeholder="Ask Katherine about the gaps between today and your direction..." />
      </div>
      <div style={{ display:"flex", justifyContent:"space-between", paddingTop:18, borderTop:"1px solid var(--border)" }}>
        <button className="btn-g" onClick={() => goto("direction_1yr")}>← Direction · 1-YEAR</button>
        <button className="btn" onClick={() => { markDone("direction_align"); saveData("to_mapofme_origin", "a1"); setPhase("_mapofme"); }}>My Map of Me™ →</button>
      </div>
    </>);
  }
  if (step === "to_intro") return wrapContent(<>
    <div className="lbl" style={{ marginBottom:11, color:"#B07312" }}>AG45™ · The OWN IT™ Methodology</div>
    <h2 style={{ fontFamily:"var(--serif)", fontSize:42, fontWeight:400, lineHeight:1.05, marginBottom:16, letterSpacing:"-0.5px" }}>
      You are the spine.<br /><em style={{ color:"#1D9E75" }}>How aligned are you?</em>
    </h2>
    <p style={{ fontSize:15, color:"var(--text2)", lineHeight:1.7, marginBottom:14, maxWidth:620 }}>
      The 5As™ are the spine of True Ownership. Move through each one &mdash; first as the owner you are becoming, then as the business you are building.
    </p>
    {/* True Ownership destination banner */}
    <div style={{ background:"linear-gradient(135deg,#12163A 0%,#0A2E22 100%)", borderRadius:16, padding:"22px 26px", textAlign:"center", color:"#fff", border:"1px solid rgba(186,117,23,0.35)", position:"relative", overflow:"hidden", margin:"18px 0 16px" }}>
      <div style={{ position:"absolute", top:0, left:0, right:0, height:2, background:"linear-gradient(90deg,#1B1F4B,#B07312,#0F6E56)" }} />
      <div style={{ fontSize:9, letterSpacing:"0.24em", textTransform:"uppercase", color:"#FAC775", marginBottom:6, fontWeight:700 }}>The destination &middot; When both sides align</div>
      <div style={{ fontFamily:"var(--serif)", fontSize:"1.6rem", fontWeight:700, color:"#fff", marginBottom:8, lineHeight:1.1 }}>True Ownership™</div>
      <div style={{ fontSize:13, opacity:0.82, lineHeight:1.65, maxWidth:540, margin:"0 auto 12px" }}>
        Not the owner alone. Not the business alone. When you as the owner <em>and</em> your business are fully aligned &mdash; that is True Ownership. Soul Aligned Strategy™, fully lived.
      </div>
      <div style={{ display:"flex", alignItems:"center", justifyContent:"center", gap:8, flexWrap:"wrap" }}>
        <div style={{ background:"rgba(255,255,255,0.1)", border:"0.5px solid rgba(255,255,255,0.25)", borderRadius:6, padding:"4px 12px", fontSize:11, fontWeight:500 }}>OWN IT™</div>
        <span style={{ fontSize:13, opacity:0.5 }}>+</span>
        <div style={{ background:"rgba(255,255,255,0.1)", border:"0.5px solid rgba(255,255,255,0.25)", borderRadius:6, padding:"4px 12px", fontSize:11, fontWeight:500 }}>Leader-Run Business</div>
        <span style={{ fontSize:13, color:"#FAC775", fontWeight:500 }}>=</span>
        <span style={{ fontFamily:"var(--serif)", fontSize:13, fontWeight:700, color:"#FAC775", borderBottom:"1px solid rgba(186,117,23,0.5)", paddingBottom:1 }}>True Ownership</span>
      </div>
    </div>
    {/* Guidance strip */}
    <div style={{ margin:"14px 0 12px", display:"flex", alignItems:"center", justifyContent:"center", gap:14, padding:"10px 16px", background:"var(--bg2)", border:"1px dashed var(--border2)", borderRadius:12, fontSize:12, color:"var(--text2)", flexWrap:"wrap" }}>
      <span style={{ display:"flex", alignItems:"center", gap:6, fontWeight:500, color:"#B07312", letterSpacing:"0.04em" }}>
        <span>CLICK A ROW</span><span>&rarr;</span><span>SEE BOTH SIDES</span>
      </span>
      <span style={{ fontStyle:"italic", fontSize:12.5, color:"var(--text3)" }}>Each row pairs Owner (left) and Business (right). Click anywhere on a row to open both.</span>
    </div>
    {/* Open all / Collapse all toggle */}
    {(() => {
      const allOpen = [1,2,3,4,5].every((n) => !!map?.[`to_intro_o${n}_open`] && !!map?.[`to_intro_b${n}_open`]);
      const toggleAllRows = () => {
        const updates: Record<string, boolean> = {};
        for (const n of [1,2,3,4,5]) {
          updates[`to_intro_o${n}_open`] = !allOpen;
          updates[`to_intro_b${n}_open`] = !allOpen;
        }
        setMap(prev => { const next = { ...prev, ...updates }; saveMap(next); return next; });
      };
      return (
        <div style={{ display:"flex", justifyContent:"flex-end", marginBottom:8 }}>
          <button onClick={toggleAllRows}
            style={{ background:"transparent", border:"1px solid var(--border2)", borderRadius:6, padding:"5px 11px", fontFamily:"var(--sans)", fontSize:11, color:"var(--text3)", cursor:"pointer", letterSpacing:"0.04em" }}
            onMouseOver={(e) => { e.currentTarget.style.color = "var(--text)"; e.currentTarget.style.borderColor = "var(--border)"; }}
            onMouseOut={(e) => { e.currentTarget.style.color = "var(--text3)"; e.currentTarget.style.borderColor = "var(--border2)"; }}
          >{allOpen ? "Collapse all 5" : "Open all 5 →"}</button>
        </div>
      );
    })()}
    {/* Column labels */}
    <div style={{ display:"grid", gridTemplateColumns:"1fr 110px 1fr", gap:0, marginBottom:14, alignItems:"center" }}>
      <div style={{ textAlign:"center", padding:"10px 12px", borderRadius:11, background:"rgba(155,170,224,0.08)", color:"#9BAAE0", border:"0.5px solid rgba(155,170,224,0.25)", position:"relative" }}>
        <div style={{ position:"absolute", top:-9, left:"50%", transform:"translateX(-50%)", background:"#B07312", color:"#fff", fontSize:9, fontWeight:700, letterSpacing:"0.1em", padding:"3px 9px", borderRadius:999, boxShadow:"0 4px 10px rgba(176,115,18,0.3)" }}>STEP 1 &darr;</div>
        <div style={{ fontSize:12, fontWeight:700 }}>The Owner</div>
        <div style={{ fontSize:10, opacity:0.72, marginTop:2, fontStyle:"italic" }}>How you personally move through each A</div>
      </div>
      <div style={{ textAlign:"center", fontSize:9, letterSpacing:"0.18em", textTransform:"uppercase", color:"var(--text3)", lineHeight:1.4, fontWeight:600 }}>THE SPINE<br />THE 5As™</div>
      <div style={{ textAlign:"center", padding:"10px 12px", borderRadius:11, background:"rgba(93,202,165,0.08)", color:"#5DCAA5", border:"0.5px solid rgba(93,202,165,0.25)", position:"relative" }}>
        <div style={{ position:"absolute", top:-9, left:"50%", transform:"translateX(-50%)", background:"#0F6E56", color:"#fff", fontSize:9, fontWeight:700, letterSpacing:"0.1em", padding:"3px 9px", borderRadius:999, boxShadow:"0 4px 10px rgba(15,110,86,0.3)" }}>STEP 2 &darr;</div>
        <div style={{ fontSize:12, fontWeight:700 }}>The Business</div>
        <div style={{ fontSize:10, opacity:0.72, marginTop:2, fontStyle:"italic" }}>How this shows up in what you build</div>
      </div>
    </div>
    {/* Main 5 A's grid */}
    <div style={{ display:"grid", gridTemplateColumns:"1fr 110px 1fr", gap:0, rowGap:10 }}>
      {[
        { n:1, name:"All In It",     shift:"Commitment",    bg:"#1B1F4B", numCol:"#B8C0E8",
          o:{ lens:"Owner · Commitment Shift",   hook:"“Stop hedging. Both feet in.”", body:"You stop negotiating with your goals. Mentally, emotionally, strategically — all in. Clarity on who you are, what matters, where you’re going.", refl:"Where are you still hedging instead of committing fully?" },
          b:{ lens:"Business · Commitment Shift", hook:"“Your business needs your full bet.”", body:"Clear vision, short and long-term direction. You stop treating the business like a side hustle and start leading it like a CEO.", refl:"Is your business strategy built on full commitment or half-measures?" } },
        { n:2, name:"Align With It", shift:"Integrity", bg:"#0F6E56", numCol:"#9FE1CB",
          o:{ lens:"Owner · Integrity Shift", hook:"“Alignment isn’t fluff. It’s firepower.”", body:"Align your why, who you are, and where you’re going with what you want. When your time reflects your values, pressure becomes clarity.", refl:"Is your time aligned with what matters most?" },
          b:{ lens:"Business · Integrity Shift", hook:"“Everything rowing in one direction.”", body:"Prioritize how and where you spend your time — and get your team bought in. When everyone is rowing in one direction, the business moves.", refl:"Where is your time — and your team’s — most misaligned?" } },
        { n:3, name:"Advocate", shift:"Expansion", bg:"#085041", numCol:"#5DCAA5",
          o:{ lens:"Owner · Expansion Shift", hook:"“Lone wolf energy won’t build legacy.”", body:"You don’t grow in isolation. You rise when you stop playing small and surround yourself with the right energy, influence and expertise. Let the right people in.", refl:"Do the people around you expand or contract you and your vision?" },
          b:{ lens:"Business · Expansion Shift", hook:"“Growth partnerships. Team alignment.”", body:"Trusted advisors, an aligned team, strategic collaborators. The owner stops being the bottleneck and builds a business that grows beyond them.", refl:"What investment in people or partnerships would accelerate your growth?" } },
        { n:4, name:"Act On It", shift:"Momentum", bg:"#BA7517", numCol:"#FAC775",
          o:{ lens:"Owner · Momentum Shift", hook:"“Ideas don’t change your life. Actions do.”", body:"Clarity without follow-through is mental clutter. You stop starting and start finishing. A rhythm that paves the path — powered by clarity, not fear.", refl:"Are your actions powered by fear or clarity?" },
          b:{ lens:"Business · Momentum Shift", hook:"“Soul aligned strategy in motion.”", body:"Aligned strategy broken into measurable actions building toward the longer-term vision. Direction and rhythm — not a plan in a drawer.", refl:"Do your action steps actually move the business toward its vision?" } },
        { n:5, name:"Accountable", shift:"Mastery", bg:"#2A3580", numCol:"#9FAAE0",
          o:{ lens:"Owner · Mastery Shift", hook:"“Own the good, the bad, and the ugly.”", body:"You stop spinning when you stop tolerating your own avoidance. Face your results and rise from them. A rhythm that keeps you moving even when motivation fades.", refl:"What truth are you avoiding that needs accountability?" },
          b:{ lens:"Business · Mastery Shift", hook:"“Show your follow-through, see your future.”", body:"Clear operating rhythm: scorecards, check-ins, accountability — where reflection and celebration become culture. Ambition turns into traction.", refl:"Does your business have a rhythm that holds results even without you?" } },
      ].map((row:any) => {
        const oKey = `to_intro_o${row.n}_open`;
        const bKey = `to_intro_b${row.n}_open`;
        const oOpen = !!map?.[oKey];
        const bOpen = !!map?.[bKey];
        const rowOpen = oOpen || bOpen;
        const pathLeft = row.n;
        const pathRight = row.n + 5;
        const isHover = spineHoverRow === row.n;
        // Click anywhere on the row (Owner card, vertebra, or Business card)
        const toggleRow = () => { const next = { ...map, [oKey]: !rowOpen, [bKey]: !rowOpen }; setMap(next); saveMap(next); };
        const onEnter = () => setSpineHoverRow(row.n);
        const onLeave = () => setSpineHoverRow((prev) => prev === row.n ? null : prev);
        const ownerHoverShadow = isHover ? "0 0 0 1px rgba(155,170,224,0.55)" : "none";
        const businessHoverShadow = isHover ? "0 0 0 1px rgba(93,202,165,0.55)" : "none";
        const ownerBg = isHover ? "rgba(155,170,224,0.05)" : "var(--bg2)";
        const businessBg = isHover ? "rgba(93,202,165,0.05)" : "var(--bg2)";
        const vertebraShadow = isHover ? `0 4px 14px ${row.bg}80` : "none";
        return (
          <React.Fragment key={row.n}>
            {/* Owner card */}
            <div onMouseEnter={onEnter} onMouseLeave={onLeave} style={{ position:"relative", borderRadius:11, borderTop:"0.5px solid var(--border2)", borderRight:"0.5px solid var(--border2)", borderBottom:"0.5px solid var(--border2)", borderLeft:"3px solid #9BAAE0", background:ownerBg, boxShadow:ownerHoverShadow, overflow:"visible", transition:"background .18s, box-shadow .18s" }}>
              <div style={{ position:"absolute", top:10, left:-10, width:22, height:22, borderRadius:"50%", background:"#B07312", color:"#fff", display:"flex", alignItems:"center", justifyContent:"center", fontSize:10, fontWeight:700, boxShadow:"0 4px 10px rgba(176,115,18,0.45)", border:"2px solid var(--bg2)", zIndex:3 }}>{pathLeft}</div>
              <div onClick={toggleRow} style={{ display:"flex", alignItems:"center", justifyContent:"space-between", gap:8, padding:"11px 12px", cursor:"pointer", userSelect:"none" }}>
                <div style={{ display:"flex", alignItems:"center", gap:10, minWidth:0, flex:1 }}>
                  <div style={{ fontFamily:"var(--serif)", fontSize:16, fontWeight:700, color:"#FAC775", minWidth:22, textAlign:"center" }}>A{row.n}</div>
                  <div style={{ minWidth:0, flex:1 }}>
                    <div style={{ fontSize:9, letterSpacing:"0.14em", textTransform:"uppercase", color:"var(--text3)", marginBottom:2, fontWeight:600 }}>{row.o.lens}</div>
                    <div style={{ fontFamily:"var(--serif)", fontSize:13, fontStyle:"italic", color:"var(--text)", lineHeight:1.35 }}>{row.o.hook}</div>
                  </div>
                </div>
                <div style={{ fontSize:11, color:"var(--text3)", transform:rowOpen ? "rotate(180deg)" : "rotate(0deg)", transition:"transform 0.25s", width:18, height:18, borderRadius:"50%", background:"rgba(255,255,255,0.08)", display:"flex", alignItems:"center", justifyContent:"center" }}>&#9662;</div>
              </div>
              {rowOpen && (
                <div style={{ padding:"0 12px 12px" }}>
                  <div style={{ borderTop:"0.5px solid var(--border2)", paddingTop:10 }}>
                    <div style={{ fontSize:12, color:"var(--text2)", lineHeight:1.6 }}>{row.o.body}</div>
                    <div style={{ fontSize:11.5, color:"var(--text3)", marginTop:8, lineHeight:1.5, paddingTop:8, borderTop:"0.5px dashed var(--border)", fontStyle:"italic" }}>&rarr; {row.o.refl}</div>
                  </div>
                </div>
              )}
            </div>
            {/* Vertebra center */}
            <div onMouseEnter={onEnter} onMouseLeave={onLeave} onClick={toggleRow} style={{ display:"flex", alignItems:"flex-start", justifyContent:"center", padding:"6px 0", cursor:"pointer", userSelect:"none" }}>
              <div style={{ width:"100%", borderRadius:10, padding:"12px 8px", textAlign:"center", background:row.bg, color:"#fff", boxShadow:vertebraShadow, transition:"box-shadow .18s, transform .18s", transform:isHover ? "scale(1.04)" : "scale(1)" }}>
                <div style={{ fontFamily:"var(--serif)", fontSize:"1.5rem", fontWeight:700, lineHeight:1, color:row.numCol }}>{row.n}</div>
                <div style={{ fontSize:9, fontWeight:600, letterSpacing:"0.12em", textTransform:"uppercase", marginTop:3, lineHeight:1.2 }}>{row.name}</div>
                <div style={{ fontSize:8.5, opacity:0.7, marginTop:2, fontStyle:"italic", lineHeight:1.2 }}>{row.shift}</div>
              </div>
            </div>
            {/* Business card */}
            <div onMouseEnter={onEnter} onMouseLeave={onLeave} style={{ position:"relative", borderRadius:11, borderTop:"0.5px solid var(--border2)", borderLeft:"0.5px solid var(--border2)", borderBottom:"0.5px solid var(--border2)", borderRight:"3px solid #5DCAA5", background:businessBg, boxShadow:businessHoverShadow, overflow:"visible", transition:"background .18s, box-shadow .18s" }}>
              <div style={{ position:"absolute", top:10, right:-10, width:22, height:22, borderRadius:"50%", background:"#0F6E56", color:"#fff", display:"flex", alignItems:"center", justifyContent:"center", fontSize:10, fontWeight:700, boxShadow:"0 4px 10px rgba(15,110,86,0.4)", border:"2px solid var(--bg2)", zIndex:3 }}>{pathRight}</div>
              <div onClick={toggleRow} style={{ display:"flex", alignItems:"center", justifyContent:"space-between", gap:8, padding:"11px 12px", cursor:"pointer", userSelect:"none" }}>
                <div style={{ display:"flex", alignItems:"center", gap:10, minWidth:0, flex:1 }}>
                  <div style={{ fontFamily:"var(--serif)", fontSize:16, fontWeight:700, color:"#5DCAA5", minWidth:22, textAlign:"center" }}>A{row.n}</div>
                  <div style={{ minWidth:0, flex:1 }}>
                    <div style={{ fontSize:9, letterSpacing:"0.14em", textTransform:"uppercase", color:"var(--text3)", marginBottom:2, fontWeight:600 }}>{row.b.lens}</div>
                    <div style={{ fontFamily:"var(--serif)", fontSize:13, fontStyle:"italic", color:"var(--text)", lineHeight:1.35 }}>{row.b.hook}</div>
                  </div>
                </div>
                <div style={{ fontSize:11, color:"var(--text3)", transform:rowOpen ? "rotate(180deg)" : "rotate(0deg)", transition:"transform 0.25s", width:18, height:18, borderRadius:"50%", background:"rgba(255,255,255,0.08)", display:"flex", alignItems:"center", justifyContent:"center" }}>&#9662;</div>
              </div>
              {rowOpen && (
                <div style={{ padding:"0 12px 12px" }}>
                  <div style={{ borderTop:"0.5px solid var(--border2)", paddingTop:10 }}>
                    <div style={{ fontSize:12, color:"var(--text2)", lineHeight:1.6 }}>{row.b.body}</div>
                    <div style={{ fontSize:11.5, color:"var(--text3)", marginTop:8, lineHeight:1.5, paddingTop:8, borderTop:"0.5px dashed var(--border)", fontStyle:"italic" }}>&rarr; {row.b.refl}</div>
                  </div>
                </div>
              )}
            </div>
          </React.Fragment>
        );
      })}
    </div>
    <div style={{ marginTop:28, marginBottom:10, textAlign:"center", fontSize:10, letterSpacing:"0.22em", textTransform:"uppercase", color:"var(--text3)", fontWeight:600 }}>
      &darr;&nbsp;&nbsp;The Outcomes&nbsp;&nbsp;&darr;
    </div>
    <div style={{ display:"grid", gridTemplateColumns:"1fr 110px 1fr", gap:0, alignItems:"stretch" }}>
      <div style={{ borderRadius:11, padding:"18px 20px", background:"#2A3580", color:"#fff", textAlign:"center", display:"flex", flexDirection:"column", justifyContent:"center" }}>
        <div style={{ fontSize:9, letterSpacing:"0.16em", textTransform:"uppercase", color:"#9FAAE0", marginBottom:6, fontWeight:600 }}>Owner Outcome</div>
        <div style={{ fontFamily:"var(--serif)", fontSize:20, fontWeight:700, marginBottom:8, letterSpacing:"0.03em" }}>OWN IT</div>
        <div style={{ fontSize:11.5, lineHeight:1.55, opacity:0.92 }}>You lead from identity, not fear. Aligned decisions. Abundant mindset. Showing up 100% as yourself &mdash; in life and in business.</div>
      </div>
      <div style={{ display:"flex", alignItems:"center", justifyContent:"center", padding:"0 6px" }}>
        <div style={{ width:"100%", borderRadius:10, padding:"12px 6px", textAlign:"center", background:"#BA7517", color:"#fff" }}>
          <div style={{ fontSize:9, fontWeight:600, letterSpacing:"0.14em", textTransform:"uppercase", marginBottom:4, opacity:0.85 }}>How</div>
          <div style={{ fontFamily:"var(--serif)", fontSize:13, fontWeight:700, lineHeight:1.2 }}>True Ownership</div>
        </div>
      </div>
      <div style={{ borderRadius:11, padding:"18px 20px", background:"#0F6E56", color:"#fff", textAlign:"center", display:"flex", flexDirection:"column", justifyContent:"center" }}>
        <div style={{ fontSize:9, letterSpacing:"0.16em", textTransform:"uppercase", color:"#9FE5C4", marginBottom:6, fontWeight:600 }}>Business Outcome</div>
        <div style={{ fontFamily:"var(--serif)", fontSize:20, fontWeight:700, marginBottom:8, letterSpacing:"0.03em" }}>Leader-Run Business</div>
        <div style={{ fontSize:11.5, lineHeight:1.55, opacity:0.92 }}>Grows in value. Delivers measurable outcomes. Sustains success beyond the owner. Runs on alignment, not just effort.</div>
      </div>
    </div>
    <div style={{ marginTop:36, paddingTop:28, borderTop:"1px solid var(--border)", display:"flex", flexDirection:"column", alignItems:"center", gap:12 }}>
      <div style={{ fontSize:11.5, color:"var(--text3)", textAlign:"center", fontStyle:"italic", maxWidth:440 }}>Open each card to take it in. When you&rsquo;re ready, continue.</div>
      <button className="btn" onClick={() => { markDone("to_intro"); goto("intro"); }}>Everything Starts With You &rarr;</button>
    </div>
  </>);
  if (step === "intro") return wrapContent(<>
    <div className="lbl" style={{ marginBottom:11 }}>A1 · All In It</div>
    <h2 style={{ fontFamily:"var(--serif)", fontSize:42, fontWeight:400, lineHeight:1.1, marginBottom:16, letterSpacing:"-0.5px" }}>
      <em>Everything Starts With You</em>
    </h2>
    <p style={{ fontSize:15, color:"var(--text2)", lineHeight:1.85, marginBottom:14, maxWidth:540 }}>
      {name}, before you can build a life that is truly yours -- you need to know who is building it. Not the role. Not the title. <em>You.</em>
    </p>
    <p style={{ fontSize:15, color:"var(--text2)", lineHeight:1.85, marginBottom:24, maxWidth:540 }}>
      A1 is your Map of Me. Your internal world -- purpose, identity, values -- reflected against your external world -- direction, superpowers, behaviours. We build both sides together, then hold them up to the mirror.
    </p>
    {/* Core principle */}
    <div style={{ padding:"18px 20px", background:"rgba(201,168,76,.07)", border:"1px solid rgba(201,168,76,.18)", borderRadius:11, marginBottom:22 }}>
      <div style={{ fontSize:10, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color:"var(--warm)", marginBottom:10, fontFamily:"var(--sans)" }}>Before we start -- one principle</div>
      <div style={{ fontFamily:"var(--serif)", fontSize:17, fontStyle:"italic", color:"var(--text)", lineHeight:1.85, marginBottom:10 }}>
        "You are the authority on your own life. This system is a mirror -- it reflects your own thinking back more clearly. It does not give you answers. You already have them."
      </div>
      <div style={{ fontSize:13, color:"var(--text3)", lineHeight:1.7 }}>
        The voices here -- Katherine, the coach, the challenger -- are a board of advisors. They help you think. But your voice leads. That is why in this programme, you write first. The board responds after.
      </div>
    </div>
    <VideoBlock title="All In It -- Why the Foundation Changes Everything" duration="~8 min"
      points={[
        "Why belonging to yourself comes before building anything else",
        "The mirror principle -- internal reflects external",
        "How the Map of Me™ works as a living document",
        "Why the order of the three mirror pairs is deliberate"
      ]} />
    <MirrorIntroCards goto={goto} />
    {/* What you will build */}
    <div style={{ padding:"16px 18px", background:"var(--bg2)", border:"1px solid var(--border)", borderRadius:11, marginBottom:28 }}>
      <div style={{ fontSize:10, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color:"var(--warm)", marginBottom:12, fontFamily:"var(--sans)" }}>What you build in A1</div>
      {[
        { icon:"🔥", label:"Purpose", desc:"Your internal why -- the reason you exist that has nothing to do with your role." },
        { icon:"⛰️", label:"Direction", desc:"Your BAG -- the 10–15 year summit your purpose is pointing toward." },
        { icon:"🦁", label:"Identity", desc:"Who you are at your best, anchored to animals and built from your own evidence." },
        { icon:"⚡", label:"Superpowers", desc:"How your identity shows up in the world -- and what happens when it goes too far." },
        { icon:"⚖️", label:"Values",  desc:"The standards you live by -- discovered through what makes your blood boil." },
        { icon:"🎯", label:"Behaviors", desc:"The proof that your values are real -- how you act when it costs you something." },
      ].map((item, i) => (
        <div key={i} style={{ display:"flex", alignItems:"flex-start", gap:11, marginBottom: i < 5 ? 10 : 0 }}>
          <span style={{ fontSize:15, flexShrink:0, marginTop:1 }}>{item.icon}</span>
          <div>
            <span style={{ fontFamily:"var(--sans)", fontSize:13, fontWeight:600, color:"var(--text)" }}>{item.label} -- </span>
            <span style={{ fontSize:13, color:"var(--text3)", lineHeight:1.6 }}>{item.desc}</span>
          </div>
        </div>
      ))}
    </div>
    <button className="btn" onClick={() => { set("mirror1_sub", "purpose"); goto("mirror1"); }}>Start with Purpose →</button>
  </>);
  if (step === "mirror1") {
    const m1sub = map.mirror1_sub || "purpose";
    // Sub-step progress indicator
    const M1Progress = () => {
      const steps = [
        { id:"purpose",   label:"Purpose",   icon:"🔥" },
        { id:"direction", label:"Direction", icon:"⛰️" },
        { id:"output",    label:"The Mirror",icon:"🪞" },
      ];
      const currentIdx = steps.findIndex(s => s.id === m1sub);
      return (
        <div style={{ display:"flex", alignItems:"center", gap:0, marginBottom:22 }}>
          {steps.map((s, i) => {
            const isActive = m1sub === s.id;
            const isDone = currentIdx > i;
            return (
              <React.Fragment key={s.id}>
                <div style={{ display:"flex", flexDirection:"column", alignItems:"center", gap:4 }}>
                  <div style={{ width:32, height:32, borderRadius:"50%", background: isActive ? "var(--warm)" : isDone ? "rgba(52,211,153,.2)" : "var(--bg3)", border: isActive ? "none" : isDone ? "1px solid #34d399" : "1px solid var(--border2)", display:"flex", alignItems:"center", justifyContent:"center", fontSize:14, cursor: "pointer", transition:"all .2s" }}
                    onClick={() => set("mirror1_sub", s.id)}>
                    {isDone ? <span style={{ fontSize:13, color:"#34d399" }}>✓</span> : <span>{s.icon}</span>}
                  </div>
                  <span style={{ fontSize:10, fontWeight: isActive ? 700 : 400, color: isActive ? "var(--warm)" : isDone ? "#34d399" : "var(--text4)", letterSpacing:0.5, textTransform:"uppercase", whiteSpace:"nowrap" }}>{s.label}</span>
                </div>
                {i < steps.length - 1 && <div style={{ flex:1, height:1, background: isDone ? "#34d399" : "var(--border2)", margin:"0 8px", marginBottom:18, transition:"background .3s" }} />}
              </React.Fragment>
            );
          })}
        </div>
      );
    };
    // 1a -- PURPOSE
    if (m1sub === "purpose") return wrapContent(<>
      <div className="lbl" style={{ marginBottom:12 }}>Mirror 1 of 3 · Step 1</div>
      {M1Progress()}
      <h2 style={{ fontFamily:"var(--serif)", fontSize:34, fontWeight:400, lineHeight:1.2, marginBottom:7, letterSpacing:"-0.3px" }}>Purpose</h2>
      <p style={{ fontSize:16, color:"var(--text2)", lineHeight:1.75, marginBottom:20, maxWidth:540 }}>Your internal why -- independent of any role, business, or outcome. We find it by peeling.</p>
      <VideoBlock title="Purpose -- Your Internal Why" duration="~6 min"
        points={["Purpose is 100% internal -- not a role, not a business","The peeling process: asking 'so what's' until something true surfaces","Short enough to say in the car. True enough to get you out of bed on a hard day."]} />
      <div style={{ marginBottom:20, padding:"13px 16px", background:"rgba(201,168,76,.06)", border:"1px solid rgba(201,168,76,.18)", borderRadius:10 }}>
        <div style={{ fontFamily:"var(--serif)", fontSize:14, fontStyle:"italic", color:"var(--text2)", lineHeight:1.7 }}>"When I ask people what their purpose is, they usually say their kids or their business. That's not purpose -- those are attachments. Purpose needs to be 100% internal to you."</div>
      </div>
      <PurposePeelingInline
        layers={map.purpose_layers || [""]}
        onLayersChange={v => set("purpose_layers", v)}
        purposeFinal={map.purpose_final || ""}
        onFinalChange={v => set("purpose_final", v)}
        purposeResult={ai.purpose || null}
        onResult={r => { setAi(a => ({ ...a, purpose:r ? { ...r } : null })); if (r) { set("purpose_draft", r.draft || ""); } }}
        name={name} intake={intake}
        allSessions={map.purpose_sessions || []}
        onSessionSave={s => set("purpose_sessions", [...(map.purpose_sessions || []), s])}
        onContinueToNext={() => set("mirror1_sub", "direction")}
      />
      <div style={{ marginBottom:22, marginTop:8 }}>
        <AIChat voiceId={voice} onVoiceChange={setVoicePersist} name={name} intake={intake} mapData={map}
          sectionLabel="purpose"
          placeholder="Ask Katherine about your purpose -- she can see everything you've written..." />
      </div>
      <div style={{ display:"flex", justifyContent:"space-between", paddingTop:18, borderTop:"1px solid var(--border)" }}>
        <button className="btn-g" onClick={() => goto("intro")}>← Introduction</button>
        <button className="btn" onClick={() => set("mirror1_sub", "direction")}>Direction → Your BAG</button>
      </div>
    </>);
    // 1b -- DIRECTION
    if (m1sub === "direction") return wrapContent(<>
      <div className="lbl" style={{ marginBottom:12 }}>Mirror 1 of 3 · Step 2</div>
      {M1Progress()}
      <h2 style={{ fontFamily:"var(--serif)", fontSize:34, fontWeight:400, lineHeight:1.2, marginBottom:7, letterSpacing:"-0.3px" }}>Direction</h2>
      <p style={{ fontSize:16, color:"var(--text2)", lineHeight:1.75, marginBottom:20, maxWidth:540 }}>Your BAG -- Big Ass Goal. The 10–15 year summit that your purpose points toward.</p>
      <DirectionSection map={map} set={set} voiceId={voice} name={name} intake={intake} />
      <div style={{ marginBottom:22, marginTop:8 }}>
        <AIChat voiceId={voice} onVoiceChange={setVoicePersist} name={name} intake={intake} mapData={map}
          sectionLabel="direction and BAG"
          placeholder="Ask Katherine about your direction or life priorities -- she can see everything you've written..." />
      </div>
      <div style={{ display:"flex", justifyContent:"space-between", paddingTop:18, borderTop:"1px solid var(--border)" }}>
        <button className="btn-g" onClick={() => set("mirror1_sub", "purpose")}>← Purpose</button>
        <button className="btn" onClick={() => set("mirror1_sub", "output")}>See the Mirror →</button>
      </div>
    </>);
    // 1c -- OUTPUT / MIRROR
    if (m1sub === "output") return wrapContent(<>
      <div className="lbl" style={{ marginBottom:12 }}>Mirror 1 of 3 · The Mirror</div>
      {M1Progress()}
      <h2 style={{ fontFamily:"var(--serif)", fontSize:34, fontWeight:400, lineHeight:1.2, marginBottom:7, letterSpacing:"-0.3px" }}>Purpose <em style={{ color:"var(--text3)", fontSize:26 }}>reflects</em> Direction</h2>
      <p style={{ fontSize:16, color:"var(--text2)", lineHeight:1.75, marginBottom:24, maxWidth:540 }}>Your internal why, mirrored against your external summit. This is where alignment begins.</p>
      {/* THE MIRROR -- side by side output */}
      <div style={{ display:"grid", gridTemplateColumns:"1fr 40px 1fr", gap:0, marginBottom:28 }}>
        {/* PURPOSE side */}
        <div style={{ background:"var(--bg2)", border:"1px solid rgba(201,168,76,.25)", borderRadius:12, padding:"22px 20px" }}>
          <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:16 }}>
            <span style={{ fontSize:18 }}>🔥</span>
            <div>
              <div style={{ fontFamily:"var(--sans)", fontSize:11, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color:"var(--warm)" }}>Purpose · Internal</div>
              <div style={{ fontSize:11, color:"var(--text4)" }}>Your why -- independent of any role</div>
            </div>
          </div>
          <div style={{ fontFamily:"var(--serif)", fontSize:20, fontStyle:"italic", fontWeight:300, color:"var(--text)", lineHeight:1.7, marginBottom:14 }}>
            "{map.purpose_final || map.purpose_draft || "Not yet written"}"
          </div>
          {(map.purpose_sessions || []).length > 0 && (
            <div style={{ fontSize:11, color:"var(--text4)", fontStyle:"italic" }}>
              {(map.purpose_sessions || []).length} peeling session{(map.purpose_sessions || []).length > 1 ? "s" : ""} completed
            </div>
          )}
          <button onClick={() => set("mirror1_sub", "purpose")}
            style={{ marginTop:12, background:"none", border:"1px solid rgba(201,168,76,.3)", borderRadius:20, color:"var(--warm)", cursor:"pointer", fontFamily:"var(--sans)", fontSize:11, padding:"5px 13px" }}>
            ✎ Edit Purpose
          </button>
        </div>
        {/* Mirror divider */}
        <div style={{ display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", gap:6 }}>
          <div style={{ flex:1, width:1, background:"var(--border)", opacity:0.4 }} />
          <div style={{ width:32, height:32, borderRadius:"50%", border:"1px solid var(--border2)", background:"var(--bg)", display:"flex", alignItems:"center", justifyContent:"center", fontSize:15 }}>🪞</div>
          <div style={{ flex:1, width:1, background:"var(--border)", opacity:0.4 }} />
        </div>
        {/* DIRECTION side */}
        <div style={{ background:"var(--bg2)", border:"1px solid rgba(79,203,242,.2)", borderRadius:12, padding:"22px 20px" }}>
          <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:16 }}>
            <span style={{ fontSize:18 }}>⛰️</span>
            <div>
              <div style={{ fontFamily:"var(--sans)", fontSize:11, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color:"var(--accent)" }}>Direction · External</div>
              <div style={{ fontSize:11, color:"var(--text4)" }}>Your BAG{map.bag_year ? ` · ${map.bag_year}` : " · 10–15 year summit"}</div>
            </div>
          </div>
          {/* Time summary */}
          {map.time_summary && (
            <div style={{ marginBottom:12 }}>
              <div style={{ fontSize:10, fontWeight:700, letterSpacing:1.5, textTransform:"uppercase", color:"var(--text4)", marginBottom:5 }}>Time</div>
              <div style={{ fontFamily:"var(--serif)", fontSize:16, fontStyle:"italic", color:"var(--warm)", lineHeight:1.6 }}>"{map.time_summary}"</div>
            </div>
          )}
          {/* Life goals list -- show goals if any, else chips */}
          {(map.life_areas || []).length > 0 && (
            <div style={{ marginBottom:12 }}>
              <div style={{ fontSize:10, fontWeight:700, letterSpacing:1.5, textTransform:"uppercase", color:"var(--text4)", marginBottom:8 }}>
                Life Goals {map.bag_year ? `· ${map.bag_year}` : ""}
              </div>
              {(map.life_areas || []).map((area, i) => (
                <div key={area.id} style={{ display:"flex", alignItems:"flex-start", gap:8, marginBottom:9 }}>
                  <div style={{ display:"flex", alignItems:"center", gap:4, flexShrink:0, marginTop:3 }}>
                    <div style={{ width:15, height:15, borderRadius:"50%", background:"var(--warm)", display:"flex", alignItems:"center", justifyContent:"center" }}>
                      <span style={{ fontSize:7, fontWeight:700, color:"#0d1b2e" }}>{i+1}</span>
                    </div>
                    <span style={{ fontSize:12 }}>{area.icon}</span>
                  </div>
                  <div style={{ flex:1 }}>
                    <div style={{ fontFamily:"var(--sans)", fontSize:10, fontWeight:700, color:"var(--warm)", letterSpacing:0.5, textTransform:"uppercase", marginBottom:2 }}>{area.label}</div>
                    {area.goal
                      ? <div style={{ fontFamily:"var(--serif)", fontSize:13, fontStyle:"italic", color:"var(--text2)", lineHeight:1.5 }}>{area.goal}</div>
                      : <div style={{ fontSize:11, color:"var(--text4)", fontStyle:"italic" }}>Goal not yet written</div>
                    }
                  </div>
                </div>
              ))}
            </div>
          )}
          {/* Wealth summary */}
          {map.wealth_summary && (
            <div style={{ marginBottom:12 }}>
              <div style={{ fontSize:10, fontWeight:700, letterSpacing:1.5, textTransform:"uppercase", color:"var(--text4)", marginBottom:5 }}>Wealth</div>
              <div style={{ fontFamily:"var(--serif)", fontSize:16, fontStyle:"italic", color:"#34d399", lineHeight:1.6 }}>"{map.wealth_summary}"</div>
            </div>
          )}
          {/* Growth summary */}
          {(map.growth_summary || map.bag_growth) && (
            <div style={{ marginBottom:12 }}>
              <div style={{ fontSize:10, fontWeight:700, letterSpacing:1.5, textTransform:"uppercase", color:"var(--text4)", marginBottom:5 }}>Growth</div>
              <div style={{ fontFamily:"var(--serif)", fontSize:16, fontStyle:"italic", color:"#a78bfa", lineHeight:1.6 }}>"{map.growth_summary || map.bag_growth.slice(0, 120)}{!map.growth_summary && map.bag_growth.length > 120 ? "..." : ""}"</div>
            </div>
          )}
          <button onClick={() => set("mirror1_sub", "direction")}
            style={{ marginTop:4, background:"none", border:"1px solid rgba(79,203,242,.3)", borderRadius:20, color:"var(--accent)", cursor:"pointer", fontFamily:"var(--sans)", fontSize:11, padding:"5px 13px" }}>
            ✎ Edit Direction
          </button>
        </div>
      </div>
      {/* Katherine's read on alignment */}
      {!ai.mirror1_align && (map.purpose_final || map.purpose_draft) && (map.life_areas || []).length > 0 && (
        <div style={{ textAlign:"center", marginBottom:22 }}>
          <button className="btn" onClick={() => (() => {
              const prioritiesList = (map.life_areas || []).map((a,i) => (i+1) + ". " + a.label + (a.feel ? " (feel: " + a.feel.slice(0,60) + ")" : "")).join(", ");
              runAI("mirror1_align",
                "You are Katherine Breuss. " + name + " has completed their Purpose and Direction. Purpose: \"" + (map.purpose_final || map.purpose_draft) + "\". Life priorities ranked: " + prioritiesList + ". BAG year: " + (map.bag_year || "not set") + ". Growth: \"" + (map.bag_growth || "") + "\". In 2-3 sentences: what is the thread between their purpose and their priorities? Does the ranking reflect their purpose? Name one specific alignment you see and one potential tension. Respond ONLY with a JSON object, no preamble: {\"thread\":\"...\",\"alignment\":\"...\",\"tension\":\"...\"}"
              );
            })()}>
            {busy.mirror1_align ? <span className="dot-l"><span /><span /><span /></span> : "✦ See how Purpose and Direction align"}
          </button>
        </div>
      )}
      {ai.mirror1_align && (
        <div className="fade-up" style={{ padding:"18px 22px", background:"rgba(201,168,76,.06)", border:"1px solid rgba(201,168,76,.2)", borderRadius:11, marginBottom:22 }}>
          <div style={{ fontSize:11, fontWeight:500, letterSpacing:2, textTransform:"uppercase", color:"var(--warm)", marginBottom:11 }}>Katherine's read on your mirror</div>
          <ResultCard color="var(--warm)" label="The thread">{ai.mirror1_align.thread}</ResultCard>
          <ResultCard color="#34d399" label="What aligns">{ai.mirror1_align.alignment}</ResultCard>
          <ResultCard color="#f59e0b" label="A tension to notice">{ai.mirror1_align.tension}</ResultCard>
          {/* Reflection -- replaces Own It Check */}
          <div style={{ marginTop:16, padding:"16px 18px", background:"var(--bg3)", border:"1px solid var(--border2)", borderRadius:10 }}>
            <div style={{ fontFamily:"var(--sans)", fontSize:13, fontWeight:600, color:"var(--text)", marginBottom:4 }}>
              Based on this -- what, if anything, would you go back and change?
            </div>
            <div style={{ fontSize:12, color:"var(--text4)", marginBottom:10, lineHeight:1.5 }}>
              In your purpose, your priorities, or how they connect. You can go back and update either at any time.
            </div>
            <textarea rows={3} value={map.mirror1_reflection || ""} onChange={e => set("mirror1_reflection", e.target.value)}
              placeholder="What I'd go back and change or refine is..."
              className="to-field" style={{ fontSize:13, marginBottom:12 }} />
            <div style={{ display:"flex", gap:9 }}>
              <button
                onClick={() => { set("mirror1_reflection_done", true); }}
                style={{ flex:1, padding:"10px", background:"rgba(52,211,153,.1)", border:"1px solid #34d399", borderRadius:8, color:"#34d399", cursor:"pointer", fontFamily:"var(--sans)", fontSize:13, fontWeight:700, transition:"all .2s" }}
                onMouseEnter={e => e.currentTarget.style.background = "rgba(52,211,153,.2)"}
                onMouseLeave={e => e.currentTarget.style.background = "rgba(52,211,153,.1)"}>
                ✓ Yes -- this is it
              </button>
              <button
                onClick={() => { set("mirror1_sub", map.mirror1_reflection?.toLowerCase().includes("purpose") ? "purpose" : "direction"); }}
                style={{ flex:1, padding:"10px", background:"rgba(245,158,11,.08)", border:"1px solid rgba(245,158,11,.4)", borderRadius:8, color:"#f59e0b", cursor:"pointer", fontFamily:"var(--sans)", fontSize:13, fontWeight:500, transition:"all .2s" }}
                onMouseEnter={e => e.currentTarget.style.background = "rgba(245,158,11,.18)"}
                onMouseLeave={e => e.currentTarget.style.background = "rgba(245,158,11,.08)"}>
                Not yet -- go back and update
              </button>
            </div>
            {map.mirror1_reflection_done && (
              <div className="fade-in" style={{ marginTop:10, fontSize:12, color:"#34d399", display:"flex", alignItems:"center", gap:6 }}>
                <span>✓</span> Confirmed -- your mirror is set. You can still update anytime.
              </div>
            )}
          </div>
        </div>
      )}
      <div style={{ marginBottom:22 }}>
        <AIChat voiceId={voice} onVoiceChange={setVoicePersist} name={name} intake={intake} mapData={map}
          sectionLabel="purpose and direction"
          placeholder="Ask Katherine about how your purpose and direction connect..." />
      </div>
      <div style={{ display:"flex", justifyContent:"space-between", paddingTop:18, borderTop:"1px solid var(--border)" }}>
        <button className="btn-g" onClick={() => set("mirror1_sub", "direction")}>← Direction</button>
        <button className="btn" onClick={() => { markDone("mirror1"); goto("mirror2"); }}>Identity · Superpowers →</button>
      </div>
    </>);
    // 1d -- ALIGNMENT
    if (m1sub === "alignment") {
      // W.1b-A: Pull items from new state shape (time_picked / wealth_picked)
      // with fallback to legacy life_areas for Time if the user hasn't migrated yet.
      const timePicked = (map.time_picked || []) as string[];
      const timeItemsMap = (map.time_items || {}) as Record<string, any>;
      const timeItems = timePicked.length > 0
        ? timePicked.map(id => {
            const preset = TIME_AREA_PRESETS.find(p => p.id === id);
            const stored = timeItemsMap[id] || {};
            return {
              id,
              label: preset?.label || stored.label || id,
              icon:  preset?.icon  || stored.icon  || "✨",
            };
          })
        // Legacy fallback: use life_areas array if no time_picked yet
        : ((map.life_areas || []) as any[]).map(a => ({
            id: a.id || a.label,
            label: a.label || a.id || "",
            icon: a.icon || "⏳",
          }));
      const wealthPicked = (map.wealth_picked || []) as string[];
      const wealthItemsMap = (map.wealth_items || {}) as Record<string, any>;
      const wealthItems = wealthPicked.map(id => {
        const preset = WEALTH_AREA_PRESETS.find(p => p.id === id);
        const stored = wealthItemsMap[id] || {};
        return {
          id,
          label: preset?.label || stored.label || id,
          icon:  preset?.icon  || stored.icon  || "✨",
        };
      });
      const sections = [
        { id:"time",   label:"Time",   icon:"⏳", sentence: map.time_overall_sentence || map.time_summary || "",
          emptySentence:"Add your time vision in Direction first.",
          emptyItems:"Pick your life priorities in Direction first." },
        { id:"wealth", label:"Wealth", icon:"💰", sentence: map.wealth_overall_sentence || map.wealth_summary || "",
          emptySentence:"Add your wealth vision in Direction first.",
          emptyItems:"Pick your wealth categories in Direction first." },
        { id:"growth", label:"Growth", icon:"🌱", sentence: map.growth_sentence || map.growth_summary || "",
          emptySentence:"Write your growth vision in Direction first.",
          emptyItems:"" },
      ];
      // Per-card average
      // Time: avg of per-item sliders (by id). Wealth: avg of per-item sliders (by id). Growth: single slider.
      const cardAvg = (sec: any) => {
        if (sec.id === "time") {
          if (!timeItems.length) return null;
          const vals = timeItems.map(a => (map?.[`align1_time_${a.id}`] ?? 5) as number);
          return vals.reduce((s,v) => s+v, 0) / vals.length;
        }
        if (sec.id === "wealth") {
          if (!wealthItems.length) return null;
          const vals = wealthItems.map(w => (map?.[`align1_wealth_${w.id}`] ?? 5) as number);
          return vals.reduce((s,v) => s+v, 0) / vals.length;
        }
        if (sec.id === "growth") {
          if (!sec.sentence) return null;
          return (map?.[`align1_growth`] ?? 5) as number;
        }
        return (map?.[`align_dir_${sec.id}`] ?? 5) as number;
      };
      return wrapContent(<>
        <div className="lbl" style={{ marginBottom:12 }}>Mirror 1 of 3 · Step 4</div>
        {M1Progress()}
        <h2 style={{ fontFamily:"var(--serif)", fontSize:34, fontWeight:400, lineHeight:1.2, marginBottom:7, letterSpacing:"-0.3px" }}>Alignment</h2>
        <p style={{ fontSize:16, color:"var(--text2)", lineHeight:1.75, marginBottom:18, maxWidth:540 }}>
          This is your synthesis. For each area of your direction, rate how fully you're living toward it right now.
        </p>
        {sections.map(sec => {
          const avg = cardAvg(sec);
          const col = avg == null ? "var(--text4)" : avg >= 7 ? "#34d399" : avg >= 4 ? "#f59e0b" : "#ef4444";
          const openKey = `align_dir_${sec.id}_open`;
          const isOpen = map?.[openKey] !== false;
          return (
            <div key={sec.id} style={{ marginBottom:16, border:"1px solid var(--border2)", borderRadius:10, overflow:"hidden" }}>
              <div onClick={() => set(openKey, !isOpen)}
                style={{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:"14px 18px", background:"var(--bg3)", cursor:"pointer", userSelect:"none" }}>
                <div style={{ fontFamily:"var(--serif)", fontSize:16, fontStyle:"italic", color:"var(--warm)" }}>{sec.icon} {sec.label}</div>
                <div style={{ display:"flex", alignItems:"center", gap:10 }}>
                  <span style={{ fontSize:13, fontWeight:700, color:col }}>{avg == null ? "—" : `${avg.toFixed(1)}/10`}</span>
                  <span style={{ fontSize:14, color:"var(--text3)", transform: isOpen ? "rotate(180deg)" : "none", transition:"transform .2s" }}>▾</span>
                </div>
              </div>
              {isOpen && (
                <div style={{ padding:"16px 18px", borderTop:"1px solid var(--border)" }}>
                  {sec.sentence ? (
                    <div style={{ fontFamily:"var(--serif)", fontSize:13, fontStyle:"italic", color:"var(--text3)", lineHeight:1.6, marginBottom:14 }}>"{sec.sentence}"</div>
                  ) : (
                    <div style={{ fontSize:12, color:"var(--text4)", fontStyle:"italic", lineHeight:1.5, marginBottom:14 }}>{sec.emptySentence}</div>
                  )}
                  {sec.id === "time" ? (
                    timeItems.length === 0 ? (
                      <div style={{ fontSize:12, color:"var(--text4)", fontStyle:"italic", lineHeight:1.5 }}>{sec.emptyItems}</div>
                    ) : (
                      timeItems.map((a) => {
                        const k = `align1_time_${a.id}`;
                        const sv = (map?.[k] ?? 5) as number;
                        const sCol = sv >= 7 ? "#34d399" : sv >= 4 ? "#f59e0b" : "#ef4444";
                        return (
                          <div key={a.id} style={{ marginBottom:14 }}>
                            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:4 }}>
                              <span style={{ fontFamily:"var(--sans)", fontSize:13, fontWeight:700, color:"var(--text)" }}>{a.icon} {a.label}</span>
                              <span style={{ fontSize:12, fontWeight:700, color:sCol }}>{sv}/10</span>
                            </div>
                            <input type="range" min={1} max={10} step={1} value={sv}
                              onChange={e => set(k, Number(e.target.value))}
                              style={{ width:"100%", accentColor: sCol }} />
                            <div style={{ display:"flex", justifyContent:"space-between", fontSize:10, marginTop:2 }}>
                              <span style={{ color:"#ef4444" }}>1 = living far from this</span>
                              <span style={{ color:"#34d399" }}>10 = fully embodying this</span>
                            </div>
                          </div>
                        );
                      })
                    )
                  ) : sec.id === "wealth" ? (
                    wealthItems.length === 0 ? (
                      <div style={{ fontSize:12, color:"var(--text4)", fontStyle:"italic", lineHeight:1.5 }}>{sec.emptyItems}</div>
                    ) : (
                      wealthItems.map((it) => {
                        const k = `align1_wealth_${it.id}`;
                        const sv = (map?.[k] ?? 5) as number;
                        const sCol = sv >= 7 ? "#34d399" : sv >= 4 ? "#f59e0b" : "#ef4444";
                        return (
                          <div key={it.id} style={{ marginBottom:14 }}>
                            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:4 }}>
                              <span style={{ fontFamily:"var(--sans)", fontSize:13, fontWeight:700, color:"var(--text)" }}>{it.icon} {it.label}</span>
                              <span style={{ fontSize:12, fontWeight:700, color:sCol }}>{sv}/10</span>
                            </div>
                            <input type="range" min={1} max={10} step={1} value={sv}
                              onChange={e => set(k, Number(e.target.value))}
                              style={{ width:"100%", accentColor: sCol }} />
                            <div style={{ display:"flex", justifyContent:"space-between", fontSize:10, marginTop:2 }}>
                              <span style={{ color:"#ef4444" }}>1 = living far from this</span>
                              <span style={{ color:"#34d399" }}>10 = fully embodying this</span>
                            </div>
                          </div>
                        );
                      })
                    )
                  ) : sec.id === "growth" ? (
                    !sec.sentence ? (
                      <div style={{ fontSize:12, color:"var(--text4)", fontStyle:"italic", lineHeight:1.5 }}>Write your growth vision in Direction first, then rate how fully you're embodying it.</div>
                    ) : (() => {
                      const k = `align1_growth`;
                      const sv = (map?.[k] ?? 5) as number;
                      const sCol = sv >= 7 ? "#34d399" : sv >= 4 ? "#f59e0b" : "#ef4444";
                      return (
                        <div>
                          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:4 }}>
                            <span style={{ fontFamily:"var(--sans)", fontSize:13, fontWeight:700, color:"var(--text)" }}>Living toward who I'm becoming</span>
                            <span style={{ fontSize:12, fontWeight:700, color:sCol }}>{sv}/10</span>
                          </div>
                          <input type="range" min={1} max={10} step={1} value={sv}
                            onChange={e => set(k, Number(e.target.value))}
                            style={{ width:"100%", accentColor: sCol }} />
                          <div style={{ display:"flex", justifyContent:"space-between", fontSize:10, marginTop:2 }}>
                            <span style={{ color:"#ef4444" }}>1 = living far from this</span>
                            <span style={{ color:"#34d399" }}>10 = fully embodying this</span>
                          </div>
                        </div>
                      );
                    })()
                  ) : (
                    (() => {
                      const k = `align_dir_${sec.id}`;
                      const sv = (map?.[k] ?? 5) as number;
                      const sCol = sv >= 7 ? "#34d399" : sv >= 4 ? "#f59e0b" : "#ef4444";
                      return (
                        <>
                          <input type="range" min={1} max={10} step={1} value={sv}
                            onChange={e => set(k, Number(e.target.value))}
                            style={{ width:"100%", accentColor: sCol }} />
                          <div style={{ display:"flex", justifyContent:"space-between", fontSize:10, marginTop:2 }}>
                            <span style={{ color:"#ef4444" }}>1 = living far from this</span>
                            <span style={{ color:"#34d399" }}>10 = fully embodying this</span>
                          </div>
                        </>
                      );
                    })()
                  )}
                </div>
              )}
            </div>
          );
        })}
        {(() => {
          const hasResult = !!map.align1_dir_misalignment;
          return (
            <button className="btn" style={{display:"none", marginBottom:22, marginTop:6 }}
              onClick={async () => {
                const summary = sections.map(sec => {
                  const s = cardAvg(sec);
                  const sStr = s == null ? "n/a" : s.toFixed(1);
                  let detail = "";
                  if (sec.id === "time" && timeItems.length) {
                    detail = " [" + timeItems.map(a => {
                      const v = map?.[`align1_time_${a.id}`] ?? 5;
                      return `${a.label}: ${v}/10`;
                    }).join(", ") + "]";
                  }
                  if (sec.id === "wealth" && wealthItems.length) {
                    detail = " [" + wealthItems.map(w => {
                      const v = map?.[`align1_wealth_${w.id}`] ?? 5;
                      return `${w.label}: ${v}/10`;
                    }).join(", ") + "]";
                  }
                  if (sec.id === "growth" && sec.sentence) {
                    const v = map?.[`align1_growth`] ?? 5;
                    detail = ` [Growth: ${v}/10]`;
                  }
                  return `${sec.label}: ${sStr}/10${sec.sentence ? ` — "${sec.sentence}"` : ""}${detail}`;
                }).join("; ");
                let lowest = sections[0];
                let lowestScore = cardAvg(sections[0]) ?? 5;
                sections.forEach(sec => {
                  const sc = cardAvg(sec) ?? 5;
                  if (sc < lowestScore) { lowestScore = sc; lowest = sec; }
                });
                setBusy(b => ({ ...b, mirror1_align: true }));
                const result = await callStructured(
                  `You are Katherine Breuss, a direct but compassionate coach. ${name} has rated how fully they are living toward each area of their direction on a 1-10 scale (1 = living far from this, 10 = fully embodying it). Ratings: ${summary}. Purpose: "${map.purpose_final || map.purpose_draft || ""}". The lowest-scoring area is ${lowest.label} (${lowestScore}/10). Identify the single most important misalignment — usually (but not always) the lowest score, unless another gap is more consequential. Name the EXACT area. Then explain: why this matters for their direction, what to focus on first (one concrete action), and how shifting this connects forward. Be specific and personal — no generic coaching language. Return ONLY valid JSON in this exact shape: {"key_misalignment":"Area: X","why_it_matters":"...","focus_first":"...","bridge_to_a2":"..."}`
                );
                set("align1_dir_misalignment", result);
                setBusy(b => ({ ...b, mirror1_align: false }));
              }}>
              {busy.mirror1_align
                ? <span className="dot-l"><span /><span /><span /></span>
                : (hasResult ? "" : "")}
            </button>
          );
        })()}
        {false && map.align1_dir_misalignment && (
          <div className="fade-up" style={{ padding:"18px 22px", background:"rgba(245,158,11,.06)", border:"1px solid rgba(245,158,11,.2)", borderRadius:11, marginBottom:22 }}>
            <div style={{ fontSize:11, fontWeight:500, letterSpacing:2, textTransform:"uppercase", color:"#f59e0b", marginBottom:11 }}>Your key misalignment to focus on</div>
            <div style={{ fontFamily:"var(--serif)", fontSize:17, fontWeight:400, color:"var(--text)", lineHeight:1.7, marginBottom:9 }}>{map.align1_dir_misalignment.key_misalignment}</div>
            <div style={{ fontSize:13, color:"var(--text2)", lineHeight:1.7, marginBottom:11 }}>{map.align1_dir_misalignment.why_it_matters}</div>
            <div style={{ padding:"9px 13px", background:"rgba(201,168,76,.06)", border:"1px solid rgba(201,168,76,.12)", borderRadius:7, marginBottom:9 }}>
              <div style={{ fontSize:11, fontWeight:500, letterSpacing:1.5, textTransform:"uppercase", color:"var(--accent)", marginBottom:3 }}>Focus first on</div>
              <div style={{ fontSize:13, color:"var(--text)", lineHeight:1.6 }}>{map.align1_dir_misalignment.focus_first}</div>
            </div>
            {map.align1_dir_misalignment.bridge_to_a2 && <div style={{ fontSize:14, color:"var(--text3)", fontStyle:"italic", lineHeight:1.6 }}>Carries forward: {map.align1_dir_misalignment.bridge_to_a2}</div>}
          </div>
        )}
        <div style={{ marginBottom:22 }}>
          <AIChat voiceId={voice} onVoiceChange={setVoicePersist} name={name} intake={intake} mapData={map}
            sectionLabel="direction alignment"
            placeholder="Ask Katherine about the gap between your direction and how you're living..." />
        </div>
        <div style={{ display:"flex", justifyContent:"space-between", paddingTop:18, borderTop:"1px solid var(--border)" }}>
          <button className="btn-g" onClick={() => set("mirror1_sub", "output")}>← The Mirror</button>
          <button className="btn" onClick={() => { markDone("mirror1"); goto("direction_3yr"); }}>Direction · 3-YEAR →</button>
        </div>
      </>);
    }
  }
  if (step === "mirror2") {
    const m2sub = map.mirror2_sub || "qualities";
    const m2animals = map.animals || [];
    const validAnimals = m2animals.filter(a => a.name);
    // Sub-step progress
    const M2Progress = () => {
      const order = ["qualities","capabilities","pressure","lovedones","myidentity"];
      const currentIdx = order.indexOf(m2sub);
      const steps = [
        { id:"qualities",    label:"Qualities", icon:"✦" },
        { id:"capabilities", label:"Superpowers", icon:"⚡" },
        { id:"pressure",     label:"Under Pressure", icon:"🔥" },
        { id:"lovedones",    label:"Loved Ones", icon:"🤝" },
      ];
      return (
        <div style={{ display:"flex", alignItems:"center", gap:0, marginBottom:22 }}>
          {steps.map((s, i) => {
            const isActive = m2sub === s.id;
            const isDone = order.indexOf(s.id) < currentIdx;
            return (
              <React.Fragment key={s.id}>
                <div style={{ display:"flex", flexDirection:"column", alignItems:"center", gap:4 }}>
                  <div style={{ width:30, height:30, borderRadius:"50%", background: isActive ? "var(--warm)" : isDone ? "rgba(52,211,153,.2)" : "var(--bg3)", border: isActive ? "none" : isDone ? "1px solid #34d399" : "1px solid var(--border2)", display:"flex", alignItems:"center", justifyContent:"center", fontSize:13, cursor: "pointer" }}
                    onClick={() => set("mirror2_sub", s.id)}>
                    {isDone ? <span style={{ fontSize:12, color:"#34d399" }}>✓</span> : <span>{s.icon}</span>}
                  </div>
                  <span style={{ fontSize:9, fontWeight: isActive ? 700 : 400, color: isActive ? "var(--warm)" : isDone ? "#34d399" : "var(--text4)", textTransform:"uppercase", whiteSpace:"nowrap", maxWidth:52, textAlign:"center", lineHeight:1.3 }}>{s.label}</span>
                </div>
                {i < 3 && <div style={{ flex:1, height:1, background: order.indexOf(steps[i+1].id) <= currentIdx ? "#34d399" : "var(--border2)", margin:"0 4px", marginBottom:22 }} />}
              </React.Fragment>
            );
          })}
        </div>
      );
    };
    // ── STEP 1: QUALITIES & ANIMALS ──────────────────────────────────────────
    if (m2sub === "qualities") {
      const chips = map.identity_chips || [];
      const hasEnoughQualities = chips.length >= 5;
      const hasThreeAnimals = validAnimals.length >= 3;
      const aiUnlocked = hasEnoughQualities && hasThreeAnimals;
      const addQualityChip = (label) => {
        const t = label.trim();
        if (!t || chips.find(c => c.label.toLowerCase() === t.toLowerCase())) return;
        set("identity_chips", [...chips, { id:`c${Date.now()}`, label: t, assignedTo: null }]);
        setChipInput("");
      };
      const removeQualityChip = (id) => {
        const removedChip = chips.find(c => c.id === id);
        const removedLabel = removedChip?.label?.toLowerCase() || "";
        const newChips = chips.filter(c => c.id !== id);
        set("identity_chips", newChips);
        const nextAnimals = m2animals.map((a, i) => ({
          ...a,
          adjective1: newChips.filter(c => c.assignedTo === i).map(c => c.label).join(", "),
          capabilities: (a.capabilities || []).filter(cap => cap.name.toLowerCase() !== removedLabel)
        }));
        set("animals", nextAnimals);
      };
      const unassignChipFromAnimal = (id) => {
        const removedChip = chips.find(c => c.id === id);
        const removedLabel = removedChip?.label?.toLowerCase() || "";
        const animalIdx = removedChip?.assignedTo;
        const newChips = chips.map(c => c.id === id ? { ...c, assignedTo: null } : c);
        set("identity_chips", newChips);
        const nextAnimals = m2animals.map((a, i) => ({
          ...a,
          adjective1: newChips.filter(c => c.assignedTo === i).map(c => c.label).join(", "),
          capabilities: i === animalIdx
            ? (a.capabilities || []).filter(cap => cap.name.toLowerCase() !== removedLabel)
            : (a.capabilities || [])
        }));
        set("animals", nextAnimals);
      };
      const assignChipToAnimal = (chipId, animalIdx) => {
        const newChips = chips.map(c => c.id === chipId ? { ...c, assignedTo: animalIdx } : c);
        set("identity_chips", newChips);
        const base = m2animals.length >= 3 ? [...m2animals] : [...m2animals, ...Array(3 - m2animals.length).fill({ name:"", adj1:"", adj2:"", adjective1:"" })];
        base[animalIdx] = { ...base[animalIdx], adjective1: newChips.filter(c => c.assignedTo === animalIdx).map(c => c.label).join(", ") };
        set("animals", base);
      };
      const applyAISuggestions = () => {
        const sort = ai.identity_sort;
        if (!sort) return;
        const newChips = [...chips];
        const base = m2animals.length >= 3 ? [...m2animals] : [...m2animals, ...Array(3 - m2animals.length).fill({ name:"", adj1:"", adj2:"", adjective1:"" })];
        ["animal1","animal2","animal3"].forEach((key, idx) => {
          const s = sort[key];
          if (!s || idx >= m2animals.length) return;
          const animalName = (s.name || "").toLowerCase();
          const targetIdx = m2animals.findIndex(a => a.name.toLowerCase() === animalName);
          const ti = targetIdx >= 0 ? targetIdx : idx;
          (s.qualities || []).forEach(q => {
            const ci = newChips.findIndex(c => c.label.toLowerCase() === q.toLowerCase());
            if (ci >= 0) newChips[ci] = { ...newChips[ci], assignedTo: ti };
          });
          base[ti] = { ...base[ti], adjective1: newChips.filter(c => c.assignedTo === ti).map(c => c.label).join(", ") };
        });
        set("identity_chips", newChips);
        set("animals", base);
      };
      return wrapContent(<>
        <div className="lbl" style={{ marginBottom:12 }}>Mirror 2 of 3 · Step 1</div>
        {M2Progress()}
        <h2 style={{ fontFamily:"var(--serif)", fontSize:34, fontWeight:400, lineHeight:1.2, marginBottom:7, letterSpacing:"-0.3px" }}>Identity</h2>
        <p style={{ fontSize:16, color:"var(--text2)", lineHeight:1.75, marginBottom:18, maxWidth:540 }}>
          Start with yourself. Write the qualities that describe you at your best -- unfiltered. Then drag them to your animals.
        </p>
        <VideoBlock title="Identity -- Who You Are at Your Best" duration="~6 min"
          points={["Why we anchor identity to animals -- images over word lists","The two-adjective rule -- specific to you, not the generic animal","How to sort your qualities without overthinking it","You write first. The board advises after."]} />
        <div style={{ padding:"13px 16px", background:"rgba(201,168,76,.06)", border:"1px solid rgba(201,168,76,.14)", borderRadius:9, marginBottom:20 }}>
          <div style={{ fontFamily:"var(--serif)", fontSize:14, fontStyle:"italic", color:"var(--text2)", lineHeight:1.7 }}>
            "You are the authority on your own identity. Write your qualities first. Then sort them to your animals. The AI can suggest -- you decide."
          </div>
        </div>
        {/* Chip input */}
        <div style={{ marginBottom:22 }}>
          <div style={{ fontFamily:"var(--sans)", fontSize:13, fontWeight:700, color:"var(--text)", marginBottom:4 }}>Step 1 -- Brain dump your qualities (aim for 15–30)</div>
          <div style={{ fontSize:12, color:"var(--text3)", marginBottom:10, lineHeight:1.6 }}>Every quality that describes you at your best. Hit Enter or click Add. Then drag chips to your animals.</div>
          <div style={{ display:"flex", gap:7, marginBottom:10 }}>
            <input className="to-field" value={chipInput} onChange={e => setChipInput(e.target.value)}
              onKeyDown={e => { if (e.key === "Enter") { e.preventDefault(); addQualityChip(chipInput); } }}
              placeholder="Type a quality and press Enter..." style={{ flex:1, padding:"9px 13px", fontSize:13, borderRadius:8 }} />
            <button onClick={() => addQualityChip(chipInput)}
              style={{ background:"var(--bg3)", border:"1px solid var(--border2)", borderRadius:8, color:"var(--warm)", cursor:"pointer", fontFamily:"var(--sans)", fontSize:12, padding:"0 16px", flexShrink:0 }}>
              Add
            </button>
          </div>
          {chips.length > 0 ? (
            <div style={{ display:"flex", flexWrap:"wrap", gap:6, padding:"10px 12px", background:"var(--bg3)", border:"1px solid var(--border2)", borderRadius:9, minHeight:48 }}>
              {chips.map(chip => {
                const isAssigned = chip.assignedTo !== null && chip.assignedTo !== undefined;
                const animalName = isAssigned && m2animals[chip.assignedTo] ? m2animals[chip.assignedTo].name : null;
                return (
                  <div key={chip.id} className={`chip chip-drag ${isAssigned ? "chip-green" : "chip-gold"}`}
                    draggable onDragStart={e => e.dataTransfer.setData("chipId", chip.id)}
                    title={animalName ? `Assigned to ${animalName}` : "Drag to an animal"}>
                    {isAssigned && <span style={{ fontSize:10 }}>✓</span>}
                    {chip.label}
                    <button onClick={() => isAssigned ? unassignChipFromAnimal(chip.id) : removeQualityChip(chip.id)}
                      style={{ background:"none", border:"none", color:"inherit", cursor:"pointer", fontSize:14, padding:"0 0 0 3px", lineHeight:1, opacity:.6 }}>×</button>
                  </div>
                );
              })}
            </div>
          ) : (
            <div style={{ padding:"14px", background:"var(--bg3)", border:"1.5px dashed var(--border2)", borderRadius:9, textAlign:"center", color:"var(--text4)", fontSize:12, fontStyle:"italic" }}>
              Your quality chips will appear here — drag them to animals below
            </div>
          )}
          <div style={{ fontSize:11, color:"var(--text4)", marginTop:5 }}>{chips.length} {chips.length === 1 ? "quality" : "qualities"} · {chips.filter(c => c.assignedTo !== null && c.assignedTo !== undefined).length} assigned</div>
        </div>
        {/* 3 animal drop zones */}
        <div style={{ marginBottom:22 }}>
          <div style={{ fontFamily:"var(--sans)", fontSize:13, fontWeight:700, color:"var(--text)", marginBottom:4 }}>Step 2 -- Choose exactly 3 animals</div>
          <div style={{ fontSize:12, color:"var(--text3)", marginBottom:12, lineHeight:1.6 }}>Name each animal, then drag your quality chips onto them.</div>
          {[0,1,2].map(i => {
            const a = m2animals[i] || { name:"", adj1:"", adj2:"", adjective1:"" };
            const assignedChips = chips.filter(c => c.assignedTo === i);
            const updateAnimalField = (field, val) => {
              const next = m2animals.length >= 3 ? [...m2animals] : [...m2animals, ...Array(3 - m2animals.length).fill({ name:"", adj1:"", adj2:"", adjective1:"" })];
              next[i] = { ...next[i], [field]: val };
              set("animals", next);
            };
            const adj1 = a.adj1 || "";
            const adj2 = a.adj2 || "";
            const previewTitle = [adj1, adj2, a.name].filter(Boolean).join(" ");
            return (
              <div key={i}
                className={`drop-zone${dragOver === i ? " over" : ""}`}
                style={{ background:"var(--bg3)", border:`1.5px ${dragOver === i ? "dashed rgba(201,168,76,.6)" : "solid var(--border2)"}`, borderRadius:9, marginBottom:10, padding:"13px 15px" }}
                onDragOver={e => { e.preventDefault(); setDragOver(i); }}
                onDragLeave={() => setDragOver(null)}
                onDrop={e => { e.preventDefault(); setDragOver(null); const id = e.dataTransfer.getData("chipId"); if (id) assignChipToAnimal(id, i); }}>
                <div style={{ fontSize:11, fontWeight:700, letterSpacing:1.5, textTransform:"uppercase", color:"var(--warm)", marginBottom:9 }}>Animal {i+1}</div>
                <TextInput value={a.name || ""} onChange={v => updateAnimalField("name", v)}
                  placeholder={["e.g. Lion","e.g. Eagle","e.g. Dolphin"][i]} style={{ fontSize:13, marginBottom:10 }} />
                {/* Two adjective inputs */}
                <div style={{ marginBottom:10 }}>
                  <div style={{ fontSize:11, color:"var(--text4)", marginBottom:6 }}>Describe your animal (2 words)</div>
                  <div style={{ display:"flex", gap:7 }}>
                    <input className="to-field" value={adj1} onChange={e => updateAnimalField("adj1", e.target.value)}
                      placeholder="e.g. Gracefully" style={{ flex:1, padding:"7px 11px", fontSize:12, borderRadius:7 }} />
                    <input className="to-field" value={adj2} onChange={e => updateAnimalField("adj2", e.target.value)}
                      placeholder="e.g. Wise" style={{ flex:1, padding:"7px 11px", fontSize:12, borderRadius:7 }} />
                  </div>
                  {adj1 && adj2 && a.name && (
                    <div style={{ marginTop:7, fontFamily:"var(--serif)", fontSize:14, fontStyle:"italic", color:"var(--warm)" }}>
                      "{previewTitle}"
                    </div>
                  )}
                </div>
                {assignedChips.length > 0 ? (
                  <div style={{ display:"flex", flexWrap:"wrap", gap:5 }}>
                    {assignedChips.map(chip => (
                            <span key={chip.id} className="chip chip-green" style={{ fontSize:11, display:"inline-flex", alignItems:"center", gap:3 }}>
                              <span style={{ fontSize:10 }}>✓</span>{chip.label}
                              <button onClick={e => { e.stopPropagation(); unassignChipFromAnimal(chip.id); }} style={{ background:"none", border:"none", cursor:"pointer", color:"inherit", fontSize:13, padding:0, lineHeight:1, opacity:.6 }}>×</button>
                            </span>
                    ))}
                  </div>
                ) : (
                  <div style={{ padding:"9px", border:"1.5px dashed rgba(201,168,76,.2)", borderRadius:7, textAlign:"center", color:"var(--text4)", fontSize:11, fontStyle:"italic" }}>
                    {a.name ? "Drop quality chips here" : "Name this animal first"}
                  </div>
                )}
              </div>
            );
          })}
        </div>
        {/* AI sort suggestion */}
        <div style={{ padding:"14px 16px", background: aiUnlocked ? "var(--bg2)" : "var(--bg3)", border:"1px solid var(--border2)", borderRadius:9, marginBottom:22, opacity: aiUnlocked ? 1 : 0.6 }}>
          <div style={{ fontSize:11, fontWeight:700, letterSpacing:1.5, textTransform:"uppercase", color: aiUnlocked ? "var(--warm)" : "var(--text4)", marginBottom:6 }}>
            ✦ Ask AI to suggest how to sort your qualities
          </div>
          <div style={{ fontSize:12, color:"var(--text3)", marginBottom:10, lineHeight:1.5 }}>
            {aiUnlocked
              ? "You have your qualities and animals. The AI can suggest how to sort them -- you decide."
              : "Add at least 5 qualities and name all 3 animals first -- you lead, the board advises."
            }
          </div>
          {aiUnlocked && !ai.identity_sort && (
            <button onClick={() => {
              const qualityList = chips.map(c => c.label).join(", ");
              const animalNames = validAnimals.map(a => a.name).join(", ");
              runAI("identity_sort",
                `You are a mirror -- not an authority. ${name} has written these qualities: "${qualityList}". Their 3 animals are: ${animalNames}. Suggest how to sort the qualities to each animal -- 3 to 5 per animal. Explain briefly why each grouping makes sense. Respond ONLY with valid JSON, no other text: {"animal1":{"name":"...","qualities":["..."],"reason":"..."},"animal2":{"name":"...","qualities":["..."],"reason":"..."},"animal3":{"name":"...","qualities":["..."],"reason":"..."}}`
              );
            }}
              style={{ background:"none", border:"1px solid rgba(201,168,76,.3)", borderRadius:20, color:"var(--warm)", cursor:"pointer", fontFamily:"var(--sans)", fontSize:12, padding:"7px 16px" }}>
              {busy.identity_sort ? <span className="dot-l"><span /><span /><span /></span> : "✦ Get sorting suggestion"}
            </button>
          )}
          {ai.identity_sort && (
            <div className="fade-in">
              <div style={{ fontSize:11, color:"var(--text4)", fontStyle:"italic", marginBottom:10 }}>This is a suggestion -- adjust it until it feels right to you.</div>
              {["animal1","animal2","animal3"].map(k => ai.identity_sort[k] ? (
                <div key={k} style={{ marginBottom:10, padding:"10px 13px", background:"var(--bg3)", border:"1px solid var(--border2)", borderRadius:8 }}>
                  <div style={{ fontFamily:"var(--sans)", fontSize:12, fontWeight:700, color:"var(--warm)", marginBottom:5 }}>{ai.identity_sort[k].name}</div>
                  <div style={{ display:"flex", flexWrap:"wrap", gap:5, marginBottom:6 }}>
                    {(ai.identity_sort[k].qualities || []).map((q, qi) => (
                      <span key={qi} style={{ fontSize:11, padding:"2px 9px", background:"rgba(201,168,76,.1)", border:"1px solid rgba(201,168,76,.2)", borderRadius:12, color:"var(--warm)" }}>{q}</span>
                    ))}
                  </div>
                  <div style={{ fontSize:11, color:"var(--text4)", fontStyle:"italic" }}>{ai.identity_sort[k].reason}</div>
                </div>
              ) : null)}
              <button onClick={applyAISuggestions}
                style={{ marginTop:6, background:"none", border:"1px solid rgba(52,211,153,.4)", borderRadius:20, color:"#34d399", cursor:"pointer", fontFamily:"var(--sans)", fontSize:12, padding:"7px 16px" }}>
                ✦ Add AI suggestions to my animals
              </button>
            </div>
          )}
        </div>
        <div style={{ display:"flex", justifyContent:"space-between", paddingTop:18, borderTop:"1px solid var(--border)" }}>
          <button className="btn-g" onClick={() => goto("direction_3yr")}>← Direction · 3-YEAR</button>
          <button className="btn" onClick={() => set("mirror2_sub", "capabilities")}>Superpowers →</button>
        </div>
      </>);
    }
    // ── STEP 2: CAPABILITIES ─────────────────────────────────────────────────
    if (m2sub === "capabilities") return wrapContent(<>
      <div className="lbl" style={{ marginBottom:12 }}>Mirror 2 of 3 · Step 2</div>
      {M2Progress()}
      <h2 style={{ fontFamily:"var(--serif)", fontSize:34, fontWeight:400, lineHeight:1.2, marginBottom:7, letterSpacing:"-0.3px" }}>Superpowers</h2>
      <p style={{ fontSize:16, color:"var(--text2)", lineHeight:1.75, marginBottom:18, maxWidth:540 }}>
        For each animal, name 3–5 superpowers -- what your qualities actually enable in practice. Describe each one in your own words and give two real examples of when you lived it.
      </p>
      <div style={{ padding:"13px 16px", background:"rgba(201,168,76,.06)", border:"1px solid rgba(201,168,76,.14)", borderRadius:9, marginBottom:22 }}>
        <div style={{ fontFamily:"var(--serif)", fontSize:14, fontStyle:"italic", color:"var(--text2)", lineHeight:1.7 }}>
          "The examples are the most important part. They are your evidence -- your own proof that you are this person."
        </div>
      </div>
      {validAnimals.length === 0 && (
        <div style={{ padding:20, textAlign:"center", color:"var(--text4)", fontSize:13, fontStyle:"italic" }}>Go back to Step 1 and name your animals first.</div>
      )}
      {validAnimals.map((animal, animalIdx) => (
        <CapAnimalCard key={animalIdx} animal={animal} animalIdx={animalIdx} m2animals={m2animals} set={set} map={map} />
      ))}
      <div style={{ display:"flex", justifyContent:"space-between", paddingTop:18, borderTop:"1px solid var(--border)" }}>
        <button className="btn-g" onClick={() => set("mirror2_sub", "qualities")}>← Qualities & Animals</button>
        <button className="btn" onClick={() => set("mirror2_sub", "pressure")}>Under Pressure →</button>
      </div>
    </>);
  // — STEP 3: UNDER PRESSURE ————————————————————————————————
  if (m2sub === "pressure") return wrapContent(<>
    <div className="lbl" style={{ marginBottom:12 }}>Mirror 2 of 3 · Step 3</div>
    {M2Progress()}
    {map?.return_to_a2 === "iv_align" && (
      <div style={{ padding:"10px 14px", marginBottom:14, background:"rgba(96,165,250,.08)", border:"1px solid rgba(96,165,250,.3)", borderLeft:"3px solid #60a5fa", borderRadius:8, display:"flex", alignItems:"center", justifyContent:"space-between", gap:10 }}>
        <div style={{ fontSize:12, color:"var(--text2)", lineHeight:1.5 }}>
          <strong style={{ color:"#60a5fa", fontWeight:700 }}>From A2 Alignment</strong> — have a look, then jump back.
        </div>
        <button onClick={async () => {
          // Write the next-A2 target directly to localStorage so A2's mount effect picks it up.
          const current = await loadData(KEYS.map);
          const next = { ...(current || {}), return_to_a2: null, a2_pending_step: "iv_align" };
          await saveData(KEYS.map, next);
          await saveData(KEYS.phase, "a2");
          setPhase("a2");
        }}
          style={{ padding:"6px 12px", borderRadius:12, background:"transparent", color:"#60a5fa", border:"1px solid #60a5fa", cursor:"pointer", fontSize:11, fontWeight:700, flexShrink:0 }}>
          ← Back to A2 Alignment
        </button>
      </div>
    )}
    <h2 style={{ fontFamily:"var(--serif)", fontSize:34, fontWeight:400, lineHeight:1.2, marginBottom:7, letterSpacing:"-0.3px" }}>Under Pressure</h2>
    <p style={{ fontSize:16, color:"var(--text2)", lineHeight:1.75, marginBottom:18, maxWidth:540 }}>
      Character is not revealed when things are easy. For each animal — how do you actually show up when things go wrong?
    </p>
    <div style={{ padding:"13px 16px", background:"rgba(239,68,68,.05)", border:"1px solid rgba(239,68,68,.15)", borderRadius:8, marginBottom:20 }}>
      <div style={{ fontFamily:"var(--serif)", fontSize:14, fontStyle:"italic", color:"var(--text2)", lineHeight:1.5 }}>
        "This is the most important question in this section. Not who you are when things are good — who you are when things are hard. Be honest."
      </div>
    </div>
    {validAnimals.length === 0 && (
      <div style={{ padding:20, textAlign:"center", color:"var(--text4)", fontSize:13, fontStyle:"italic" }}>Go back to Step 1 to name your animals first.</div>
    )}
    {validAnimals.map((animal, i) => {
      const trueIdx = m2animals.findIndex(a => a.name === animal.name);
      const caps = (animal.capabilities || []).filter((c: any) => c.name);
      return (
        <div key={i} style={{ marginBottom:24, padding:"16px 18px", background:"var(--bg3)", border:"1px solid var(--border2)", borderRadius:10 }}>
          <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:16 }}>
            <span style={{ fontFamily:"var(--serif)", fontSize:16, fontStyle:"italic", color:"var(--warm)" }}>
              {[animal.adj1, animal.adj2, animal.name].filter(Boolean).join(" ")}
            </span>
          </div>
          {caps.length === 0 && (
            <div style={{ padding:12, textAlign:"center", color:"var(--text4)", fontSize:13, fontStyle:"italic" }}>Go back to Step 2 — Superpowers to add superpowers first.</div>
          )}
          {caps.map((cap: any, ci: number) => {
            const supChips: string[] = cap.superpower_chips || [];
            const detKey = `det_text_${trueIdx}_${ci}`;
            const detChipsKey = `det_chips_${trueIdx}_${ci}`;
            const detInputKey = `det_input_${trueIdx}_${ci}`;
            const alignKey = `align_cap_${trueIdx}_${ci}`;
            const collapseKey = `up_open_${trueIdx}_${ci}`;
            const isOpen = (map?.[collapseKey] === true);
            const detVal = (map?.[detKey] || "") as string;
            const detChips: string[] = (map?.[detChipsKey] || []) as string[];
            const detInput = (map?.[detInputKey] || "") as string;
            const alignScore = (map?.[alignKey] ?? 5) as number;
            const alignCol = alignScore >= 7 ? "#34d399" : alignScore >= 4 ? "#f59e0b" : "#ef4444";
            const PRESET_DET = ["overthink","withdraw","over-control","people-please","deflect","shut down","spiral","freeze","blame","numb","go quiet","get reactive"];
            return (
              <div key={ci} style={{ marginBottom:12, border:"1px solid var(--border2)", borderRadius:8, overflow:"hidden" }}>
                {/* Collapsible header */}
                <div onClick={() => set(collapseKey, !isOpen)}
                  style={{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:"10px 14px", background:"var(--bg4)", cursor:"pointer", userSelect:"none" }}>
                  <div style={{ fontSize:13, fontWeight:700, color:"var(--text)" }}>{cap.name}</div>
                  <div style={{ display:"flex", alignItems:"center", gap:8 }}>

                    <span style={{ fontSize:14, color:"var(--text3)", transform: isOpen ? "rotate(180deg)" : "none", transition:"transform .2s" }}>▾</span>
                  </div>
                </div>
                {isOpen && (
                <div style={{ padding:"14px 14px 10px", borderTop:"1px solid var(--border)" }}>

                {/* Superpower chips — read only */}
                                {supChips.length > 0 && <div style={{ fontSize:10, fontWeight:700, letterSpacing:1.5, textTransform:"uppercase", color:"var(--warm)", marginBottom:4 }}>Superpower</div>}
{supChips.length > 0 && (
                  <div style={{ display:"flex", flexWrap:"wrap", gap:5, marginBottom:12 }}>
                    {supChips.map((w: string) => (
                      <span key={w} style={{ fontSize:11, padding:"3px 10px", borderRadius:20, background:"rgba(201,168,76,.15)", border:"1px solid rgba(201,168,76,.35)", color:"var(--warm)", fontFamily:"var(--sans)" }}>{w}</span>
                    ))}
                  </div>
                )}
                {/* Free text */}
                <label style={{ display:"block", fontSize:11, fontWeight:500, color:"var(--text3)", marginBottom:5 }}>
                  When <em>{cap.name}</em> is over or underused — how do you show up?
                </label>
                <TextArea
                  value={detVal}
                  onChange={(v: string) => set(detKey, v)}
                  rows={3}
                  placeholder={`When ${cap.name} goes out of balance, I tend to...`}
                  style={{ fontSize:13, marginBottom:10 }}
                />
                {/* Detriment chips — preset + add + delete */}
                <div style={{ fontSize:11, color:"var(--text3)", marginBottom:6 }}>Tap a word to add it, or write your own below.</div>
                <div style={{ display:"flex", flexWrap:"wrap", gap:5, marginBottom:8 }}>
                  {PRESET_DET.map((word: string) => {
                    const on = detChips.includes(word);
                    return (
                      <button key={word}
                        onClick={() => set(detChipsKey, on ? detChips.filter((w: string) => w !== word) : [...detChips, word])}
                        style={{ display:"inline-flex", alignItems:"center", gap:4, fontSize:11, padding:"3px 10px", borderRadius:20, border:`1px solid ${on ? "rgba(239,68,68,.6)" : "var(--border2)"}`, background: on ? "rgba(239,68,68,.12)" : "transparent", color: on ? "#ef4444" : "var(--text3)", cursor:"pointer", fontFamily:"var(--sans)", transition:"all .15s" }}>
                        {on && <span onClick={e => { e.stopPropagation(); set(detChipsKey, detChips.filter((w: string) => w !== word)); }} style={{ fontWeight:700, fontSize:10, opacity:.7 }}>×</span>}
                        {word}
                      </button>
                    );
                  })}
                  {/* Custom chips */}
                  {detChips.filter((w: string) => !PRESET_DET.includes(w)).map((word: string) => (
                    <button key={word}
                      style={{ display:"inline-flex", alignItems:"center", gap:4, fontSize:11, padding:"3px 10px", borderRadius:20, border:"1px solid rgba(239,68,68,.6)", background:"rgba(239,68,68,.12)", color:"#ef4444", cursor:"pointer", fontFamily:"var(--sans)" }}>
                      <span onClick={() => set(detChipsKey, detChips.filter((w2: string) => w2 !== word))} style={{ fontWeight:700, fontSize:10, opacity:.7 }}>×</span>
                      {word}
                    </button>
                  ))}
                </div>
                {/* Add custom word */}
                <div style={{ display:"flex", gap:5, marginBottom:12 }}>
                  <input value={detInput} onChange={e => set(detInputKey, e.target.value)}
                    onKeyDown={e => { if (e.key === "Enter" && detInput.trim()) { set(detChipsKey, [...detChips, detInput.trim()]); set(detInputKey, ""); }}}
                    placeholder="Add a word…" style={{ flex:1, fontSize:11, padding:"4px 9px", borderRadius:6, border:"1px solid var(--border2)", background:"var(--bg4)", color:"var(--text)", fontFamily:"var(--sans)" }} />
                  <button onClick={() => { if (detInput.trim()) { set(detChipsKey, [...detChips, detInput.trim()]); set(detInputKey, ""); }}}
                    style={{ fontSize:11, padding:"4px 10px", borderRadius:6, border:"1px solid rgba(201,168,76,.3)", background:"rgba(201,168,76,.1)", color:"var(--warm)", cursor:"pointer", fontFamily:"var(--sans)" }}>Add</button>
                </div>
                </div>
                )}
              </div>
            );
          })}
        </div>
      );
    })}
    <div style={{ display:"flex", justifyContent:"space-between", paddingTop:18, borderTop:"1px solid var(--border)" }}>
      <button className="btn-g" onClick={() => set("mirror2_sub", "capabilities")}>← Superpowers</button>
      <button className="btn" onClick={() => set("mirror2_sub", "lovedones")}>Loved Ones →</button>
    </div>
  </>);
    // ── STEP 5: MY IDENTITY ──────────────────────────────────────────────────
    if (m2sub === "myidentity") return wrapContent(<>
      <div className="lbl" style={{ marginBottom:12 }}>Mirror 2 of 3 · Step 5</div>
      {M2Progress()}
      <h2 style={{ fontFamily:"var(--serif)", fontSize:34, fontWeight:400, lineHeight:1.2, marginBottom:7, letterSpacing:"-0.3px" }}>My Identity</h2>
      <p style={{ fontSize:16, color:"var(--text2)", lineHeight:1.75, marginBottom:18, maxWidth:540 }}>
        This is your synthesis. For each animal, rate how fully you're living each capability right now — and be honest about how you show up under pressure.
      </p>
      {validAnimals.length === 0 && (
        <div style={{ padding:20, textAlign:"center", color:"var(--text4)", fontSize:13, fontStyle:"italic" }}>Go back to Step 1 to name your animals first.</div>
      )}
      {validAnimals.map((animal, animalIdx) => {
        const trueIdx = m2animals.findIndex(a => a.name === animal.name);
        const _chipSet = new Set((map.identity_chips||[]).map(c=>c.label.toLowerCase()));
        const caps = (animal.capabilities || []).filter(c => !c.name || !_chipSet.size || _chipSet.has(c.name.toLowerCase()));
        const miKey = `mi_open_${animalIdx}`;
        const miOpen = map?.[miKey] !== false;
        const miScores = caps.map((_,ci) => (map?.[`align_cap_${trueIdx}_${ci}`] ?? 5) as number);
        const miAvg = caps.length > 0 ? (miScores.reduce((a,b)=>a+b,0)/caps.length).toFixed(1) : null;
        const miAvgCol = miAvg !== null ? (parseFloat(miAvg) >= 7 ? "#22c55e" : parseFloat(miAvg) > 3 ? "#f59e0b" : "#ef4444") : "var(--warm)";
        return (
          <div key={animalIdx} style={{ marginBottom:22, border:"1px solid var(--border2)", borderRadius:10, overflow:"hidden" }}>
            <div onClick={() => set(miKey, !miOpen)}
              style={{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:"14px 18px", background:"var(--bg3)", cursor:"pointer", userSelect:"none" }}>
              <div style={{ fontFamily:"var(--serif)", fontSize:16, fontStyle:"italic", color:"var(--warm)" }}>{[animal.adj1, animal.adj2, animal.name].filter(Boolean).join(" ")}</div>
              <div style={{ display:"flex", alignItems:"center", gap:10 }}>
                {miAvg && <span style={{ fontSize:13, fontWeight:700, color:miAvgCol }}>Avg {miAvg}/10</span>}
                <span style={{ fontSize:14, color:"var(--text3)", transform: miOpen ? "rotate(180deg)" : "none", transition:"transform .2s" }}>▾</span>
              </div>
            </div>
            {miOpen && (
            <div style={{ padding:"16px 18px", borderTop:"1px solid var(--border)" }}>
              <div style={{ fontSize:10, fontWeight:700, letterSpacing:1.5, textTransform:"uppercase", color:"#a78bfa", marginBottom:10 }}>Superpowers</div>
              {caps.length === 0 ? (
                <div style={{ fontSize:12, color:"var(--text4)", fontStyle:"italic", lineHeight:1.5 }}>
                  Go to Step 2 · Superpowers to add superpowers for this animal.
                </div>
              ) : caps.map((cap, ci) => {
                const storeKey = `align_cap_${trueIdx}_${ci}`;
                const score = map[storeKey] ?? 5;
                const col = score >= 7 ? "#34d399" : score >= 4 ? "#f59e0b" : "#ef4444";
                return (
                  <div key={ci} style={{ marginBottom:14 }}>
                    <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:4 }}>
                      <span style={{ fontSize:12, fontWeight:600, color:"var(--text)" }}>{cap.name}</span>
                      <span style={{ fontSize:13, fontWeight:700, color:col }}>{score}/10</span>
                    </div>
                    <input type="range" min={1} max={10} step={1} value={score}
                      onChange={e => set(storeKey, Number(e.target.value))}
                      style={{ width:"100%", accentColor: col }} />
                    <div style={{ display:"flex", justifyContent:"space-between", fontSize:10, marginTop:2 }}><span style={{ color:"#ef4444" }}>1 = living far from this</span><span style={{ color:"#34d399" }}>10 = fully embodying this</span></div>
                  </div>
                );
              })}
            </div>
            )}
          </div>
        );
      })}
      <div style={{ display:"flex", justifyContent:"space-between", paddingTop:18, borderTop:"1px solid var(--border)" }}>
        <button className="btn-g" onClick={() => set("mirror2_sub", "lovedones")}>← Loved Ones</button>
        <button className="btn" onClick={() => { markDone("mirror2"); goto("mirror3"); }}>Values · Behaviors →</button>
      </div>
    </>);
    // ── STEP 4: LOVED ONES ───────────────────────────────────────────────────
    return wrapContent(<>
      <div className="lbl" style={{ marginBottom:12 }}>Mirror 2 of 3 · Step 4</div>
      {M2Progress()}
      <h2 style={{ fontFamily:"var(--serif)", fontSize:34, fontWeight:400, lineHeight:1.2, marginBottom:7, letterSpacing:"-0.3px" }}>The Loved Ones Check</h2>
      <p style={{ fontSize:16, color:"var(--text2)", lineHeight:1.75, marginBottom:18, maxWidth:540 }}>
        Share your animals, your capabilities and your under-pressure answers with someone who knows you well. Ask them what they see. Then record it here.
      </p>
      <div style={{ padding:"13px 16px", background:"rgba(167,139,250,.06)", border:"1px solid rgba(167,139,250,.18)", borderRadius:9, marginBottom:22 }}>
        <div style={{ fontFamily:"var(--serif)", fontSize:14, fontStyle:"italic", color:"var(--text2)", lineHeight:1.7 }}>
          "We are so reliant on others telling us who we are without exploring within ourselves first. You have now done that work. Does what you see match what those closest to you see?"
        </div>
      </div>
      <div style={{ marginBottom:18 }}>
        <label style={{ display:"block", fontFamily:"var(--sans)", fontSize:13, fontWeight:600, color:"var(--text)", marginBottom:6 }}>Who did you share this with?</label>
        <TextInput value={map.lovedones_who || ""} onChange={v => set("lovedones_who", v)} placeholder="e.g. My partner, my closest friend..." style={{ fontSize:13, marginBottom:14 }} />
        <label style={{ display:"block", fontFamily:"var(--sans)", fontSize:13, fontWeight:600, color:"var(--text)", marginBottom:6 }}>What did they say?</label>
        <TextArea value={map.lovedones_input || ""} onChange={v => set("lovedones_input", v)} rows={5}
          placeholder="Their words -- what did they see in you that confirmed or surprised you?" style={{ fontSize:13, marginBottom:14 }} />
        <label style={{ display:"block", fontFamily:"var(--sans)", fontSize:13, fontWeight:600, color:"var(--text)", marginBottom:6 }}>What surprised you? What confirmed what you already knew?</label>
        <TextArea value={map.lovedones_reflection || ""} onChange={v => set("lovedones_reflection", v)} rows={4}
          placeholder="What I didn't expect was... / What confirmed what I already knew was..." style={{ fontSize:13 }} />
      </div>
      <div style={{ padding:"13px 16px", background:"var(--bg2)", border:"1px solid var(--border)", borderRadius:9, marginBottom:22 }}>
        <div style={{ fontSize:12, color:"var(--text3)", lineHeight:1.7 }}>
          The gap between what you wrote and what they saw -- that is data. Not judgment. You cannot choose your advocates wisely until you know yourself. You have done that work here.
        </div>
      </div>
      <div style={{ marginBottom:22 }}>
        <AIChat voiceId={voice} onVoiceChange={setVoicePersist} name={name} intake={intake} mapData={map}
          sectionLabel="identity and animals"
          placeholder="Ask Katherine about your identity -- she can see everything you've written..." />
      </div>
      <div style={{ display:"flex", justifyContent:"space-between", paddingTop:18, borderTop:"1px solid var(--border)" }}>
        <button className="btn-g" onClick={() => set("mirror2_sub", "pressure")}>← Under Pressure</button>
        <button className="btn" onClick={() => { markDone("mirror2"); goto("mirror3"); }}>Values · Behaviors →</button>
      </div>
    </>);
  }
  if (step === "mirror3") {
    const m3sub = map.mirror3_sub || "values";
    const values = map.values || [{ name:"", irk:"", behaviors:"" }];
    const setVal = (i, field, val) => { const n = [...values]; n[i] = { ...n[i], [field]:val }; set("values", n); };
    const M3Progress = () => {
      const order = ["values","behaviors","hierarchy","alignment"];
      const currentIdx = order.indexOf(m3sub);
      const steps = [
        { id:"values",     label:"Values",     icon:"⚖️" },
        { id:"behaviors",  label:"Behaviors",  icon:"🎯" },
        { id:"hierarchy",  label:"Hierarchy",  icon:"📊" },
      ];
      return (
        <div style={{ display:"flex", alignItems:"center", gap:0, marginBottom:22 }}>
          {steps.map((s, i) => {
            const isActive = m3sub === s.id;
            const isDone = order.indexOf(s.id) < currentIdx;
            return (
              <React.Fragment key={s.id}>
                <div style={{ display:"flex", flexDirection:"column", alignItems:"center", gap:4 }}>
                  <div style={{ width:30, height:30, borderRadius:"50%", background: isActive ? "var(--warm)" : isDone ? "rgba(52,211,153,.2)" : "var(--bg3)", border: isActive ? "none" : isDone ? "1px solid #34d399" : "1px solid var(--border2)", display:"flex", alignItems:"center", justifyContent:"center", fontSize:13, cursor:"pointer" }}
                    onClick={() => set("mirror3_sub", s.id)}>
                    {isDone ? <span style={{ fontSize:12, color:"#34d399" }}>✓</span> : <span>{s.icon}</span>}
                  </div>
                  <span style={{ fontSize:9, fontWeight: isActive ? 700 : 400, color: isActive ? "var(--warm)" : isDone ? "#34d399" : "var(--text4)", textTransform:"uppercase", whiteSpace:"nowrap", maxWidth:60, textAlign:"center", lineHeight:1.3 }}>{s.label}</span>
                </div>
                {i < 2 && <div style={{ flex:1, height:1, background: order.indexOf(steps[i+1].id) <= currentIdx ? "#34d399" : "var(--border2)", margin:"0 4px", marginBottom:22 }} />}
              </React.Fragment>
            );
          })}
        </div>
      );
    };
    // ── STEP 1: VALUES ───────────────────────────────────────────────────────
    if (m3sub === "values") return wrapContent(<>
      <div className="lbl" style={{ marginBottom:12 }}>Mirror 3 of 3 · Step 1</div>
      {M3Progress()}
      <h2 style={{ fontFamily:"var(--serif)", fontSize:34, fontWeight:400, lineHeight:1.2, marginBottom:7, letterSpacing:"-0.3px" }}>Values</h2>
      <p style={{ fontSize:16, color:"var(--text2)", lineHeight:1.75, marginBottom:20, maxWidth:540 }}>What you stand for internally. The fastest way to find your values is to find what makes your blood boil — then peel back one layer.</p>
      <VideoBlock title="Values — What You Actually Stand For" duration="~7 min" points={["Why irritation is your fastest path to values","The peeling method: from reaction to root","Values as decision filters, not motivational posters"]} />
      <div style={{ marginBottom:18, padding:"13px 16px", background:"rgba(201,168,76,.06)", border:"1px solid rgba(201,168,76,.18)", borderRadius:9 }}>
        <div style={{ fontFamily:"var(--serif)", fontSize:14, fontStyle:"italic", color:"var(--text2)", lineHeight:1.7 }}>"Your values are discovered, not invented. We find them through what makes your blood boil."</div>
      </div>
      <div style={{ marginBottom:18, padding:"13px 16px", background:"rgba(201,168,76,.06)", border:"1px solid rgba(201,168,76,.18)", borderRadius:9 }}>
        <div style={{ fontFamily:"var(--serif)", fontSize:14, fontStyle:"italic", color:"var(--text2)", lineHeight:1.7 }}>"What irritates you most in others is often what you refuse to compromise on yourself."</div>
      </div>
      <div style={{ fontSize:13, fontWeight:700, color:"var(--text)", marginBottom:10 }}>Your values</div>
      {values.map((val, i) => {
        const valOpenKey = `val_${i}_open`;
        const valOpen = map?.[valOpenKey] !== false;
        const headerName = (map?.[`val_${i}_name`] || val.name || `Value ${i + 1}`);
        return (
          <div key={i} style={{ background:"var(--bg3)", border:"1px solid var(--border2)", borderRadius:9, marginBottom:10, overflow:"hidden" }}>
            <div onClick={() => set(valOpenKey, !valOpen)}
              style={{ padding:"10px 14px", borderBottom: valOpen ? "1px solid var(--border)" : "none", display:"flex", justifyContent:"space-between", alignItems:"center", cursor:"pointer", userSelect:"none" }}>
              <div style={{ display:"flex", flexDirection:"column", gap:3, minWidth:0, flex:1 }}>
                <div style={{ display:"flex", alignItems:"center", gap:10 }}>
                  <span style={{ fontSize:10, fontWeight:700, letterSpacing:1.5, textTransform:"uppercase", color:"var(--text4)" }}>Value {i + 1}{i === 0 ? " · Most important" : ""}</span>
                  <span style={{ fontSize:13, fontWeight:600, color:"var(--warm)" }}>{headerName}</span>
                </div>
                {!valOpen && map?.[`val_${i}_summary`] && (
                  <div style={{ fontSize:12, fontStyle:"italic", color:"var(--text3)", lineHeight:1.5, overflow:"hidden", textOverflow:"ellipsis" }}>{map[`val_${i}_summary`]}</div>
                )}
              </div>
              <div style={{ display:"flex", alignItems:"center", gap:8 }}>
                {values.length > 1 && <button onClick={(e) => { e.stopPropagation(); set("values", values.filter((_, idx) => idx !== i)); }} style={{ background:"none", border:"none", color:"var(--text4)", cursor:"pointer", fontSize:16, padding:0 }}>×</button>}
                <span style={{ fontSize:14, color:"var(--text3)", transform: valOpen ? "rotate(180deg)" : "none", transition:"transform .2s" }}>▾</span>
              </div>
            </div>
            {valOpen && (() => {
              const fIrk      = map?.[`val_${i}_irk`]    || "";
              const stomps    = (map?.[`val_${i}_stomps`] as string[]) || [];
              const stompDone = !!map?.[`val_${i}_stomp_done`];
              const gives     = (map?.[`val_${i}_gives`] as string[]) || [];
              const givesDone = !!map?.[`val_${i}_gives_done`];
              const fName     = map?.[`val_${i}_name`]   || "";
              const fSummary  = map?.[`val_${i}_summary`]|| "";
              const visibleStomps = stompDone
                ? stomps
                : (() => {
                    if (stomps.length === 0) return [""];
                    const last = stomps[stomps.length - 1] || "";
                    return last.trim() ? [...stomps, ""] : stomps;
                  })();
              const visibleGives = givesDone
                ? gives
                : (() => {
                    if (gives.length === 0) return [""];
                    const last = gives[gives.length - 1] || "";
                    return last.trim() ? [...gives, ""] : gives;
                  })();
              const setStomp = (idx: number, v: string) => {
                const next = [...stomps];
                while (next.length <= idx) next.push("");
                next[idx] = v;
                set(`val_${i}_stomps`, next);
              };
              const setGive = (idx: number, v: string) => {
                const next = [...gives];
                while (next.length <= idx) next.push("");
                next[idx] = v;
                set(`val_${i}_gives`, next);
              };
              const firstStompFilled = stomps.some(s => (s || "").trim());
              const firstGiveFilled  = gives.some(g => (g || "").trim());
              const showGives = stompDone;
              const showName  = stompDone && givesDone;
              const showSummary = showName && fName.trim();
              const QLabel = ({ num, label }: any) => (
                <label style={{ display:"block", fontSize:12, fontWeight:600, color:"var(--text)", marginBottom:3 }}>
                  <span style={{ color:"var(--warm)", fontWeight:700, marginRight:6 }}>Q{num}.</span>{label}
                </label>
              );
              const Helper = ({ children }: any) => (
                <div style={{ fontSize:11, color:"var(--text3)", fontStyle:"italic", marginBottom:5, lineHeight:1.5 }}>{children}</div>
              );
              let qNum = 1;
              return (
                <div style={{ padding:"14px 16px" }}>
                  {/* Q1 irk */}
                  <div style={{ marginBottom:14 }}>
                    <QLabel num={qNum++} label="What behaviors in others — and maybe yourself — genuinely irk you?" />
                    <TextArea value={fIrk} onChange={(v: string) => set(`val_${i}_irk`, v)} rows={2} placeholder="People who don't follow through. When someone takes credit..." style={{ fontSize:13 }} />
                  </div>
                  {/* Dynamic stomp chain */}
                  {fIrk.trim() && visibleStomps.map((s, sIdx) => {
                    const label = sIdx === 0 ? "What are they stomping on?" : "What is THAT stomping on?";
                    const helper = sIdx === 0
                      ? "If they did the opposite, what would that tell you they were honoring?"
                      : "Go deeper — keep asking what the violation points to.";
                    const n = qNum++;
                    return (
                      <div key={`stomp-${sIdx}`} style={{ marginBottom:14 }}>
                        <QLabel num={n} label={label} />
                        <Helper>{helper}</Helper>
                        <TextArea value={s} onChange={(v: string) => setStomp(sIdx, v)} rows={2} placeholder="" style={{ fontSize:13 }} disabled={stompDone} />
                      </div>
                    );
                  })}
                  {fIrk.trim() && firstStompFilled && !stompDone && (
                    <button onClick={() => {
                      const trimmed = stomps.filter(s => (s || "").trim());
                      set(`val_${i}_stomps`, trimmed);
                      set(`val_${i}_stomp_done`, true);
                    }} style={{ background:"rgba(201,168,76,.08)", border:"1px solid rgba(201,168,76,.35)", borderRadius:6, color:"var(--warm)", cursor:"pointer", fontFamily:"var(--sans)", fontSize:12, fontWeight:500, padding:"7px 12px", marginBottom:14 }}>
                      ✓ I've reached the root
                    </button>
                  )}
                  {stompDone && !showGives && null}
                  {stompDone && (
                    <button onClick={() => { set(`val_${i}_stomp_done`, false); set(`val_${i}_gives_done`, false); }} style={{ background:"none", border:"none", color:"var(--text4)", cursor:"pointer", fontFamily:"var(--sans)", fontSize:11, padding:0, marginBottom:14, textDecoration:"underline" }}>
                      ↺ Keep peeling
                    </button>
                  )}
                  {/* Dynamic gives chain */}
                  {showGives && visibleGives.map((g, gIdx) => {
                    const label = gIdx === 0 ? "What does this give you?" : "And what does THAT give you?";
                    const helper = gIdx === 0 ? "Flip it — if this was fully honored, what would that feel like?" : "";
                    const n = qNum++;
                    return (
                      <div key={`give-${gIdx}`} style={{ marginBottom:14 }}>
                        <QLabel num={n} label={label} />
                        {helper && <Helper>{helper}</Helper>}
                        <TextArea value={g} onChange={(v: string) => setGive(gIdx, v)} rows={2} placeholder="" style={{ fontSize:13 }} disabled={givesDone} />
                      </div>
                    );
                  })}
                  {showGives && firstGiveFilled && !givesDone && (
                    <button onClick={() => {
                      const trimmed = gives.filter(g => (g || "").trim());
                      set(`val_${i}_gives`, trimmed);
                      set(`val_${i}_gives_done`, true);
                    }} style={{ background:"rgba(201,168,76,.08)", border:"1px solid rgba(201,168,76,.35)", borderRadius:6, color:"var(--warm)", cursor:"pointer", fontFamily:"var(--sans)", fontSize:12, fontWeight:500, padding:"7px 12px", marginBottom:14 }}>
                      ✓ I'm at the highest level
                    </button>
                  )}
                  {givesDone && (
                    <button onClick={() => set(`val_${i}_gives_done`, false)} style={{ background:"none", border:"none", color:"var(--text4)", cursor:"pointer", fontFamily:"var(--sans)", fontSize:11, padding:0, marginBottom:14, textDecoration:"underline" }}>
                      ↺ Keep going higher
                    </button>
                  )}
                  {/* Name the value */}
                  {showName && (
                    <div style={{ marginBottom:14 }}>
                      <QLabel num={qNum++} label="You've found your value. Give it a name." />
                      <Helper>One or two words — make it yours.</Helper>
                      <TextInput value={fName} onChange={(v: string) => { set(`val_${i}_name`, v); setVal(i, "name", v); }} placeholder="e.g. Integrity" style={{ fontSize:14, fontWeight:600, padding:"8px 10px" }} />
                    </div>
                  )}
                  {/* Summary with AI */}
                  {showSummary && (
                    <div style={{ marginBottom:14 }}>
                      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:3, gap:8 }}>
                        <QLabel num={qNum++} label="In one sentence, what does this value mean to you?" />
                        <button onClick={async () => {
                          const sumKey = `valSum_${i}`;
                          setBusy(b => ({ ...b, [sumKey]:true }));
                          const stompList = stomps.map((s, n) => `  Level ${n+1}: ${s}`).join("\n");
                          const givesList = gives.map((g, n) => `  Level ${n+1}: ${g}`).join("\n");
                          const existing = (map?.[`val_${i}_summary`] || "").trim();
                          if (!existing) {
                            const prompt = `You are Katherine Breuss. ${name || "The user"} did the values peeling exercise and arrived at the value "${fName}". Their answers:\nIrk: ${fIrk}\nStomp chain (what's being violated, deepest last):\n${stompList}\nGives chain (what it gives them, highest last):\n${givesList}\n\nWrite ONE sentence (max 25 words) in their voice that captures what "${fName}" means to them as a personal value. No fluff, no quotes, no preamble. Return JSON: {"summary":"..."}`;
                            const r = await callStructured(prompt);
                            if (r && r.summary) set(`val_${i}_summary`, r.summary);
                          } else {
                            const prompt = `You are Katherine Breuss. The user peeled to find their value. Irk: ${fIrk}. Stomps: ${stomps.join(" → ")}. Gives: ${gives.join(" → ")}. They named it "${fName}" and wrote: "${existing}". Give 2-3 sentences of warm feedback — does this capture their root? Is it strong and specific? Speak directly to them in second person. No preamble. Return JSON: {"feedback":"..."}`;
                            const r = await callStructured(prompt);
                            if (r && r.feedback) set(`val_${i}_feedback`, r.feedback);
                          }
                          setBusy(b => ({ ...b, [sumKey]:false }));
                        }} disabled={!!busy[`valSum_${i}`]}
                          style={{ background:"none", border:"1px solid var(--border2)", borderRadius:5, color:"var(--warm)", cursor: busy[`valSum_${i}`] ? "wait" : "pointer", fontFamily:"var(--sans)", fontSize:10, padding:"4px 9px", flexShrink:0, whiteSpace:"nowrap" }}>
                          {busy[`valSum_${i}`] ? "..." : (fSummary.trim() ? "✦ Ask Katherine for feedback" : "✦ Ask Katherine")}
                        </button>
                      </div>
                      <Helper>This is what shows in the rest of the app.</Helper>
                      <TextArea value={fSummary} onChange={(v: string) => set(`val_${i}_summary`, v)} rows={2} placeholder="This is what shows in the rest of the app" style={{ fontSize:13 }} />
                      {map?.[`val_${i}_feedback`] && (
                        <div style={{ marginTop:10, padding:"11px 14px", background:"rgba(201,168,76,.06)", border:"1px solid rgba(201,168,76,.22)", borderRadius:8, position:"relative" }}>
                          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:5 }}>
                            <div style={{ fontSize:10, fontWeight:700, letterSpacing:1.5, textTransform:"uppercase", color:"var(--warm)" }}>Katherine's thoughts</div>
                            <button onClick={() => set(`val_${i}_feedback`, "")} style={{ background:"none", border:"none", color:"var(--text4)", cursor:"pointer", fontSize:14, padding:0, lineHeight:1 }}>×</button>
                          </div>
                          <div style={{ fontFamily:"var(--serif)", fontStyle:"italic", fontSize:13, color:"var(--text2)", lineHeight:1.7 }}>{map[`val_${i}_feedback`]}</div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })()}
          </div>
        );
      })}
      <button onClick={() => set("values", [...values, { name:"", irk:"", behaviors:"" }])} style={{ width:"100%", padding:"12px", background:"transparent", border:"1.5px dashed var(--border2)", borderRadius:8, color:"var(--warm)", cursor:"pointer", fontFamily:"var(--sans)", fontSize:13, fontWeight:500, marginBottom:18 }}>+ Add Another Value</button>
      <div style={{ marginBottom:22, marginTop:14 }}>
        <AIChat voiceId={voice} onVoiceChange={setVoicePersist} name={name} intake={intake} mapData={map} sectionLabel="values" placeholder="Ask Katherine about your values -- she can see everything you've written..." />
      </div>
      <div style={{ display:"flex", justifyContent:"space-between", paddingTop:18, borderTop:"1px solid var(--border)" }}>
        <button className="btn-g" onClick={() => goto("mirror2")}>← Identity · Superpowers</button>
        <button className="btn" onClick={() => set("mirror3_sub", "behaviors")}>Behaviors →</button>
      </div>
    </>);
    // ── STEP 2: BEHAVIORS (placeholder) ──────────────────────────────────────
    if (m3sub === "behaviors") return wrapContent(<>
      <div className="lbl" style={{ marginBottom:12 }}>Mirror 3 of 3 · Step 2</div>
      {M3Progress()}
      {map?.return_to_a2 === "iv_align" && (
        <div style={{ padding:"10px 14px", marginBottom:14, background:"rgba(96,165,250,.08)", border:"1px solid rgba(96,165,250,.3)", borderLeft:"3px solid #60a5fa", borderRadius:8, display:"flex", alignItems:"center", justifyContent:"space-between", gap:10 }}>
          <div style={{ fontSize:12, color:"var(--text2)", lineHeight:1.5 }}>
            <strong style={{ color:"#60a5fa", fontWeight:700 }}>From A2 Alignment</strong> — have a look, then jump back.
          </div>
          <button onClick={async () => {
            const current = await loadData(KEYS.map);
            const next = { ...(current || {}), return_to_a2: null, a2_pending_step: "iv_align" };
            await saveData(KEYS.map, next);
            await saveData(KEYS.phase, "a2");
            setPhase("a2");
          }}
            style={{ padding:"6px 12px", borderRadius:12, background:"transparent", color:"#60a5fa", border:"1px solid #60a5fa", cursor:"pointer", fontSize:11, fontWeight:700, flexShrink:0 }}>
            ← Back to A2 Alignment
          </button>
        </div>
      )}
      <h2 style={{ fontFamily:"var(--serif)", fontSize:34, fontWeight:400, lineHeight:1.2, marginBottom:7, letterSpacing:"-0.3px" }}>Behaviors</h2>
      <p style={{ fontSize:16, color:"var(--text2)", lineHeight:1.75, marginBottom:20, maxWidth:540 }}>For each value, name the specific behaviors that bring it to life. A value without behaviors is just a word.</p>
      {values.map((val, i) => {
        const vName = (map?.[`val_${i}_name`] || val.name || `Value ${i + 1}`);
        const vSummary = map?.[`val_${i}_summary`] || "";
        const behCount = map?.[`beh_${i}_count`] || 1;
        return (
          <div key={i} style={{ marginBottom:26 }}>
            {/* Value section header */}
            <div style={{ marginBottom:12, paddingBottom:10, borderBottom:"1px solid var(--border)" }}>
              <div style={{ fontFamily:"var(--serif)", fontSize:22, fontWeight:500, color:"var(--warm)", lineHeight:1.25, letterSpacing:"-.2px" }}>{vName}</div>
              {vSummary && <div style={{ fontSize:12, fontStyle:"italic", color:"var(--text3)", lineHeight:1.6, marginTop:4 }}>{vSummary}</div>}
            </div>
            {/* Behavior cards */}
            {Array.from({ length: behCount }).map((_, j) => {
              const bName    = map?.[`beh_${i}_${j}_name`]    || "";
              const bBullets = (map?.[`beh_${i}_${j}_bullets`] as string[]) || [];
              const bDetail  = map?.[`beh_${i}_${j}_detail`]  || "";
              const bDraft   = map?.[`beh_${i}_${j}_draft`]   || "";
              const bOpen    = map?.[`beh_${i}_${j}_open`]    !== false;
              const busyKey  = `behAI_${i}_${j}`;
              const setBullets = (arr: string[]) => set(`beh_${i}_${j}_bullets`, arr);
              return (
                <div key={j} style={{ marginBottom:10, background:"var(--bg3)", border:"1px solid var(--border2)", borderRadius:10, overflow:"hidden" }}>
                  {/* Header */}
                  <div onClick={() => set(`beh_${i}_${j}_open`, !bOpen)}
                    style={{ padding:"10px 14px", display:"flex", alignItems:"center", justifyContent:"space-between", cursor:"pointer", userSelect:"none", borderBottom: bOpen ? "1px solid var(--border)" : "none" }}>
                    <div style={{ display:"flex", alignItems:"center", gap:10 }}>
                      <span style={{ fontSize:10, fontWeight:700, letterSpacing:1.5, textTransform:"uppercase", color:"var(--text4)" }}>Behavior {j + 1}</span>
                      {bName && <span style={{ fontSize:13, fontWeight:600, color:"var(--warm)" }}>{bName}</span>}
                    </div>
                    <div style={{ display:"flex", alignItems:"center", gap:8 }}>
                      {behCount > 1 && <button onClick={(e) => {
                        e.stopPropagation();
                        // Shift subsequent indices down
                        for (let k = j; k < behCount - 1; k++) {
                          set(`beh_${i}_${k}_name`,    map?.[`beh_${i}_${k+1}_name`] || "");
                          set(`beh_${i}_${k}_bullets`, map?.[`beh_${i}_${k+1}_bullets`] || []);
                          set(`beh_${i}_${k}_detail`,  map?.[`beh_${i}_${k+1}_detail`] || "");
                        }
                        set(`beh_${i}_count`, behCount - 1);
                      }} style={{ background:"none", border:"none", color:"var(--text4)", cursor:"pointer", fontSize:16, padding:0 }}>×</button>}
                      <span style={{ fontSize:14, color:"var(--text3)", transform: bOpen ? "rotate(180deg)" : "none", transition:"transform .2s" }}>▾</span>
                    </div>
                  </div>
                  {/* Body */}
                  {bOpen && (
                    <div style={{ padding:"14px 16px" }}>
                      {/* Name */}
                      <div style={{ marginBottom:12 }}>
                        <label style={{ display:"block", fontSize:11, color:"var(--text3)", marginBottom:4, fontWeight:500 }}>Name this behavior</label>
                        <TextInput value={bName} onChange={(v: string) => set(`beh_${i}_${j}_name`, v)} placeholder="e.g. Keep promises to myself first" style={{ fontSize:13 }} />
                      </div>
                      {/* Bullets */}
                      <div style={{ marginBottom:12 }}>
                        <label style={{ display:"block", fontSize:11, color:"var(--text3)", marginBottom:4, fontWeight:500 }}>What this looks like in practice</label>
                        {bBullets.length > 0 && (
                          <div style={{ marginBottom:6 }}>
                            {bBullets.map((b, bi) => (
                              <div key={bi} style={{ display:"flex", alignItems:"flex-start", gap:8, padding:"5px 0", fontSize:13, color:"var(--text2)", lineHeight:1.6 }}>
                                <span style={{ color:"var(--warm)", flexShrink:0, marginTop:1 }}>•</span>
                                <span style={{ flex:1 }}>{b}</span>
                                <button onClick={() => setBullets(bBullets.filter((_, k) => k !== bi))}
                                  style={{ background:"none", border:"none", color:"var(--text4)", cursor:"pointer", fontSize:14, padding:0, lineHeight:1, flexShrink:0 }}>×</button>
                              </div>
                            ))}
                          </div>
                        )}
                        <input value={bDraft}
                          onChange={e => set(`beh_${i}_${j}_draft`, e.target.value)}
                          onKeyDown={e => {
                            if (e.key === "Enter" && bDraft.trim()) {
                              e.preventDefault();
                              setBullets([...bBullets, bDraft.trim()]);
                              set(`beh_${i}_${j}_draft`, "");
                            }
                          }}
                          placeholder="Type a bullet and press Enter..."
                          style={{ width:"100%", fontSize:13, padding:"7px 10px", borderRadius:6, border:"1px solid var(--border2)", background:"var(--bg4)", color:"var(--text)", fontFamily:"var(--sans)", boxSizing:"border-box" }} />
                      </div>
                      {/* Optional detail */}
                      <div style={{ marginBottom:12 }}>
                        <label style={{ display:"block", fontSize:11, color:"var(--text3)", marginBottom:4, fontWeight:500 }}>Detail (optional)</label>
                        <TextArea value={bDetail} onChange={(v: string) => set(`beh_${i}_${j}_detail`, v)} rows={2} placeholder="Why this behavior matters, when it's hard, what it unlocks..." style={{ fontSize:13 }} />
                      </div>
                      {/* Ask Katherine */}
                      <button onClick={async () => {
                        setBusy(b => ({ ...b, [busyKey]:true }));
                        const prompt = `You are Katherine Breuss. ${name || "The user"} holds the value "${vName}"${vSummary ? ` (which means: "${vSummary}")` : ""}. They are defining a concrete behavior that brings this value to life${bName ? `, called "${bName}"` : ""}${bDetail ? ` (detail: "${bDetail}")` : ""}. Their existing bullets: ${bBullets.length ? bBullets.map(x => `"${x}"`).join(", ") : "(none)"}. Suggest 3-5 specific, concrete new bullet points — each one a small, observable action in daily life. Keep each under 12 words. No duplicates of existing bullets. Return JSON: {"bullets":["...","...","..."]}`;
                        const r = await callStructured(prompt);
                        if (r && Array.isArray(r.bullets)) setBullets([...bBullets, ...r.bullets]);
                        setBusy(b => ({ ...b, [busyKey]:false }));
                      }} disabled={!!busy[busyKey]}
                        style={{ background:"none", border:"1px solid var(--border2)", borderRadius:5, color:"var(--warm)", cursor: busy[busyKey] ? "wait" : "pointer", fontFamily:"var(--sans)", fontSize:11, padding:"5px 11px" }}>
                        {busy[busyKey] ? "..." : "✦ Ask Katherine for suggestions"}
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
            {/* Add behavior */}
            <button onClick={() => set(`beh_${i}_count`, behCount + 1)}
              style={{ width:"100%", padding:"10px", background:"transparent", border:"1.5px dashed var(--border2)", borderRadius:8, color:"var(--warm)", cursor:"pointer", fontFamily:"var(--sans)", fontSize:12, fontWeight:500 }}>
              + Add Behavior
            </button>
          </div>
        );
      })}
      <div style={{ marginBottom:22, marginTop:14 }}>
        <AIChat voiceId={voice} onVoiceChange={setVoicePersist} name={name} intake={intake} mapData={map} sectionLabel="behaviors" placeholder="Ask Katherine about your behaviors -- she can see everything you've written..." />
      </div>
      <div style={{ display:"flex", justifyContent:"space-between", paddingTop:18, borderTop:"1px solid var(--border)" }}>
        <button className="btn-g" onClick={() => set("mirror3_sub", "values")}>← Values</button>
        <button className="btn" onClick={() => set("mirror3_sub", "hierarchy")}>Hierarchy →</button>
      </div>
    </>);
    // ── STEP 3: HIERARCHY (placeholder) ──────────────────────────────────────
    if (m3sub === "hierarchy") {
      const valCount = values.length;
      const rawOrder = (map?.hier_order as number[]) || [];
      // Clean: keep only valid indices, append missing ones
      const order: number[] = [];
      rawOrder.forEach(n => { if (Number.isInteger(n) && n >= 0 && n < valCount && !order.includes(n)) order.push(n); });
      for (let n = 0; n < valCount; n++) if (!order.includes(n)) order.push(n);
      const dragFrom = map?._hier_drag;
      const dragOver = map?._hier_over;
      const reorder = (from: number, to: number) => {
        if (from === to || from == null || to == null) return;
        const next = [...order];
        const [moved] = next.splice(from, 1);
        next.splice(to, 0, moved);
        set("hier_order", next);
      };
      return wrapContent(<>
        <div className="lbl" style={{ marginBottom:12 }}>Mirror 3 of 3 · Step 3</div>
        {M3Progress()}
        <h2 style={{ fontFamily:"var(--serif)", fontSize:34, fontWeight:400, lineHeight:1.2, marginBottom:7, letterSpacing:"-0.3px" }}>Hierarchy</h2>
        <p style={{ fontSize:16, color:"var(--text2)", lineHeight:1.75, marginBottom:16, maxWidth:540 }}>Rank your values. When they compete, not all are equal — this is where you find out which ones you won't trade.</p>
        <div style={{ marginBottom:22, padding:"13px 16px", background:"rgba(201,168,76,.06)", border:"1px solid rgba(201,168,76,.18)", borderRadius:9 }}>
          <div style={{ fontFamily:"var(--serif)", fontSize:14, fontStyle:"italic", color:"var(--text2)", lineHeight:1.7 }}>"Your values are never all equal. This is where you find out which ones you won't trade."</div>
        </div>
        {(() => { const hp = map?.hier_phase || "rank"; return (<>
        {hp === "rank" && (<>
        <div style={{ fontSize:11, fontWeight:700, letterSpacing:1.5, textTransform:"uppercase", color:"var(--text4)", marginBottom:6 }}>Phase 1 · Rank</div>
        <div style={{ fontSize:13, fontWeight:600, color:"var(--text)", marginBottom:3 }}>Drag to rank — most important at the top</div>
        <div style={{ fontSize:12, color:"var(--text3)", marginBottom:14, lineHeight:1.6 }}>1 = most important, non-negotiable.</div>
        </>)}
        {hp === "test" && (<>
        <div style={{ fontSize:11, fontWeight:700, letterSpacing:1.5, textTransform:"uppercase", color:"var(--text4)", marginBottom:6 }}>Phase 2 · Test</div>
        <div style={{ fontSize:13, fontWeight:600, color:"var(--text)", marginBottom:3 }}>Pressure-test your ranking</div>
        <div style={{ fontSize:12, color:"var(--text3)", marginBottom:14, lineHeight:1.6 }}>Answer each trade-off question honestly — this reveals which values are truly non-negotiable.</div>
        <button onClick={() => set("hier_phase", "rank")} style={{ background:"none", border:"none", color:"var(--text4)", cursor:"pointer", fontFamily:"var(--sans)", fontSize:11, padding:0, marginBottom:14, textDecoration:"underline" }}>↺ Back to ranking</button>
        </>)}
        {valCount === 0 && <div style={{ padding:30, textAlign:"center", color:"var(--text4)", fontSize:13, fontStyle:"italic", border:"1.5px dashed var(--border2)", borderRadius:10 }}>Add values in Step 1 first.</div>}
        </>); })()}
        {order.map((vIdx, pos) => {
          const vName = (map?.[`val_${vIdx}_name`] || values[vIdx]?.name || `Value ${vIdx + 1}`);
          const vSummary = map?.[`val_${vIdx}_summary`] || "";
          const isDragging = dragFrom === pos;
          const isOver = dragOver === pos && dragFrom !== pos;
          return (
            <div key={vIdx}
              draggable
              onDragStart={(e) => { set("_hier_drag", pos); e.dataTransfer.effectAllowed = "move"; }}
              onDragEnter={() => set("_hier_over", pos)}
              onDragOver={(e) => { e.preventDefault(); e.dataTransfer.dropEffect = "move"; }}
              onDrop={(e) => { e.preventDefault(); reorder(dragFrom, pos); set("_hier_drag", null); set("_hier_over", null); }}
              onDragEnd={() => { set("_hier_drag", null); set("_hier_over", null); }}
              style={{
                display:"flex", alignItems:"center", gap:12,
                background: isOver ? "rgba(201,168,76,.1)" : "var(--bg3)",
                border: `1px solid ${isOver ? "rgba(201,168,76,.5)" : "var(--border2)"}`,
                borderRadius:10, padding:"12px 14px", marginBottom:8,
                cursor:"grab", userSelect:"none",
                opacity: isDragging ? 0.4 : 1,
                transition:"background .15s, border-color .15s, opacity .15s",
              }}>
              <span style={{ fontSize:16, color:"var(--text4)", flexShrink:0, letterSpacing:-2, lineHeight:1 }}>⋮⋮</span>
              <span style={{ fontFamily:"var(--serif)", fontSize:18, fontWeight:400, color:"var(--text3)", flexShrink:0, width:26, textAlign:"center" }}>{pos + 1}</span>
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ fontSize:14, fontWeight:600, color:"var(--warm)", lineHeight:1.3 }}>{vName}</div>
                {vSummary && <div style={{ fontSize:12, fontStyle:"italic", color:"var(--text3)", lineHeight:1.5, marginTop:3 }}>{vSummary}</div>}
              </div>
              <div style={{ display:"flex", flexDirection:"column", gap:2, flexShrink:0 }}>
                <button onClick={() => reorder(pos, Math.max(0, pos - 1))} disabled={pos === 0}
                  style={{ background:"none", border:"1px solid var(--border2)", color: pos === 0 ? "var(--text4)" : "var(--text3)", cursor: pos === 0 ? "default" : "pointer", fontSize:10, borderRadius:4, width:22, height:18, padding:0, lineHeight:1 }}>▲</button>
                <button onClick={() => reorder(pos, Math.min(valCount - 1, pos + 1))} disabled={pos === valCount - 1}
                  style={{ background:"none", border:"1px solid var(--border2)", color: pos === valCount - 1 ? "var(--text4)" : "var(--text3)", cursor: pos === valCount - 1 ? "default" : "pointer", fontSize:10, borderRadius:4, width:22, height:18, padding:0, lineHeight:1 }}>▼</button>
              </div>
            </div>
          );
        })}
        {(map?.hier_phase || "rank") === "rank" && valCount > 0 && (
          <button onClick={() => set("hier_phase", "test")}
            style={{ width:"100%", marginTop:14, padding:"11px 14px", background:"var(--warm)", border:"none", borderRadius:8, color:"#000", cursor:"pointer", fontFamily:"var(--sans)", fontSize:13, fontWeight:600, letterSpacing:".2px" }}>
            Test My Ranking →
          </button>
        )}
        {(map?.hier_phase === "test") && valCount >= 2 && (() => {
          const totalQs = order.length - 1;
          const testIdx = Math.max(0, Math.min(totalQs, parseInt(map?.hier_test_idx) || 0));
          const stage = map?.hier_test_stage === "followup" ? "followup" : "primary";
          const topIdx = order[0];
          const topName = map?.[`val_${topIdx}_name`] || values[topIdx]?.name || `Value ${topIdx + 1}`;
          if (testIdx < totalQs) {
            const bPos = testIdx + 1;
            const bIdx = order[bPos];
            const bName = map?.[`val_${bIdx}_name`] || values[bIdx]?.name || `Value ${bIdx + 1}`;
            const primaryAnswer = (v: "yes" | "no") => {
              set(`hier_test_${bIdx}`, v);
              if (v === "yes") {
                set("hier_test_idx", testIdx + 1);
                set("hier_test_stage", "primary");
              } else {
                set("hier_test_stage", "followup");
              }
            };
            const followupAnswer = (v: "yes" | "no") => {
              set(`hier_test_${bIdx}_fu`, v);
              if (v === "yes") {
                const next = [...order];
                [next[0], next[bPos]] = [next[bPos], next[0]];
                set("hier_order", next);
              }
              set("hier_test_idx", testIdx + 1);
              set("hier_test_stage", "primary");
            };
            return (
              <div style={{ marginTop:20, padding:"22px 22px", background:"var(--bg3)", border:"1px solid var(--border2)", borderRadius:12 }}>
                <div style={{ fontSize:11, color:"var(--text4)", letterSpacing:1.2, textTransform:"uppercase", marginBottom:10 }}>Question {testIdx + 1} of {totalQs}</div>
                {stage === "primary" && (<>
                  <div style={{ fontFamily:"var(--serif)", fontSize:22, fontWeight:400, color:"var(--text)", lineHeight:1.4, marginBottom:20 }}>
                    Can you have <span style={{ color:"var(--warm)" }}>{topName}</span> without <span style={{ color:"var(--warm)" }}>{bName}</span>?
                  </div>
                  <div style={{ display:"flex", gap:10 }}>
                    <button onClick={() => primaryAnswer("yes")}
                      style={{ flex:1, padding:"11px 14px", background:"var(--bg2)", border:"1px solid var(--border2)", borderRadius:8, color:"var(--text)", cursor:"pointer", fontFamily:"var(--sans)", fontSize:13, fontWeight:600 }}>Yes</button>
                    <button onClick={() => primaryAnswer("no")}
                      style={{ flex:1, padding:"11px 14px", background:"var(--bg2)", border:"1px solid var(--border2)", borderRadius:8, color:"var(--text)", cursor:"pointer", fontFamily:"var(--sans)", fontSize:13, fontWeight:600 }}>No</button>
                  </div>
                </>)}
                {stage === "followup" && (<>
                  <div style={{ fontSize:14, color:"var(--text3)", fontStyle:"italic", marginBottom:10 }}>You said no — <span style={{ color:"var(--warm)" }}>{topName}</span> depends on <span style={{ color:"var(--warm)" }}>{bName}</span>.</div>
                  <div style={{ fontFamily:"var(--serif)", fontSize:22, fontWeight:400, color:"var(--text)", lineHeight:1.4, marginBottom:20 }}>
                    Does <span style={{ color:"var(--warm)" }}>{bName}</span> need to move above <span style={{ color:"var(--warm)" }}>{topName}</span>?
                  </div>
                  <div style={{ display:"flex", gap:10 }}>
                    <button onClick={() => followupAnswer("yes")}
                      style={{ flex:1, padding:"11px 14px", background:"var(--bg2)", border:"1px solid var(--border2)", borderRadius:8, color:"var(--text)", cursor:"pointer", fontFamily:"var(--sans)", fontSize:13, fontWeight:600 }}>Yes — swap them</button>
                    <button onClick={() => followupAnswer("no")}
                      style={{ flex:1, padding:"11px 14px", background:"var(--bg2)", border:"1px solid var(--border2)", borderRadius:8, color:"var(--text)", cursor:"pointer", fontFamily:"var(--sans)", fontSize:13, fontWeight:600 }}>No — keep order</button>
                  </div>
                  <button onClick={() => set("hier_test_stage", "primary")}
                    style={{ marginTop:12, background:"none", border:"none", color:"var(--text4)", cursor:"pointer", fontFamily:"var(--sans)", fontSize:11, padding:0, textDecoration:"underline" }}>← Back to previous question</button>
                </>)}
                {stage === "primary" && testIdx > 0 && (
                  <button onClick={() => { set("hier_test_idx", testIdx - 1); set("hier_test_stage", "primary"); }}
                    style={{ marginTop:12, background:"none", border:"none", color:"var(--text4)", cursor:"pointer", fontFamily:"var(--sans)", fontSize:11, padding:0, textDecoration:"underline" }}>← Previous question</button>
                )}
              </div>
            );
          }
          return (
            <div style={{ marginTop:20, padding:"24px 22px", background:"var(--bg3)", border:"1px solid var(--border2)", borderRadius:12 }}>
              <div style={{ fontFamily:"var(--serif)", fontSize:26, fontWeight:400, color:"var(--warm)", lineHeight:1.3, marginBottom:16, letterSpacing:"-0.2px" }}>Your hierarchy is set.</div>
              <div style={{ display:"flex", flexDirection:"column", gap:8, marginBottom:16 }}>
                {order.map((vIdx, pos) => {
                  const vName = map?.[`val_${vIdx}_name`] || values[vIdx]?.name || `Value ${vIdx + 1}`;
                  const vSummary = map?.[`val_${vIdx}_summary`] || "";
                  return (
                    <div key={vIdx} style={{ display:"flex", alignItems:"center", gap:12, padding:"12px 14px", background:"var(--bg2)", border:"1px solid var(--border)", borderRadius:10 }}>
                      <span style={{ fontFamily:"var(--serif)", fontSize:20, fontWeight:400, color:"var(--warm)", flexShrink:0, width:26, textAlign:"center" }}>{pos + 1}</span>
                      <div style={{ flex:1, minWidth:0 }}>
                        <div style={{ fontSize:14, fontWeight:600, color:"var(--warm)", lineHeight:1.3 }}>{vName}</div>
                        {vSummary && <div style={{ fontSize:12, fontStyle:"italic", color:"var(--text3)", lineHeight:1.5, marginTop:3 }}>{vSummary}</div>}
                      </div>
                    </div>
                  );
                })}
              </div>
              <button onClick={() => { set("hier_test_idx", 0); set("hier_test_stage", "primary"); }}
                style={{ background:"none", border:"1px solid var(--border2)", color:"var(--text3)", cursor:"pointer", fontFamily:"var(--sans)", fontSize:12, padding:"8px 14px", borderRadius:6 }}>
                ↺ Retake
              </button>
            </div>
          );
        })()}
        <div style={{ marginBottom:22, marginTop:18 }}>
          <AIChat voiceId={voice} onVoiceChange={setVoicePersist} name={name} intake={intake} mapData={map} sectionLabel="hierarchy" placeholder="Ask Katherine about your ranking -- which ones are truly non-negotiable?" />
        </div>
        <div style={{ display:"flex", justifyContent:"space-between", paddingTop:18, borderTop:"1px solid var(--border)" }}>
          <button className="btn-g" onClick={() => set("mirror3_sub", "behaviors")}>← Behaviors</button>
          <button className="btn" onClick={() => { markDone("mirror3"); goto("direction_1yr"); }}>Direction · 1-YEAR →</button>
        </div>
      </>);
    }
    // ── STEP 4: ALIGNMENT (placeholder) ──────────────────────────────────────
    {
      const valCount = parseInt(map?.val_count) || values.filter(v => v.name).length || 0;
      return wrapContent(<>
        <div className="lbl" style={{ marginBottom:12 }}>Mirror 3 of 3 · Step 4</div>
        {M3Progress()}
        <h2 style={{ fontFamily:"var(--serif)", fontSize:34, fontWeight:400, lineHeight:1.2, marginBottom:7, letterSpacing:"-0.3px" }}>Alignment</h2>
        <p style={{ fontSize:16, color:"var(--text2)", lineHeight:1.75, marginBottom:18, maxWidth:540 }}>
          This is your synthesis. For each value, rate how fully you're living each behavior right now.
        </p>
        {valCount === 0 && (
          <div style={{ padding:20, textAlign:"center", color:"var(--text4)", fontSize:13, fontStyle:"italic" }}>Go back to Step 1 to name your values first.</div>
        )}
        {Array.from({ length: valCount }).map((_, i) => {
          const vName = map?.[`val_${i}_name`] || values[i]?.name || "";
          if (!vName) return null;
          const bCount = parseInt(map?.[`beh_${i}_count`]) || 0;
          const validBehs: { j:number; name:string }[] = [];
          for (let j = 0; j < bCount; j++) {
            const bn = map?.[`beh_${i}_${j}_name`];
            if (bn) validBehs.push({ j, name: bn });
          }
          const openKey = `align_val_${i}_open`;
          const isOpen = map?.[openKey] !== false;
          const scores = validBehs.map(({ j }) => (map?.[`align_val_${i}_beh_${j}`] ?? 5) as number);
          const avgScore = scores.length > 0 ? (scores.reduce((a,b)=>a+b,0) / scores.length).toFixed(1) : null;
          const avgCol = avgScore !== null ? (parseFloat(avgScore) >= 7 ? "#22c55e" : parseFloat(avgScore) > 3 ? "#f59e0b" : "#ef4444") : "var(--warm)";
          return (
            <div key={i} style={{ marginBottom:22, border:"1px solid var(--border2)", borderRadius:10, overflow:"hidden" }}>
              <div onClick={() => set(openKey, !isOpen)}
                style={{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:"14px 18px", background:"var(--bg3)", cursor:"pointer", userSelect:"none" }}>
                <div style={{ fontFamily:"var(--serif)", fontSize:16, fontStyle:"italic", color:"var(--warm)" }}>{vName}</div>
                <div style={{ display:"flex", alignItems:"center", gap:10 }}>
                  {avgScore && <span style={{ fontSize:13, fontWeight:700, color:avgCol }}>Avg {avgScore}/10</span>}
                  <span style={{ fontSize:14, color:"var(--text3)", transform: isOpen ? "rotate(180deg)" : "none", transition:"transform .2s" }}>▾</span>
                </div>
              </div>
              {isOpen && (
                <div style={{ padding:"16px 18px", borderTop:"1px solid var(--border)" }}>
                  <div style={{ fontSize:10, fontWeight:700, letterSpacing:1.5, textTransform:"uppercase", color:"#a78bfa", marginBottom:10 }}>Behaviors</div>
                  {validBehs.length === 0 ? (
                    <div style={{ fontSize:12, color:"var(--text4)", fontStyle:"italic", lineHeight:1.5 }}>
                      Go to Step 2 · Behaviors to add behaviors for this value.
                    </div>
                  ) : validBehs.map(({ j, name }) => {
                    const storeKey = `align_val_${i}_beh_${j}`;
                    const score = (map?.[storeKey] ?? 5) as number;
                    const col = score >= 7 ? "#34d399" : score >= 4 ? "#f59e0b" : "#ef4444";
                    return (
                      <div key={j} style={{ marginBottom:14 }}>
                        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:4 }}>
                          <span style={{ fontSize:12, fontWeight:600, color:"var(--text)" }}>{name}</span>
                          <span style={{ fontSize:13, fontWeight:700, color:col }}>{score}/10</span>
                        </div>
                        <input type="range" min={1} max={10} step={1} value={score}
                          onChange={e => set(storeKey, Number(e.target.value))}
                          style={{ width:"100%", accentColor: col }} />
                        <div style={{ display:"flex", justifyContent:"space-between", fontSize:10, marginTop:2 }}>
                          <span style={{ color:"#ef4444" }}>1 = living far from this</span>
                          <span style={{ color:"#34d399" }}>10 = fully embodying this</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
        {(() => {
          const entries: { vName:string; beh: { name:string; score:number }[] }[] = [];
          for (let i = 0; i < valCount; i++) {
            const vName = map?.[`val_${i}_name`] || values[i]?.name || "";
            if (!vName) continue;
            const bCount = parseInt(map?.[`beh_${i}_count`]) || 0;
            const beh: { name:string; score:number }[] = [];
            for (let j = 0; j < bCount; j++) {
              const bn = map?.[`beh_${i}_${j}_name`];
              if (!bn) continue;
              const s = (map?.[`align_val_${i}_beh_${j}`] ?? 5) as number;
              beh.push({ name: bn, score: s });
            }
            entries.push({ vName, beh });
          }
          const totalBehaviors = entries.reduce((a, e) => a + e.beh.length, 0);
          if (valCount === 0) return null;
          if (totalBehaviors === 0) {
            return (
              <div style={{ padding:"14px 16px", background:"var(--bg2)", border:"1px dashed var(--border2)", borderRadius:10, marginBottom:22, fontSize:13, color:"var(--text3)", lineHeight:1.6, fontStyle:"italic" }}>
                Add at least one behavior to see your key misalignment.
              </div>
            );
          }
          const hasResult = !!ai.mirror3_align;
          return (
            <button className="btn" style={{display:"none", marginBottom:22 }}
              onClick={() => {
                const summary = entries.map(e => `${e.vName} [${e.beh.map(b => `${b.name}: ${b.score}/10`).join(", ")}]`).join("; ");
                let lowestLabel = "";
                let lowestScore = 11;
                entries.forEach(e => e.beh.forEach(b => { if (b.score < lowestScore) { lowestScore = b.score; lowestLabel = `"${b.name}" under value "${e.vName}" (${b.score}/10)`; } }));
                runAI("mirror3_align",
                  `You are Katherine Breuss, a direct but compassionate coach. ${name} has rated how fully they are living each behavior for each of their values on a 1-10 scale (1 = living far from this, 10 = fully embodying it). Here are ALL their ratings: ${summary}. The lowest-scoring behavior is ${lowestLabel}. Your task: identify the single most important misalignment — usually (but not always) the lowest score, unless another gap is more consequential given context. Name the EXACT value and behavior. Then explain: why this matters for how they're showing up, what to focus on first (one concrete action), and how shifting this connects forward to the rest of their values work. Be specific and personal — no generic coaching language. Return ONLY valid JSON in this exact shape: {"key_misalignment":"Value: X — Behavior: Y","why_it_matters":"...","focus_first":"...","bridge_to_a2":"..."}`
                );
              }}>
              {busy.mirror3_align
                ? <span className="dot-l"><span /><span /><span /></span>
                : (hasResult ? "" : "")}
            </button>
          );
        })()}
        {false && ai.mirror3_align && (
          <div className="fade-up" style={{ padding:"18px 22px", background:"rgba(245,158,11,.06)", border:"1px solid rgba(245,158,11,.2)", borderRadius:11, marginBottom:22 }}>
            <div style={{ fontSize:11, fontWeight:500, letterSpacing:2, textTransform:"uppercase", color:"#f59e0b", marginBottom:11 }}>Your key misalignment to focus on</div>
            <div style={{ fontFamily:"var(--serif)", fontSize:17, fontWeight:400, color:"var(--text)", lineHeight:1.7, marginBottom:9 }}>{ai.mirror3_align.key_misalignment}</div>
            <div style={{ fontSize:13, color:"var(--text2)", lineHeight:1.7, marginBottom:11 }}>{ai.mirror3_align.why_it_matters}</div>
            <div style={{ padding:"9px 13px", background:"rgba(201,168,76,.06)", border:"1px solid rgba(201,168,76,.12)", borderRadius:7, marginBottom:9 }}>
              <div style={{ fontSize:11, fontWeight:500, letterSpacing:1.5, textTransform:"uppercase", color:"var(--accent)", marginBottom:3 }}>Focus first on</div>
              <div style={{ fontSize:13, color:"var(--text)", lineHeight:1.6 }}>{ai.mirror3_align.focus_first}</div>
            </div>
            {ai.mirror3_align.bridge_to_a2 && <div style={{ fontSize:14, color:"var(--text3)", fontStyle:"italic", lineHeight:1.6 }}>Carries forward: {ai.mirror3_align.bridge_to_a2}</div>}
          </div>
        )}
        <div style={{ marginBottom:22 }}>
          <AIChat voiceId={voice} onVoiceChange={setVoicePersist} name={name} intake={intake} mapData={map}
            sectionLabel="alignment" placeholder="Ask Katherine about the gap between what you value and how you're living..." />
        </div>
        <div style={{ display:"flex", justifyContent:"space-between", paddingTop:18, borderTop:"1px solid var(--border)" }}>
          <button className="btn-g" onClick={() => set("mirror3_sub", "hierarchy")}>← Hierarchy</button>
          <button className="btn" onClick={() => { markDone("mirror3"); goto("direction_1yr"); }}>Direction · 1-YEAR →</button>
        </div>
      </>);
    }
  }
  if (step === "direction_3yr") {
    return wrapContent(<>
      <DirectionTimeline_v2 activeHorizon="threeyr" map={map} />
      <div className="lbl" style={{ marginBottom:12 }}>Direction · 3-YEAR</div>
      <h2 style={{ fontFamily:"var(--serif)", fontSize:34, fontWeight:400, lineHeight:1.2, marginBottom:7, letterSpacing:"-0.3px" }}>
        3-YEAR · {new Date().getFullYear() + 3}
      </h2>
      <p style={{ fontSize:16, color:"var(--text2)", lineHeight:1.75, marginBottom:20, maxWidth:540 }}>
        Pull the horizon closer. Same priorities, refined for {new Date().getFullYear() + 3}.
        No sensory work here -- just get specific about what each area looks like.
      </p>
      <ThreeYearPage map={map} set={set} voiceId={voice} name={name} intake={intake} />
      <div style={{ marginBottom:22, marginTop:18 }}>
        <AIChat voiceId={voice} onVoiceChange={setVoicePersist} name={name} intake={intake} mapData={map}
          sectionLabel="3-year direction"
          placeholder="Ask Katherine about refining your 3-year horizon..." />
      </div>
      <div style={{ display:"flex", justifyContent:"space-between", paddingTop:18, borderTop:"1px solid var(--border)" }}>
        <button className="btn-g" onClick={() => goto("mirror1")}>← Purpose · Direction</button>
        <button className="btn" onClick={() => { markDone("direction_3yr"); goto("mirror2"); }}>Identity · Superpowers →</button>
      </div>
    </>);
  }
  if (step === "align") {
    // Helper: slider with score display
    const AlignSlider = ({ storeKey, label, desc, color="#c9a84c", indent=false }) => {
      const val = map[storeKey] !== undefined ? map[storeKey] : 5;
      const col = val >= 7 ? "#34d399" : val >= 4 ? "#f59e0b" : "#ef4444";
      return (
        <div style={{ marginBottom:10, paddingLeft: indent ? 14 : 0, borderLeft: indent ? "2px solid var(--border2)" : "none" }}>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:4 }}>
            <div>
              <div style={{ fontSize: indent ? 12 : 13, fontWeight: indent ? 400 : 600, color: indent ? "var(--text2)" : "var(--text)" }}>{label}</div>
              {desc && <div style={{ fontSize:11, color:"var(--text4)", marginTop:1 }}>{desc}</div>}
            </div>
            <div style={{ fontFamily:"var(--serif)", fontSize: indent ? 16 : 19, fontWeight:300, color:col, flexShrink:0, marginLeft:12 }}>{val}<span style={{ fontSize:10 }}>/10</span></div>
          </div>
          <input type="range" min={0} max={10} step={1} value={val}
            onChange={e => set(storeKey, Number(e.target.value))}
            style={{ accentColor:col, width:"100%" }} />
          <div style={{ fontSize:10, color:"var(--text4)", marginTop:2 }}>
            {val >= 8 ? "Strong alignment" : val >= 5 ? "Partial -- something in the way" : "Low -- needs attention"}
          </div>
        </div>
      );
    };
    // Helper: section avg badge
    const ScoreRow = ({ storeKey, label, desc, indent=false, defaultVal=5 }) => {
      const val = map[storeKey] !== undefined ? map[storeKey] : defaultVal;
      const col = val >= 7 ? "#34d399" : val >= 4 ? "#f59e0b" : "#ef4444";
      const isScored = map[storeKey] !== undefined;
      return (
        <div style={{ marginBottom:8, paddingLeft: indent ? 14 : 0, borderLeft: indent ? "2px solid var(--border2)" : "none" }}>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", gap:12 }}>
            <div style={{ minWidth:0, flex:1 }}>
              <div style={{ fontSize: indent ? 12 : 13, fontWeight: indent ? 400 : 600, color: indent ? "var(--text2)" : "var(--text)" }}>{label}</div>
              {desc && <div style={{ fontSize:11, color:"var(--text4)", marginTop:1 }}>{desc}</div>}
            </div>
            {isScored ? (
              <div style={{ fontFamily:"var(--serif)", fontSize:18, fontWeight:300, color:col, flexShrink:0 }}>{val}<span style={{ fontSize:10 }}>/10</span></div>
            ) : (
              <div style={{ fontSize:10, color:"var(--text4)", fontStyle:"italic", flexShrink:0 }}>not scored</div>
            )}
          </div>
        </div>
      );
    };
    const AvgBadge = ({ scores }) => {
      const valid = scores.filter(s => s !== undefined && s !== null);
      if (valid.length === 0) return null;
      const avg = Math.round(valid.reduce((a,b) => a+b, 0) / valid.length * 10) / 10;
      const col = avg >= 7 ? "#34d399" : avg >= 4 ? "#f59e0b" : "#ef4444";
      return (
        <div style={{ display:"inline-flex", alignItems:"center", gap:5, padding:"3px 10px", background:`rgba(${avg >= 7 ? "52,211,153" : avg >= 4 ? "245,158,11" : "239,68,68"},.1)`, border:`1px solid ${col}`, borderRadius:20, marginLeft:10 }}>
          <span style={{ fontSize:11, fontWeight:700, color:col }}>avg {avg}/10</span>
        </div>
      );
    };
    // Compute all sub-scores for the final Katherine prompt
    // W.1b-A: Pull time/wealth items from new state shape. Legacy fallback for Time only.
    const timePicked = (map.time_picked || []) as string[];
    const timeItemsMap = (map.time_items || {}) as Record<string, any>;
    const timeItems = timePicked.length > 0
      ? timePicked.map(id => {
          const preset = TIME_AREA_PRESETS.find(p => p.id === id);
          const stored = timeItemsMap[id] || {};
          return {
            id,
            label: preset?.label || stored.label || id,
            icon:  preset?.icon  || stored.icon  || "",
          };
        })
      : ((map.life_areas || []) as any[]).map(a => ({
          id: a.id || a.label,
          label: a.label || a.id || "",
          icon:  a.icon  || "",
        }));
    const wealthPicked = (map.wealth_picked || []) as string[];
    const wealthItemsMap = (map.wealth_items || {}) as Record<string, any>;
    const wealthItems = wealthPicked.map(id => {
      const preset = WEALTH_AREA_PRESETS.find(p => p.id === id);
      const stored = wealthItemsMap[id] || {};
      return {
        id,
        label: preset?.label || stored.label || id,
        icon:  preset?.icon  || stored.icon  || "",
      };
    });
    const growthSentence = map.growth_sentence || map.growth_summary || "";
    const animals = (map.animals || []).filter(a => a.name);
    const values = (map.values || []).filter(v => v.name);
    const dirScores = [
      ...timeItems.map(a => map[`align1_time_${a.id}`]),
      ...wealthItems.map(w => map[`align1_wealth_${w.id}`]),
      growthSentence ? map[`align1_growth`] : undefined,
    ].filter(s => s !== undefined);
    const spScores = animals.flatMap((a,i) => {
      const caps = (a.capabilities || []).filter(c => c.name);
      if (!caps.length) return [];
      return caps.map((_,ci) => map[`align_cap_${i}_${ci}`]).filter(s => s !== undefined);
    });
    // Behaviors: read directly from map keys (val_${i}_name, beh_${i}_count, beh_${i}_${j}_name)
    const valCountAlign = parseInt(map?.val_count) || values.length || 0;
    const valueRows = Array.from({ length: valCountAlign }).map((_, i) => {
      const vName = map?.[`val_${i}_name`] || values[i]?.name || "";
      const bCount = parseInt(map?.[`beh_${i}_count`]) || 0;
      const behs: { j:number; name:string }[] = [];
      for (let j = 0; j < bCount; j++) {
        const bn = map?.[`beh_${i}_${j}_name`];
        if (bn) behs.push({ j, name: bn });
      }
      return { i, name: vName, behs, summary: map?.[`val_${i}_summary`] || "" };
    }).filter(r => r.name);
    const bhvScores = valueRows.flatMap(r =>
      r.behs.map(({ j }) => map[`align_val_${r.i}_beh_${j}`]).filter(s => s !== undefined)
    );
    const avg = arr => arr.length ? Math.round(arr.reduce((a,b)=>a+b,0)/arr.length*10)/10 : null;
    return wrapContent(<>
      <div className="lbl" style={{ marginBottom:12 }}>Alignment Check</div>
      <h2 style={{ fontFamily:"var(--serif)", fontSize:34, fontWeight:400, lineHeight:1.2, marginBottom:7, letterSpacing:"-0.3px" }}>Your <em>Alignment Snapshot</em></h2>
      <p style={{ fontSize:16, color:"var(--text2)", lineHeight:1.8, marginBottom:26, maxWidth:520 }}>This isn't about doing everything — it's about finding the one shift that will most change who you are, how you show up, and the direction of your life.</p>
      {/* ── PURPOSE · DIRECTION ── */}
      {(() => { const isOpen = map?.align_check_dir_open !== false; return (
      <div style={{ background:"var(--bg2)", border:"1px solid var(--border)", borderRadius:11, marginBottom:14, overflow:"hidden" }}>
        <div onClick={() => set("align_check_dir_open", !isOpen)}
          style={{ padding:"13px 18px", borderBottom: isOpen ? "1px solid var(--border)" : "none", display:"flex", alignItems:"center", gap:9, cursor:"pointer", userSelect:"none" }}>
          <span style={{ fontSize:17 }}>⛰️</span>
          <span style={{ fontFamily:"var(--sans)", fontSize:14, fontWeight:700, color:"var(--text)" }}>Purpose · Direction</span>
          <AvgBadge scores={dirScores} />
          <span style={{ marginLeft:"auto", fontSize:14, color:"var(--text3)", transform: isOpen ? "rotate(180deg)" : "none", transition:"transform .2s" }}>▾</span>
        </div>
        {isOpen && (<div style={{ padding:"14px 18px" }}>
          {/* Time priorities */}
          <div style={{ marginBottom:16 }}>
            <div style={{ display:"flex", alignItems:"center", gap:9, marginBottom:10, padding:"8px 12px", background:"var(--bg3)", borderRadius:8 }}>
              <div style={{ fontFamily:"var(--serif)", fontSize:15, fontStyle:"italic", color:"var(--warm)" }}>⏳ Time Priorities</div>
              {timeItems.length > 0 && <AvgBadge scores={timeItems.map(a => map[`align1_time_${a.id}`] ?? 5)} />}
            </div>
            {timeItems.length === 0 && (
              <div style={{ fontSize:12, color:"var(--text4)", fontStyle:"italic", padding:"8px 0" }}>No life priorities set yet -- go back to Direction to add them.</div>
            )}
            {timeItems.map((a) => (
              <AlignSlider key={a.id}
                storeKey={`align1_time_${a.id}`}
                label={`${a.icon} ${a.label}`.trim()}
                desc={`How aligned is how you actually spend time with ${a.label}?`}
                indent={true} />
            ))}
          </div>
          {/* Wealth */}
          <div style={{ marginBottom:16 }}>
            <div style={{ display:"flex", alignItems:"center", gap:9, marginBottom:10, padding:"8px 12px", background:"var(--bg3)", borderRadius:8 }}>
              <div style={{ fontFamily:"var(--serif)", fontSize:15, fontStyle:"italic", color:"var(--warm)" }}>💰 Wealth</div>
              {wealthItems.length > 0 && <AvgBadge scores={wealthItems.map(w => map[`align1_wealth_${w.id}`] ?? 5)} />}
            </div>
            {wealthItems.length === 0 && (
              <div style={{ fontSize:12, color:"var(--text4)", fontStyle:"italic", padding:"8px 0" }}>No wealth categories set yet -- go back to Direction to add them.</div>
            )}
            {wealthItems.map(w => (
              <AlignSlider key={w.id}
                storeKey={`align1_wealth_${w.id}`}
                label={`${w.icon} ${w.label}`.trim()}
                desc={`How aligned are you with your ${w.label.toLowerCase()} vision?`}
                indent={true} />
            ))}
          </div>
          {/* Growth -- single slider (prototype parity) */}
          <div>
            <div style={{ display:"flex", alignItems:"center", gap:9, marginBottom:10, padding:"8px 12px", background:"var(--bg3)", borderRadius:8 }}>
              <div style={{ fontFamily:"var(--serif)", fontSize:15, fontStyle:"italic", color:"var(--warm)" }}>🌱 Growth</div>
            </div>
            {!growthSentence ? (
              <div style={{ fontSize:12, color:"var(--text4)", fontStyle:"italic", padding:"8px 0" }}>Write your growth vision in Direction first.</div>
            ) : (
              <AlignSlider
                storeKey={`align1_growth`}
                label="Living toward who I'm becoming"
                desc="How aligned is who you are today with the person you're becoming?"
                indent={true} />
            )}
          </div>
        </div>)}
      </div>
      ); })()}
      {/* ── IDENTITY · SUPERPOWERS ── */}
      {(() => { const isOpen = map?.align_check_sup_open !== false; return (
      <div style={{ background:"var(--bg2)", border:"1px solid var(--border)", borderRadius:11, marginBottom:14, overflow:"hidden" }}>
        <div onClick={() => set("align_check_sup_open", !isOpen)}
          style={{ padding:"13px 18px", borderBottom: isOpen ? "1px solid var(--border)" : "none", display:"flex", alignItems:"center", gap:9, cursor:"pointer", userSelect:"none" }}>
          <span style={{ fontSize:17 }}>⚡</span>
          <span style={{ fontFamily:"var(--sans)", fontSize:14, fontWeight:700, color:"var(--text)" }}>Identity · Superpowers</span>
          <AvgBadge scores={spScores} />
          <span style={{ marginLeft:"auto", fontSize:14, color:"var(--text3)", transform: isOpen ? "rotate(180deg)" : "none", transition:"transform .2s" }}>▾</span>
        </div>
        {isOpen && (<div style={{ padding:"14px 18px" }}>
          {animals.length === 0 && (
            <div style={{ fontSize:12, color:"var(--text4)", fontStyle:"italic" }}>No animals set yet -- go back to Identity to add them.</div>
          )}
          {animals.map((a, i) => {
            const capList = (a.capabilities || []).filter(c => c.name);
            const animalScores = capList.map((_,ci) => map[`align_cap_${i}_${ci}`]).filter(s => s !== undefined);
            const pressureText = a.under_pressure || "";
            return (
              <div key={i} style={{ marginBottom:18 }}>
                {/* Animal header */}
                <div style={{ display:"flex", alignItems:"center", gap:9, marginBottom:10, padding:"8px 12px", background:"var(--bg3)", borderRadius:8 }}>
                  <div style={{ fontFamily:"var(--serif)", fontSize:15, fontStyle:"italic", color:"var(--warm)" }}>"{ [a.adj1, a.adj2, a.name].filter(Boolean).join(" ") }"</div>
                  <AvgBadge scores={animalScores} />
                </div>
                {capList.length === 0 ? (
                  <div style={{ fontSize:12, color:"var(--text4)", fontStyle:"italic", paddingLeft:14, borderLeft:"2px solid var(--border2)" }}>
                    Go to Identity · Superpowers and add superpowers for this animal.
                  </div>
                ) : (
                  <div>
                    {capList.map((cap, ci) => (
                      <AlignSlider key={ci}
                        storeKey={`align_cap_${i}_${ci}`}
                        label={cap.name}
                        desc={cap.description || `How fully are you living this superpower right now?`}
                        indent={true} />
                    ))}
                    {pressureText && (
                      <div style={{ padding:"8px 12px", background:"rgba(239,68,68,.05)", border:"1px solid rgba(239,68,68,.15)", borderRadius:7, marginTop:6, marginLeft:14 }}>
                        <div style={{ fontSize:10, fontWeight:700, letterSpacing:1, textTransform:"uppercase", color:"#ef4444", marginBottom:3 }}>Under Pressure</div>
                        <div style={{ fontSize:11, color:"var(--text3)", lineHeight:1.5 }}>{pressureText}</div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>)}
      </div>
      ); })()}
      {/* ── VALUES · BEHAVIORS ── */}
      {(() => { const isOpen = map?.align_check_beh_open !== false; return (
      <div style={{ background:"var(--bg2)", border:"1px solid var(--border)", borderRadius:11, marginBottom:22, overflow:"hidden" }}>
        <div onClick={() => set("align_check_beh_open", !isOpen)}
          style={{ padding:"13px 18px", borderBottom: isOpen ? "1px solid var(--border)" : "none", display:"flex", alignItems:"center", gap:9, cursor:"pointer", userSelect:"none" }}>
          <span style={{ fontSize:17 }}>🎯</span>
          <span style={{ fontFamily:"var(--sans)", fontSize:14, fontWeight:700, color:"var(--text)" }}>Values · Behaviors</span>
          <AvgBadge scores={bhvScores} />
          <span style={{ marginLeft:"auto", fontSize:14, color:"var(--text3)", transform: isOpen ? "rotate(180deg)" : "none", transition:"transform .2s" }}>▾</span>
        </div>
        {isOpen && (<div style={{ padding:"14px 18px" }}>
          {valueRows.length === 0 && (
            <div style={{ fontSize:12, color:"var(--text4)", fontStyle:"italic" }}>No values set yet -- go back to Values · Behaviors to add them.</div>
          )}
          {valueRows.map(row => {
            const valScores = row.behs.map(({ j }) => map[`align_val_${row.i}_beh_${j}`]).filter(s => s !== undefined);
            return (
              <div key={row.i} style={{ marginBottom:18 }}>
                <div style={{ display:"flex", alignItems:"center", gap:9, marginBottom:10, padding:"8px 12px", background:"var(--bg3)", borderRadius:8 }}>
                  <div style={{ fontFamily:"var(--serif)", fontSize:15, fontStyle:"italic", color:"var(--warm)" }}>"{row.name}"</div>
                  <AvgBadge scores={valScores} />
                </div>
                {row.summary && (
                  <div style={{ fontSize:14, color:"var(--text3)", fontStyle:"italic", paddingLeft:14, marginBottom:8, borderLeft:"2px solid rgba(52,211,153,.3)" }}>{row.summary}</div>
                )}
                {row.behs.length === 0 ? (
                  <div style={{ fontSize:12, color:"var(--text4)", fontStyle:"italic", paddingLeft:14, borderLeft:"2px solid var(--border2)" }}>
                    No behaviors defined yet -- go to Values · Behaviors · Step 2 to add them.
                  </div>
                ) : (
                  <div>
                    {row.behs.map(({ j, name }) => (
                      <AlignSlider key={j}
                        storeKey={`align_val_${row.i}_beh_${j}`}
                        label={name}
                        desc="How consistently are you doing this?"
                        indent={true} />
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>)}
      </div>
      ); })()}
      {/* Katherine's key misalignment read */}
      {(() => {
        const runMisalignment = (excludeAreas: string[] = []) => {
          const purpose = (map.purpose_final && map.purpose_final.trim())
            || ((map.purpose_layers || []).filter((l: string) => (l||"").trim()).join(" ").trim())
            || (map.purpose_draft || "").trim()
            || "(no purpose statement set)";
          const lines: string[] = [];
          timeItems.forEach((a: any) => {
            const v = map[`align1_time_${a.id}`];
            lines.push(`Direction · Time · ${a.label}: ${v ?? "not rated"}/10`);
          });
          wealthItems.forEach((w: any) => {
            const v = map[`align1_wealth_${w.id}`];
            lines.push(`Direction · Wealth · ${w.label}: ${v ?? "not rated"}/10`);
          });
          if (growthSentence) {
            const v = map[`align1_growth`];
            lines.push(`Direction · Growth · Living toward who I'm becoming: ${v ?? "not rated"}/10`);
          }
          animals.forEach((a: any, i: number) => {
            const animalLabel = [a.adj1, a.adj2, a.name].filter(Boolean).join(" ");
            const caps = (a.capabilities || []).filter((c: any) => c.name);
            caps.forEach((cap: any, ci: number) => {
              const v = map[`align_cap_${i}_${ci}`];
              lines.push(`Superpowers · ${animalLabel} · ${cap.name}: ${v ?? "not rated"}/10`);
            });
          });
          valueRows.forEach((row: any) => {
            row.behs.forEach(({ j, name: bn }: any) => {
              const v = map[`align_val_${row.i}_beh_${j}`];
              lines.push(`Values · ${row.name} · ${bn}: ${v ?? "not rated"}/10`);
            });
          });
          const scoresBlock = lines.length ? lines.join("\n") : "(no scores recorded)";
          const exclusion = excludeAreas.length
            ? `\n\nIMPORTANT: Previous suggestions covered these areas: ${excludeAreas.map(a => `"${a}"`).join(", ")}. Identify a DIFFERENT area of misalignment -- not any of these. Pick the next biggest gap.`
            : "";
          runAI("align",
            `You are Katherine Breuss, a direct but compassionate coach. ${name}'s purpose: "${purpose}".
Their full alignment scores (1 = living far from this, 10 = fully embodying it):
${scoresBlock}
Identify the single biggest gap between how they're living and their purpose. Give a specific 3-4 sentence insight: name the exact area, explain why this gap matters for their purpose, and give one concrete action they can take this week. No generic coaching language -- be specific to what they wrote.${exclusion}
Return ONLY valid JSON: {"key_misalignment":"Area: <exact name>","why_it_matters":"<why this gap matters for their purpose>","focus_first":"<one concrete action this week>","bridge_to_a2":"<one short sentence on how shifting this carries forward>"}`
          );
        };
        const prevAreas: string[] = (map.align_prev_areas as string[]) || [];
        return (<>
          {!ai.align && (
            <button className="btn" style={{display:"none", marginBottom:22 }}
              onClick={() => { set("align_prev_areas", []); runMisalignment([]); }}>
              {busy.align ? <span className="dot-l"><span /><span /><span /></span> : ""}
            </button>
          )}
          {false && ai.align && (() => {
            const focusDraft = (map?.map_focus_text != null && map.map_focus_text !== "") ? map.map_focus_text : (ai.align?.focus_first || "");
            const confirmed = !!map?.map_focus_confirmed_flag;
            return (
            <div className="fade-up" style={{ padding:"18px 22px", background:"rgba(245,158,11,.06)", border:"1px solid rgba(245,158,11,.2)", borderRadius:11, marginBottom:14 }}>
              <div style={{ fontSize:11, fontWeight:500, letterSpacing:2, textTransform:"uppercase", color:"#f59e0b", marginBottom:11 }}>Your key misalignment to focus on</div>
              <div style={{ fontFamily:"var(--serif)", fontSize:17, fontWeight:400, color:"var(--text)", lineHeight:1.7, marginBottom:9 }}>{ai.align.key_misalignment}</div>
              <div style={{ fontSize:13, color:"var(--text2)", lineHeight:1.7, marginBottom:11 }}>{ai.align.why_it_matters}</div>
              <div style={{ padding:"11px 13px", background:"rgba(201,168,76,.06)", border:"1px solid rgba(201,168,76,.12)", borderRadius:7, marginBottom:11 }}>
                <div style={{ fontSize:11, fontWeight:500, letterSpacing:1.5, textTransform:"uppercase", color:"var(--accent)", marginBottom:6 }}>Focus first on</div>
                <textarea
                  value={focusDraft}
                  onChange={e => { set("map_focus_text", e.target.value); if (confirmed) set("map_focus_confirmed_flag", false); }}
                  rows={3}
                  style={{ width:"100%", background:"var(--bg2)", border:"1px solid var(--border2)", borderRadius:6, color:"var(--text)", fontFamily:"var(--sans)", fontSize:13, padding:"8px 10px", lineHeight:1.6, resize:"vertical", marginBottom:8 }}
                  placeholder="Edit the focus wording before confirming..."
                />
                <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", gap:10 }}>
                  <div style={{ fontSize:11, color: confirmed ? "var(--warm)" : "var(--text4)", fontStyle: confirmed ? "normal" : "italic" }}>
                    {confirmed ? "✓ Confirmed — this carries into your Map of Me" : "Edit the wording, then confirm to carry into your Map of Me."}
                  </div>
                  <button
                    onClick={() => { set("map_focus_text", focusDraft); set("map_focus_confirmed_flag", true); markDone("align"); saveData("to_mapofme_origin", "a1"); setPhase("_mapofme"); }}
                    disabled={confirmed || !focusDraft.trim()}
                    style={{ padding:"6px 13px", borderRadius:14, fontSize:11, fontWeight:600, cursor: confirmed || !focusDraft.trim() ? "default" : "pointer", border: confirmed ? "1px solid var(--warm)" : "1px solid var(--border2)", background: confirmed ? "var(--warm)" : "transparent", color: confirmed ? "#0d1b2e" : "var(--text2)", opacity: !focusDraft.trim() ? 0.5 : 1, whiteSpace:"nowrap" }}>
                    {confirmed ? "✓ Confirmed" : "✓ Confirm this as my focus"}
                  </button>
                </div>
              </div>
              {ai.align.bridge_to_a2 && <div style={{ fontSize:14, color:"var(--text3)", fontStyle:"italic", lineHeight:1.6, marginBottom:4 }}>Carries into A2: {ai.align.bridge_to_a2}</div>}
            </div>
            );
          })()}
          {false && ai.align && (
            <button className="btn-g" style={{display:"none", marginBottom:22 }}
              disabled={!!busy.align}
              onClick={() => {
                const cur = ai.align?.key_misalignment || "";
                const nextPrev = cur ? [...prevAreas, cur] : prevAreas;
                set("align_prev_areas", nextPrev);
                runMisalignment(nextPrev);
              }}>
              {busy.align ? <span className="dot-l"><span /><span /><span /></span> : "↻ Give me another suggestion"}
            </button>
          )}
        </>);
      })()}
      <div style={{ marginBottom:22 }}>
        <AIChat voiceId={voice} onVoiceChange={setVoicePersist} name={name} intake={intake} mapData={map} sectionLabel="alignment" placeholder="Ask Katherine about your alignment -- she can see everything you've written..." />
      </div>
      <div style={{ display:"flex", justifyContent:"space-between", paddingTop:18, borderTop:"1px solid var(--border)" }}>
        <button className="btn-g" onClick={() => goto("mirror3")}>← Values · Behaviors</button>
        <button className="btn" onClick={() => { markDone("align"); saveData("to_mapofme_origin", "a1"); setPhase("_mapofme"); }}>Build My Map of Me™ →</button>
      </div>
    </>);
  }
  return null;
}
let _jspdfPromise: Promise<any> | null = null;
function loadJsPDF(): Promise<any> {
  if (typeof window === "undefined") return Promise.reject(new Error("no window"));
  const w = window as any;
  if (w.jspdf?.jsPDF) return Promise.resolve(w.jspdf.jsPDF);
  if (_jspdfPromise) return _jspdfPromise;
  _jspdfPromise = new Promise((resolve, reject) => {
    const s = document.createElement("script");
    s.src = "https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js";
    s.async = true;
    s.onload = () => {
      const J = (window as any).jspdf?.jsPDF;
      if (J) resolve(J); else reject(new Error("jsPDF failed to load"));
    };
    s.onerror = () => reject(new Error("jsPDF script failed"));
    document.head.appendChild(s);
  });
  return _jspdfPromise;
}
let _logoPromise: Promise<string> | null = null;
function loadLogoBase64(): Promise<string> {
  if (_logoPromise) return _logoPromise;
  _logoPromise = (async () => {
    const res = await fetch(`${import.meta.env.BASE_URL}ag45_logo_transparent.png`);
    if (!res.ok) throw new Error("logo fetch failed");
    const blob = await res.blob();
    return await new Promise<string>((resolve, reject) => {
      const r = new FileReader();
      r.onloadend = () => resolve(String(r.result));
      r.onerror = () => reject(new Error("logo read failed"));
      r.readAsDataURL(blob);
    });
  })();
  return _logoPromise;
}
function MapDownloadSection({ name, map }: { name: any; map: any }) {
  const [busy, setBusy] = useState<null | "snapshot" | "full">(null);
  const generate = async (mode: "snapshot" | "full") => {
    setBusy(mode);
    try {
      const [JsPDF, logoData] = await Promise.all([
        loadJsPDF(),
        loadLogoBase64().catch(() => ""),
      ]);
      const doc = new JsPDF({ unit: "pt", format: "a4" });
      const pw = doc.internal.pageSize.getWidth();
      const ph = doc.internal.pageSize.getHeight();
      const marginX = 40;
      const maxW = pw - marginX * 2;
      const safeName = (name || "User").toString();
      const NAVY: [number, number, number] = [27, 42, 75];
      const GOLD: [number, number, number] = [201, 168, 76];
      const TEXT: [number, number, number] = [50, 50, 50];
      const MUTED: [number, number, number] = [100, 100, 100];
      const HEADER_H = 70;
      const LOGO_PT = 56.7;
      const drawHeader = () => {
        doc.setFillColor(...NAVY);
        doc.rect(0, 0, pw, HEADER_H, "F");
        let textX = marginX;
        if (logoData) {
          try {
            doc.addImage(logoData, "PNG", marginX / 2, (HEADER_H - LOGO_PT) / 2, LOGO_PT, LOGO_PT);
            textX = marginX / 2 + LOGO_PT + 12;
          } catch (e) { /* ignore */ }
        }
        doc.setFont("helvetica", "bold");
        doc.setFontSize(13);
        doc.setTextColor(255, 255, 255);
        doc.text("AccelerateGrowth45", textX, HEADER_H / 2 - 4);
        doc.setFont("helvetica", "normal");
        doc.setFontSize(9);
        doc.setTextColor(...GOLD);
        doc.text(`True Ownership™  ·  ${safeName}'s Map of Me™`, textX, HEADER_H / 2 + 12);
      };
      const drawFooter = (pageNum: number, total: number) => {
        doc.setFont("helvetica", "normal");
        doc.setFontSize(8);
        doc.setTextColor(...MUTED);
        doc.text(new Date().toLocaleDateString(), marginX, ph - 20);
        doc.text(`Page ${pageNum} of ${total}`, pw - marginX, ph - 20, { align: "right" });
      };
      let y = HEADER_H + 24;
      const newPage = () => { doc.addPage(); drawHeader(); y = HEADER_H + 24; };
      const ensure = (need: number) => { if (y + need > ph - 40) newPage(); };
      const sectionHeading = (label: string) => {
        ensure(36);
        y += 8;
        doc.setFont("helvetica", "bold");
        doc.setFontSize(12);
        doc.setTextColor(...GOLD);
        doc.text(label.toUpperCase(), marginX, y);
        y += 6;
        doc.setDrawColor(...GOLD);
        doc.setLineWidth(0.7);
        doc.line(marginX, y, marginX + 60, y);
        y += 16;
      };
      const writeText = (text: string, opts: { font?: string; style?: string; size?: number; color?: [number,number,number]; indent?: number; lineH?: number; gap?: number } = {}) => {
        if (!text) return;
        const { font = "helvetica", style = "normal", size = 10, color = TEXT, indent = 0, lineH = 14, gap = 4 } = opts;
        doc.setFont(font, style);
        doc.setFontSize(size);
        doc.setTextColor(...color);
        const lines = doc.splitTextToSize(String(text), maxW - indent);
        for (const line of lines) {
          ensure(lineH);
          doc.text(line, marginX + indent, y);
          y += lineH;
        }
        y += gap;
      };
      const purpose = map?.purpose_final || map?.purpose_draft || "";
      const bagYear = map?.bag_year || "";
      const lifeAreas = ((map?.life_areas || []) as any[]).filter(a => a && (a.label || a.id));
      const wealthItems = [
        { label: "Retirement", body: map?.bag_retirement },
        { label: "Assets",     body: map?.bag_assets },
        { label: "Cashflow",   body: map?.bag_cashflow },
      ].filter(w => w.body);
      const growth = map?.bag_growth || "";
      const animals = ((map?.animals || []) as any[]).filter(a => a && (a.name || a.adj1 || a.adj2));
      const valCount = parseInt(map?.val_count) || ((map?.values || []).length) || 0;
      const values: { name: string; summary: string; behs: { name: string; description?: string }[] }[] = [];
      for (let i = 0; i < valCount; i++) {
        const vName = map?.[`val_${i}_name`] || (map?.values || [])[i]?.name || "";
        if (!vName) continue;
        const vSummary = map?.[`val_${i}_summary`] || (map?.values || [])[i]?.summary || "";
        const behCount = parseInt(map?.[`beh_${i}_count`]) || 0;
        const behs: { name: string; description?: string }[] = [];
        for (let j = 0; j < behCount; j++) {
          const bn = map?.[`beh_${i}_${j}_name`];
          if (bn) behs.push({ name: bn, description: map?.[`beh_${i}_${j}_description`] });
        }
        values.push({ name: vName, summary: vSummary, behs });
      }
      const focusOne = (map?.map_focus_text != null ? map.map_focus_text : (map?.map_focus_default || "")) || "";
      drawHeader();
      doc.setFont("helvetica", "bold");
      doc.setFontSize(mode === "snapshot" ? 17 : 20);
      doc.setTextColor(...NAVY);
      doc.text(`${safeName}'s Map of Me™`, marginX, y);
      y += mode === "snapshot" ? 22 : 28;
      if (mode === "snapshot") {
        if (purpose) {
          sectionHeading("Purpose");
          writeText(purpose, { font: "times", style: "italic", size: 11, color: TEXT, lineH: 14, gap: 6 });
        }
        if (lifeAreas.length) {
          sectionHeading(`Time Priorities${bagYear ? ` · BAG Year ${bagYear}` : ""}`);
          lifeAreas.forEach(a => {
            writeText(`• ${a.label || a.id}`, { style: "bold", size: 10, color: NAVY, gap: 1 });
          });
          y += 2;
        }
        if (animals.length) {
          sectionHeading("Identity & Superpowers");
          animals.forEach(a => {
            const label = [a.adj1, a.adj2, a.name].filter(Boolean).join(" ");
            const topCap = (a.capabilities || []).filter((c: any) => c?.name)[0]?.name || "";
            writeText(label + (topCap ? `  —  ${topCap}` : ""), { style: "bold", size: 10, color: NAVY, gap: 2 });
          });
          y += 2;
        }
        if (values.length) {
          sectionHeading("Values");
          values.forEach(v => {
            writeText(`• "${v.name}"`, { style: "bold", size: 10, color: NAVY, gap: 1 });
          });
          y += 2;
        }
        if (focusOne) {
          sectionHeading("The One Thing");
          writeText(focusOne, { font: "times", style: "italic", size: 11, color: TEXT, lineH: 14, gap: 4 });
        }
      } else {
        if (purpose) {
          sectionHeading("Purpose");
          writeText(purpose, { font: "times", style: "italic", size: 13, color: TEXT, lineH: 16, gap: 8 });
        }
        if (lifeAreas.length) {
          sectionHeading(`Time Priorities${bagYear ? ` · BAG Year ${bagYear}` : ""}`);
          lifeAreas.forEach(a => {
            writeText(`• ${a.label || a.id}`, { style: "bold", size: 11, color: NAVY, gap: 2 });
            if (a.see)  writeText(`See: ${a.see}`,   { indent: 14, color: MUTED, gap: 1 });
            if (a.hear) writeText(`Hear: ${a.hear}`, { indent: 14, color: MUTED, gap: 1 });
            if (a.feel) writeText(`Feel: ${a.feel}`, { indent: 14, color: MUTED, gap: 1 });
            if (a.goal) writeText(`Goal: ${a.goal}`, { indent: 14, color: MUTED, gap: 1 });
            y += 4;
          });
        }
        if (wealthItems.length) {
          sectionHeading("Wealth");
          wealthItems.forEach(w => {
            writeText(w.label, { style: "bold", size: 11, color: NAVY, gap: 2 });
            writeText(w.body, { indent: 14, color: TEXT, gap: 6 });
          });
        }
        if (growth) {
          sectionHeading("Growth");
          writeText(growth, { color: TEXT, gap: 6 });
        }
        if (animals.length) {
          sectionHeading("Identity & Superpowers");
          animals.forEach(a => {
            const label = [a.adj1, a.adj2, a.name].filter(Boolean).join(" ");
            writeText(label, { style: "bold", size: 12, color: NAVY, gap: 4 });
            const caps = (a.capabilities || []).filter((c: any) => c?.name);
            caps.forEach((c: any) => {
              writeText(`• ${c.name}`, { style: "bold", indent: 14, color: TEXT, gap: 1 });
              if (c.description) writeText(c.description, { font: "times", style: "italic", indent: 24, color: MUTED, gap: 3 });
            });
            y += 4;
          });
        }
        if (values.length) {
          sectionHeading("Values & Behaviours");
          values.forEach(v => {
            writeText(`"${v.name}"`, { style: "bold", size: 12, color: NAVY, gap: 3 });
            if (v.summary) writeText(v.summary, { font: "times", style: "italic", indent: 14, color: MUTED, gap: 4 });
            v.behs.forEach(b => {
              writeText(`• ${b.name}`, { style: "bold", indent: 14, color: TEXT, gap: 1 });
              if (b.description) writeText(b.description, { font: "times", style: "italic", indent: 24, color: MUTED, gap: 3 });
            });
            y += 4;
          });
        }
        if (focusOne) {
          sectionHeading("The One Thing");
          writeText(focusOne, { font: "times", style: "italic", size: 13, color: TEXT, lineH: 16, gap: 6 });
        }
      }
      const total = doc.internal.getNumberOfPages();
      for (let p = 1; p <= total; p++) {
        doc.setPage(p);
        drawFooter(p, total);
      }
      const fileSafe = safeName.replace(/[^A-Za-z0-9_-]+/g, "_");
      doc.save(`${fileSafe}-map-of-me${mode === "snapshot" ? "-snapshot" : ""}.pdf`);
    } catch (e) {
      console.error(e);
      alert("PDF generation failed. Please try again.");
    }
    setBusy(null);
  };
  return (
    <div style={{ padding:"17px 20px", background:"var(--bg2)", border:"1px solid var(--border)", borderRadius:11, marginBottom:22 }}>
      <div style={{ fontSize:11, fontWeight:500, letterSpacing:1.5, textTransform:"uppercase", color:"var(--warm)", marginBottom:11 }}>Download your Map of Me™</div>
      <div style={{ display:"flex", gap:10, flexWrap:"wrap" }}>
        <button className="btn-g" disabled={!!busy} onClick={() => generate("snapshot")}>
          {busy === "snapshot" ? "Generating..." : "⬇ Snapshot (1 page)"}
        </button>
        <button className="btn-g" disabled={!!busy} onClick={() => generate("full")}>
          {busy === "full" ? "Generating..." : "⬇ Full Map"}
        </button>
          <button className="btn-g" onClick={() => {
            try {
              const backup: any = {};
              ["to_done","to_map","to_phase","to_intake","to_step"].forEach(k => {
                const v = localStorage.getItem(k);
                if (v !== null) backup[k] = v;
              });
              let userName = "my";
              try { userName = (JSON.parse(backup.to_intake || "{}").name || "my").replace(/[^A-Za-z0-9_-]+/g, "_"); } catch {}
              backup._backup_meta = { exported_at: new Date().toISOString(), source: location.hostname, user: userName, version: "A1" };
              const blob = new Blob([JSON.stringify(backup, null, 2)], { type: "application/json" });
              const url = URL.createObjectURL(blob);
              const a = document.createElement("a");
              a.href = url;
              a.download = `${userName}-true-ownership-backup-${new Date().toISOString().slice(0,10)}.json`;
              document.body.appendChild(a);
              a.click();
              document.body.removeChild(a);
              URL.revokeObjectURL(url);
            } catch (err) { console.error(err); alert("Backup failed. Please try again."); }
          }}>
            ↓ Backup my data (JSON)
          </button>
      </div>
    </div>
  );
}

// ─── My Map of Me · standalone viewing surface ─────────────────────
function MapOfMePage({ onBack }: any) {
  const [map, setMap] = useState<any>({});
  useEffect(() => { (async () => { const m = await loadData(KEYS.map); if (m) setMap(m); })(); }, []);
  const [voice, setVoice] = useState("coach");
  useEffect(() => { (async () => { const v = await loadData(KEYS.voice); if (v) setVoice(v); })(); }, []);
  const [origin, setOrigin] = useState<string>("a1");
  useEffect(() => { const o = loadDataSync("to_mapofme_origin"); if (o === "a1" || o === "a2" || o === "a3") setOrigin(o); }, []);
  const setVoicePersist = (v: string) => { setVoice(v); saveData(KEYS.voice, v); };
  const [openSections, setOpenSections] = useState<any>({ a1: true, a2: true, a3: true, a4: false, a5: false });

  const a1Done = !!(map.purpose_final || (map.purpose_layers && map.purpose_layers.length > 0) || map.purpose_draft);
  const a2Done = !!map.a2_one_thing;
  const a3Done = !!(map.a3_board_candidates && map.a3_board_candidates.length > 0);
  const a4Done = false;
  const a5Done = false;
  const allDoneFlags: any = { a1: a1Done, a2: a2Done, a3: a3Done, a4: a4Done, a5: a5Done };

  const allOpen = Object.values(openSections).every(Boolean);
  const toggleAll = () => {
    const next = !allOpen;
    setOpenSections({ a1: next, a2: next, a3: next, a4: next, a5: next });
  };
  const toggleSection = (k: string) => setOpenSections((p: any) => ({ ...p, [k]: !p[k] }));

  const lastUpdated = new Date()
    .toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })
    .toUpperCase();

  const phases = [
    { key: "a1", code: "A1", name: "All In It",            tag: "Map of who you are" },
    { key: "a2", code: "A2", name: "Align With It",        tag: "Time, focus, and the One Thing" },
    { key: "a3", code: "A3", name: "Advocate For It",      tag: "People, environment, board" },
    { key: "a4", code: "A4", name: "Act On It",            tag: "Rhythms and commitments" },
    { key: "a5", code: "A5", name: "Accountability To It", tag: "Final integration" },
  ];

  const PhasePill = ({ code, done }: any) => (
    <div style={{
      padding: "3px 10px", borderRadius: 14, fontSize: 11, fontWeight: 700, letterSpacing: 1.2,
      background: done ? "rgba(52,211,153,.15)" : "var(--bg2)",
      color: done ? "#34d399" : "var(--text4)",
      border: `1px solid ${done ? "rgba(52,211,153,.35)" : "var(--border2)"}`,
    }}>{code}</div>
  );

  const SidebarPhaseItem = ({ label, done }: any) => (
    <div style={{
      display: "flex", alignItems: "center", gap: 9, padding: "7px 10px",
      borderRadius: 8, fontFamily: "var(--sans)", fontSize: 12, color: "var(--text2)",
      cursor: "default", marginBottom: 2,
    }}>
      <span style={{
        width: 8, height: 8, borderRadius: "50%",
        background: done ? "#34d399" : "var(--text4)",
        flexShrink: 0,
      }} />
      <span>{label}</span>
    </div>
  );

  const StripCell = ({ code, name, done }: any) => (
    <div style={{
      flex: 1, padding: "11px 13px",
      border: `1px solid ${done ? "rgba(52,211,153,.35)" : "var(--border2)"}`,
      borderRadius: 8, background: done ? "rgba(52,211,153,.06)" : "var(--bg2)",
      display: "flex", flexDirection: "column", gap: 3,
    }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: 1.2, color: done ? "#34d399" : "var(--text4)" }}>{code}</div>
        <div style={{ fontSize: 10, color: done ? "#34d399" : "var(--text4)" }}>{done ? "✓ Done" : "Pending"}</div>
      </div>
      <div style={{ fontSize: 11, color: "var(--text3)", fontFamily: "var(--sans)" }}>{name}</div>
    </div>
  );

  const PhaseHead = ({ code, name, tag, done, open, onClick }: any) => (
    <div onClick={onClick} style={{
      display: "flex", alignItems: "center", gap: 14, padding: "15px 18px",
      background: "var(--bg2)",
      border: `1px solid ${done ? "rgba(201,168,76,.25)" : "var(--border)"}`,
      borderRadius: open ? "10px 10px 0 0" : 10,
      cursor: "pointer", userSelect: "none",
    }}>
      <div style={{
        width: 36, height: 36, borderRadius: "50%",
        background: done ? "rgba(201,168,76,.15)" : "var(--bg3)",
        border: `1px solid ${done ? "rgba(201,168,76,.35)" : "var(--border2)"}`,
        display: "flex", alignItems: "center", justifyContent: "center",
        fontSize: 12, fontWeight: 700, color: done ? "var(--warm)" : "var(--text4)",
        flexShrink: 0,
      }}>{code}</div>
      <div style={{ flex: 1 }}>
        <div style={{ fontFamily: "var(--serif)", fontSize: 18, color: "var(--text)", fontStyle: "italic" }}>{name}</div>
        <div style={{ fontSize: 11, color: "var(--text4)", marginTop: 2 }}>{tag}</div>
      </div>
      <div style={{ fontSize: 13, color: "var(--text3)" }}>{open ? "▾" : "▸"}</div>
    </div>
  );

  const PhaseBodyShell = ({ children }: any) => (
    <div style={{
      background: "var(--bg2)", border: "1px solid var(--border)", borderTop: "none",
      borderRadius: "0 0 10px 10px", padding: "22px 24px", marginBottom: 14,
    }}>{children}</div>
  );

  const PendingBody = ({ msg }: any) => (
    <div style={{
      padding: "22px 26px", background: "rgba(255,255,255,.02)",
      border: "1px dashed var(--border2)", borderRadius: 8,
      color: "var(--text4)", fontSize: 13, fontStyle: "italic", lineHeight: 1.7,
    }}>{msg}</div>
  );

  const SubCard = ({ title, phaseCode, children }: any) => (
    <div style={{ marginBottom: 18 }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }}>
        <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: 2, textTransform: "uppercase", color: "var(--warm)" }}>{title}</div>
        {phaseCode && (
          <button onClick={() => onBack && onBack(phaseCode.toLowerCase())}
            style={{ background: "transparent", border: "none", color: "var(--text4)", fontSize: 11, cursor: "pointer", padding: 0 }}>
            Back to {phaseCode} →
          </button>
        )}
      </div>
      <div style={{ background: "rgba(0,0,0,.18)", border: "1px solid var(--border)", borderRadius: 9, padding: "16px 18px" }}>
        {children}
      </div>
    </div>
  );

  // ===== A1 =====
  const renderA1 = () => {
    const purposeText = (map.purpose_final && map.purpose_final.trim())
      || (map.purpose_layers && map.purpose_layers.length > 0
            ? map.purpose_layers.filter((l: string) => (l || "").trim()).join(" · ")
            : "")
      || (map.purpose_draft || "")
      || "";

    const validAreas: any[] = map.life_areas || [];
    const hierOrder: number[] = (map.hier_order || []) as number[];
    const orderedAreas: any[] = hierOrder.length
      ? [
          ...hierOrder.map((i: number) => validAreas[i]).filter(Boolean),
          ...validAreas.filter((_a: any, i: number) => !hierOrder.includes(i)),
        ]
      : validAreas;

    const bagWealth = [
      { label: "Retirement",          body: map.bag_retirement },
      { label: "Assets",              body: map.bag_assets },
      { label: "Cash flow & Salary",  body: map.bag_cashflow },
      { label: map.bag_other_label || "Other", body: map.bag_other },
    ];
    const bagGrowth = [
      { label: map.bag_growth_label1 || "Skills & Learning",      body: map.bag_growth_1 },
      { label: map.bag_growth_label2 || "Relationships",          body: map.bag_growth_2 },
      { label: map.bag_growth_label3 || "Purpose & Contribution", body: map.bag_growth_3 },
      { label: map.bag_growth_label4 || "Other",                  body: map.bag_growth_4 },
    ];
    const bagGrowthSentence  = map.growth_sentence  || map.growth_summary  || "";
    const oneyrGrowth        = map.oneyr_growth_sentence || "";
    const bagTimeSentence    = map.time_summary    || map.time_overall_sentence    || "";
    const bagWealthSentence  = map.wealth_summary  || map.wealth_overall_sentence  || "";

    const animals: any[] = (map.animals || []).filter((a: any) => a && a.name);

    const valuesRows: { i: number; name: string; summary: string }[] = [];
    for (let i = 0; i < 30; i++) {
      const n = map[`val_${i}_name`];
      if (!n) break;
      valuesRows.push({ i, name: n, summary: map[`val_${i}_summary`] || "" });
    }

    const colHeader: React.CSSProperties = { fontSize: 10, fontWeight: 700, letterSpacing: 1.5, textTransform: "uppercase", color: "var(--warm)", marginBottom: 8, textAlign: "center" };
    const subHeader: React.CSSProperties = { fontSize: 9.5, fontWeight: 700, letterSpacing: 1.2, textTransform: "uppercase", color: "var(--text4)", marginBottom: 5, marginTop: 10 };
    const cellBody: React.CSSProperties  = { fontSize: 12, color: "var(--text2)", lineHeight: 1.55, fontStyle: "italic" };

    const dirCol = (header: string, time: any, wealth: any[], growth: any[], growthSentence: string, timeSentence: string, wealthSentence: string) => (
      <div style={{ background: "rgba(0,0,0,.22)", border: "1px solid var(--border)", borderRadius: 8, padding: "13px 14px" }}>
        <div style={colHeader}>{header}</div>
        <div style={subHeader}>⏳ Time</div>
        {timeSentence
          ? <div style={cellBody}>{timeSentence}</div>
          : (Array.isArray(time) && time.length > 0
              ? time.slice(0, 4).map((a: any, i: number) => (
                  <div key={i} style={{ ...cellBody, fontStyle: "normal", marginBottom: 3 }}>· {a?.label || `Area ${i + 1}`}</div>
                ))
              : <div style={{ ...cellBody, color: "var(--text4)" }}>—</div>)}
        <div style={subHeader}>💰 Wealth</div>
        {wealthSentence ? <div style={cellBody}>{wealthSentence}</div> : null}
        {wealth.some(w => w.body) ? wealth.filter(w => w.body).map((w, i) => (
          <div key={i} style={{ ...cellBody, fontStyle: "normal", marginBottom: 3 }}>
            <span style={{ color: "var(--text4)" }}>{w.label}:</span> {w.body}
          </div>
        )) : (!wealthSentence && <div style={{ ...cellBody, color: "var(--text4)" }}>—</div>)}
        <div style={subHeader}>🌱 Growth</div>
        {growthSentence ? <div style={cellBody}>{growthSentence}</div> : null}
        {growth.some(g => g.body) ? growth.filter(g => g.body).map((g, i) => (
          <div key={i} style={{ ...cellBody, fontStyle: "normal", marginBottom: 3 }}>
            <span style={{ color: "var(--text4)" }}>{g.label}:</span> {g.body}
          </div>
        )) : (!growthSentence && <div style={{ ...cellBody, color: "var(--text4)" }}>—</div>)}
      </div>
    );

    return (
      <>
        <SubCard title="Purpose · the north star" phaseCode="A1">
          <div style={{ fontFamily: "var(--serif)", fontStyle: "italic", fontSize: 22, lineHeight: 1.55, color: purposeText ? "var(--text)" : "var(--text4)" }}>
            "{purposeText || "(not yet captured)"}"
          </div>
        </SubCard>

        <SubCard title="Direction · 1-Year · 3-Year · BAG" phaseCode="A1">
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12 }}>
            {dirCol("1-YEAR", null, [], [], oneyrGrowth, "", "")}
            {dirCol("3-YEAR", null, [], [], "", "", "")}
            {dirCol(map.bag_year ? `BAG · ${map.bag_year}` : "BAG", orderedAreas, bagWealth, bagGrowth, bagGrowthSentence, bagTimeSentence, bagWealthSentence)}
          </div>
        </SubCard>

        <SubCard title="Identity · Superpowers" phaseCode="A1">
          {animals.length === 0
            ? <div style={{ color: "var(--text4)", fontSize: 13, fontStyle: "italic" }}>(not yet captured)</div>
            : (
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                {animals.map((a: any, i: number) => {
                  const animalLabel = [a.adj1, a.adj2, a.name].filter(Boolean).join(" ");
                  const caps = (a.capabilities || []).filter((c: any) => c && c.name);
                  const chips = (a.identity_chips || []) as any[];
                  return (
                    <div key={i} style={{ padding: "12px 14px", background: "var(--bg2)", border: "1px solid var(--border)", borderRadius: 8 }}>
                      <div style={{ fontFamily: "var(--serif)", fontSize: 17, fontStyle: "italic", color: "var(--warm)", marginBottom: 8 }}>{animalLabel}</div>
                      {caps.length > 0 && (
                        <div style={{ display: "flex", flexWrap: "wrap", gap: 5, marginBottom: chips.length ? 8 : 0 }}>
                          {caps.map((c: any, ci: number) => (
                            <div key={ci} style={{ padding: "3px 9px", background: "rgba(201,168,76,.08)", border: "1px solid rgba(201,168,76,.25)", borderRadius: 12, fontSize: 11, color: "var(--text2)" }}>{c.name}</div>
                          ))}
                        </div>
                      )}
                      {chips.length > 0 && (
                        <div style={{ display: "flex", flexWrap: "wrap", gap: 5 }}>
                          {chips.map((c: any, ci: number) => (
                            <div key={ci} style={{ padding: "3px 9px", background: "rgba(167,139,250,.08)", border: "1px solid rgba(167,139,250,.25)", borderRadius: 12, fontSize: 11, color: "var(--text2)" }}>
                              {c.label || c.name || c.text || ""}
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
        </SubCard>

        <SubCard title="Values in order" phaseCode="A1">
          {valuesRows.length === 0
            ? <div style={{ color: "var(--text4)", fontSize: 13, fontStyle: "italic" }}>(no values yet)</div>
            : (
              <ol style={{ margin: 0, padding: "0 0 0 22px" }}>
                {valuesRows.map(v => (
                  <li key={v.i} style={{ marginBottom: 9, color: "var(--text2)", fontSize: 13, lineHeight: 1.6 }}>
                    <span style={{ fontWeight: 700, color: "var(--text)" }}>{v.name}</span>
                    {v.summary && <> — <span style={{ color: "var(--text3)" }}>{v.summary}</span></>}
                  </li>
                ))}
              </ol>
            )}
        </SubCard>

        <SubCard title="Big Ass Goal · the integrated three" phaseCode="A1">
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 14 }}>
            {[
              { lbl: "Time",   body: bagTimeSentence },
              { lbl: "Wealth", body: bagWealthSentence },
              { lbl: "Growth", body: bagGrowthSentence },
            ].map((b, i) => (
              <div key={i} style={{ padding: "12px 14px", background: "var(--bg2)", border: "1px solid var(--border)", borderRadius: 8 }}>
                <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 1.5, textTransform: "uppercase", color: "var(--warm)", marginBottom: 6 }}>{b.lbl}</div>
                <div style={{ fontSize: 13, color: b.body ? "var(--text2)" : "var(--text4)", lineHeight: 1.6, fontStyle: b.body ? "italic" : "normal" }}>
                  {b.body || "—"}
                </div>
              </div>
            ))}
          </div>
        </SubCard>
      </>
    );
  };

  // ===== A2 =====
  const renderA2 = () => {
    const acts: any[] = map.a2_ta_acts || [];
    const supports = acts.filter((a: any) => a && a.category === "support").length;
    const reshape  = acts.filter((a: any) => a && a.category === "reshape").length;
    const leaks    = acts.filter((a: any) => a && a.category === "leak").length;
    const hasCategories = supports + reshape + leaks > 0;

    const fslParts = [map.a2_fsl_s1, map.a2_fsl_s2, map.a2_fsl_s3, map.a2_fsl_s4]
      .filter((s: any) => s && s.trim());

    return (
      <>
        <SubCard title="Key Misalignment" phaseCode="A2">
          <div style={{ fontSize: 13, color: map.a2_km_pinned_id ? "var(--text2)" : "var(--text4)" }}>
            Pinned: {map.a2_km_pinned_id || "—"}
          </div>
        </SubCard>

        <SubCard title="Time Audit" phaseCode="A2">
          {hasCategories ? (
            <div style={{ display: "flex", gap: 14, flexWrap: "wrap", marginBottom: 10 }}>
              <div style={{ fontSize: 13, color: "var(--text2)" }}><strong style={{ color: "#34d399" }}>Supports:</strong> {supports}</div>
              <div style={{ fontSize: 13, color: "var(--text2)" }}><strong style={{ color: "var(--warm)" }}>Reshape:</strong> {reshape}</div>
              <div style={{ fontSize: 13, color: "var(--text2)" }}><strong style={{ color: "#ef4444" }}>Leaks:</strong> {leaks}</div>
            </div>
          ) : (
            <div style={{ fontSize: 13, color: "var(--text2)", marginBottom: 10 }}>Total acts logged: {acts.length}</div>
          )}
          <div style={{ fontSize: 12, color: "var(--text3)", paddingTop: 8, borderTop: "1px solid var(--border)" }}>
            Pinned Priority: {map.a2_km_pinned_id || "—"}
          </div>
        </SubCard>

        <SubCard title="Future Self Letter" phaseCode="A2">
          {fslParts.length === 0 ? (
            <div style={{ color: "var(--text4)", fontSize: 13, fontStyle: "italic" }}>(letter not yet written)</div>
          ) : (
            <div style={{ paddingLeft: 14, borderLeft: "2px solid var(--warm)", fontFamily: "var(--serif)", fontStyle: "italic", fontSize: 17, lineHeight: 1.7, color: "var(--text)" }}>
              "{fslParts.join(" ")}"
            </div>
          )}
        </SubCard>

        <SubCard title="Your One Thing" phaseCode="A2">
          <div style={{ fontFamily: "var(--serif)", fontStyle: "italic", fontSize: 22, color: "var(--text)", lineHeight: 1.55, marginBottom: 8 }}>
            "{map.a2_one_thing || "—"}"
          </div>
          {map.a2_one_thing_confirmed && (
            <div style={{ display: "inline-block", padding: "3px 10px", background: "rgba(52,211,153,.12)", border: "1px solid rgba(52,211,153,.35)", borderRadius: 12, fontSize: 10, fontWeight: 700, letterSpacing: 1.2, color: "#34d399" }}>
              ✓ CONFIRMED
            </div>
          )}
        </SubCard>
      </>
    );
  };

  // ===== A3 =====
  const renderA3 = () => {
    const people: any[] = map.a3_people || [];
    const advocates = people.filter((p: any) => p.rating === "advocate");
    const neutrals  = people.filter((p: any) => p.rating === "neutral");
    const anchors   = people.filter((p: any) => p.rating === "anchor");
    const topAdvocates = advocates.slice(0, 3).map((p: any) => p.name);

    const candidates: any[]   = map.a3_board_candidates || [];
    const missingSeats: any[] = map.a3_board_missing || [];
    const seatedCands = candidates.filter((c: any) => c.primary && c.seatName);

    const envItems: any[] = map.a3_env_items || [];
    const envChange  = envItems.filter((e: any) => e.rating === "change").length;
    const envProtect = envItems.filter((e: any) => e.rating === "protect").length;
    const envOther   = envItems.filter((e: any) => e.rating && e.rating !== "change" && e.rating !== "protect").length;
    const ratedPeople = advocates.length + neutrals.length + anchors.length;
    const ratedEnv    = envItems.filter((e: any) => e.rating).length;

    const thoughts: any[] = map.a3_thoughts || [];
    const advThoughts = thoughts.filter((t: any) => t.rating === "advocate");
    const neuThoughts = thoughts.filter((t: any) => !t.rating || t.rating === "neutral");
    const ancThoughts = thoughts.filter((t: any) => t.rating === "anchor");

    const cardWrap: React.CSSProperties  = { background: "rgba(0,0,0,.18)", border: "1px solid var(--border)", borderRadius: 9, padding: "16px 18px" };
    const cardTitle: React.CSSProperties = { fontSize: 11, fontWeight: 700, letterSpacing: 2, textTransform: "uppercase", color: "var(--warm)", marginBottom: 10 };
    const backLink = (
      <button onClick={() => onBack && onBack("a3")} style={{ background: "transparent", border: "none", color: "var(--text4)", fontSize: 11, cursor: "pointer", padding: 0 }}>
        Back to A3 →
      </button>
    );

    const cx = 130, cy = 70, rx = 110, ry = 50;
    const boardSeats = seatedCands.slice(0, 8).map((c: any, i: number) => {
      const angle = (i / Math.max(seatedCands.length, 1)) * Math.PI * 2 - Math.PI / 2;
      return {
        id: c.id,
        x: cx + Math.cos(angle) * (rx + 10),
        y: cy + Math.sin(angle) * (ry + 10),
        label: c.seatName,
      };
    });

    return (
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 22 }}>
        <div style={cardWrap}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
            <div style={cardTitle}>People · Your inner circle</div>{backLink}
          </div>
          <div style={{ display: "flex", gap: 14, flexWrap: "wrap", marginBottom: 10 }}>
            <div style={{ fontSize: 13, color: "var(--text2)" }}><strong style={{ color: "#34d399" }}>Advocates:</strong> {advocates.length}</div>
            <div style={{ fontSize: 13, color: "var(--text2)" }}><strong style={{ color: "var(--text3)" }}>Neutrals:</strong> {neutrals.length}</div>
            <div style={{ fontSize: 13, color: "var(--text2)" }}><strong style={{ color: "#ef4444" }}>Anchors:</strong> {anchors.length}</div>
          </div>
          {topAdvocates.length > 0 && (
            <div style={{ fontSize: 12, color: "var(--text3)", lineHeight: 1.6 }}>
              Top advocates: {topAdvocates.join(", ")}
            </div>
          )}
          {ratedPeople === 0 && <div style={{ fontSize: 12, color: "var(--text4)", fontStyle: "italic" }}>(none rated yet)</div>}
        </div>

        <div style={cardWrap}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
            <div style={cardTitle}>Board</div>{backLink}
          </div>
          <svg viewBox="0 0 260 140" width="100%" height="140" style={{ display: "block", marginBottom: 10 }}>
            <ellipse cx={cx} cy={cy} rx={rx} ry={ry} fill="rgba(201,168,76,.06)" stroke="rgba(201,168,76,.35)" strokeWidth="1.5" />
            <text x={cx} y={cy + 4} textAnchor="middle" fontSize="11" fill="#c9a84c" fontStyle="italic">Your Board</text>
            {boardSeats.map((s: any, i: number) => (
              <g key={s.id || i}>
                <circle cx={s.x} cy={s.y} r="3.5" fill="#34d399" />
                <text x={s.x} y={s.y - 6} textAnchor="middle" fontSize="9" fill="#d4cfc5">{s.label}</text>
              </g>
            ))}
          </svg>
          <div style={{ fontSize: 12, color: "var(--text3)" }}>
            Seated: <strong style={{ color: "var(--text2)" }}>{seatedCands.length}</strong>
            {missingSeats.length > 0 && <> · Missing: <strong style={{ color: "var(--text2)" }}>{missingSeats.length}</strong></>}
          </div>
        </div>

        <div style={cardWrap}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
            <div style={cardTitle}>Environment</div>{backLink}
          </div>
          {map.a3_env_takeaway ? (
            <div style={{ fontFamily: "var(--serif)", fontStyle: "italic", fontSize: 16, color: "var(--text)", lineHeight: 1.6, marginBottom: 12 }}>
              "{map.a3_env_takeaway}"
            </div>
          ) : (
            <div style={{ fontSize: 12, color: "var(--text4)", fontStyle: "italic", marginBottom: 10 }}>(no takeaway yet)</div>
          )}
          <div style={{ display: "flex", gap: 14, flexWrap: "wrap", paddingTop: 10, borderTop: "1px solid var(--border)" }}>
            <div style={{ fontSize: 12, color: "var(--text2)" }}><strong style={{ color: "var(--warm)" }}>Change:</strong> {envChange}</div>
            <div style={{ fontSize: 12, color: "var(--text2)" }}><strong style={{ color: "#34d399" }}>Protect:</strong> {envProtect}</div>
            {envOther > 0 && <div style={{ fontSize: 12, color: "var(--text2)" }}><strong style={{ color: "var(--text3)" }}>Other:</strong> {envOther}</div>}
            {ratedEnv === 0 && <div style={{ fontSize: 12, color: "var(--text4)" }}>(none rated)</div>}
          </div>
        </div>

        <div style={cardWrap}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
            <div style={cardTitle}>Thoughts landscape</div>{backLink}
          </div>
          {[
            { rows: advThoughts, color: "#34d399",       bg: "rgba(52,211,153,.08)",  brd: "rgba(52,211,153,.3)",  lbl: "Advocate" },
            { rows: neuThoughts, color: "var(--text3)",  bg: "rgba(155,150,144,.08)", brd: "rgba(155,150,144,.3)", lbl: "Neutral" },
            { rows: ancThoughts, color: "#ef4444",       bg: "rgba(239,68,68,.08)",   brd: "rgba(239,68,68,.3)",   lbl: "Anchor" },
          ].map((row, i) => (
            <div key={i} style={{ marginBottom: 8 }}>
              <div style={{ fontSize: 9.5, fontWeight: 700, letterSpacing: 1.2, textTransform: "uppercase", color: row.color, marginBottom: 4 }}>{row.lbl} · {row.rows.length}</div>
              {row.rows.length === 0 ? (
                <div style={{ fontSize: 11, color: "var(--text4)", fontStyle: "italic" }}>—</div>
              ) : (
                <div style={{ display: "flex", flexWrap: "wrap", gap: 4 }}>
                  {row.rows.slice(0, 12).map((th: any) => (
                    <div key={th.id} style={{ padding: "3px 8px", background: row.bg, border: `1px solid ${row.brd}`, borderRadius: 10, fontSize: 10.5, color: "var(--text2)", maxWidth: 200, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                      {th.text}
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>

        <div style={cardWrap}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
            <div style={cardTitle}>Best friend response</div>{backLink}
          </div>
          {map.a3_best_friend ? (
            <div style={{ paddingLeft: 14, borderLeft: "2px solid var(--warm)", fontFamily: "var(--serif)", fontStyle: "italic", fontSize: 16, color: "var(--text)", lineHeight: 1.7 }}>
              "{map.a3_best_friend}"
            </div>
          ) : (
            <div style={{ fontSize: 12, color: "var(--text4)", fontStyle: "italic" }}>(not yet captured)</div>
          )}
        </div>

        <div style={cardWrap}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
            <div style={cardTitle}>Energy map snapshot</div>{backLink}
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
            <div>
              <div style={{ fontSize: 9.5, fontWeight: 700, letterSpacing: 1.2, textTransform: "uppercase", color: "var(--text3)", marginBottom: 5 }}>People</div>
              <div style={{ fontSize: 12, color: "var(--text2)" }}>+{advocates.length} advocate · -{anchors.length} anchor</div>
            </div>
            <div>
              <div style={{ fontSize: 9.5, fontWeight: 700, letterSpacing: 1.2, textTransform: "uppercase", color: "var(--text3)", marginBottom: 5 }}>Environment</div>
              <div style={{ fontSize: 12, color: "var(--text2)" }}>+{envProtect} protect · {envChange} change</div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div style={{ minHeight: "100vh", background: "var(--bg)", color: "var(--text)" }}>
      <style>{CSS}</style>

      {/* TOP BAR */}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "14px 28px", borderBottom: "1px solid var(--border)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 9 }}>
          <span style={{ width: 8, height: 8, borderRadius: "50%", background: "var(--warm)" }} />
          <span style={{ fontFamily: "var(--sans)", fontSize: 13, color: "var(--text)", fontWeight: 600 }}>True Ownership™</span>
          <span style={{ color: "var(--text4)" }}>·</span>
          <span style={{ fontFamily: "var(--serif)", fontSize: 14, fontStyle: "italic", color: "var(--text3)" }}>Katherine</span>
        </div>
        <div style={{ display: "flex", gap: 6 }}>
          {phases.map(p => <PhasePill key={p.key} code={p.code} done={allDoneFlags[p.key]} />)}
        </div>
      </div>

      <div style={{ display: "flex", alignItems: "flex-start" }}>
        {/* SIDEBAR */}
        <div style={{ width: 206, flexShrink: 0, padding: "24px 16px", borderRight: "1px solid var(--border)", minHeight: "calc(100vh - 47px)" }}>
          <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 2, textTransform: "uppercase", color: "var(--text4)", marginBottom: 11 }}>My Map of Me™</div>
          <SidebarPhaseItem label="All In It · A1" done={a1Done} />
          <SidebarPhaseItem label="Align With It · A2" done={a2Done} />
          <SidebarPhaseItem label="Advocate For It · A3" done={a3Done} />
          <SidebarPhaseItem label="Act On It · A4" done={false} />
          <SidebarPhaseItem label="Accountability To It · A5" done={false} />

          <div style={{ height: 1, background: "var(--border)", margin: "18px 0 13px" }} />
          <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 2, textTransform: "uppercase", color: "var(--text4)", marginBottom: 9 }}>Progress</div>
          <div className="sidebar-btn active" style={{ cursor: "default" }}>
            <span style={{ fontSize: 12, color: "var(--warm)", fontWeight: 600 }}>My Map of Me™</span>
          </div>

          <div style={{ height: 1, background: "var(--border)", margin: "18px 0 13px" }} />
          <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 2, textTransform: "uppercase", color: "var(--text4)", marginBottom: 9 }}>Voice</div>
          <VoiceDropdown voiceId={voice} onSelect={setVoicePersist} />
        </div>

        {/* MAIN */}
        <div style={{ flex: 1, padding: "32px 40px", maxWidth: 980 }}>
          <button onClick={() => onBack && onBack(origin)} style={{
            display:"inline-flex", alignItems:"center", gap:6, marginBottom:18,
            background:"transparent", border:"1px solid var(--border2)",
            color:"var(--text2)", padding:"5px 12px", borderRadius:14,
            fontFamily:"var(--sans)", fontSize:11, letterSpacing:0.5, cursor:"pointer",
          }}>← Back to {origin.toUpperCase()}</button>
          <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: 2, textTransform: "uppercase", color: "var(--warm)", marginBottom: 11 }}>My Map of Me™</div>
          <h1 style={{ fontFamily: "var(--serif)", fontSize: 34, fontWeight: 400, lineHeight: 1.2, letterSpacing: "-0.5px", margin: "0 0 10px" }}>
            A living reflection of who you are — and what you're building.
          </h1>
          <div style={{ fontSize: 15, color: "var(--text2)", fontStyle: "italic", lineHeight: 1.6, marginBottom: 14 }}>
            Not finished. Not meant to be. This grows as you do.
          </div>
          <div style={{ fontSize: 11, color: "var(--text4)", textTransform: "uppercase", letterSpacing: 1.5, marginBottom: 22 }}>
            LAST UPDATED · {lastUpdated}
          </div>

          {/* PROGRESS STRIP */}
          <div style={{ display: "flex", gap: 8, marginBottom: 14 }}>
            {phases.map(p => <StripCell key={p.key} code={p.code} name={p.name} done={allDoneFlags[p.key]} />)}
          </div>

          {/* CONTROLS */}
          <div style={{ display: "flex", justifyContent: "flex-end", marginBottom: 18 }}>
            <button onClick={toggleAll} style={{ background: "transparent", border: "1px solid var(--border2)", color: "var(--text2)", padding: "6px 14px", borderRadius: 14, fontSize: 12, cursor: "pointer" }}>
              {allOpen ? "Collapse all" : "Expand all"}
            </button>
          </div>

          {/* PHASE SECTIONS */}
          {phases.map(p => {
            const done = allDoneFlags[p.key];
            const open = !!openSections[p.key];
            const pendingMsg = ({
              a1: "This grows as you complete A1.",
              a2: "This grows when you reach A2 — your alignment, time audit, and One Thing.",
              a3: "This grows when you reach A3 — your people, environment, board, and inner landscape.",
              a4: "This grows when you reach A4 — your rhythms, commitments, and accountability structure.",
              a5: "This grows when you reach A5 — final integration.",
            } as any)[p.key];
            return (
              <div key={p.key}>
                <PhaseHead code={p.code} name={p.name} tag={p.tag} done={done} open={open} onClick={() => toggleSection(p.key)} />
                {open && (
                  <PhaseBodyShell>
                    {!done ? <PendingBody msg={pendingMsg} />
                      : p.key === "a1" ? renderA1()
                      : p.key === "a2" ? renderA2()
                      : p.key === "a3" ? renderA3()
                      : <PendingBody msg={pendingMsg} />}
                  </PhaseBodyShell>
                )}
              </div>
            );
          })}

          {/* FOOTER */}
          <div style={{ marginTop: 32, paddingTop: 18, borderTop: "1px solid var(--border)", textAlign: "center" }}>
            <div style={{ fontSize: 12, color: "var(--text4)", fontStyle: "italic", lineHeight: 1.7 }}>
              Your Map of Me builds throughout True Ownership. You'll be able to download the complete version once you've worked through all five phases.
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}

function AuthedApp() {
  const [phase, setPhase] = useState("loading");
  const [intake, setIntake] = useState(null);
  const prevPhaseRef = useRef("a1");
  useEffect(() => {
    Promise.all([loadData(KEYS.intake), loadData(KEYS.phase)]).then(([i, p]) => {
      if (i) setIntake(i);
      // Defensive: never restore the user into "_admin" on next sign-in.
      const safe = p === "_admin" ? null : p;
      setPhase(safe || (i ? "a1" : "intake"));
    });
  }, []);
  // Track the last "real" phase so we can return to it from the admin pane.
  useEffect(() => {
    if (phase !== "_admin" && phase !== "loading") prevPhaseRef.current = phase;
  }, [phase]);
  const doneIntake = async (data) => { setIntake(data); await saveData(KEYS.intake, data); await saveData(KEYS.phase, "a1"); setPhase("a1"); };
  const doneA1 = async () => { await saveData(KEYS.phase, "done"); setPhase("done"); };
  const doneA2 = async () => { await saveData(KEYS.phase, "done"); setPhase("done"); };
  const doneA3 = doneA2;
  if (phase === "loading") return <div style={{ minHeight:"100vh", background:"#0d1b2e", display:"flex", alignItems:"center", justifyContent:"center" }}><style>{CSS}</style><div style={{ fontFamily:"var(--sans)", fontSize:12, color:"#3d3d38", letterSpacing:2, animation:"pulse 1.5s infinite" }}>Loading…</div></div>;
  if (phase === "_admin") return <><AdminScreenGuarded onExit={() => setPhase(prevPhaseRef.current)} /><AccountMenu /></>;
  if (phase === "_mapofme") return <><MapOfMePage onBack={(origin?: string) => setPhase((origin || loadDataSync("to_mapofme_origin") || "a1") as any)} /><AdminBar phase={phase} onAdminClick={() => setPhase("_admin")} /><AccountMenu /></>;
  const phaseOwnsTopBar = phase === "a1" || phase === "a2" || phase === "a3";
  return (
    <div style={{ background:"#0d1b2e", minHeight:"100vh" }}>
      <style>{CSS}</style>
      {!phaseOwnsTopBar && <AdminBar phase={phase} onAdminClick={() => setPhase("_admin")} />}
      {!phaseOwnsTopBar && <AccountMenu />}
      {phase === "intake" && <Intake onDone={doneIntake} />}
      {phase === "a1" && intake && <A1 intake={intake} onDone={doneA1} phase={phase} setPhase={setPhase} />}
      {phase === "a2" && intake && <A2 intake={intake} onDone={doneA2} phase={phase} setPhase={setPhase} />}
      {phase === "a3" && intake && <A3 intake={intake} onDone={doneA3} phase={phase} setPhase={setPhase} />}
      {phase === "done" && (
        <div style={{ minHeight:"100vh", display:"flex", alignItems:"center", justifyContent:"center", padding:36 }}>
          <div className="fade-up" style={{ maxWidth:480, textAlign:"center" }}>
            <div style={{ fontSize:38, marginBottom:14 }}>⛰️</div>
            <div className="lbl" style={{ marginBottom:11, display:"block" }}>A1 Complete</div>
            <h2 style={{ fontFamily:"var(--serif)", fontSize:38, fontWeight:300, lineHeight:1.2, marginBottom:13, letterSpacing:"-0.5px" }}>Your Map of Me™ is built.<br /><em>Now we align it with your life.</em></h2>
            <p style={{ fontFamily:"var(--sans)", fontSize:14, color:"#7a766e", lineHeight:1.8, marginBottom:26 }}>A2 -- Align With It -- asks: does how you actually live match who you now know yourself to be?</p>
            <button className="btn" style={{ marginBottom:11 }} onClick={() => setPhase("a2")}>A2 -- Align With It -&gt;</button>
            <div><button className="btn-g" onClick={() => setPhase("a1")}>← Return to Map of Me™</button></div>
          </div>
        </div>
      )}
    </div>
  );
}
function LoadingScreen() {
  return <div style={{ minHeight:"100vh", background:"#0d1b2e", display:"flex", alignItems:"center", justifyContent:"center" }}><style>{CSS}</style><div style={{ fontFamily:"var(--sans)", fontSize:12, color:"#3d3d38", letterSpacing:2, animation:"pulse 1.5s infinite" }}>Loading…</div></div>;
}

function SignInScreen() {
  const { login } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const e_ = email.trim();
    if (!e_ || !password) {
      setError("Email and password are required.");
      return;
    }
    setError(null);
    setBusy(true);
    const err = await login(e_, password);
    setBusy(false);
    if (err) setError(err);
  }

  return (
    <div style={{ minHeight:"100vh", background:"#0d1b2e", display:"flex", flexDirection:"column" }}>
      <style>{CSS}</style>
      <div style={{ flex:1, display:"flex", alignItems:"center", justifyContent:"center", padding:36 }}>
      <form onSubmit={handleSubmit} className="fade-up" style={{ width:"100%", maxWidth:420 }}>
        <div style={{ textAlign:"center", marginBottom:18 }}>
          <img
            src={`${import.meta.env.BASE_URL}ag45-logo.png`}
            alt="AccelerateGrowth45"
            width={220}
            style={{ height:"auto", display:"block", margin:"0 auto 28px" }}
          />
          <div className="lbl" style={{ marginBottom:18 }}>True Ownership™</div>
          <h1 style={{ fontFamily:"var(--serif)", fontSize:42, fontWeight:300, color:"#e8e3d8", marginBottom:14, letterSpacing:"-0.5px", lineHeight:1.15 }}>Welcome back</h1>
          <p style={{ fontFamily:"var(--sans)", fontSize:14, color:"#7a766e", lineHeight:1.8 }}>Sign in to start — or pick up where you left off.</p>
        </div>
        <div style={{ display:"flex", flexDirection:"column", gap:11, marginTop:30 }}>
          <label style={{ display:"block" }}>
            <div className="lbl" style={{ marginBottom:6, fontSize:11, color:"var(--text3)" }}>Email</div>
            <input
              type="email"
              autoComplete="email"
              autoFocus
              className="to-field"
              placeholder="you@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              disabled={busy}
            />
          </label>
          <label style={{ display:"block" }}>
            <div className="lbl" style={{ marginBottom:6, fontSize:11, color:"var(--text3)" }}>Password</div>
            <input
              type="password"
              autoComplete="current-password"
              className="to-field"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              disabled={busy}
            />
          </label>
          {error && (
            <div style={{ fontFamily:"var(--sans)", fontSize:12, color:"#ef4444", background:"rgba(239,68,68,0.08)", border:"1px solid rgba(239,68,68,0.25)", borderRadius:6, padding:"9px 12px" }}>
              {error}
            </div>
          )}
          <button type="submit" className="btn" disabled={busy} style={{ marginTop:8, justifyContent:"center" }}>
            {busy ? "Signing in…" : "Sign in"}
          </button>
        </div>
        <div style={{ textAlign:"center", marginTop:22, fontFamily:"var(--sans)", fontSize:11, color:"#5c5953", letterSpacing:1 }}>
          Access by invite. Contact Katherine if you need an account.
        </div>
      </form>
      </div>
      <Footer />
    </div>
  );
}

function ChangePasswordModal({ onClose }: { onClose: () => void }) {
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!currentPassword || !newPassword) {
      setError("Please fill in every field.");
      return;
    }
    if (newPassword.length < 8) {
      setError("New password must be at least 8 characters.");
      return;
    }
    if (newPassword !== confirm) {
      setError("New password and confirmation don't match.");
      return;
    }
    setError(null);
    setBusy(true);
    try {
      const res = await fetch("/api/auth/me/password", {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ currentPassword, newPassword }),
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({} as { error?: string }));
        setError(data.error ?? `Couldn't change password (HTTP ${res.status}).`);
        setBusy(false);
        return;
      }
      // Success — server killed the session. Force a hard reload so we
      // land back on the sign-in screen with the new password.
      setDone(true);
      setTimeout(() => { window.location.reload(); }, 1400);
    } catch {
      setError("Network error — please try again.");
      setBusy(false);
    }
  }

  return (
    <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.75)", display:"flex", alignItems:"center", justifyContent:"center", zIndex:9999, padding:24 }}>
      <form onSubmit={handleSubmit} className="fade-up" style={{ width:"100%", maxWidth:440, background:"#1a2940", border:"1px solid rgba(201,168,76,0.3)", borderRadius:8, padding:32, fontFamily:"var(--sans)" }}>
        <h2 style={{ fontFamily:"var(--serif)", fontSize:26, fontWeight:300, color:"#e8e3d8", marginBottom:8, letterSpacing:"-0.3px", lineHeight:1.25 }}>Change password</h2>
        <p style={{ fontSize:13, color:"var(--text3)", lineHeight:1.7, marginBottom:22 }}>You'll be signed out and asked to sign in again with your new password.</p>
        {done ? (
          <div style={{ fontSize:13, color:"#34d399", padding:"12px 14px", background:"rgba(52,211,153,0.08)", border:"1px solid rgba(52,211,153,0.25)", borderRadius:6 }}>
            Password updated. Reloading…
          </div>
        ) : (
          <div style={{ display:"flex", flexDirection:"column", gap:11 }}>
            <label>
              <div className="lbl" style={{ marginBottom:6, fontSize:11, color:"var(--text3)" }}>Current password</div>
              <input type="password" autoComplete="current-password" className="to-field" value={currentPassword} onChange={(e) => setCurrentPassword(e.target.value)} disabled={busy} autoFocus />
            </label>
            <label>
              <div className="lbl" style={{ marginBottom:6, fontSize:11, color:"var(--text3)" }}>New password</div>
              <input type="password" autoComplete="new-password" className="to-field" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} disabled={busy} placeholder="At least 8 characters" />
            </label>
            <label>
              <div className="lbl" style={{ marginBottom:6, fontSize:11, color:"var(--text3)" }}>Confirm new password</div>
              <input type="password" autoComplete="new-password" className="to-field" value={confirm} onChange={(e) => setConfirm(e.target.value)} disabled={busy} />
            </label>
            {error && (
              <div style={{ fontSize:12, color:"#ef4444", background:"rgba(239,68,68,0.08)", border:"1px solid rgba(239,68,68,0.25)", borderRadius:6, padding:"9px 12px" }}>
                {error}
              </div>
            )}
            <div style={{ display:"flex", gap:10, marginTop:10 }}>
              <button type="submit" className="btn" disabled={busy} style={{ flex:1, justifyContent:"center" }}>{busy ? "Saving…" : "Save"}</button>
              <button type="button" className="btn-g" disabled={busy} onClick={onClose}>Cancel</button>
            </div>
          </div>
        )}
      </form>
    </div>
  );
}

function detectMigrationCandidates(serverCache: Record<string, any>): string[] {
  const out: string[] = [];
  const map: Array<[string, string]> = [
    ["map", "to_map"], ["voice", "to_voice"], ["mapofme_origin", "to_mapofme_origin"],
    ["intake", "to_intake"], ["phase", "to_phase"], ["step", "to_step"], ["done", "to_done"],
  ];
  for (const [serverKey, localKey] of map) {
    const local = localStorage.getItem(localKey);
    if (!local) continue;
    const serverVal = serverCache[serverKey];
    const serverHasReal = serverKey in serverCache && serverVal != null;
    if (!serverHasReal) out.push(serverKey);
  }
  return out;
}

function MigrationModal({ onClose }: { onClose: () => void }) {
  const [busy, setBusy] = useState(false);
  const [candidates] = useState<string[]>(() => detectMigrationCandidates(serverDataCache || {}));

  async function importAll() {
    setBusy(true);
    await Promise.all(candidates.map(async (sk) => {
      const localKey = "to_" + sk;
      const raw = localStorage.getItem(localKey);
      if (raw === null) return;
      let value: any = raw;
      try { value = JSON.parse(raw); } catch {}
      try {
        const r = await fetch(`/api/userdata/${sk}`, {
          method: "PUT",
          credentials: "include",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ value }),
        });
        if (r.ok && serverDataCache) serverDataCache[sk] = value;
      } catch { /* swallow */ }
    }));
    localStorage.setItem("to_migrated", "true");
    setBusy(false);
    onClose();
  }

  function skip() {
    localStorage.setItem("to_migrated", "true");
    onClose();
  }

  return (
    <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.75)", display:"flex", alignItems:"center", justifyContent:"center", zIndex:9999, padding:24 }}>
      <div className="fade-up" style={{ background:"#1a2940", border:"1px solid rgba(201,168,76,0.3)", borderRadius:8, padding:36, maxWidth:480, fontFamily:"var(--sans)" }}>
        <h2 style={{ fontFamily:"var(--serif)", fontSize:26, fontWeight:300, color:"#e8e3d8", marginBottom:16, letterSpacing:"-0.3px", lineHeight:1.25 }}>Import your existing work?</h2>
        <p style={{ fontSize:14, color:"#a8a497", lineHeight:1.7, marginBottom:28 }}>We found work you've already done in this app on this device. Import it to your account so you can pick up where you left off — even from a different device.</p>
        <button className="btn" disabled={busy} onClick={importAll} style={{ marginRight:10, marginBottom:10 }}>{busy ? "Importing…" : "Import to my account"}</button>
        <button className="btn-g" disabled={busy} onClick={skip}>Skip — start fresh</button>
      </div>
    </div>
  );
}

// ────────────────────────────────────────────────────────────────────────────
// ADMIN PANE  (owner-only)  ── Stage 3 sub-step D
// ────────────────────────────────────────────────────────────────────────────

type AdminUser = {
  id: string;
  email: string | null;
  firstName: string | null;
  lastName: string | null;
  role: "owner" | "client";
  hasPassword: boolean;
  createdAt: string | null;
  updatedAt: string | null;
};

function AdminBar({ phase, onAdminClick, mode = "fixed" }: { phase: string; onAdminClick: () => void; mode?: "fixed" | "inline" }) {
  const { user } = useAuth();
  if (user?.role !== "owner") return null;
  if (phase === "_admin" || phase === "loading") return null;
  const baseStyle: React.CSSProperties = {
    fontSize: 11, color: "var(--warm)", background: "transparent",
    border: "1px solid rgba(201,168,76,0.45)", borderRadius: 4,
    padding: "6px 12px", cursor: "pointer", letterSpacing: 1.5,
    fontFamily: "var(--sans)", textTransform: "uppercase" as const,
  };
  const positionStyle: React.CSSProperties = mode === "inline"
    ? {}
    : { position: "fixed", top: 14, right: 170, zIndex: 1000 };
  return (
    <button
      onClick={onAdminClick}
      style={{ ...positionStyle, ...baseStyle }}
      title="Open admin pane"
    >
      Admin
    </button>
  );
}

function fmtDate(iso: string | null): string {
  if (!iso) return "—";
  try {
    const d = new Date(iso);
    return d.toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
  } catch {
    return "—";
  }
}

function fmtName(u: AdminUser): string {
  const parts = [u.firstName, u.lastName].filter(Boolean);
  return parts.length ? parts.join(" ") : "—";
}

function NewUserModal({ onClose, onCreated }: { onClose: () => void; onCreated: () => void }) {
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [role, setRole] = useState<"client" | "owner">("client");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [tempPassword, setTempPassword] = useState<string | null>(null);
  const [createdEmail, setCreatedEmail] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!email.trim() || !email.includes("@")) {
      setError("A valid email is required.");
      return;
    }
    setError(null);
    setBusy(true);
    try {
      const res = await fetch("/api/admin/users", {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: email.trim(),
          firstName: firstName.trim() || null,
          lastName: lastName.trim() || null,
          role,
        }),
      });
      const data = await res.json().catch(() => ({} as { error?: string; tempPassword?: string }));
      if (!res.ok) {
        setError(data.error ?? `Couldn't create user (HTTP ${res.status}).`);
        setBusy(false);
        return;
      }
      setTempPassword(data.tempPassword ?? null);
      setCreatedEmail(email.trim());
      setBusy(false);
      onCreated();
    } catch {
      setError("Network error — please try again.");
      setBusy(false);
    }
  }

  async function copyPw() {
    if (!tempPassword) return;
    try { await navigator.clipboard.writeText(tempPassword); setCopied(true); setTimeout(() => setCopied(false), 1600); } catch { /* ignore */ }
  }

  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.75)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 9999, padding: 24 }}>
      <div style={{ background: "#1a2940", borderRadius: 12, padding: 28, maxWidth: 480, width: "100%", color: "var(--text)", fontFamily: "var(--sans)", border: "1px solid var(--border2)" }}>
        {tempPassword ? (
          <div>
            <div className="lbl" style={{ marginBottom: 11, color: "#34d399" }}>USER CREATED</div>
            <h2 style={{ fontFamily: "var(--serif)", fontSize: 24, fontWeight: 400, marginBottom: 14, color: "var(--text)" }}>Share this password with {createdEmail}</h2>
            <p style={{ fontSize: 13, color: "var(--text3)", lineHeight: 1.6, marginBottom: 18 }}>
              The temp password is shown <em>once</em>. They'll use it to sign in, then change it themselves under <strong>Account → Change password</strong>.
            </p>
            <div style={{ background: "#0d1b2e", border: "1px solid var(--warm)", borderRadius: 8, padding: 14, fontFamily: "monospace", fontSize: 16, letterSpacing: 1, color: "var(--warm)", marginBottom: 14, wordBreak: "break-all" }}>
              {tempPassword}
            </div>
            <div style={{ display: "flex", gap: 10 }}>
              <button className="btn-g" onClick={copyPw}>{copied ? "Copied ✓" : "Copy password"}</button>
              <button className="btn" onClick={onClose}>Done</button>
            </div>
          </div>
        ) : (
          <form onSubmit={submit}>
            <div className="lbl" style={{ marginBottom: 11 }}>NEW USER</div>
            <h2 style={{ fontFamily: "var(--serif)", fontSize: 24, fontWeight: 400, marginBottom: 18, color: "var(--text)" }}>Create an account</h2>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 12 }}>
              <div>
                <label style={{ display: "block", fontSize: 11, color: "var(--text3)", marginBottom: 6, letterSpacing: 1 }}>FIRST NAME</label>
                <input className="to-field" value={firstName} onChange={(e) => setFirstName(e.target.value)} disabled={busy} style={{ fontSize: 14 }} />
              </div>
              <div>
                <label style={{ display: "block", fontSize: 11, color: "var(--text3)", marginBottom: 6, letterSpacing: 1 }}>LAST NAME</label>
                <input className="to-field" value={lastName} onChange={(e) => setLastName(e.target.value)} disabled={busy} style={{ fontSize: 14 }} />
              </div>
            </div>
            <div style={{ marginBottom: 12 }}>
              <label style={{ display: "block", fontSize: 11, color: "var(--text3)", marginBottom: 6, letterSpacing: 1 }}>EMAIL *</label>
              <input className="to-field" type="email" value={email} onChange={(e) => setEmail(e.target.value)} disabled={busy} style={{ fontSize: 14 }} required autoFocus />
            </div>
            <div style={{ marginBottom: 18 }}>
              <label style={{ display: "block", fontSize: 11, color: "var(--text3)", marginBottom: 6, letterSpacing: 1 }}>ROLE</label>
              <select className="to-field" value={role} onChange={(e) => setRole(e.target.value as "client" | "owner")} disabled={busy} style={{ fontSize: 14, appearance: "auto" }}>
                <option value="client">Client</option>
                <option value="owner">Owner (full admin access)</option>
              </select>
            </div>
            <p style={{ fontSize: 12, color: "var(--text3)", lineHeight: 1.5, marginBottom: 16 }}>
              A temp password will be generated automatically and shown once. Share it with the new user — they'll change it on first sign-in.
            </p>
            {error && (
              <div style={{ color: "#fca5a5", background: "rgba(220,38,38,0.15)", border: "1px solid rgba(220,38,38,0.4)", padding: 10, borderRadius: 6, fontSize: 13, marginBottom: 14 }}>{error}</div>
            )}
            <div style={{ display: "flex", gap: 10, justifyContent: "flex-end" }}>
              <button type="button" className="btn-g" onClick={onClose} disabled={busy}>Cancel</button>
              <button type="submit" className="btn" disabled={busy}>{busy ? "Creating…" : "Create user"}</button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}

function AdminResetPwModal({ user, onClose }: { user: AdminUser; onClose: () => void }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [tempPassword, setTempPassword] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  async function reset() {
    setError(null);
    setBusy(true);
    try {
      const res = await fetch(`/api/admin/users/${encodeURIComponent(user.id)}/change-password`, {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      });
      const data = await res.json().catch(() => ({} as { error?: string; tempPassword?: string }));
      if (!res.ok) {
        setError(data.error ?? `Couldn't reset password (HTTP ${res.status}).`);
        setBusy(false);
        return;
      }
      setTempPassword(data.tempPassword ?? null);
      setBusy(false);
    } catch {
      setError("Network error — please try again.");
      setBusy(false);
    }
  }

  async function copyPw() {
    if (!tempPassword) return;
    try { await navigator.clipboard.writeText(tempPassword); setCopied(true); setTimeout(() => setCopied(false), 1600); } catch { /* ignore */ }
  }

  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.75)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 9999, padding: 24 }}>
      <div style={{ background: "#1a2940", borderRadius: 12, padding: 28, maxWidth: 480, width: "100%", color: "var(--text)", fontFamily: "var(--sans)", border: "1px solid var(--border2)" }}>
        {tempPassword ? (
          <div>
            <div className="lbl" style={{ marginBottom: 11, color: "#34d399" }}>PASSWORD RESET</div>
            <h2 style={{ fontFamily: "var(--serif)", fontSize: 22, fontWeight: 400, marginBottom: 14 }}>New temp password for {user.email}</h2>
            <p style={{ fontSize: 13, color: "var(--text3)", lineHeight: 1.6, marginBottom: 18 }}>
              Their existing sessions have been wiped. Share this once — they'll change it after sign-in.
            </p>
            <div style={{ background: "#0d1b2e", border: "1px solid var(--warm)", borderRadius: 8, padding: 14, fontFamily: "monospace", fontSize: 16, letterSpacing: 1, color: "var(--warm)", marginBottom: 14, wordBreak: "break-all" }}>
              {tempPassword}
            </div>
            <div style={{ display: "flex", gap: 10 }}>
              <button className="btn-g" onClick={copyPw}>{copied ? "Copied ✓" : "Copy password"}</button>
              <button className="btn" onClick={onClose}>Done</button>
            </div>
          </div>
        ) : (
          <div>
            <div className="lbl" style={{ marginBottom: 11 }}>RESET PASSWORD</div>
            <h2 style={{ fontFamily: "var(--serif)", fontSize: 22, fontWeight: 400, marginBottom: 14 }}>Reset password for {user.email}?</h2>
            <p style={{ fontSize: 13, color: "var(--text3)", lineHeight: 1.6, marginBottom: 18 }}>
              A new temp password will be generated and shown once. Their current password and any active sessions will be invalidated.
            </p>
            {error && (
              <div style={{ color: "#fca5a5", background: "rgba(220,38,38,0.15)", border: "1px solid rgba(220,38,38,0.4)", padding: 10, borderRadius: 6, fontSize: 13, marginBottom: 14 }}>{error}</div>
            )}
            <div style={{ display: "flex", gap: 10, justifyContent: "flex-end" }}>
              <button className="btn-g" onClick={onClose} disabled={busy}>Cancel</button>
              <button className="btn" onClick={reset} disabled={busy}>{busy ? "Resetting…" : "Generate new password"}</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// Wrapper enforces "owner-only" at the React layer. If the signed-in user
// isn't an owner (e.g. session expired and was re-bound to a client account,
// or the URL state was tampered), bounce out of the admin pane immediately.
function AdminScreenGuarded({ onExit }: { onExit: () => void }) {
  const { user, isLoading } = useAuth();
  useEffect(() => {
    if (!isLoading && user?.role !== "owner") onExit();
  }, [isLoading, user, onExit]);
  if (isLoading || user?.role !== "owner") {
    return <div style={{ minHeight:"100vh", background:"#0d1b2e", display:"flex", alignItems:"center", justifyContent:"center" }}><style>{CSS}</style><div style={{ fontFamily:"var(--sans)", fontSize:12, color:"#3d3d38", letterSpacing:2 }}>…</div></div>;
  }
  return <AdminScreen onExit={onExit} />;
}

function AdminScreen({ onExit }: { onExit: () => void }) {
  const { user: me, refresh: refreshAuth } = useAuth();
  const [users, setUsers] = useState<AdminUser[] | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);
  const [showNewUser, setShowNewUser] = useState(false);
  const [resetTarget, setResetTarget] = useState<AdminUser | null>(null);
  // Single global lock — prevents overlapping mutations (e.g. rapid
  // multi-row clicks) which would otherwise produce confusing error races.
  const [busy, setBusy] = useState(false);

  // If any admin call comes back as 401/403, the session has expired or the
  // current user is no longer an owner. Re-fetching /api/auth/me clears the
  // local user, which trips the auth guard and bounces back to sign-in.
  const handleAuthFailure = useCallback(async () => {
    await refreshAuth();
    onExit();
  }, [refreshAuth, onExit]);

  const refresh = useCallback(async () => {
    try {
      const res = await fetch("/api/admin/users", { credentials: "include" });
      if (res.status === 401 || res.status === 403) { await handleAuthFailure(); return; }
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = (await res.json()) as { users: AdminUser[] };
      setUsers(data.users);
      setLoadError(null);
    } catch (e: unknown) {
      setLoadError(e instanceof Error ? e.message : "Failed to load users");
    }
  }, [handleAuthFailure]);

  useEffect(() => { refresh(); }, [refresh]);

  async function changeRole(target: AdminUser, nextRole: "owner" | "client") {
    if (busy) return;
    const verb = nextRole === "owner" ? "promote" : "demote";
    if (!window.confirm(`${verb === "promote" ? "Promote" : "Demote"} ${target.email} to ${nextRole}?`)) return;
    setActionError(null);
    setBusy(true);
    try {
      const res = await fetch(`/api/admin/users/${encodeURIComponent(target.id)}/role`, {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ role: nextRole }),
      });
      if (res.status === 401 || res.status === 403) { await handleAuthFailure(); return; }
      const data = await res.json().catch(() => ({} as { error?: string }));
      if (!res.ok) {
        setActionError(data.error ?? `Couldn't ${verb} (HTTP ${res.status}).`);
      } else {
        await refresh();
      }
    } catch {
      setActionError("Network error — please try again.");
    } finally {
      setBusy(false);
    }
  }

  async function deleteUser(target: AdminUser) {
    if (busy) return;
    if (!window.confirm(
      `Delete ${target.email}?\n\n` +
      `This permanently removes their account and ALL of their workshop data ` +
      `(map, intake, phase, etc). This cannot be undone.`
    )) return;
    setActionError(null);
    setBusy(true);
    try {
      const res = await fetch(`/api/admin/users/${encodeURIComponent(target.id)}`, {
        method: "DELETE",
        credentials: "include",
      });
      if (res.status === 401 || res.status === 403) { await handleAuthFailure(); return; }
      const data = await res.json().catch(() => ({} as { error?: string }));
      if (!res.ok) {
        setActionError(data.error ?? `Couldn't delete (HTTP ${res.status}).`);
      } else {
        await refresh();
      }
    } catch {
      setActionError("Network error — please try again.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div style={{ minHeight: "100vh", background: "var(--bg)", color: "var(--text)", fontFamily: "var(--sans)" }}>
      <style>{CSS}</style>

      {/* Header */}
      <div style={{ borderBottom: "1px solid var(--border2)", padding: "22px 32px", display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 16 }}>
        <div>
          <div className="lbl" style={{ marginBottom: 6 }}>TRUE OWNERSHIP · ADMIN</div>
          <h1 style={{ fontFamily: "var(--serif)", fontSize: 32, fontWeight: 400, margin: 0, letterSpacing: "-0.5px" }}>All users</h1>
        </div>
        <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
          <button className="btn-g" onClick={onExit}>← Back to app</button>
          <button className="btn" onClick={() => setShowNewUser(true)}>+ New user</button>
        </div>
      </div>

      {/* Body */}
      <div style={{ padding: "28px 32px", maxWidth: 1100, margin: "0 auto" }}>
        {actionError && (
          <div style={{ color: "#fca5a5", background: "rgba(220,38,38,0.15)", border: "1px solid rgba(220,38,38,0.4)", padding: 12, borderRadius: 6, fontSize: 13, marginBottom: 18 }}>
            {actionError}{" "}
            <button onClick={() => setActionError(null)} style={{ background: "transparent", border: "none", color: "#fca5a5", cursor: "pointer", marginLeft: 8, textDecoration: "underline", fontSize: 12 }}>dismiss</button>
          </div>
        )}
        {loadError && (
          <div style={{ color: "#fca5a5", background: "rgba(220,38,38,0.15)", border: "1px solid rgba(220,38,38,0.4)", padding: 12, borderRadius: 6, fontSize: 13, marginBottom: 18 }}>
            Couldn't load users: {loadError}{" "}
            <button onClick={refresh} style={{ background: "transparent", border: "none", color: "#fca5a5", cursor: "pointer", marginLeft: 8, textDecoration: "underline", fontSize: 12 }}>retry</button>
          </div>
        )}

        {users === null && !loadError && (
          <div style={{ color: "var(--text3)", fontSize: 13, padding: 24, textAlign: "center" }}>Loading users…</div>
        )}

        {users && users.length === 0 && (
          <div style={{ color: "var(--text3)", fontSize: 13, padding: 24, textAlign: "center" }}>No users yet.</div>
        )}

        {users && users.length > 0 && (
          <div style={{ background: "var(--bg2)", border: "1px solid var(--border2)", borderRadius: 10, overflow: "hidden" }}>
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
              <thead>
                <tr style={{ background: "var(--bg3)", color: "var(--text3)", textAlign: "left" }}>
                  <th style={{ padding: "12px 14px", fontSize: 11, fontWeight: 600, letterSpacing: 1, textTransform: "uppercase" }}>Name</th>
                  <th style={{ padding: "12px 14px", fontSize: 11, fontWeight: 600, letterSpacing: 1, textTransform: "uppercase" }}>Email</th>
                  <th style={{ padding: "12px 14px", fontSize: 11, fontWeight: 600, letterSpacing: 1, textTransform: "uppercase" }}>Role</th>
                  <th style={{ padding: "12px 14px", fontSize: 11, fontWeight: 600, letterSpacing: 1, textTransform: "uppercase" }}>Created</th>
                  <th style={{ padding: "12px 14px", fontSize: 11, fontWeight: 600, letterSpacing: 1, textTransform: "uppercase", textAlign: "right" }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {users.map((u) => {
                  const isMe = me?.id === u.id;
                  const ownerCount = users.filter((x) => x.role === "owner").length;
                  const isLastOwner = u.role === "owner" && ownerCount <= 1;
                  return (
                    <tr key={u.id} style={{ borderTop: "1px solid var(--border2)" }}>
                      <td style={{ padding: "13px 14px", color: "var(--text)" }}>
                        {fmtName(u)}{isMe && <span style={{ marginLeft: 8, fontSize: 10, color: "var(--text3)", letterSpacing: 1 }}>(you)</span>}
                      </td>
                      <td style={{ padding: "13px 14px", color: "var(--text2)", fontFamily: "monospace", fontSize: 12 }}>{u.email}</td>
                      <td style={{ padding: "13px 14px" }}>
                        <span style={{
                          background: u.role === "owner" ? "rgba(201,168,76,0.18)" : "rgba(122,118,110,0.18)",
                          color: u.role === "owner" ? "var(--warm)" : "var(--text3)",
                          borderRadius: 3, padding: "2px 8px", fontSize: 10, letterSpacing: 1, textTransform: "uppercase",
                        }}>{u.role}</span>
                      </td>
                      <td style={{ padding: "13px 14px", color: "var(--text3)", fontSize: 12 }}>{fmtDate(u.createdAt)}</td>
                      <td style={{ padding: "13px 14px", textAlign: "right", whiteSpace: "nowrap" }}>
                        <button
                          onClick={() => setResetTarget(u)}
                          disabled={busy}
                          style={{ background: "transparent", border: "1px solid var(--border2)", color: "var(--text2)", borderRadius: 4, padding: "5px 10px", fontSize: 11, cursor: busy ? "not-allowed" : "pointer", marginLeft: 6, fontFamily: "var(--sans)" }}
                          title="Generate a new temp password"
                        >Reset password</button>
                        {u.role === "client" ? (
                          <button
                            onClick={() => changeRole(u, "owner")}
                            disabled={busy}
                            style={{ background: "transparent", border: "1px solid rgba(201,168,76,0.45)", color: "var(--warm)", borderRadius: 4, padding: "5px 10px", fontSize: 11, cursor: busy ? "not-allowed" : "pointer", marginLeft: 6, fontFamily: "var(--sans)" }}
                          >Promote</button>
                        ) : (
                          <button
                            onClick={() => changeRole(u, "client")}
                            disabled={busy || isMe || isLastOwner}
                            style={{ background: "transparent", border: "1px solid var(--border2)", color: (isMe || isLastOwner) ? "var(--text4)" : "var(--text2)", borderRadius: 4, padding: "5px 10px", fontSize: 11, cursor: (busy || isMe || isLastOwner) ? "not-allowed" : "pointer", marginLeft: 6, fontFamily: "var(--sans)" }}
                            title={isMe ? "Can't demote yourself" : isLastOwner ? "Can't demote the last owner" : "Demote to client"}
                          >Demote</button>
                        )}
                        <button
                          onClick={() => deleteUser(u)}
                          disabled={busy || isMe || isLastOwner}
                          style={{ background: "transparent", border: "1px solid rgba(220,38,38,0.4)", color: (isMe || isLastOwner) ? "var(--text4)" : "#fca5a5", borderRadius: 4, padding: "5px 10px", fontSize: 11, cursor: (busy || isMe || isLastOwner) ? "not-allowed" : "pointer", marginLeft: 6, fontFamily: "var(--sans)" }}
                          title={isMe ? "Can't delete yourself" : isLastOwner ? "Can't delete the last owner" : "Delete user and all their data"}
                        >Delete</button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        <div style={{ marginTop: 24, fontSize: 11, color: "var(--text4)", lineHeight: 1.6 }}>
          {users && <>Total: {users.length} user{users.length === 1 ? "" : "s"} · {users.filter((u) => u.role === "owner").length} owner{users.filter((u) => u.role === "owner").length === 1 ? "" : "s"}</>}
        </div>
      </div>

      {showNewUser && (
        <NewUserModal onClose={() => setShowNewUser(false)} onCreated={() => { refresh(); }} />
      )}
      {resetTarget && (
        <AdminResetPwModal user={resetTarget} onClose={() => { setResetTarget(null); refresh(); }} />
      )}
    </div>
  );
}

function AccountMenu({ mode = "fixed" }: { mode?: "fixed" | "inline" } = {}) {
  const { logout, user } = useAuth();
  const [open, setOpen] = useState(false);
  const [showPwd, setShowPwd] = useState(false);
  const ref = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (!open) return;
    function onDocClick(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener("mousedown", onDocClick);
    return () => document.removeEventListener("mousedown", onDocClick);
  }, [open]);

  const label = (user?.email || "Account").split("@")[0];

  const wrapperStyle: React.CSSProperties = mode === "inline"
    ? { position:"relative", fontFamily:"var(--sans)" }
    : { position:"fixed", top:14, right:14, zIndex:1000, fontFamily:"var(--sans)" };

  return (
    <>
      <div ref={ref} style={wrapperStyle}>
        <button
          onClick={() => setOpen((v) => !v)}
          style={{ fontSize:11, color:"#7a766e", background:"transparent", border:"1px solid rgba(122,118,110,0.3)", borderRadius:4, padding:"6px 12px", cursor:"pointer", letterSpacing:1, display:"inline-flex", alignItems:"center", gap:6 }}
        >
          <span>{label}</span>
          {user?.role === "owner" && (
            <span style={{ background:"rgba(201,168,76,0.18)", color:"var(--warm)", borderRadius:3, padding:"1px 6px", fontSize:9, letterSpacing:1 }}>OWNER</span>
          )}
          <span style={{ opacity:0.6 }}>{open ? "▴" : "▾"}</span>
        </button>
        {open && (
          <div style={{ position:"absolute", top:34, right:0, minWidth:180, background:"#1a2940", border:"1px solid rgba(122,118,110,0.3)", borderRadius:6, padding:6, boxShadow:"0 8px 24px rgba(0,0,0,0.5)" }}>
            <button
              onClick={() => { setShowPwd(true); setOpen(false); }}
              style={{ display:"block", width:"100%", textAlign:"left", padding:"8px 10px", background:"transparent", border:"none", color:"var(--text2)", fontSize:12, fontFamily:"var(--sans)", cursor:"pointer", borderRadius:4 }}
              onMouseOver={(e) => (e.currentTarget.style.background = "rgba(255,255,255,0.04)")}
              onMouseOut={(e) => (e.currentTarget.style.background = "transparent")}
            >
              Change password
            </button>
            <button
              onClick={() => { setOpen(false); logout(); }}
              style={{ display:"block", width:"100%", textAlign:"left", padding:"8px 10px", background:"transparent", border:"none", color:"var(--text2)", fontSize:12, fontFamily:"var(--sans)", cursor:"pointer", borderRadius:4 }}
              onMouseOver={(e) => (e.currentTarget.style.background = "rgba(255,255,255,0.04)")}
              onMouseOut={(e) => (e.currentTarget.style.background = "transparent")}
            >
              Sign out
            </button>
          </div>
        )}
      </div>
      {showPwd && <ChangePasswordModal onClose={() => setShowPwd(false)} />}
    </>
  );
}

function ServerDataLoader({ children }: { children: React.ReactNode }) {
  const [ready, setReady] = useState(false);
  const [showMigration, setShowMigration] = useState(false);

  useEffect(() => {
    fetch("/api/userdata", { credentials: "include" })
      .then((r) => r.ok ? r.json() : {})
      .then((cache: Record<string, any>) => {
        // Strip verification-test-* placeholder values from cache (they'll be overwritten on next save)
        for (const k of Object.keys(cache)) {
          const v = cache[k];
          if (typeof v === "string" && v.startsWith("verification-test-")) {
            delete cache[k];
          }
        }
        _setServerAuthState(true, cache);
        const migrated = localStorage.getItem("to_migrated") === "true";
        const candidates = detectMigrationCandidates(cache);
        if (!migrated && candidates.length > 0) setShowMigration(true);
        setReady(true);
      })
      .catch(() => {
        _setServerAuthState(true, {});
        setReady(true);
      });
  }, []);

  if (!ready) return <LoadingScreen />;
  return (
    <div style={{ display:"flex", flexDirection:"column", minHeight:"100vh" }}>
      <div style={{ flex:1, minHeight:0, display:"flex", flexDirection:"column" }}>
        {children}
      </div>
      <Footer />
      {showMigration && <MigrationModal onClose={() => setShowMigration(false)} />}
    </div>
  );
}

export default function App() {
  const { isLoading, isAuthenticated } = useAuth();
  if (isLoading) return <LoadingScreen />;
  if (!isAuthenticated) return <SignInScreen />;
  return <ServerDataLoader><AuthedApp /></ServerDataLoader>;
}
