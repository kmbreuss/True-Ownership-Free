# True Ownership · Entry Hall + Framework + Spine — Replit Build Brief (v2)

**Date:** May 30, 2026
**Owner:** Katherine Breuss (AG45)
**App:** True Ownership · React (`artifacts/true-ownership/src/App.tsx`)
**Dev URL:** `https://b8363272-ff9f-404c-9632-5af68f34d738-00-2kazqkj8gufie.spock.replit.dev/?newA1=1&newM4=1`
**Status:** All design decisions LOCKED. Ready for Replit Agent.
**Scope:** Three new surfaces — persistent left-rail Spine, Entry Hall (home), The Framework (5A explainer)

---

## TL;DR

Build three new surfaces in `artifacts/true-ownership/src/App.tsx`:

1. **Persistent Left Rail Spine** — visible on Entry Hall, The Framework, A1 hub, mirror hubs (M1/M2/M3/M4), and future A2-A5 hubs. **Hidden** inside any room overlay and inside Map of Me.
2. **Entry Hall** (new home page) — welcomes the user, sets the principle, leads into the framework.
3. **The Framework** (new 5A architecture page) — explains the 5A Framework™ across both Phase 1 (Own It) and Phase 2 (Build It), with the navy↔gold phase duality from the Owners Blueprint landing page.

**No new feature flag.** This is additive to the existing `?newA1=1` gate. Same testing URL as today: `?newA1=1&newM4=1`.

**Visual source of truth:** `Home_and_Framework_Mockup_v4.html` (attached). Build to match exactly.

---

## Architecture context (from prior debriefs)

### The two apps — don't confuse them

| App | Where | File | Stack |
|---|---|---|---|
| **True Ownership** ← this build | `b8363272-...spock.replit.dev` | `artifacts/true-ownership/src/App.tsx` | React, single-file |
| **Boardroom OS** (separate) | `ag45-owners-circle.com` | `public/workspace.html` | Vanilla JS |

This build is for the **True Ownership** React app. Session debriefs mentioning `_switchTo`, `foundation→a1` rename, `renderVision`, `workspace.html` are about Boardroom OS — not relevant here.

### Current state of True Ownership

A1 ALL IN is fully shipped:
- M1 Purpose, M2 Vision, M3 Identity, M4 Values — all complete with seals
- A1 hub renders 4 mirror cards with COMPLETE / UP NEXT chips, progress bars, Review/Begin CTAs
- Published May 27, 2026 via Strategy 1: legacy at `/`, new A1 behind `?newA1=1`

### What "Entry Hall" already is

"Entry Hall" is a placeholder span in the existing breadcrumb hierarchy. It appears on every A1-level page today as:

```
Entry Hall › A1 · All In It › The Commitment
Entry Hall › A1 · All In It › Values
Entry Hall › A1 · All In It › Identity
```

(See Mirror 4 build plan v2 for the canonical breadcrumb pattern.)

**Today the placeholder doesn't link anywhere — clicking it does nothing.** This ship makes Entry Hall a real surface, and wires every breadcrumb's first segment to navigate there.

### Why the Spine

The spine is the IP made visible. Five disciplines, five vertebrae, one continuous thread down the left side of the app. Lesson from Ship 5.5: "Spine ≠ navigation. The spine is the IP. Treat it as brand presence on every hub page, not as a sidebar nav." Direction was locked in the prior session; this ship is the build.

---

## Reference materials

| File | Role |
|---|---|
| `Home_and_Framework_Mockup_v4.html` | **Visual source of truth.** Build to match exactly. |
| `Mirror4_BuildPlan_v2.md` | Reference for state-slice + module + localStorage pattern (mirror4Constants.ts pattern) |
| `Ship_5_5_Complete_Handover_v2.md` | Source for displayName helper, gating pattern, design tokens |
| `AG45_App_Standards.md` (v1.1) | Personalization rules, variable-count grammar, voice register |
| `owners-blueprint-landing.html` | Source of canonical 5A Framework copy (Shifts, deliverables, phase intros) |

---

## Feature flag — no new flag

The build ships under the existing `?newA1=1` gate. No `?newHome=1` or any new query param.

- `/` (no flags) → legacy app, unchanged
- `/?newA1=1` → new A1 experience, **now includes Entry Hall + Framework + Spine**
- `/?newA1=1&newM4=1` → same plus dev-unlock for M4 (existing testing pattern)

---

## File touched

**Only one file:** `artifacts/true-ownership/src/App.tsx` (the single-file React app).

Do not touch:
- The legacy app at `/` (without flags) — stays as-is
- Any of the mirror room flows (M1/M2/M3/M4)
- `mirror4Constants.ts` or other mirror constants modules

---

## Design tokens (LOCKED — both themes)

The app supports light and dark theme. Both are valid; the live A1 we walked was rendering in **light** mode by default. Bind every new class to theme-aware tokens — never hardcode.

```css
:root {
  /* LIGHT THEME (default) */
  --na1-bg: #f5f3ef;
  --na1-bg-soft: #ece8df;
  --na1-bg-card: #fffdf8;
  --na1-text: #2a2620;
  --na1-text-sec: #534b3f;
  --na1-text-mute: #8a8170;
  --gold: #b8892f;
  --gold-soft: rgba(184, 137, 47, 0.16);
  --gold-line: rgba(184, 137, 47, 0.38);
  --gold-warm: rgba(184, 137, 47, 0.08);
  --gold-glow: rgba(184, 137, 47, 0.25);

  /* Framework page phase duality */
  --navy: #1A2A44;
  --navy-deep: #0F1B2E;
  --footer-ink: #0d1b2e;

  --rail-w: 220px;
}

[data-theme="dark"] {
  /* DARK THEME */
  --na1-bg: #0a1428;
  --na1-bg-soft: #0f1a30;
  --na1-bg-card: #0f1a30;
  --na1-text: #e8e2d3;
  --na1-text-sec: rgba(232,226,211,0.55);
  --na1-text-mute: rgba(232,226,211,0.35);
  --gold: #c9a24b;          /* dark theme gold */
  --gold-soft: rgba(201,162,75,0.16);
  --gold-line: rgba(201,162,75,0.35);
  --gold-warm: rgba(201,162,75,0.08);
  --gold-glow: rgba(201,162,75,0.25);
}
```

**Critical theme lesson from Ship 5.6k Part C:** if you introduce a new class for header text and bind it to a hardcoded color, text disappears in one of the themes. Always bind text colors to `var(--na1-*)` tokens.

**Fonts (locked for the new A1 experience):**
- Body: `"DM Sans", system-ui, sans-serif`
- Hero / headings: `Georgia, "Times New Roman", serif` — **weight 600** for the chunky display-serif feel
- Italic warmth ("Welcome, Katherine."): Georgia italic, weight 400

❌ Do not use Cormorant Garamond, Inter, Source Serif 4, or Geist anywhere in the new surfaces. The DM Sans + Georgia pairing is what the live A1 hub uses; match it.

---

## State additions

Follow the per-mirror state-slice pattern from M3/M4. Add a dedicated `home` slice:

```typescript
// state.home shape
{
  visited: boolean;   // has the user ever seen Entry Hall?
}
```

Persist via the same pattern used by mirror state — dedicated localStorage key (`to_home_state_v1`), `loadHomeState()` / `saveHomeState()` helpers, ref-guarded `useEffect` for Strict Mode safety. If a separate module is overkill for one boolean, inline it on `state.home` and persist via the same store the other slices use — Agent's call.

No other new state. Spine status is computed at render time from existing mirror state. The Framework page is purely presentational — no state.

---

## Routing additions

The True Ownership app uses string view names persisted to `to_app_route_v1`. Add two routes:

| Route | Surface |
|---|---|
| `"entry-hall"` | Entry Hall (Home) |
| `"framework"` | The Framework |

### Refresh-resume

`to_app_route_v1` is read on app boot and writes on every view change. Add both new routes to the persistence whitelist.

### Default landing logic

```typescript
// On app boot (when newA1 flag is on):
if (lastRoute && isValidRoute(lastRoute)) {
  return lastRoute;  // resume where they left off
}
if (!state.home.visited) {
  return "entry-hall";  // first-time → Entry Hall
}
return "a1";  // returning user with no last route → A1 hub
```

### Route transitions to wire

| From → To | Trigger |
|---|---|
| Entry Hall → Framework | "See the framework →" CTA on Entry Hall |
| Entry Hall → A1 | "Skip to A1 · All In It →" link on Entry Hall (also sets `state.home.visited = true`) |
| Framework → A1 | "Begin A1 · All In It →" CTA on Framework (also sets `state.home.visited = true`) |
| Framework → Entry Hall | "← Back to Entry Hall" quiet link on Framework |
| Any view → Entry Hall | Click on `Entry Hall` segment in any breadcrumb |

The existing breadcrumbs throughout the app (M1/M2/M3/M4 hubs and rooms) already render "Entry Hall" as a span. **Wire that span to be a clickable link** that routes to `entry-hall`.

---

## Surface 1 — Persistent Left Rail Spine

### Position
Fixed left rail, 220px wide, full viewport height (top to bottom). When visible, the centered content area shifts right by 220px.

### Visibility rules (LOCKED)

| Surface | Spine? |
|---|---|
| Entry Hall | ✅ |
| The Framework | ✅ |
| A1 hub | ✅ |
| Mirror hubs (M1 Purpose hub, M2 Vision hub, M3 Identity hub, M4 Values hub) | ✅ |
| A2/A3/A4/A5 hubs (when built — not in this ship) | ✅ |
| Inside ANY room overlay (M1/M2/M3/M4 rooms, all sub-rooms, modals over them) | ❌ Hidden |
| Map of Me overlay | ❌ Hidden |
| Onboarding flow (name capture, if reached) | ❌ Hidden |
| Mobile under 768px viewport | ❌ Hidden (desktop-first ship) |

"Hidden" means `display: none` on the spine element (not blur — keep it simple). Content area `margin-left` flips back to `0` when spine is hidden.

### Structure (top to bottom)

```
True Ownership™                ← Georgia, 14px, --na1-text
{displayName}                  ← DM Sans, 10px, uppercase, --na1-text-mute, letter-spacing 0.16em

[continuous gold thread — vertical, behind all bones]

[bone]  ← 22px circle, gold-filled or outline
  01    ← Georgia italic 10px gold
  All In ← Georgia 600, 13.5px
  YOU ARE HERE  ← DM Sans 700, 9px, letter-spacing 0.18em, gold — only on active

[bone] · 02 · Align
[bone] · 03 · Advocate
[bone] · 04 · Act
[bone] · 05 · Accountable
```

### Bone states

| State | Bone treatment |
|---|---|
| Active ("YOU ARE HERE") | 22px circle, filled `var(--gold)`, `box-shadow: 0 0 0 5px var(--gold-soft), 0 0 16px var(--gold-glow)`. Italic gold "01" + Georgia 600 label in `var(--na1-text)` + "YOU ARE HERE" status text |
| Claimed | 22px circle, filled `var(--gold)`, no glow. Label in `var(--na1-text)`. No status text. |
| Ahead | 22px circle, `background: var(--na1-bg)`, `border: 1.5px solid var(--na1-text-mute)`, no fill. Italic gold "0N" + Georgia 600 label in `var(--na1-text-mute)`. No status text. |

### Connecting thread

1px vertical line behind all bones. Linear gradient:
- Above + through the active vertebra: `var(--gold-line)` (the climbed path)
- Below the active vertebra: `var(--gold-warm)` (the climb ahead — faded)

### Spine status computation

```typescript
function getSpineStatus() {
  // M1 + M2 + M3 + M4 all complete → A1 claimed
  const a1Complete = state.mirror1?.complete && state.mirror2?.complete &&
                     state.mirror3?.complete && state.mirror4?.complete;
  const a1InProgress = !a1Complete && (
    state.mirror1?.unlocked || state.mirror2?.unlocked ||
    state.mirror3?.unlocked || state.mirror4?.unlocked
  );

  return {
    a1: a1Complete ? "claimed" : (a1InProgress ? "here" : "here"),
    a2: "ahead", a3: "ahead", a4: "ahead", a5: "ahead",
  };
}
```

For now A1 is always either "here" or "claimed". When A2 is built later, this function extends.

### Personalization in spine sub-line

The sub-line under "True Ownership™" reads the display name. Use `resolveDisplayName(state.user)`.

If empty → render nothing under the brand (no orphan sub-line). If present → render the name in uppercase letter-spaced.

---

## Surface 2 — Entry Hall

### Breadcrumb

Single segment, current view:
```
Entry Hall    ← DM Sans 13px, color --na1-text-mute
```

### Content (exact copy, in order)

```
Eyebrow:     TRUE OWNERSHIP · WELCOME

Mirror quote (italic Georgia 22px, gold left-bar 2px):
  "Our life is a mirror of how we think and feel about ourselves."

Hero (Georgia 600, 48px, color --na1-text, letter-spacing -0.4px):
  Everything starts with you.

Hero-italic (Georgia italic 16px, color --na1-text-sec):
  Welcome, {displayName}.    ← empty-name fallback: "Welcome."  (no comma)

Lead (DM Sans 17px, color --na1-text-sec, max-width 620px):
  Before you can build a life that is truly yours, you need to know who is
  building it. Not the role. Not the title. *You.*
  (the "You." is italic Georgia in --na1-text via <em>)

Principle card (--na1-bg-card, --gold-line border, 12px radius, 32px padding):
  Eyebrow:    BEFORE WE START — ONE PRINCIPLE
  Principle (Georgia italic 19px, --na1-text):
    "You are the authority on your own life. This system is a mirror — it
    reflects your own thinking back more clearly. It doesn't give you answers.
    You already have them."
  Meta (DM Sans 15px, --na1-text-sec):
    The voices here — Katherine, the coach, the challenger — are a board of
    advisors. They help you think. But your voice leads. That's why here,
    **you write first**. The board responds after.

AI note (Georgia italic 16px, --na1-text-sec, gold-line left border 2px, 24px left pad):
  We live in a world that trains us to look outside ourselves first — and AI
  is only going to deepen that pull. Before you look out, build the inner
  trust. Know who you are. Then look outward from a foundation that's actually
  yours.

Video card (--na1-bg-card, --gold-line border, 12px radius):
  [▶ play button — 48px gold circle, white triangle]   00 (italic gold)
                                                       Welcome to True Ownership (Georgia 600 17px)
                                                       Katherine · 4 min (DM Sans 12px --na1-text-mute)
  (placeholder card — video content TBD)

CTAs (row):
  [See the framework →]     ← gold-filled pill, white text, DM Sans 600 14px (primary)
  Skip to A1 · All In It →  ← quiet text link, --na1-text-mute (secondary)
```

### Personalization rules

Use `resolveDisplayName(state.user)` (from `/src/lib/displayName.ts`, same helper M1/M3/M4 use).

| State | Renders |
|---|---|
| Name present (e.g. "Katherine") | `Welcome, Katherine.` |
| Name empty/null | `Welcome.` (no comma artifact) |

This is the same pattern Ship 5.5e-A1 used for the existing A1 hub greeting — replicate it exactly.

### CTAs

- **See the framework →** → routes to `framework`
- **Skip to A1 · All In It →** → sets `state.home.visited = true`, saves, routes to `a1`

---

## Surface 3 — The Framework

### Breadcrumb

```
Entry Hall  ›  The Framework
```

Click on `Entry Hall` → routes to `entry-hall`. Separator `›` in `var(--gold-line)`. Current segment in `var(--na1-text-sec)`.

### Content (in order)

```
Eyebrow:    THE 5A FRAMEWORK™

Hero (Georgia 600, 52px, --na1-text):
  90 days. Two phases.
  *One complete owner.*
  (the second line is italic Georgia, color --gold, weight 500 via <em>)

Sub (DM Sans 17px, --na1-text-sec, max-width 620px):
  The 5A Framework applied first to **you** — then to **your business**.
  Five disciplines. The same shifts, run twice — once on the owner, once
  on what they build.
```

### Phase tabs (2-column grid, locked design)

```
┌─────────────────────────────────────┬─────────────────────────────────────┐
│  Phase 1 · Days 1–45                │  Phase 2 · Days 46–90               │
│  Own It — The Personal Side          │  Build It — The Business Side       │
└─────────────────────────────────────┴─────────────────────────────────────┘
```

| Tab state | Background | Eyebrow color | Title color |
|---|---|---|---|
| Phase 1 active | `var(--navy)` | `var(--gold)` | `#fff` |
| Phase 2 active | `var(--gold)` | `rgba(255,255,255,0.75)` | `#fff` |
| Inactive | `var(--na1-bg-soft)` | `var(--na1-text-mute)` | `var(--na1-text-mute)` |

Default selection: **Phase 1** on first paint.

### Phase body layout

```
┌──────────────────────────────────────────┬───────────┐
│  Phase intro (tag + headline)            │ Day N     │  ← day badge (vertical text)
│                                          │           │
│  A1 [32px num]  Name                     │   ●       │  ← spine bar (color matches active phase)
│                 Shift                    │           │
│                 Description              │   ●       │
│                 → Deliverable             │           │
│  ─────────────────────────────            │   ●       │
│  A2 [num]  ...                           │           │
│  A3 [num]  ...                           │   ●       │
│  A4 [num]  ...                           │           │
│  A5 [num]  ...                           │   ●       │
│                                          │           │
│                                          │ Day N+45  │
└──────────────────────────────────────────┴───────────┘
```

Right column: 64px wide. Day badges top + bottom in vertical text (`writing-mode: vertical-rl; transform: rotate(180deg)`). Alternating dots and lines between.

### Phase 1 content (Own It)

**Intro:**
- Tag (navy in P1): `Days 1–45 · Who you are as an owner`
- Headline (Georgia 28px 600): `You go in first.` then on next line: `*The business follows.*` (italic Georgia, navy)

**A-cards:**

| A | Name | Shift | Description | Deliverable |
|---|---|---|---|---|
| A1 | All In It | Commitment Shift | Map your purpose, identity, values, and direction. Who are you as an owner — and what are you building toward? | → Map of Me™ |
| A2 | Align With It | Integrity Shift | Self-alignment and time audit. Where is your energy actually going — and does it match what matters most? | → Time Audit |
| A3 | Advocate For It | Expansion Shift | Build your personal board of advisors. Who is in your corner — and who needs to be? | → Board of Advisors |
| A4 | Act On It | Momentum Shift | Establish your personal weekly operating rhythm. How do you show up consistently at your best? | → Actionable Roadmap |
| A5 | Accountable To It | Mastery Shift | Personal scorecards. How do you keep the commitments you made to yourself? | → Stay Committed |

### Phase 2 content (Build It)

**Intro:**
- Tag (gold in P2): `Days 46–90 · Now the business`
- Headline: `The owner is ready.` then on next line: `*Time to build.*` (italic Georgia, gold)

**A-cards:**

| A | Name | Shift | Description | Deliverable |
|---|---|---|---|---|
| A1 | All In It | Commitment Shift | Define the soul, vision, and direction of your business. Why does it exist? Who does it serve? What does it become? | → Business Soul Foundation |
| A2 | Align With It | Integrity Shift | SWOTT analysis and 3-year strategic priorities. Where does the business stand — and where is it going? | → Align Priorities |
| A3 | Advocate For It | Expansion Shift | Build your business board of advisors. What expert voices does your business need in the room to make better decisions? | → Decisions and Your Board |
| A4 | Act On It | Momentum Shift | Set this year's focus areas and quarterly plan. What gets done — and in what order? | → Quarterly Plan |
| A5 | Accountable To It | Mastery Shift | Operating rhythm and critical numbers. How does your business know it's winning week to week? | → Operating Dashboard |

### Card typography

| Element | Style | Color |
|---|---|---|
| A-num | Georgia 600, 32px | navy in P1, gold in P2 |
| A-name | Georgia 600, 19px | `var(--na1-text)` |
| A-shift | DM Sans 700, 11px, letter-spacing 0.16em, uppercase | navy in P1, gold in P2 |
| A-desc | DM Sans 14.5px | `var(--na1-text-sec)` |
| A-deliverable | Georgia italic 13px 600, pill bg | navy on `rgba(26,42,68,0.06)` in P1; gold on `var(--gold-warm)` in P2 |

### Day badges

- P1: "Day 1" (top) · "Day 45" (bottom). Navy bg, gold text.
- P2: "Day 46" (top) · "Day 90" (bottom). Gold bg, navy text.
- Style: vertical text, DM Sans 9px 700, letter-spacing 0.18em, 5px×9px padding.

### CTAs

- **Begin A1 · All In It →** → sets `state.home.visited = true`, routes to `a1`
- **← Back to Entry Hall** (quiet link) → routes to `entry-hall`

### Phase toggle behavior

Click Phase 1 tab → `panel-p1` shown, `panel-p2` hidden, body data-phase = "p1", day badges = "Day 1"/"Day 45", A-numbers + Shift labels go navy.

Click Phase 2 tab → swap. Day badges = "Day 46"/"Day 90", A-numbers + Shift labels go gold.

---

## What does NOT change

Per Katherine: "We don't go into A1 here — we will have a blurb at the top of A1 that describes it."

The A1 hub already has its own intro: eyebrow + "Commit to the life you want to live." + "Welcome back, {name}." + "Four mirrors. Name your purpose, dream your 10 years, claim your gifts, declare what you stand for." That existing copy stays. **No A1 hub changes in this ship** other than the spine appearing on its left side.

---

## Patterns to carry forward

1. **State-aware unlock gates** — compound checks (`prior.complete && prior.unlocked`)
2. **Theme-aware classes** — bind every text-color class to `var(--na1-*)` tokens, never hardcoded values
3. **Refresh-resume** — `to_app_route_v1` writes on every view change, reads on app boot. Both new routes added to whitelist.
4. **Personalization helper** — `resolveDisplayName(state.user)` from `/src/lib/displayName.ts`. Always check name presence before composing. Empty-name fallback mandatory. (Lesson from Ship 5.5d/5.5e: "Welcome back, ." and "My's Map of Me" are real artifacts that ship when no one checks the empty path.)
5. **Curly quotes for content, not straight** — use `"…"` (chars 8220/8221), em dashes `—` (char 8212), never `--`
6. **Variable-count grammar** — not relevant here (no count language on Entry Hall)
7. **Ship-and-walk** — Agent ships to dev → Claude walks via Chrome MCP browser tools → verifies spec match → flags deviations BEFORE approving

---

## DO NOT list

- ❌ Don't introduce a new feature flag — build under existing `?newA1=1`
- ❌ Don't change the legacy app at `/` (without flags)
- ❌ Don't modify M1, M2, M3, or M4 room flows
- ❌ Don't add a blurb to the A1 hub — existing copy stays
- ❌ Don't build A2, A3, A4, or A5 hub content — spine just shows them as ahead vertebrae
- ❌ Don't add a mobile spine collapse — desktop-first ship; spine hidden under 768px
- ❌ Don't use Cormorant Garamond, Inter, Source Serif 4, or Geist anywhere — only DM Sans + Georgia
- ❌ Don't hardcode color values — bind to `var(--na1-*)` and `var(--gold)` tokens so both themes work
- ❌ Don't build Map of Me here — exists separately
- ❌ Don't render the spine inside room overlays — hidden in rooms

---

## Definition of done

A ship is complete when ALL of these are true under URL `?newA1=1&newM4=1`:

### Spine
- [ ] Renders on Entry Hall, Framework, A1 hub, all four mirror hubs (M1/M2/M3/M4)
- [ ] Hidden inside any room overlay
- [ ] Hidden inside Map of Me overlay
- [ ] A1 vertebra shows "YOU ARE HERE" with gold glow + soft ring shadow (when at least one mirror touched but A1 not fully complete)
- [ ] A1 vertebra shows as "claimed" (gold filled, no status text) when all 4 mirrors complete
- [ ] A2–A5 vertebrae render as muted outline bones, no status text
- [ ] Italic gold "01" / "02" / "03" / "04" / "05" above each bone
- [ ] Verb names: All In · Align · Advocate · Act · Accountable
- [ ] Connecting gold thread visible between vertebrae, fading below the active vertebra
- [ ] Both light and dark themes render correctly (theme toggle works)
- [ ] Hidden under 768px viewport

### Entry Hall
- [ ] Loads at default URL for any first-time user under `?newA1=1`
- [ ] Breadcrumb: `Entry Hall` (current segment only)
- [ ] Mirror quote renders with 2px gold left-bar
- [ ] Hero "Everything starts with you." in Georgia 600, 48px
- [ ] `Welcome, {name}.` renders correctly (and `Welcome.` when name empty — no comma artifact)
- [ ] Lead paragraph with italic "*You.*" via `<em>`
- [ ] Principle card renders complete: eyebrow + italic principle + meta with bold "you write first"
- [ ] AI note in italic Georgia with gold-line left border
- [ ] Video card renders with gold play button + "00" + title + meta
- [ ] Two CTAs: gold "See the framework →" + quiet "Skip to A1 · All In It →"
- [ ] Empty-name path tested explicitly
- [ ] Refresh on Entry Hall returns to Entry Hall (route persists)

### The Framework
- [ ] Breadcrumb: `Entry Hall › The Framework` with sep gold-line
- [ ] Clicking `Entry Hall` segment routes to Entry Hall
- [ ] Hero "90 days. Two phases." + italic gold "*One complete owner.*"
- [ ] Phase tabs default to Phase 1 active (navy fill)
- [ ] Click Phase 2 → tab fills gold, panel swaps, day badges go "Day 46" / "Day 90", A-numbers + Shift labels turn gold, spine bar gold
- [ ] Click Phase 1 → reverts navy + "Day 1" / "Day 45" + navy A-numbers/Shifts
- [ ] All 5 A-cards per phase render with name, Shift, description, deliverable callout
- [ ] Spine bar renders with day badges + 5 dots + 6 lines
- [ ] CTAs: gold "Begin A1 · All In It →" + quiet "← Back to Entry Hall"
- [ ] Refresh on Framework returns to Framework

### Routing
- [ ] First visit (no `state.home.visited`) → Entry Hall
- [ ] After clicking any "Skip to A1" or "Begin A1" → `state.home.visited = true` persists, routes to A1 hub
- [ ] Returning user on app boot → resume at last `to_app_route_v1` value
- [ ] All route transitions write `to_app_route_v1`
- [ ] `Entry Hall` segment in every existing breadcrumb (M1/M2/M3/M4 hubs and rooms) now navigates to `entry-hall` when clicked
- [ ] Both new routes added to `ALLOWED_VIEWS` whitelist for persistence

### Visual parity
- [ ] Entry Hall and Framework match `Home_and_Framework_Mockup_v4.html` pixel-near-perfect
- [ ] Spine matches the mockup's left rail (22px bones, italic "0N" labels, gold thread, glow on active)

---

## Verification checklist (after dev ship)

Claude will walk the dev URL via Chrome MCP tools. Specific checks:

1. **Visual parity with mockup** — open `Home_and_Framework_Mockup_v4.html` and dev URL side by side
2. **Spine across views** — Entry Hall → Framework → A1 hub → click into M1 → spine appears on first three, disappears in M1 room → close M1 → spine back
3. **Phase toggle** — clean navy ↔ gold transitions, day badges flip, A-number colors flip, spine bar color flips
4. **Empty-name fallback** — set `state.user.displayName = null`, reload, confirm `Welcome.` (no comma)
5. **Refresh-resume on every surface** — Entry Hall stays on Entry Hall, Framework stays on Framework, etc.
6. **Breadcrumb wiring** — open any M3 room, click "Entry Hall" in breadcrumb → lands on Entry Hall
7. **CTA routing** — every button/link goes where it should
8. **Light + dark mode** — both readable, theme toggle works, no broken contrast on new classes
9. **Legacy app intact** — visit `/` without flags; old methodology page serves unchanged

---

## Anthropic API key reminder (still outstanding from prior ships)

M1–M3 personalization and M4 scenario generation use client-side `fetch` to Anthropic. In dev the key is wired. **In production, confirm env vars or API proxy is set up.** Not blocking for this ship; please verify by completing a Mirror 4 pressure-test on the published URL after this ship lands and confirming scenarios populate.

---

## Hard-won lessons (apply here)

1. **Design before code.** This brief + the v4 mockup is the lock. No improvising.
2. **Read live source before editing.** Never describe edits from assumption.
3. **Theme awareness on every new class.** Bind to tokens, not hardcoded values. (Ship 5.6k lesson.)
4. **Refresh-resume on every new route.** Whitelist both new routes.
5. **Empty-name fallbacks tested explicitly.** Personalization needs static maps, not inference. (Ship 5.5e lesson.)
6. **Stop discipline.** Plan → approve → code → demo → walk → sign-off. Don't queue multiple gates in one Agent message.
7. **IDE webview ≠ running app.** Always verify on `spock.replit.dev`, not the Replit IDE preview tab.
8. **Replit pastes truncate silently above ~7-8KB.** Keep paste chunks under 3KB.
9. **Trust Agent's pattern repetition.** Once a helper is verifiably wired in one surface, reusing it in N more can be code-trusted without re-walking each time.

---

## Quick reference

| What | Where |
|---|---|
| Dev URL | `https://b8363272-ff9f-404c-9632-5af68f34d738-00-2kazqkj8gufie.spock.replit.dev/?newA1=1&newM4=1` |
| Repo | `github.com/kmbreuss/true-ownership` |
| Replit project | `https://replit.com/@katherine62/True-Ownership` |
| Main file | `artifacts/true-ownership/src/App.tsx` |
| Visual source of truth | `Home_and_Framework_Mockup_v4.html` |
| Display name helper | `/src/lib/displayName.ts` → `resolveDisplayName(state.user)` |
| Persisted-route key | `to_app_route_v1` |
| Home state key | `to_home_state_v1` (new — Agent's call whether to use this or inline on existing store) |

---

## Final note

Build to the mockup. The mockup carries the voice, the spacing, the color logic, the typography weights, the interaction states. When in doubt, open `Home_and_Framework_Mockup_v4.html` and copy the pattern exactly.

The brief explains the *why* and the *system context*; the mockup shows the *what*.

When the ship is ready on dev, post the URL and Claude will walk it via Chrome MCP browser tools same as every M4 ship. Specific checks above; flag any deviation before approving.

— end of brief —
